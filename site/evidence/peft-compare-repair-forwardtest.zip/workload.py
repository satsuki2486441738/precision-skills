"""Collect native full-rank weighted-adapter inference and its composition formula.

Run with the existing CPU interpreter; --output-root owns fresh compare-collect-UTC
artifacts. --fixture initializes retained inputs once if absent; later runs read
exactly those bytes. PYTHONPATH may select an isolated PEFT source. Source identities
and original input/state hashes are recorded in each capture. No model downloads.
"""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import inspect
import json
from pathlib import Path
import sys

import numpy as np
import peft
import torch
from peft import LoraConfig, get_peft_model

ROOT = Path(__file__).resolve().parent
TOOLS = Path(__file__).resolve().parents[4] / 'skills/precision-compare/scripts'
sys.path.insert(0, str(TOOLS))
from compare_tensors import compare
from validate_artifacts import validate


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    return path


def collect(output_root, fixture):
    torch.set_num_threads(1)
    settings = json.loads((ROOT/'settings.json').read_text())
    torch.manual_seed(settings['seed'])
    dtype = getattr(torch, settings['dtype'])
    ni, no, rank = settings['input_size'], settings['output_size'], settings['rank']
    if not fixture.exists():
        tensors = {'base_weight': torch.randn(no, ni, dtype=dtype)/4,
                   'base_bias': torch.randn(no, dtype=dtype)/4,
                   'input': torch.randn(settings['batch_size'], ni, dtype=dtype)}
        for i in range(2):
            tensors[f'A{i}'] = torch.randn(rank, ni, dtype=dtype)/4
            tensors[f'B{i}'] = torch.randn(no, rank, dtype=dtype)/4
        with fixture.open('xb') as stream:
            np.savez(stream, **{k:v.numpy() for k,v in tensors.items()})
    with np.load(fixture, allow_pickle=False) as arrays:
        values = {k:torch.from_numpy(arrays[k].copy()) for k in arrays.files}
    base = torch.nn.Sequential(torch.nn.Linear(ni, no, bias=True)).to(dtype).eval()
    with torch.no_grad():
        base[0].weight.copy_(values['base_weight'])
        base[0].bias.copy_(values['base_bias'])
    configs = [LoraConfig(target_modules=['0'], r=rank, lora_alpha=alpha, lora_dropout=0)
               for alpha in settings['alphas']]
    model = get_peft_model(copy.deepcopy(base), configs[0])
    model.add_adapter('second', configs[1]); model.to(dtype).eval()
    layer = model.base_model.model[0]
    with torch.no_grad():
        for i, name in enumerate(('default','second')):
            layer.lora_A[name].weight.copy_(values[f'A{i}'])
            layer.lora_B[name].weight.copy_(values[f'B{i}'])
    initial_hash = hashlib.sha256(b''.join(k.encode()+v.detach().numpy().tobytes()
                                for k,v in sorted(model.state_dict().items()))).hexdigest()
    x = values['input'].clone().requires_grad_()
    composed_weight = values['base_weight'] + sum(weight*(alpha/rank)*(values[f'B{i}']@values[f'A{i}'])
                                for i,(weight,alpha) in enumerate(zip(settings['weights'],settings['alphas'])))
    expected = torch.nn.functional.linear(x, composed_weight, values['base_bias'])
    expected_grad = torch.autograd.grad(expected.square().sum(), x)[0]
    basis = torch.cat([torch.zeros(1,ni,dtype=dtype),torch.eye(ni,dtype=dtype)])
    expected_basis = torch.nn.functional.linear(basis,composed_weight,values['base_bias'])
    model.add_weighted_adapter(['default','second'], settings['weights'], 'combined',
                               combination_type='svd',svd_rank=min(ni,no))
    model.set_adapter('combined')
    actual = model(x)
    actual_grad = torch.autograd.grad(actual.square().sum(), x)[0]
    actual_basis = model(basis)
    observations = {'forward':(expected,actual),'input_gradient':(expected_grad,actual_grad),
                    'basis_forward':(expected_basis,actual_basis)}
    root = output_root / datetime.now(timezone.utc).strftime('compare-collect-%Y%m%dT%H%M%SZ')
    root.mkdir(parents=True,exist_ok=False)
    common = {'model':{'kind':'weighted LoRA linear','settings':settings,'initial_state_sha256':initial_hash},
              'inputs':{'fixture_sha256':sha(fixture)},
              'numerics':{'device':'cpu','dtype':str(dtype),'evaluation':True},
              'scope':'full-rank weighted-adapter composition'}
    side_conditions = {'composed':{'implementation':'independent explicit composition'},
                       'combined':{'implementation':'native PEFT weighted adapter'}}
    entries = [dict(name=name,shape=list(a.shape),present=True,
                    coordinates={'boundary':name,'invocation':0,'stage':'inference'})
               for name,(a,b) in observations.items()]
    contract = write(root/'contract.json',dict(schema_version=2,kind='tensors',thresholds=None,
                common=common,side_conditions=side_conditions,expected_ranks={side:[0] for side in side_conditions},
                stage='observations',tensors=entries))
    source_class = type(model.base_model)
    source_file = Path(inspect.getfile(source_class)).resolve()
    identities = {'peft_version':peft.__version__,'peft_module':peft.__file__,
                  'executed_class':source_class.__qualname__,'class_source':str(source_file),
                  'class_source_sha256':sha(source_file),'collector_sha256':sha(__file__),
                  'settings_sha256':sha(ROOT/'settings.json'),'fixture_sha256':sha(fixture),
                  'initial_state_sha256':initial_hash}
    write(root/'source.json',identities)
    manifests = []
    for side_index,side in enumerate(side_conditions):
        folder=root/side;folder.mkdir()
        tensors=[]
        for entry in entries:
            name=entry['name'];value=observations[name][side_index].detach().numpy()
            np.save(folder/(name+'.npy'),value,allow_pickle=False)
            tensors.append({**entry,'shards':[{'offset':0,'value':{'path':name+'.npy'}}]})
        write(folder/'environment.json',dict(rank=0,versions={'torch':torch.__version__,'numpy':np.__version__,'peft':peft.__version__},actual={**common,**side_conditions[side]},native_source=identities))
        write(folder/'status.json',dict(rank=0,status='completed'))
        manifest=write(folder/'manifest.json',dict(schema_version=2,kind='tensors',common=common,
                       side=side,expected_ranks=[0],ranks=[dict(rank=0,environment='environment.json',status='status.json')],stage='observations',tensors=tensors))
        checked=validate(contract,manifest);write(folder/'validation.json',checked)
        if checked['status']!='validated':raise ValueError(checked)
        manifests.append(manifest)
    report=compare(contract,*manifests);write(root/'report.json',report)
    if report['status']!='no_thresholds':raise ValueError(report)
    print(json.dumps({'capture':str(root),'report':str(root/'report.json'),'metrics':{k:v['max_abs']['value'] for k,v in report['per_tensor'].items()}},allow_nan=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root',type=Path,required=True)
    parser.add_argument('--fixture',type=Path,default=ROOT/'fixture.npz')
    args=parser.parse_args();collect(args.output_root.resolve(),args.fixture.resolve())
