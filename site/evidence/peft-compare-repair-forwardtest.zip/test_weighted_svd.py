"""Native CPU regression: weighted SVD must preserve the sum of adapter contributions."""
import copy
import unittest
from pathlib import Path
import numpy as np
import torch
from peft import LoraConfig, get_peft_model

ROOT = Path(__file__).resolve().parent

def build(ni=3, no=5, dtype=torch.float64, alphas=(6, 1), retained=False):
    torch.manual_seed(731)
    base = torch.nn.Sequential(torch.nn.Linear(ni, no)).to(dtype).eval()
    model = get_peft_model(copy.deepcopy(base), LoraConfig(target_modules=['0'], r=2, lora_alpha=alphas[0]))
    model.add_adapter('second', LoraConfig(target_modules=['0'], r=2, lora_alpha=alphas[1]))
    model.to(dtype).eval()
    layer = model.base_model.model[0]
    with torch.no_grad():
        for name in ('default', 'second'):
            layer.lora_A[name].weight.copy_(torch.randn(2, ni, dtype=dtype)/4)
            layer.lora_B[name].weight.copy_(torch.randn(no, 2, dtype=dtype)/4)
        x = torch.randn(7, ni, dtype=dtype)
        if retained:
            with np.load(ROOT/'fixture.npz', allow_pickle=False) as f:
                layer.base_layer.weight.copy_(torch.from_numpy(f['base_weight']))
                layer.base_layer.bias.copy_(torch.from_numpy(f['base_bias']))
                for i, name in enumerate(('default', 'second')):
                    layer.lora_A[name].weight.copy_(torch.from_numpy(f[f'A{i}']))
                    layer.lora_B[name].weight.copy_(torch.from_numpy(f[f'B{i}']))
                x = torch.from_numpy(f['input'].copy())
    return model, layer, x

class WeightedSVD(unittest.TestCase):
    def check_composition(self, ni=3, no=5, dtype=torch.float64, alphas=(6,1), weights=(.75,-.5), retained=False, method='svd'):
        model, layer, x = build(ni, no, dtype, alphas, retained)
        before = {k:v.detach().clone() for k,v in model.state_dict().items()}
        # Independent oracle from individual native forwards, before creating combined.
        with torch.no_grad():
            base_y = layer.base_layer(x)
            reference = base_y.clone()
            for name, w in zip(('default','second'), weights):
                model.set_adapter(name)
                reference += w * (model(x) - base_y)
        expected_delta = sum(w * (alpha/2) * (layer.lora_B[n].weight @ layer.lora_A[n].weight)
                             for n, w, alpha in zip(('default','second'), weights, alphas))
        model.add_weighted_adapter(['default','second'], list(weights), 'combined', combination_type=method, svd_rank=min(ni,no))
        model.set_adapter('combined')
        atol = rtol = 2e-12 if dtype == torch.float64 else 3e-6
        torch.testing.assert_close(model(x), reference, atol=atol, rtol=rtol)
        torch.testing.assert_close(layer.get_delta_weight('combined'), expected_delta, atol=atol, rtol=rtol)
        for k, value in before.items():
            torch.testing.assert_close(model.state_dict()[k], value, atol=0, rtol=0)
        x = x.clone().requires_grad_()
        actual = model(x)
        expected = torch.nn.functional.linear(x, layer.base_layer.weight + expected_delta.detach(), layer.base_layer.bias)
        ag = torch.autograd.grad(actual.square().sum(), x)[0]
        eg = torch.autograd.grad(expected.square().sum(), x)[0]
        torch.testing.assert_close(ag, eg, atol=atol*10, rtol=rtol*10)

    def test_retained_state(self):
        self.check_composition(retained=True)

    def test_neighboring_scales_shapes_dtypes_weights(self):
        for ni,no in ((3,5),(5,3),(4,4)):
            for dtype in (torch.float32, torch.float64):
                for alphas,weights in (((6,1),(.75,-.5)), ((2,2),(1.,.5)), ((0,1),(0.,-.5)), ((1,4),(-.25,.5))):
                    with self.subTest(shape=(no,ni), dtype=dtype, alphas=alphas, weights=weights):
                        self.check_composition(ni,no,dtype,alphas,weights)

    def test_cat_control(self):
        self.check_composition(retained=True, method='cat')

if __name__ == '__main__':
    torch.set_num_threads(1)
    unittest.main(verbosity=2)
