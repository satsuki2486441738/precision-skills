import pathlib,sys,json,argparse,hashlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from compare_distributions import compare as distribution_compare
from compare_target_scores import compare as target_compare
from validate_artifacts import validate
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=False)
 c=ROOT/'corrected';dr=distribution_compare(c/'distribution-contract.json',c/'reference-distribution-manifest.json',c/'native-distribution-manifest.json');tr=target_compare(c/'target-contract.json',c/'reference-target-manifest.json',c/'native-target-manifest.json')
 assert dr['status']==tr['status']=='no_thresholds'
 assert tr['metrics']==json.loads((c/'target-comparison.json').read_text())['metrics']
 assert dr['aggregate']==json.loads((c/'distribution-comparison.json').read_text())['aggregate']
 v={s:validate(c/'distribution-contract.json',c/(s+'-distribution-manifest.json')) for s in ['reference','native']};assert all(x['status']=='validated' for x in v.values())
 result={'status':'completed','thresholds':None,'target':tr,'distribution':dr,'validation':v,'scope':'captured-array offline replay; no native execution rerun'}
 (out/'results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({'status':'completed','paired_targets':tr['coverage']['paired'],'distribution_rows':dr['position_count'],'validated_sides':len(v),'metrics_equal_exported':True}))
if __name__=='__main__':main()
