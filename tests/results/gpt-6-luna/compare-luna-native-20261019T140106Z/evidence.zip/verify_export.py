import pathlib,sys,json,hashlib,zipfile
p=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'evidence.zip')
with zipfile.ZipFile(p) as z:
 e=json.loads(z.read('EXPORT.json'))
 for f in e['files']:
  b=z.read(f['archive_path']);assert len(b)==f['exported_bytes'];assert hashlib.sha256(b).hexdigest()==f['exported_sha256']
 for f in e['derived_files']:
  b=z.read(f['archive_path']);assert hashlib.sha256(b).hexdigest()==f['exported_sha256']
 print(json.dumps({'status':'validated','raw_export_pairs':len(e['files']),'derived_files':len(e['derived_files'])}))
