# Clean-context native inference usability run

Run: `compare-luna-native-20261019T140106Z` (UTC timestamp in run directory). This private run used only the pinned worktree instructions and precision-skill inference/comparison interfaces, plus the permitted Desktop model snapshot and WSL `<HOME>` runtime resources.

## Case and capture

- Model: `HuggingFaceTB/SmolLM2-135M-Instruct`, revision `12fd25f77366fa6b3b4b768ec3050bf629380bac`; vocab 49,152. HF snapshot files are pinned by `source_manifest.json`.
- Native side: llama.cpp C API, source archive revision `757cad021b357f417065ddbc41a6e8f87c1f8136`, runtime `0.7.0-dev`, CPU only, GGUF all-F32, 2 threads. GGUF SHA-256 is recorded in `native-environment.json`.
- Reference side: Transformers 4.57.1 / Torch 2.8.0+cu128 / NumPy 2.2.6 under the existing `<ENV_ROOT>/precision-vllm011` Python 3.11.17 environment; model explicitly ran on CPU, eager attention, float32, 2 Torch threads. The environment reports CUDA availability, but no CUDA device was selected or used.
- Cache-off full-forward case: prompt IDs `[504, 3575, 282, 4649, 314]`; fixed targets `[7042, 314, 260]` (`ĠParis`, `Ġis`, `Ġthe`); predictions at positions 4, 5, 6. Both sides replayed the same prefix history independently for each row.
- Three full-vocabulary FP32 logprob rows per side are saved as `reference-position-*.npy` and `native-position-*.npy`. Runtime probe completed at `runtime-probe-completed.json`; reference and native execution details are in their respective environment/status JSON files.

## Results

- Artifact validation: both sides validated, 3 distributions each, 147,456 score values per side; successful reports are `reference-validation-tol5e-5.json` and `native-validation-tol5e-5.json`.
- Distribution comparison: `distribution-comparison-tol5e-5.json`; top-1 agreement 3/3, top-100 overlap 1.0, mean tail-merged JS `9.09e-8` nats, mean probability RMSE `1.94e-5`, max probability error `1.3007e-4` at position 6/token 260. Mean own top-100 mass is about 0.95545 on both sides.
- Target-score comparison: `target-comparison-schema1.json`; 3/3 targets paired, NLL 3.1629922 (Transformers) vs 3.1628731 (llama.cpp), absolute NLL difference 0.00011915 nat/token, MAE `4.3044e-4`, P99 `6.1449e-4`, max `6.1750e-4` at target position 6/token 314.

## Preserved friction and failed attempts

- The first distribution validation/comparison used normalization tolerance `1e-5` and failed; observed full-vocabulary log masses were 1.0000115–1.0000204 from FP32 rounding. The first reports are preserved as `reference-validation.json`, `native-validation.json`, and `distribution-comparison.json`. Setting the explicit tolerance to `5e-5` resolved validation without renormalizing scores.
- The first target-score comparison used manifest schema version 2 and failed with `invalid target-score manifest`; that report is preserved as `target-comparison.json`. The target-score schema is version 1; corrected manifests and successful output are present.
- The first runtime probe spec used dotted attribute names instead of the documented `module:attribute` form and failed; the failed probe report is `runtime-probe.json`, and the successful corrected report is `runtime-probe-completed.json`.
- Native build setup needed both llama.cpp and ggml include directories; its current successful compile command and source are reviewable in `native_collector.cpp`, `native-build.log`. Initial compiler messages were captured during the session: missing `ggml.h` without `ggml/include`, then an obsolete `use_mmap` model-parameter member; removing that field and adding the header directory fixed compilation.
- The expected Desktop `resources/inference` directory was absent. Reusable resources were found in the permitted WSL tree at `<RESOURCE_ROOT>/inference`; no packages or models were installed or downloaded.
