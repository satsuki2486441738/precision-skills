import json, math, sys
from pathlib import Path
import numpy as np
import torch
repo=Path('<WORKTREE>')
run=repo/'runs'/'compare-luna-native-20261019T140106Z'
sys.path.insert(0,str(repo/'skills'/'precision-skill'/'scripts'))
from inference_capture import FixedHistory, export_records
inputs=json.loads((run/'inputs.json').read_text())
vocab=inputs['tokenizer_vocab_size']
raw=np.fromfile(run/'native-logits.f32',dtype='<f4')
if raw.size != 3*vocab: raise RuntimeError(f'wrong logits size {raw.size}, expected {3*vocab}')
if not np.isfinite(raw).all(): raise RuntimeError('native logits contain nonfinite values')
rows=raw.reshape(3,vocab)
capture=FixedHistory(inputs['sample'],inputs['prompt_ids'],inputs['continuation_ids'])
records=[]
for step, token in enumerate(inputs['continuation_ids']):
    row=torch.from_numpy(rows[step].copy())
    records.append(capture.capture_and_force(row,run/f'native-position-{len(inputs["prompt_ids"])-1+step}'))
exported=export_records(records,run)
side='llamaCppCPUFP32'
common=dict(model=dict(id='HuggingFaceTB/SmolLM2-135M-Instruct',revision=inputs['model_revision'],tokenizer_revision=inputs['model_revision'],vocab_size=vocab),
 inputs=dict(sample=inputs['sample'],prompt_ids=inputs['prompt_ids'],continuation_ids=inputs['continuation_ids'],prediction_positions=[len(inputs['prompt_ids'])-1+i for i in range(3)],targets=[dict(position=len(inputs['prompt_ids'])+i,token=t) for i,t in enumerate(inputs['continuation_ids'])],add_special_tokens=False),
 numerics=dict(model_dtype='float32',logprob_dtype='float32',normalization='natural-log-softmax-full-vocabulary'),
 scope=dict(stage='full-forward-cache-off',requested_targets=3,requested_distributions=3))
side_conditions={
 'nativeTFCPUFP32':dict(implementation='Transformers AutoModelForCausalLM',weights_format='safetensors',device='CPU',attention='eager',threads=2),
 side:dict(implementation='llama.cpp C API',weights_format='GGUF F32',device='CPU',attention='native ggml CPU',threads=2)
}
versions=dict(llama_cpp='0.7.0-dev from source archive 757cad021b357f417065ddbc41a6e8f87c1f8136',numpy=np.__version__,torch=torch.__version__)
env_actual={**common,**side_conditions[side]}
(run/'native-environment.json').write_text(json.dumps(dict(rank=0,versions=versions,actual=env_actual,library='<RESOURCE_ROOT>/inference/llama.cpp-757cad021b357f417065ddbc41a6e8f87c1f8136/build/bin/libllama.so.0.7.0',gguf_sha256='9b29071563138f115f72e147dcc8c5afbb6699f67aa099d7f075ec0ba0b295c8c'),indent=2)+'\n')
(run/'native-status.json').write_text(json.dumps(dict(rank=0,status='completed',stage='full-forward-cache-off',rows=3,vocab_size=vocab,native_logits_dtype='float32',history=inputs['prompt_ids']+inputs['continuation_ids']),indent=2)+'\n')
manifest_base=dict(schema_version=2,common=common,side=side,expected_ranks=[0],ranks=[dict(rank=0,environment='native-environment.json',status='native-status.json')])
(run/'native-distribution-manifest.json').write_text(json.dumps(dict(**manifest_base,kind='distributions',positions=exported['positions'],scores=exported['positions'],unavailable_targets=exported['unavailable_targets']),indent=2)+'\n')
(run/'native-target-manifest.json').write_text(json.dumps(dict(**manifest_base,kind='target-scores',scores=exported['scores']),indent=2)+'\n')
# Rebuild reference-side metadata and manifests with truthful cache-off runtime/stage evidence.
refenv=dict(rank=0,versions=dict(python=sys.version.split()[0],torch=torch.__version__,transformers=__import__('transformers').__version__,numpy=np.__version__),actual={**common,**side_conditions['nativeTFCPUFP32']})
(run/'reference-environment.json').write_text(json.dumps(refenv,indent=2)+'\n')
(run/'reference-status.json').write_text(json.dumps(dict(rank=0,status='completed',stage='full-forward-cache-off',rows=3,vocab_size=vocab,native_logits_dtype='float32',history=inputs['prompt_ids']+inputs['continuation_ids']),indent=2)+'\n')
refold=json.loads((run/'reference-manifest.json').read_text())
refbase=dict(schema_version=2,common=common,side='nativeTFCPUFP32',expected_ranks=[0],ranks=[dict(rank=0,environment='reference-environment.json',status='reference-status.json')])
(run/'reference-distribution-manifest.json').write_text(json.dumps(dict(**refbase,kind='distributions',positions=refold['positions'],scores=refold['positions'],unavailable_targets=refold['unavailable_targets']),indent=2)+'\n')
(run/'reference-target-manifest.json').write_text(json.dumps(dict(**refbase,kind='target-scores',scores=refold['scores']),indent=2)+'\n')
refcap=json.loads((run/'reference-capture.json').read_text()); refcap.pop('history_validation',None); refcap['history']=inputs['prompt_ids']+inputs['continuation_ids']; refcap['stage']='full-forward-cache-off'; (run/'reference-capture.json').write_text(json.dumps(refcap,indent=2)+'\n')
positions=[dict(sample=inputs['sample'],position=len(inputs['prompt_ids'])-1+i,history=inputs['prompt_ids']+inputs['continuation_ids'][:i]) for i in range(3)]
dc=dict(schema_version=2,kind='distributions',thresholds=None,common=common,side_conditions=side_conditions,expected_ranks={'nativeTFCPUFP32':[0],side:[0]},vocab_size=vocab,normalization_tolerance=1e-5,renormalization='none',positions=positions)
(run/'distribution-contract.json').write_text(json.dumps(dc,indent=2)+'\n')
targets=[dict(sample=inputs['sample'],position=len(inputs['prompt_ids'])+i,token=t) for i,t in enumerate(inputs['continuation_ids'])]
tc=dict(schema_version=1,kind='target-scores',thresholds=None,common=common,side_conditions=side_conditions,expected_ranks={'nativeTFCPUFP32':[0],side:[0]},targets=targets)
(run/'target-contract.json').write_text(json.dumps(tc,indent=2)+'\n')
print(json.dumps(dict(status='native_capture_complete',vocab=vocab,positions=[r['position'] for r in records],target_scores=[r['logprob'] for r in records],native_logits_shape=list(rows.shape))))
