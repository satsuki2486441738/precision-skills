#include "llama.h"
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

static std::vector<llama_token> read_tokens(std::ifstream &in, const char *label) {
    int n = 0;
    if (!(in >> n) || n <= 0) throw std::runtime_error(std::string("invalid ") + label + " count");
    std::vector<llama_token> v(n);
    for (auto &x : v) if (!(in >> x)) throw std::runtime_error(std::string("missing ") + label + " token");
    return v;
}
int main(int argc, char **argv) {
  try {
    if (argc != 4) throw std::runtime_error("usage: collector MODEL INPUT OUTPUT");
    std::ifstream in(argv[2]); if (!in) throw std::runtime_error("cannot open inputs");
    auto prompt = read_tokens(in, "prompt"), continuation = read_tokens(in, "continuation");
    llama_backend_init();
    auto mp = llama_model_default_params(); mp.n_gpu_layers = 0;
    auto *model = llama_model_load_from_file(argv[1], mp);
    if (!model) throw std::runtime_error("llama_model_load_from_file failed");
    auto cp = llama_context_default_params(); cp.n_ctx = 256; cp.n_batch = 256; cp.n_ubatch = 256;
    cp.n_threads = 2; cp.n_threads_batch = 2; cp.offload_kqv = false;
    auto *ctx = llama_init_from_model(model, cp);
    if (!ctx) throw std::runtime_error("llama_init_from_model failed");
    auto vocab = llama_model_get_vocab(model);
    int n_vocab = llama_vocab_n_tokens(vocab);
    std::cerr << "llama_version=" << llama_version() << " vocab=" << n_vocab << " stage=full-forward-cache-off threads=2 gpu_layers=0\n";
    std::ofstream out(argv[3], std::ios::binary | std::ios::trunc);
    if (!out) throw std::runtime_error("cannot create output");
    for (size_t step = 0; step < continuation.size(); ++step) {
      std::vector<llama_token> ids = prompt;
      ids.insert(ids.end(), continuation.begin(), continuation.begin() + step);
      llama_memory_clear(llama_get_memory(ctx), true);
      auto batch = llama_batch_init((int)ids.size(), 0, 1);
      batch.n_tokens = (int)ids.size();
      for (int i=0; i<batch.n_tokens; ++i) {
        batch.token[i] = ids[i]; batch.pos[i] = i; batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0; batch.logits[i] = (i == batch.n_tokens-1) ? 1 : 0;
      }
      int rc = llama_decode(ctx, batch);
      llama_batch_free(batch);
      if (rc != 0) throw std::runtime_error("llama_decode failed rc=" + std::to_string(rc));
      float *row = llama_get_logits_ith(ctx, -1);
      if (!row) throw std::runtime_error("missing final logits row");
      out.write(reinterpret_cast<const char *>(row), sizeof(float) * n_vocab);
      if (!out) throw std::runtime_error("failed writing logits");
    }
    out.close();
    std::cout << "status=completed rows=" << continuation.size() << " vocab=" << n_vocab << " output=" << argv[3] << "\n";
    llama_free(ctx); llama_model_free(model); llama_backend_free();
    return 0;
  } catch (const std::exception &e) { std::cerr << "status=failed error=" << e.what() << "\n"; return 1; }
}

