import json, os, sys, time
from pathlib import Path
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

repo = Path('<WORKTREE>')
run = repo / 'runs' / 'compare-luna-native-20261019T140106Z'
model_path = Path('<MODEL_SNAPSHOT>')
log = run / 'reference.log'
started = time.time()
torch.set_num_threads(2)
torch.set_num_interop_threads(2)
tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True, use_fast=True)
prompt_text = 'The capital of France is'
full_text = prompt_text + ' Paris is the'
prompt = tokenizer.encode(prompt_text, add_special_tokens=False)
full = tokenizer.encode(full_text, add_special_tokens=False)
if full[:len(prompt)] != prompt or len(full) < len(prompt) + 3:
    raise RuntimeError(f'prompt tokenization is not a prefix: prompt={prompt}, full={full}')
continuation = full[len(prompt):len(prompt)+3]
inputs = dict(sample='smollm2-native-cpu-001', prompt_text=prompt_text, full_text=full_text,
              prompt_ids=prompt, continuation_ids=continuation,
              target_pieces=[tokenizer.convert_ids_to_tokens(int(t)) for t in continuation],
              tokenizer_class=type(tokenizer).__name__, tokenizer_name_or_path=str(model_path),
              model_revision='12fd25f77366fa6b3b4b768ec3050bf629380bac',
              tokenizer_vocab_size=len(tokenizer), bos_token_id=tokenizer.bos_token_id,
              eos_token_id=tokenizer.eos_token_id, add_special_tokens=False)
(run/'inputs.json').write_text(json.dumps(inputs, indent=2)+'\n')
(run/'native-input.txt').write_text(str(len(prompt))+'\n'+' '.join(map(str,prompt))+'\n'+str(len(continuation))+'\n'+' '.join(map(str,continuation))+'\n')
print(json.dumps(dict(event='inputs', **inputs), ensure_ascii=False), flush=True)
model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True, torch_dtype=torch.float32, attn_implementation='eager').to('cpu').eval()
with torch.inference_mode():
    all_ids = prompt + continuation
    logits = model(input_ids=torch.tensor([all_ids], dtype=torch.long, device='cpu')).logits[0]
    # Model output row t-1 predicts token at t; each selected row is saved by the skill capture API.
    sys.path.insert(0, str(repo/'skills'/'precision-skill'/'scripts'))
    from inference_capture import FixedHistory, validate_history, export_records
    capture = FixedHistory(inputs['sample'], prompt, continuation)
    records=[]
    for step, token in enumerate(continuation):
        records.append(capture.capture_and_force(logits[len(prompt)-1+step], run/f'reference-position-{len(prompt)-1+step}'))
    events=[dict(stage='prefill' if i==0 else 'decode', input_ids=prompt if i==0 else [continuation[i-1]],
                 positions=list(range(len(prompt))) if i==0 else [len(prompt)+i-1], prefix_length=0 if i==0 else None)
            for i in range(len(continuation))]
    history_check=validate_history(prompt, continuation, events)
    exported=export_records(records, run)
    (run/'reference-manifest.json').write_text(json.dumps(dict(schema_version=1,kind='distributions',side='nativeTFCPUFP32',
      positions=exported['positions'],scores=exported['scores'],unavailable_targets=exported['unavailable_targets']),indent=2)+'\n')
    (run/'reference-capture.json').write_text(json.dumps(dict(status='completed',stage='full-forward-cache-off',
      framework='Transformers AutoModelForCausalLM',torch_version=torch.__version__,transformers_version=__import__('transformers').__version__,
      imported_torch=torch.__file__,imported_transformers=__import__('transformers').__file__,device='cpu',dtype='float32',
      attention='eager',threads=torch.get_num_threads(),continuation_tokens=len(continuation),
      history_validation=history_check,elapsed_seconds=time.time()-started),indent=2)+'\n')
print(json.dumps(dict(event='reference_complete', history_validation=history_check, elapsed_seconds=time.time()-started)),flush=True)

