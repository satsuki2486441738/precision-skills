Native CPU llama.cpp execution and fixed-token preconstraint full-vocabulary scoring are supported by source/logs. Saved comparator metrics reproduce exactly with no_thresholds and both distributions validate at the declared 5e-5 normalization tolerance.

Maximum target-logprob error: 0.0006175041198730469 nats at {'sample': 'smollm2-native-cpu-001', 'position': 6, 'token': 314}. No precision acceptance threshold was specified.

P1 Record actual F16 KV storage and cleared-prefix execution: llama_context_default_params uses F16 K/V; collector does not set type_k/type_v. Native uses a KV buffer within each prefix forward and clears it between three requests. Contract/environment omit KV dtype; full-forward-cache-off must be described as no cross-request cache reuse, not disabled native KV storage.

P2 Reference execution is one teacher-forced full-sequence forward: summary.md claims both sides independently replayed each prefix. Reference instead computes all rows in one causal full-sequence forward; native computes three cleared-cache prefixes. Logical target histories are valid, but forward shapes and execution boundaries differ and must be declared.

P2 Preserved reports do not preserve every superseded input/build command: Failed reports/specs remain, but the original 1e-5 contract and schema-2 target manifests were corrected in place. native-build.log is empty and native_collector.cpp contains no exact compile command, despite summary saying that command is reviewable there. Preserve future corrected metadata in fresh views and avoid claiming complete original input/build provenance.

See review.json for actual GGUF/HF file hashes, cache log lines, replay metrics and scope limits. No original files were modified.
