"""Independently verify the synthetic cold-training run and write English results."""
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
import sys

import numpy as np

RUN = Path(__file__).resolve().parent


def read(name):
    return json.loads((RUN / name).read_text(encoding="utf-8"))


def save(name, value):
    (RUN / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


checks = []


def check(name, condition, observed=None, expected=None):
    checks.append({"name": name, "verified": bool(condition), "observed": observed, "expected": expected})


def verify_metrics(label, actual, expected):
    check(label + ".count", actual["count"] == expected["count"], actual["count"], expected["count"])
    mapping = {"error_norm": "l2_error", "rmse": "rmse", "cosine": "cosine",
               "max_abs": "max_abs_error", "side_a_norm": "norm_a", "side_b_norm": "norm_b"}
    for actual_key, expected_key in mapping.items():
        a, e = actual[actual_key]["value"], expected[expected_key]
        equal = a is None if e is None else a is not None and math.isclose(a, e, rel_tol=1e-13, abs_tol=1e-13)
        check(label + "." + actual_key, equal, a, e)
        if e is None:
            check(label + ".undefined_reason", actual[actual_key].get("reason") == "zero signal norm",
                  actual[actual_key].get("reason"), "zero signal norm")


expected = read("independent_expected.json")
observed = {"gradients": read("comparison-gradients.json"), "updates": read("comparison-updates.json"),
            "input_omission": read("negative-input-omission.json"),
            "mismatched_setting": read("negative-mismatched-setting.json")}
for stage in ["gradients", "updates"]:
    report = observed[stage]
    verify_metrics(stage + ".global", report["global"], expected[stage]["global"])
    for name in ["weight", "zero"] + (["absent"] if stage == "updates" else []):
        verify_metrics(stage + "." + name, report["per_tensor"]["synthetic_model." + name], expected[stage][name])
    check(stage + ".thresholds", report["thresholds"] is None, report["thresholds"], None)
    check(stage + ".diagnostic_status", report["status"] == "no_thresholds", report["status"], "no_thresholds")
    for side in ["side_a", "side_b"]:
        check(stage + "." + side + ".rank_coverage", report["conditions"][side]["actual_ranks"] == [0, 1],
              report["conditions"][side]["actual_ranks"], [0, 1])
check("gradients.absent_presence", observed["gradients"]["per_tensor"]["synthetic_model.absent"] ==
      {"presence": "absent_on_both_sides", "count": 0},
      observed["gradients"]["per_tensor"]["synthetic_model.absent"], {"presence": "absent_on_both_sides", "count": 0})
check("gradients.maximum_coordinate", observed["gradients"]["global"]["max_coordinate"] ==
      {"parameter": "synthetic_model.weight", "index": 3},
      observed["gradients"]["global"]["max_coordinate"], {"parameter": "synthetic_model.weight", "index": 3})
update_coordinate = observed["updates"]["global"]["max_coordinate"]
check("updates.maximum_coordinate", update_coordinate["parameter"] == "synthetic_model.weight" and update_coordinate["index"] in [0, 3],
      update_coordinate, {"parameter": "synthetic_model.weight", "allowed_indices": [0, 3]})
for side in ["side_a", "side_b"]:
    check("updates." + side + ".event", observed["updates"]["events"][side] == {"synthetic_model": "applied"},
          observed["updates"]["events"][side], {"synthetic_model": "applied"})

stored_values = {}
for side, dtype in [("synthetic_fp16", "float16"), ("synthetic_fp32", "float32")]:
    stored_values[side] = {}
    for name in ["weight", "zero", "absent"]:
        stored_values[side][name] = {}
        for field in ["before", "after"]:
            pieces = [np.load(RUN / f"{side}-updates-rank{rank}-{name}-{field}.npy") for rank in [0, 1]]
            check(f"storage.{side}.{name}.{field}.dtype", all(str(a.dtype) == dtype for a in pieces),
                  [str(a.dtype) for a in pieces], [dtype, dtype])
            stored_values[side][name][field] = np.concatenate(pieces).astype(np.float64).tolist()
        stored_values[side][name]["delta"] = [a-b for a,b in zip(stored_values[side][name]["after"], stored_values[side][name]["before"])]
    expected_before = [2048., 1., 2., 3.] if side == "synthetic_fp16" else [2048.25, 1., 2., 3.]
    expected_after = [2048., .5, 1.25, 2.] if side == "synthetic_fp16" else [2048., .5, 1.25, 1.75]
    for field, values in [("before", expected_before), ("after", expected_after)]:
        check(f"storage.{side}.weight.{field}.values", stored_values[side]["weight"][field] == values,
              stored_values[side]["weight"][field], values)
    for name in ["zero", "absent"]:
        check(f"storage.{side}.{name}.unchanged", stored_values[side][name]["delta"] == [0., 0.],
              stored_values[side][name]["delta"], [0., 0.])
    for stage in ["gradients", "updates"]:
        validation = read(f"{side}-{stage}-validation.json")
        check(f"validation.{side}.{stage}", validation["status"] == "validated", validation["status"], "validated")

check("input_omission.status", observed["input_omission"]["status"] == "not_covered",
      observed["input_omission"]["status"], "not_covered")
check("input_omission.reason", observed["input_omission"].get("reason") == "tensor inventory mismatch",
      observed["input_omission"].get("reason"), "tensor inventory mismatch")
check("input_omission.aggregate_unavailable", "global" not in observed["input_omission"],
      "global" in observed["input_omission"], False)
check("mismatched_setting.status", observed["mismatched_setting"]["status"] == "incomparable",
      observed["mismatched_setting"]["status"], "incomparable")
check("mismatched_setting.reason", observed["mismatched_setting"].get("reason") == "actual condition differs: optimizer",
      observed["mismatched_setting"].get("reason"), "actual condition differs: optimizer")
commands = read("commands.json")
check("cli_return_codes", [c["returncode"] for c in commands] == [0]*10+[1,1],
      [c["returncode"] for c in commands], [0]*10+[1,1])

cases = []
for name, stage, manifest_b, output in [
    ("baseline_gradients", "gradients", "synthetic_fp32-gradients-manifest.json", "comparison-gradients.json"),
    ("baseline_updates", "updates", "synthetic_fp32-updates-manifest.json", "comparison-updates.json"),
    ("input_omission", "gradients", "synthetic_fp32-gradients-omitted-zero-manifest.json", "negative-input-omission.json"),
    ("mismatched_setting", "gradients", "synthetic_fp32-gradients-mismatched-manifest.json", "negative-mismatched-setting.json"),
]:
    cases.append({"name": name, "synthetic": True, "contract": str(RUN / f"contract-{stage}.json"),
                  "side_a_manifest": str(RUN / f"synthetic_fp16-{stage}-manifest.json"),
                  "side_b_manifest": str(RUN / manifest_b), "report": str(RUN / output)})

friction = [
    {"id": "missing_inventory_diagnostics", "type": "usability_and_documentation_ambiguity",
     "reproduced": True, "evidence": str(RUN / "negative-input-omission.json"),
     "description": "Removing the whole zero-gradient tensor yields not_covered with reason 'tensor inventory mismatch'; per_tensor is empty. No missing-name or count detail is supplied. The compare_tensors docstring says an invalid tensor leaves valid per-tensor results, but does not delimit inventory-level omissions. The independent expectation of retained weight metrics did not hold for this omission. Coverage rejection itself is correct.",
     "confirmed_tool_bug": False},
    {"id": "condition_diagnostics", "type": "usability", "reproduced": True,
     "evidence": str(RUN / "negative-mismatched-setting.json"),
     "description": "The deliberately mismatched rank-1 accumulation setting is correctly rejected, but the error identifies only optimizer and omits the side, rank, nested setting and expected/actual values.",
     "confirmed_tool_bug": False},
    {"id": "output_schema_discovery", "type": "documentation", "reproduced": True,
     "description": "The input docstrings were sufficient to construct all successful artifacts on the first attempt. Consuming reports required inspecting the first output to discover value/status wrappers, error_norm/max_abs names and the logical maximum-coordinate representation.",
     "confirmed_tool_bug": False},
]
coverage = {
    "gradients": {"expected_logical_parameters": 3, "observed_logical_parameters": 3,
                  "paired_present_parameters": 2, "paired_absent_parameters": 1,
                  "paired_present_elements": 6, "absent_gradient_elements": 2,
                  "expected_ranks_per_side": 2, "completed_ranks_per_side": 2,
                  "present_zero_parameters": 1},
    "updates": {"expected_logical_parameters": 3, "paired_parameters": 3, "paired_elements": 8,
                "unchanged_parameters": 2, "applied_events_per_side": 1,
                "expected_ranks_per_side": 2, "completed_ranks_per_side": 2},
    "input_omission": {"expected_logical_parameters": 3, "observed_side_a_parameters": 3,
                       "observed_side_b_parameters": 2, "missing_parameter": "synthetic_model.zero",
                       "missing_gradient_elements": 2, "paired_metric_elements_reported": None,
                       "tool_status": "not_covered"},
    "mismatched_setting": {"affected_side": "synthetic_fp32", "affected_rank": 1,
                           "field": "optimizer.accumulation_steps", "expected": 1, "actual": 2,
                           "tool_status": "incomparable"},
}
results = {
    "schema_version": 1, "synthetic": True, "artifact_label": "ALL ARTIFACTS ARE SYNTHETIC",
    "task": "cold-context precision-skill synthetic two-side CPU training artifacts",
    "run_path": str(RUN), "completed_utc": datetime.now(timezone.utc).isoformat(),
    "constraints": {"no_real_model": True, "no_accelerator": True, "logical_ranks_only": True,
                    "no_remote_services": True, "no_repository_or_skill_edits": True,
                    "no_tests_or_history_read": True, "thresholds": None},
    "method": {"gradient_source": "prescribed synthetic FP32 arrays",
               "parameter_update": "FP32 SGD expression assigned into native NumPy FP16/FP32 storage; actual stored before/after arrays captured",
               "sharding": "two logical rank inventories; flattened weight offsets 0 and 2, two-element parameters offsets 0 and 1",
               "independent_verification": "hand-derived literal vectors and Python scalar math; no comparator arithmetic imported",
               "verification_tolerance": "1e-13 checks arithmetic agreement only; it is not an acceptance threshold for precision"},
    "read_scope": ["AGENTS.md", "skills/precision-skill/SKILL.md", "references/sft.md", "references/comparison.md",
                   "module docstrings: tensor_artifacts.py, compare_tensors.py, artifact_io.py, conditions.py, validate_artifacts.py",
                   "CLI --help: tensor_artifacts.py, compare_tensors.py, validate_artifacts.py",
                   "AST function/class names and line numbers only, with no function implementations read"],
    "cases": cases, "effective_settings": read("effective_settings.json"), "coverage": coverage,
    "independent_expected": expected, "observed": observed, "stored_values": stored_values,
    "arithmetic_and_behavior_verification": {"checks": checks, "all_listed_checks_verified": all(c["verified"] for c in checks),
        "documented_behavior_expectation_not_met": "The expected unaffected tensor metrics were not retained for a whole-tensor inventory omission; recorded as ambiguity, not a confirmed tool bug."},
    "commands_file": str(RUN / "commands.json"), "commands": commands,
    "verification_command": [sys.executable, "-B", str(Path(__file__).resolve())],
    "friction": friction, "confirmed_tool_bugs": [],
    "reusable_tool_candidates": [{"operation": "structured coverage and condition findings",
        "input": "contract inventory plus side manifests and per-rank actual settings",
        "output": "missing tensor names/elements and mismatched side/rank/nested-field/expected/actual detail",
        "basis": "Observed diagnostics are correct but too coarse for direct triage; existing arithmetic/export tools already covered all requested operations."}],
    "limitations": ["Synthetic artifact integration only; no framework autograd, real model, native distributed synchronization or hardware numerics were tested.",
                    "FP16 versus FP32 means native NumPy array storage, not a real training-framework execution.",
                    "No precision pass/fail is inferred: all contracts and metric reports use thresholds=null."]
}
save("results.json", results)
report = f"""SYNTHETIC COLD-CONTEXT TRAINING ARTIFACT RUN

Run: {RUN}
Every input, capture, array, manifest and result in this directory is synthetic. This is a CPU-only artifact-interface exercise. It uses no real model, training framework, accelerator or distributed process group.

Outcome
The first attempted integration succeeded. Four exports and four one-side validations returned exit 0. Both normal comparisons returned exit 0 and status no_thresholds. The two deliberate negative cases returned exit 1. No confirmed arithmetic, export or condition-checking tool bug was reproduced. All {len(checks)} listed arithmetic/storage/behavior checks were verified. This statement concerns consistency with independent expected values; it is not a precision acceptance judgment. Thresholds remain null.

Method and effective settings
The synthetic model has three trainable logical parameters: weight [2,2], zero [2], and absent [2], totaling eight elements. Each side has two logical CPU ranks. Each rank owns half of each present tensor. Gradients are prescribed FP32 arrays; this is not autograd evidence. The absent parameter has present=false and no gradient shards, while zero has present=true and explicit zero-valued shards. Both parameters have stored unchanged updates.

The common synthetic SGD settings are learning rate 0.25, no momentum, no weight decay, no clipping, one accumulation step and a fixed microbatch order. Side A uses native NumPy FP16 parameter storage and side B uses native NumPy FP32 parameter storage. Both perform the update expression in FP32 before assignment to parameter storage. The contract declares both numerical and initial-state representation differences in side_conditions. It also records two expected ranks per side, and each rank stores imported Python/NumPy versions and actual settings. See effective_settings.json and the environment JSON files for exact values.

Independent expected values and observed results
Weight gradients are A=[1,2,3,4], B=[1,2,3,5]. The present-zero gradient contributes two additional coordinates. The global gradient L2 error is 1; RMSE is sqrt(1/6)=0.408248290463863; cosine is 0.9939990885479664; maximum absolute error is 1 at synthetic_model.weight flat index 3 (matrix coordinate [1,1]). Coverage is three logical parameters, two present gradient parameters, one absent gradient parameter and six paired gradient elements. Both sides cover ranks 0 and 1.

Stored weight parameters before update are A=[2048,1,2,3] in FP16 and B=[2048.25,1,2,3] in FP32. The stored after values are A=[2048,0.5,1.25,2] and B=[2048,0.5,1.25,1.75]. Actual updates therefore are A=[0,-0.5,-0.75,-1] and B=[-0.25,-0.5,-0.75,-1.25]. This verifies the FP16 rounded-away first-coordinate update using actual stored arrays. With the four unchanged elements included, global update L2 error is sqrt(0.125)=0.3535533905932738; RMSE is 0.125; cosine is 0.9812567051925867; maximum absolute error is 0.25 at weight flat indices 0 and 3. The tool selects index 0. Its global concatenated max_flat_index is 2 because the two absent-parameter update elements sort before weight; its logical max_coordinate correctly names weight index 0. Coverage is all three parameters and eight elements, with one applied optimizer event per side.

The zero-gradient cosine and both unchanged-update tensor cosines are null with reason 'zero signal norm'. All normal reported metrics, norms, counts, maximum logical coordinates, native NPY dtypes and captured stored values agree with the independent calculations. independent_expected.json contains literal-vector calculations produced with standard Python scalar math, without importing the tool's numerical code.

Negative cases
1. Input omission: removed the complete synthetic_model.zero tensor entry from side B's gradient manifest. The comparator returned status not_covered, reason 'tensor inventory mismatch', exit 1, no full aggregate and an empty per_tensor map. The actual inventory is two of three expected parameters; two present-zero elements are missing. Valid weight metrics were not retained. The initial expectation that they would remain available was not met for this whole-inventory omission; the docstring's partial-result wording is ambiguous about this boundary.
2. Mismatched setting: changed only side B rank 1 optimizer.accumulation_steps from 1 to 2. The comparator returned status incomparable, reason 'actual condition differs: optimizer', exit 1, and no metrics. The declared FP16/FP32 differences were accepted in the baseline.

Skill usability and friction
The selected recipes and module interface docstrings were sufficient to build valid artifacts on the first attempt, with no integration errors or retries. No examples, repository tests, Git history, other worktrees or parent reports were read. The output schema needed inspection to map wrapper fields and coordinates into an independent verifier. Missing-inventory errors omit the missing names/counts; mismatched-condition errors omit the side, rank, nested field and expected/actual values. These are reproducible reporting limitations, not claimed confirmed tool bugs. A reusable structured coverage/condition diagnostic helper would reduce adapter-specific reporting. No new metric or export tool was needed.

Files and reproducibility
results.json is the English machine-readable report and includes exact contract/manifest/report paths for all four cases, complete observed reports, expected metrics, effective settings, command arrays, coverage and verification records. commands.json records every export/validation/comparison command and return code. collect_synthetic.py is the task-specific collector; verify_and_report.py is the independent verifier. artifact_index.json labels all artifacts synthetic and records SHA-256 hashes. All files stay in this fresh run directory; existing runs, skill code and repository tests were untouched. Do not rerun the collector into this populated directory: tools require fresh output paths. A future replay should use a new dated run directory.

Limitations
This establishes artifact-schema and arithmetic usability for the bounded synthetic cases. It does not test real framework collection, real synchronized gradients, stateful optimizers, real distributed ownership or hardware numerical behavior. There is no precision pass/fail conclusion because thresholds are null.
"""
(RUN / "run-report.txt").write_text(report, encoding="utf-8")
index = []
for path in sorted(RUN.iterdir()):
    if path.is_file() and path.name != "artifact_index.json":
        index.append({"path": str(path), "relative_path": path.name, "synthetic": True,
                      "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
save("artifact_index.json", {"synthetic": True, "artifact_label": "ALL ARTIFACTS ARE SYNTHETIC",
                            "self_hash_excluded": True, "artifacts": index})
print(json.dumps({"synthetic": True, "verified_checks": sum(c["verified"] for c in checks),
                  "checks": len(checks), "results": str(RUN / "results.json"),
                  "report": str(RUN / "run-report.txt"), "artifact_count_including_index": len(index)+1}))
if not all(c["verified"] for c in checks):
    raise SystemExit(1)
