"""Synthetic-only CPU artifact collector and CLI exercise; no real model or ranks."""
from __future__ import annotations

import copy
import json
import math
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUN = Path(__file__).resolve().parent
REPO = RUN.parents[1]
SKILL = REPO / "skills" / "precision-skill"
COMMANDS = []


def save(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def command(script, args):
    cmd = [sys.executable, "-B", str(SKILL / "scripts" / script), *map(str, args)]
    proc = subprocess.run(cmd, cwd=SKILL, text=True, capture_output=True, timeout=30)
    row = {"argv": cmd, "cwd": str(SKILL), "returncode": proc.returncode,
           "stdout": proc.stdout, "stderr": proc.stderr,
           "synthetic": True}
    COMMANDS.append(row)
    save(RUN / "commands.json", COMMANDS)
    print(script, proc.returncode, proc.stdout[:300], proc.stderr[:300])
    return proc


COMMON = {
    "model": {"id": "synthetic-three-parameter-cpu-array-model", "synthetic": True},
    "inputs": {"id": "synthetic-fixed-gradient-input-v1", "microbatch_order": [0]},
    "scope": {"synthetic": True, "active_models": ["synthetic_model"],
              "steps": 1, "boundaries": ["synchronized-gradients", "stored-after-update"]},
    "optimizer": {"name": "synthetic_sgd", "lr": 0.25, "weight_decay": 0.0,
                  "momentum": 0.0, "accumulation_steps": 1, "clipping": False},
}
SIDE_CONDITIONS = {
    side: {
        "state": {"initial_state": "synthetic-initial-values-v1", "parameter_storage": dtype,
                  "optimizer_state": "none", "step_counter": 0},
        "numerics": {"parameter_storage": dtype, "gradient_storage": "float32",
                     "arithmetic": "float32_sgd_then_native_storage_cast", "device": "cpu",
                     "random_inputs": False, "loss_scaling": 1.0},
    }
    for side, dtype in [("synthetic_fp16", "float16"), ("synthetic_fp32", "float32")]
}
INVENTORY = [
    {"name": "synthetic_model.weight", "shape": [2, 2], "present": True},
    {"name": "synthetic_model.zero", "shape": [2], "present": True},
    {"name": "synthetic_model.absent", "shape": [2], "present": False},
]


def metrics(a, b):
    """Independent scalar arithmetic; does not import any comparison-tool code."""
    squared_error = sum((x - y) ** 2 for x, y in zip(a, b))
    a2 = sum(x*x for x in a)
    b2 = sum(y*y for y in b)
    errors = [abs(x-y) for x,y in zip(a,b)]
    return {"count": len(a), "l2_error": math.sqrt(squared_error),
            "rmse": math.sqrt(squared_error/len(a)),
            "cosine": sum(x*y for x,y in zip(a,b))/math.sqrt(a2*b2) if a2*b2 else None,
            "max_abs_error": max(errors),
            "maximum_flat_indices": [i for i,e in enumerate(errors) if e == max(errors)],
            "norm_a": math.sqrt(a2), "norm_b": math.sqrt(b2)}


def main():
    started = datetime.now(timezone.utc).isoformat()
    save(RUN / "effective_settings.json", {
        "synthetic": True, "common": COMMON, "side_conditions": SIDE_CONDITIONS,
        "ranks": [0, 1], "rank_execution": "sequential synthetic logical shards on one CPU process",
        "capture": "NumPy stored arrays before and after synthetic SGD mutation",
        "no_native_training_framework": True, "training_objective": "not requested; prescribed synthetic gradients",
        "gradient_difference": "deliberate synthetic perturbation: last weight coordinate 4 versus 5",
        "storage_difference": "deliberately declared FP16 versus FP32 including different rounded initial values",
        "versions": {"python": platform.python_version(), "numpy": np.__version__},
        "platform": platform.platform(), "thresholds": None,
        "source_invocation": [sys.executable, "-B", str(Path(__file__).resolve())],
        "wall_time_budget_seconds": 720,
    })
    save(RUN / "synthetic_parameter_inventory.json", {
        "synthetic": True, "parameters": [dict(x, trainable=True, tied_to=None) for x in INVENTORY],
        "logical_elements": 8, "present_gradient_parameters": 2,
        "present_gradient_elements": 6, "absent_gradient_parameters": 1,
        "absent_gradient_elements": 2,
    })
    for stage in ["gradients", "updates"]:
        tensors = copy.deepcopy(INVENTORY)
        if stage == "updates":
            for tensor in tensors:
                tensor["present"] = True
        contract = {"schema_version": 2, "kind": "tensors", "synthetic": True,
                    "thresholds": None, "common": COMMON, "side_conditions": SIDE_CONDITIONS,
                    "expected_ranks": {s: [0, 1] for s in SIDE_CONDITIONS},
                    "stage": stage, "tensors": tensors}
        save(RUN / f"contract-{stage}.json", contract)

    for side in SIDE_CONDITIONS:
        dtype = np.float16 if side == "synthetic_fp16" else np.float32
        grads = {"weight": np.array([1, 2, 3, 4 if side == "synthetic_fp16" else 5], np.float32),
                 "zero": np.zeros(2, np.float32), "absent": None}
        parameters = {"weight": np.array([2048.25, 1, 2, 3], dtype),
                      "zero": np.array([4, 5], dtype), "absent": np.array([6, 7], dtype)}
        before = {name: value.copy() for name, value in parameters.items()}
        for name, gradient in grads.items():
            if gradient is not None:
                parameters[name][...] = parameters[name].astype(np.float32) - np.float32(0.25) * gradient
        actual = {**copy.deepcopy(COMMON), **copy.deepcopy(SIDE_CONDITIONS[side])}
        for rank in [0, 1]:
            save(RUN / f"{side}-rank{rank}-environment.json", {
                "synthetic": True, "rank": rank,
                "versions": {"python": platform.python_version(), "numpy": np.__version__},
                "actual": actual, "rank_execution": "synthetic logical rank; same CPU process"})
            save(RUN / f"{side}-rank{rank}-status.json", {
                "synthetic": True, "rank": rank, "status": "completed"})
        for stage in ["gradients", "updates"]:
            ranks = []
            for rank in [0, 1]:
                entries = []
                for tensor in INVENTORY:
                    name = tensor["name"].split(".")[-1]
                    present = stage == "updates" or grads[name] is not None
                    entry = {"name": tensor["name"], "shape": tensor["shape"],
                             "present": present, "shards": []}
                    if present:
                        width = len(before[name]) // 2
                        offset = rank * width
                        shard = {"offset": offset}
                        values = {"value": grads[name]} if stage == "gradients" else {
                            "before": before[name], "after": parameters[name]}
                        for field, value in values.items():
                            filename = f"{side}-{stage}-rank{rank}-{name}-{field}.npy"
                            np.save(RUN / filename, value[offset:offset+width])
                            shard[field] = {"path": filename}
                        entry["shards"].append(shard)
                    entries.append(entry)
                inv_name = f"{side}-{stage}-rank{rank}-inventory.json"
                save(RUN / inv_name, entries)
                ranks.append({"rank": rank, "environment": f"{side}-rank{rank}-environment.json",
                              "status": f"{side}-rank{rank}-status.json", "inventory": inv_name})
            capture = {"synthetic": True, "side": side, "common": COMMON, "expected_ranks": [0, 1],
                       "stage": stage, "ranks": ranks}
            if stage == "updates":
                capture["events"] = {"synthetic_model": "applied"}
            capture_path = RUN / f"{side}-{stage}-capture.json"
            manifest_path = RUN / f"{side}-{stage}-manifest.json"
            save(capture_path, capture)
            command("tensor_artifacts.py", ["export", "--contract", RUN / f"contract-{stage}.json",
                                            "--capture", capture_path, "--output", manifest_path])
            if manifest_path.exists():
                command("validate_artifacts.py", ["--contract", RUN / f"contract-{stage}.json",
                        "--manifest", manifest_path, "--output", RUN / f"{side}-{stage}-validation.json"])

    for stage in ["gradients", "updates"]:
        command("compare_tensors.py", ["--contract", RUN / f"contract-{stage}.json",
                "--side-a", RUN / f"synthetic_fp16-{stage}-manifest.json",
                "--side-b", RUN / f"synthetic_fp32-{stage}-manifest.json",
                "--output", RUN / f"comparison-{stage}.json"])

    baseline_path = RUN / "synthetic_fp32-gradients-manifest.json"
    if baseline_path.exists():
        original = json.loads(baseline_path.read_text(encoding="utf-8"))
        omission = copy.deepcopy(original)
        omission["tensors"] = [t for t in omission["tensors"] if t["name"] != "synthetic_model.zero"]
        omission_path = RUN / "synthetic_fp32-gradients-omitted-zero-manifest.json"
        save(omission_path, omission)
        command("compare_tensors.py", ["--contract", RUN / "contract-gradients.json",
                "--side-a", RUN / "synthetic_fp16-gradients-manifest.json", "--side-b", omission_path,
                "--output", RUN / "negative-input-omission.json"])
        mismatch = copy.deepcopy(original)
        environment = json.loads((RUN / "synthetic_fp32-rank1-environment.json").read_text(encoding="utf-8"))
        environment["actual"]["optimizer"]["accumulation_steps"] = 2
        mismatch_env = RUN / "synthetic_fp32-rank1-mismatched-environment.json"
        save(mismatch_env, environment)
        for record in mismatch["ranks"]:
            if record["rank"] == 1:
                record["environment"] = str(mismatch_env)
        mismatch_path = RUN / "synthetic_fp32-gradients-mismatched-manifest.json"
        save(mismatch_path, mismatch)
        command("compare_tensors.py", ["--contract", RUN / "contract-gradients.json",
                "--side-a", RUN / "synthetic_fp16-gradients-manifest.json", "--side-b", mismatch_path,
                "--output", RUN / "negative-mismatched-setting.json"])

    # Expected arrays are literal, derived by hand from the tiny prescribed example.
    # This calculation never reads exported manifests, captured NPY values or tool code.
    gradient_a, gradient_b = [1., 2., 3., 4., 0., 0.], [1., 2., 3., 5., 0., 0.]
    update_a, update_b = [0., -.5, -.75, -1., 0., 0., 0., 0.], [-.25, -.5, -.75, -1.25, 0., 0., 0., 0.]
    expected = {"synthetic": True, "thresholds": None, "independence": "literal hand-derived vectors and scalar Python math",
                "gradients": {"global": metrics(gradient_a, gradient_b),
                              "weight": metrics(gradient_a[:4], gradient_b[:4]),
                              "zero": metrics([0., 0.], [0., 0.]),
                              "max_coordinate": {"tensor": "synthetic_model.weight", "flat_index": 3, "index": [1, 1]},
                              "expected_logical_parameters": 3, "paired_present_parameters": 2,
                              "paired_absent_parameters": 1, "paired_present_elements": 6},
                "updates": {"global": metrics(update_a, update_b),
                            "weight": metrics(update_a[:4], update_b[:4]),
                            "zero": metrics([0., 0.], [0., 0.]),
                            "absent": metrics([0., 0.], [0., 0.]),
                            "maximum_coordinates": [{"tensor": "synthetic_model.weight", "flat_index": i} for i in [0, 3]],
                            "paired_present_parameters": 3, "paired_present_elements": 8,
                            "initial_weight_difference": [0.25, 0., 0., 0.],
                            "storage_a": "float16", "storage_b": "float32"},
                "negative_input_omission": {"omitted_parameter": "synthetic_model.zero", "expected_exit": 1,
                                           "full_aggregate": "unavailable", "valid_weight_metrics": "retained"},
                "negative_mismatched_setting": {"rank": 1, "setting": "optimizer.accumulation_steps",
                                                "expected": 1, "actual": 2, "expected_exit": 1,
                                                "comparison": "unavailable"}}
    save(RUN / "independent_expected.json", expected)
    save(RUN / "collection_summary.json", {"synthetic": True, "started_utc": started,
         "finished_utc": datetime.now(timezone.utc).isoformat(), "commands": len(COMMANDS),
         "returncodes": [c["returncode"] for c in COMMANDS], "run_path": str(RUN)})


if __name__ == "__main__":
    main()
