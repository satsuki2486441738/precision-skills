"""Disclosed NeMo CLI adapter: official device migration, Ray NPU isolation, local data, observational step capture."""
import os,sys,pathlib,json,time
if os.environ.get('PRECISION_NEMO_CLI_ADAPTER')=='1':
 import torch,torch_npu
 from torch_npu.contrib import transfer_to_npu
 import ray
 _ray_init=ray.init
 def npu_init(*args,**kwargs):
  if kwargs.get('address')=='auto':raise ConnectionError('Private NeMo test requires an isolated owned Ray cluster')
  kwargs.update(num_gpus=0,num_cpus=8,resources={'NPU':1},include_dashboard=False,object_store_memory=256*1024*1024,_node_ip_address='127.0.0.1')
  kwargs['_temp_dir']=os.environ['PRECISION_NEMO_RAY_TMP']
  result=_ray_init(*args,**kwargs)
  print('ACTUAL_RAY_RESOURCES '+json.dumps(ray.cluster_resources()),flush=True)
  return result
 ray.init=npu_init
 import datasets
 _load_dataset=datasets.load_dataset
 def fixed_dataset(name,*args,**kwargs):
  if name=='nvidia/OpenMathInstruct-2':
   print('LOCAL_FIXED_DATASET '+os.environ['PRECISION_NEMO_DATASET'],flush=True)
   return _load_dataset('json',data_files=os.environ['PRECISION_NEMO_DATASET'],split='train')
  return _load_dataset(name,*args,**kwargs)
 datasets.load_dataset=fixed_dataset
 _adam_step=torch.optim.AdamW.step
 def observed_adam_step(self,*args,**kwargs):
  params=[p for group in self.param_groups for p in group['params']]
  observe=bool(params and params[0].device.type=='npu')
  if observe:before=[p.detach().cpu().clone() for p in params]
  result=_adam_step(self,*args,**kwargs)
  if observe:
   from safetensors.torch import save_file
   folder=pathlib.Path(os.environ['PRECISION_NEMO_CAPTURE']);folder.mkdir(parents=True,exist_ok=True);stem='adamw-'+str(os.getpid())+'-'+str(time.time_ns());after=[p.detach().cpu().clone() for p in params]
   tensors={f'parameter-{i}-{stage}':v.contiguous() for stage,values in [('before',before),('after',after)] for i,v in enumerate(values)}
   save_file(tensors,str(folder/(stem+'.safetensors')))
   record={'pid':os.getpid(),'event':'native AdamW.step completed','parameter_elements':sum(p.numel() for p in params),'device':str(params[0].device),'steps':[float(self.state[p]['step']) for p in params],'max_stored_update':max(float((x-y).abs().max()) for x,y in zip(after,before)),'capture_observational_only':True}
   (folder/(stem+'.json')).write_text(json.dumps(record,indent=2));print('NATIVE_ORCHESTRATOR_ADAMW_COMPLETE '+json.dumps(record),flush=True)
  return result
 torch.optim.AdamW.step=observed_adam_step
