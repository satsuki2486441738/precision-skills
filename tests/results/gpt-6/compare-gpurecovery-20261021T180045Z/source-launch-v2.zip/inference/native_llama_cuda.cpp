#include "llama.h"
#include "ggml-backend.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <cstdlib>

int main(int argc, char **argv) {
    if (argc != 5) return 2;
    std::ifstream input(argv[2]); int prompt_n = 0, target_n = 0; input >> prompt_n >> target_n;
    std::vector<llama_token> ids(prompt_n + target_n); for (auto &id : ids) input >> id;
    if (!input || prompt_n < 1 || target_n < 3) return 3;
    llama_backend_init();
    if (!llama_supports_gpu_offload()) { std::cerr << "CUDA GPU offload unavailable\n"; return 4; }
    auto mp = llama_model_default_params(); mp.n_gpu_layers = 999; mp.check_tensors = true;
    auto *model = llama_model_load_from_file(argv[1], mp); if (!model) return 5;
    auto cp = llama_context_default_params(); cp.n_ctx = 128; cp.n_batch = 64; cp.n_ubatch = 64;
    cp.n_seq_max = 1; cp.n_threads = 4; cp.n_threads_batch = 4;
    cp.type_k = GGML_TYPE_F32; cp.type_v = GGML_TYPE_F32;
    cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_DISABLED; cp.offload_kqv = true; cp.op_offload = true;
    auto *ctx = llama_init_from_model(model, cp); if (!ctx) return 6;
    const int vocab = llama_vocab_n_tokens(llama_model_get_vocab(model));
    std::ofstream raw(argv[3], std::ios::binary), meta(argv[4]);
    auto batch = llama_batch_init(64, 0, 1);
    meta << "{\"vocab_size\":" << vocab << ",\"rows\":" << target_n
         << ",\"gpu_offload_supported\":true,\"requested_gpu_layers\":999,\"native_logits_storage\":\"float32\",\"kv_requested\":\"float32\",\"flash_attention\":false,\"events\":[";
    for (int step = 0; step < target_n; ++step) {
        const int start = step == 0 ? 0 : prompt_n + step - 1;
        const int count = step == 0 ? prompt_n : 1; batch.n_tokens = count;
        for (int i = 0; i < count; ++i) {
            batch.token[i] = ids[start + i]; batch.pos[i] = start + i;
            batch.n_seq_id[i] = 1; batch.seq_id[i][0] = 0; batch.logits[i] = i == count - 1;
        }
        if (llama_decode(ctx, batch) != 0) return 7;
        const float *logits = llama_get_logits_ith(ctx, -1); if (!logits) return 8;
        raw.write(reinterpret_cast<const char *>(logits), sizeof(float) * vocab);
        if (step) meta << ',';
        meta << "{\"stage\":\"" << (step == 0 ? "prefill" : "decode") << "\",\"input_ids\":[";
        for (int i = 0; i < count; ++i) { if (i) meta << ','; meta << ids[start + i]; }
        meta << "],\"positions\":[";
        for (int i = 0; i < count; ++i) { if (i) meta << ','; meta << start + i; }
        meta << "],\"prefix_length\":" << start << ",\"batch_tokens\":" << count << '}';
    }
    meta << "]}";
    llama_batch_free(batch); llama_free(ctx); llama_model_free(model); llama_backend_free();
    return 0;
}
