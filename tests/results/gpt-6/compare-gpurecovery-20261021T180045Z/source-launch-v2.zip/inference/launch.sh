#!/usr/bin/env bash
set -euo pipefail
WORK_ROOT=${1:?absolute private work root required}
GPU_ID=${2:?root-assigned GPU index required}
ACTION=${3:-all}
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mkdir -p "$WORK_ROOT" "$WORK_ROOT/logs" "$WORK_ROOT/state" "$WORK_ROOT/cache"
export PYTHONNOUSERSITE=1 PYTHONPATH= HF_HUB_DISABLE_XET=1 HF_HUB_DOWNLOAD_TIMEOUT=120
export CUDA_VISIBLE_DEVICES="$GPU_ID" OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4
export PIP_CACHE_DIR="$WORK_ROOT/cache/pip" HF_HOME="$WORK_ROOT/cache/huggingface"
export TORCHINDUCTOR_COMPILE_THREADS=1 MAX_JOBS=8
unset RANK LOCAL_RANK WORLD_SIZE LOCAL_WORLD_SIZE MASTER_ADDR MASTER_PORT NODE_RANK GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE || true
exec 9>"$WORK_ROOT/state/inference-gpu-${GPU_ID}.lock"
flock -n 9 || { echo 'Assigned inference lane already locked'; exit 73; }
BASE_PY=${PRECISION_BASE_PYTHON:-python3}
VENV="$WORK_ROOT/environments/lmdeploy-cuda"
if [[ ! -x "$VENV/bin/python" ]]; then "$BASE_PY" -m venv "$VENV"; fi
PY="$VENV/bin/python"
if [[ ! -f "$WORK_ROOT/state/dependencies-v1.complete" ]]; then
  "$PY" -m pip install --disable-pip-version-check --upgrade pip wheel setuptools >"$WORK_ROOT/logs/pip-bootstrap.log" 2>&1
  "$PY" -m pip install --disable-pip-version-check 'torch==2.9.1' 'torchvision==0.24.1' --index-url https://download.pytorch.org/whl/cu128 >"$WORK_ROOT/logs/pip-torch.log" 2>&1
  "$PY" -m pip install --disable-pip-version-check 'lmdeploy==0.18.0' 'transformers==4.57.1' 'numpy==2.2.6' 'torch==2.9.1' 'torchvision==0.24.1' 'triton==3.5.1' 'peft==0.14.0' 'cmake>=3.28' ninja gguf sentencepiece >"$WORK_ROOT/logs/pip-lmdeploy.log" 2>&1
  "$PY" -m pip check >"$WORK_ROOT/logs/pip-check.log" 2>&1
  "$PY" -m pip freeze >"$WORK_ROOT/logs/pip-freeze.txt"
  touch "$WORK_ROOT/state/dependencies-v1.complete"
fi
export PATH="$VENV/bin:$PATH"
"$PY" -u "$HERE/suite.py" prepare "$WORK_ROOT" 2>&1 | tee "$WORK_ROOT/logs/prepare.log"
if [[ "$ACTION" == prepare ]]; then exit 0; fi
"$PY" -u "$HERE/suite.py" run "$WORK_ROOT" 2>&1 | tee "$WORK_ROOT/logs/run.log"
