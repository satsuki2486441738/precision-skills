"""Private CUDA native inference collector. No native output is used as CPU input weights."""
import datetime as dt
import functools
import hashlib
import importlib.metadata as md
import inspect
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time
import traceback
import urllib.request

HERE = Path(__file__).resolve().parent
MODELS = [
    {'name':'SmolLM2-135M-Instruct','repo':'HuggingFaceTB/SmolLM2-135M-Instruct','revision':'12fd25f77366fa6b3b4b768ec3050bf629380bac','native_class':'llama:LlamaForCausalLM','prompt':[504,3575,282,4649,314,7042],'targets':[30,378,3575]},
    {'name':'Qwen2.5-0.5B-Instruct','repo':'Qwen/Qwen2.5-0.5B-Instruct','revision':'7ae557604adf67be50417f59c2c2f167def9a775','native_class':'qwen2:Qwen2ForCausalLM','prompt':[785,6722,315,9625,374,12095],'targets':[13,576,6722]},
]
LLAMA_PIN = '620d2225cc436ab0b001e3200e590e3b286ef9ab'
LLAMA_TAG_OBJECT = '757cad021b357f417065ddbc41a6e8f87c1f8136'
LLAMA_ARCHIVE_SHA256 = '1aef06fb7bdc1342d30b73d9f9520a500d04d29851c8bba96a08106bdf813fbe'
RANKS = ['LOCAL_RANK','RANK','WORLD_SIZE','LOCAL_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE']

def save(path, value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False,default=str)+'\n')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''): h.update(block)
    return h.hexdigest()

def run(cmd, log, timeout=1800, env=None):
    started=time.monotonic()
    with Path(log).open('wb') as stream:
        result=subprocess.run([str(x) for x in cmd],stdout=stream,stderr=subprocess.STDOUT,timeout=timeout,env=env)
    save(str(log)+'.status.json',{'command':[str(x) for x in cmd],'returncode':result.returncode,'elapsed_seconds':time.monotonic()-started})
    result.check_returncode()

def tools_path(root):
    p=Path(os.environ.get('PRECISION_SKILL_SCRIPTS',str(root/'skill-tools')))
    if not (p/'inference_capture.py').is_file(): raise RuntimeError('Set PRECISION_SKILL_SCRIPTS to the actual precision skill scripts directory')
    sys.path.insert(0,str(p));return p

def prepare(root):
    from huggingface_hub import snapshot_download
    for sub in ['resources','logs','runs','state']: (root/sub).mkdir(exist_ok=True,parents=True)
    run(['nvidia-smi','--query-gpu=index,name,uuid,driver_version,memory.total,compute_cap','--format=csv'],root/'logs/nvidia-smi.csv',timeout=30)
    run(['nvcc','--version'],root/'logs/nvcc-version.log',timeout=30)
    import torch
    save(root/'logs/torch-build.json',{'torch':torch.__version__,'compiled_cuda':torch.version.cuda,'visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'cuda_not_initialized_during_preparation':not torch.cuda.is_initialized(),'tf32_matmul':torch.backends.cuda.matmul.allow_tf32,'tf32_cudnn':torch.backends.cudnn.allow_tf32})
    for m in MODELS:
        directory=root/'resources'/m['name']
        if not (directory/'model.safetensors').is_file():snapshot_download(m['repo'],revision=m['revision'],local_dir=directory,allow_patterns=['*.json','*.safetensors','*.txt','*.model'])
        save(root/'resources'/(m['name']+'-identity.json'),{**m,'files':{str(p.relative_to(directory)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in directory.iterdir() if p.is_file()}})
    source=root/'resources'/('llama.cpp-'+LLAMA_PIN)
    if not source.is_dir():
        archive=root/'resources'/('llama.cpp-'+LLAMA_TAG_OBJECT+'.tar.gz')
        configured=os.environ.get('PRECISION_LLAMA_SOURCE_ARCHIVE')
        if configured:
            archive=root/'resources'/Path(configured).name
            if not archive.is_file():shutil.copy(configured,archive)
        retained=HERE/'source-archives'/archive.name
        if not archive.is_file():
            if retained.is_file():shutil.copy(retained,archive)
            else:
                temporary=archive.with_suffix(archive.suffix+'.partial')
                with urllib.request.urlopen('https://codeload.github.com/ggml-org/llama.cpp/tar.gz/'+LLAMA_TAG_OBJECT,timeout=60) as response,temporary.open('wb') as output:shutil.copyfileobj(response,output)
                temporary.replace(archive)
        assert sha(archive)==LLAMA_ARCHIVE_SHA256,'Pinned official llama archive bytes differ'
        with tarfile.open(archive) as tar:
            archive_root=tar.getnames()[0].split('/')[0];tar.extractall(root/'resources',filter='data')
        extracted=root/'resources'/archive_root
        if extracted!=source:extracted.rename(source)
        save(root/'resources'/'llama-source.json',{'revision':LLAMA_PIN,'annotated_tag':'v0.7.0','tag_object':LLAMA_TAG_OBJECT,'original_archive_name':archive.name,'archive_sha256':sha(archive),'official_source':'https://github.com/ggml-org/llama.cpp/tree/'+LLAMA_PIN})
    architecture=os.environ.get('PRECISION_CUDA_ARCH','90')
    build=source/('build-cuda-sm'+architecture)
    if not (build/'bin/libllama.so').is_file():
        run(['cmake','-S',source,'-B',build,'-DGGML_CUDA=ON','-DCMAKE_CUDA_ARCHITECTURES='+architecture,'-DLLAMA_BUILD_TESTS=OFF','-DLLAMA_BUILD_EXAMPLES=OFF','-DLLAMA_BUILD_TOOLS=OFF','-DLLAMA_CURL=OFF','-DBUILD_SHARED_LIBS=ON'],root/'logs/llama-configure.log')
        run(['cmake','--build',build,'--target','llama','-j','8'],root/'logs/llama-build.log',timeout=3600)
    binary=root/'resources/native_llama_cuda'
    run(['g++','-std=c++17','-O2',HERE/'native_llama_cuda.cpp','-I'+str(source/'include'),'-I'+str(source/'ggml/include'),'-L'+str(build/'bin'),'-Wl,-rpath,'+str(build/'bin'),'-lllama','-o',binary],root/'logs/llama-adapter-build.log')
    for m in MODELS:
        gguf=root/'resources'/(m['name']+'-f16.gguf')
        if not gguf.is_file(): run([sys.executable,source/'convert_hf_to_gguf.py',root/'resources'/m['name'],'--outfile',gguf,'--outtype','f16'],root/'logs'/(m['name']+'-convert.log'))
        save(root/'resources'/(m['name']+'-gguf-identity.json'),{'gguf_sha256':sha(gguf),'bytes':gguf.stat().st_size,'source_revision':LLAMA_PIN,'source_checkpoint':m,'conversion':'official convert_hf_to_gguf.py --outtype f16; no quantization'})

def tensor_meta(x):
    import torch
    if torch.is_tensor(x): return {'shape':list(x.shape),'dtype':str(x.dtype),'device':str(x.device),'data_ptr':x.data_ptr()}
    if isinstance(x,(list,tuple)): return [tensor_meta(v) for v in x]
    if isinstance(x,dict): return {k:tensor_meta(v) for k,v in x.items()}
    return str(type(x))

def install_observer():
    import importlib
    import torch
    from safetensors.torch import save_file
    model_spec=os.environ['PRECISION_NATIVE_CLASS'].split(':')
    cls=getattr(importlib.import_module('lmdeploy.pytorch.models.'+model_spec[0]),model_spec[1])
    original=cls.forward;sig=inspect.signature(original);counts={'forward':0,'logits':0}
    @functools.wraps(original)
    def observe_forward(self,*args,**kwargs):
        bound=sig.bind(self,*args,**kwargs).arguments
        result=original(self,*args,**kwargs);counts['forward']+=1
        destination=Path(os.environ['PRECISION_CASE'])
        if counts['forward']<=64:
            meta={'pid':os.getpid(),'call':counts['forward'],'class':type(self).__module__+'.'+type(self).__name__,'input_ids':bound['input_ids'].detach().cpu().tolist(),'position_ids':bound['position_ids'].detach().cpu().tolist(),'cache':tensor_meta(bound['past_key_values']),'output':tensor_meta(result),'attention_metadata':{k:{**tensor_meta(v),**({'values':v.detach().cpu().tolist()} if v.numel()<=128 else {})} if torch.is_tensor(v) else v for k,v in vars(bound['attn_metadata']).items() if torch.is_tensor(v) or isinstance(v,(int,float,bool,str))} if hasattr(bound.get('attn_metadata'),'__dict__') else str(type(bound.get('attn_metadata')))}
            if counts['forward']==1:meta['parameters']={n:tensor_meta(p) for n,p in self.named_parameters()}
            save(destination/f"forward-{os.getpid()}-{counts['forward']}.json",meta)
        return result
    cls.forward=observe_forward
    original_logits=cls.get_logits
    @functools.wraps(original_logits)
    def observe_logits(self,*args,**kwargs):
        result=original_logits(self,*args,**kwargs);counts['logits']+=1
        if counts['logits']<=64 and result.numel()<=128*result.shape[-1]:
            base=Path(os.environ['PRECISION_CASE'])/f"logits-{os.getpid()}-{counts['logits']}"
            save_file({'logits':result.detach().cpu().contiguous().clone()},str(base)+'.safetensors')
            save(str(base)+'.json',{'pid':os.getpid(),'call':counts['logits'],'forward_call':counts['forward'],'tensor':tensor_meta(result),'boundary':'native model get_logits return before sampling and all logits processors'})
        return result
    cls.get_logits=observe_logits

class ForceHistory:
    def __init__(self, prompt, targets):self.prompt=prompt;self.targets=targets;self.calls=0
    def __call__(self, input_ids, scores):
        import torch
        step=self.calls;self.calls+=1
        if step>=len(self.targets):
            save(Path(os.environ['PRECISION_CASE'])/f'force-exhausted-{os.getpid()}-{step}.json',{'step':step,'action':'identity after all requested fixed-history scores have been collected','score':tensor_meta(scores)})
            return scores
        ids=input_ids.tolist() if hasattr(input_ids,'tolist') else list(input_ids)
        save(Path(os.environ['PRECISION_CASE'])/f'force-{os.getpid()}-{step}.json',{'step':step,'native_all_ids':ids,'forced_token':self.targets[step],'score':tensor_meta(scores),'raw_score_capture':'independent passive native get_logits observation'})
        forced=torch.full_like(scores,-float('inf'));forced[self.targets[step]]=0
        return forced

def lmdeploy_case(root,case,m):
    import torch
    from lmdeploy import pipeline,PytorchEngineConfig,GenerationConfig
    from safetensors.torch import load_file,save_file
    from runtime_probe import inspect_runtime
    save(case/'runtime.json',inspect_runtime({'imports':['torch','transformers','lmdeploy','triton','numpy'],'symbols':['lmdeploy:pipeline'],'distributions':['torch','torchvision','lmdeploy','triton','transformers','numpy']}))
    import importlib
    source_module=importlib.import_module('lmdeploy.pytorch.models.'+m['native_class'].split(':')[0])
    model_type=getattr(source_module,m['native_class'].split(':')[1])
    source_paths={}
    for name,source in [('native-model-forward',inspect.unwrap(model_type.forward)),('native-model-logits',inspect.unwrap(model_type.get_logits)),('native-logits-process',importlib.import_module('lmdeploy.pytorch.engine.logits_process'))]:
        path=Path(inspect.getsourcefile(source));shutil.copy(path,case/(name+'.py'));source_paths[name]={'module':source.__module__ if hasattr(source,'__module__') else source.__name__,'path':str(path),'sha256':sha(path)}
    save(case/'installed-source-index.json',source_paths)
    cfg=PytorchEngineConfig(dtype='float16',tp=1,device_type='cuda',session_len=128,max_batch_size=1,cache_max_entry_count=0.02,eager_mode=True,enable_prefix_caching=False,block_size=16)
    gen=GenerationConfig(max_new_tokens=3,min_new_tokens=3,ignore_eos=True,do_sample=False,temperature=1.0,top_k=0,top_p=1.0,repetition_penalty=1.0,output_logits='generation',logits_processors=[ForceHistory(m['prompt'],m['targets'])])
    save(case/'requested-config.json',{'engine':vars(cfg),'generation':{k:v for k,v in vars(gen).items() if k!='logits_processors'},'fixed_history':m})
    pipe=pipeline(str(root/'resources'/m['name']),backend_config=cfg)
    requests=[];original=pipe.async_engine.preprocess
    async def observed_request(*args,**kwargs):
        request=await original(*args,**kwargs)
        requests.append({'input_ids':list(request.inputs['input_ids']),'input_token_len':request.input_token_len})
        save(case/'requests.json',requests)
        if list(request.inputs['input_ids'])!=m['prompt']:raise RuntimeError('Native input IDs do not match requested fixed history')
        return request
    pipe.async_engine.preprocess=observed_request
    try:
        async def fixed_request():
            request=await pipe.async_engine.preprocess(messages=None,session_id=0,gen_config=gen,input_ids=list(m['prompt']),do_preprocess=False)
            chunks=[]
            async for output in pipe.async_engine.generate(request,stream_response=False):
                chunks.append({'ids':list(output.token_ids),'text':output.response,'finish_reason':output.finish_reason,'logits':tensor_meta(output.logits) if output.logits is not None else 'not_exposed'})
            return {'ids':[token for chunk in chunks for token in chunk['ids']],'chunks':chunks,'finish_reason':chunks[-1]['finish_reason']}
        response=pipe._run(coro=fixed_request()).result(timeout=600)
        save(case/'response.json',response)
        assert response['ids']==m['targets'],response
        vocab=json.loads((root/'resources'/m['name']/'config.json').read_text())['vocab_size']
        score_records=[(p,json.loads(p.read_text())) for p in case.glob('logits-*.json')]
        selected=[];rows=[]
        for step in range(3):
            expected=m['prompt'] if step==0 else [m['targets'][step-1]]
            positions=list(range(len(m['prompt']))) if step==0 else [len(m['prompt'])+step-1]
            matching=[]
            for p,r in score_records:
                fp=case/f"forward-{r['pid']}-{r['forward_call']}.json"
                if not fp.is_file():continue
                f=json.loads(fp.read_text())
                if f['input_ids'] in [expected,[expected]] and f['position_ids'] in [positions,[positions]]:matching.append((p,r,f))
            assert len(matching)==1,(step,len(matching))
            p,r,f=matching[0];assert r['tensor']['device'].startswith('cuda')
            raw=load_file(str(p.with_suffix('.safetensors')))['logits'].reshape(-1,r['tensor']['shape'][-1])[-1,:vocab]
            assert torch.isfinite(raw).all();rows.append(raw.clone());selected.append({'step':step,'score':p.name,'observation':f,'score_metadata':r})
        save_file({'logits':torch.stack(rows)},str(case/'native-logits.safetensors'))
        events=[{'stage':'prefill' if i==0 else 'decode','input_ids':r['observation']['input_ids'][0] if isinstance(r['observation']['input_ids'][0],list) else r['observation']['input_ids'],'positions':r['observation']['position_ids'],'prefix_length':0 if i==0 else len(m['prompt'])+i-1} for i,r in enumerate(selected)]
        save(case/'selected-coordinates.json',selected);save(case/'events.json',events)
        save(case/'completion.json',{'status':'completed','native_backend':'LMDeploy PyTorch CUDA','native_entrypoint':'pipeline native engine -> AsyncEngine.preprocess(input_ids) -> generate -> native CUDA model forward -> get_logits -> fixed-token processor -> cached decode','full_vocab_rows':3,'prefill':1,'cached_decode':2,'thresholds':None})
    finally:pipe.close()

def cpu_case(root,case,m):
    import torch
    from transformers import AutoModelForCausalLM
    from safetensors.torch import save_file
    from runtime_probe import inspect_runtime
    torch.set_num_threads(4)
    save(case/'runtime.json',inspect_runtime({'imports':['torch','transformers'],'symbols':['transformers:AutoModelForCausalLM'],'distributions':['torch','transformers']}))
    model=AutoModelForCausalLM.from_pretrained(root/'resources'/m['name'],dtype=torch.float16,attn_implementation='eager',local_files_only=True).float().cpu().eval()
    rows=[];cache=None;events=[]
    with torch.inference_mode():
        for step in range(3):
            ids=m['prompt'] if step==0 else [m['targets'][step-1]];start=0 if step==0 else len(m['prompt'])+step-1
            positions=list(range(start,start+len(ids)))
            output=model(input_ids=torch.tensor([ids]),attention_mask=torch.ones((1,start+len(ids)),dtype=torch.long),position_ids=torch.tensor([positions]),past_key_values=cache,use_cache=True)
            cache=output.past_key_values;rows.append(output.logits[0,-1].cpu().clone())
            layers=cache.layers if hasattr(cache,'layers') else cache
            kv=tensor_meta([(x.keys,x.values) if hasattr(x,'keys') else x for x in layers])
            events.append({'stage':'prefill' if step==0 else 'decode','input_ids':ids,'positions':positions,'prefix_length':start,'cache':kv,'logits':tensor_meta(output.logits)})
    save_file({'logits':torch.stack(rows)},str(case/'native-logits.safetensors'));save(case/'events.json',events)
    save(case/'completion.json',{'status':'completed','execution':'independent CPU FP32 eager native cache','weights':'same checkpoint cast to FP16 then FP32, matching LMDeploy and F16 GGUF','uses_native_scores':False,'uses_native_weights':False,'thresholds':None})

def llama_case(root,case,m):
    import numpy as np
    tokens=case/'tokens.txt';tokens.write_text('6 3\n'+' '.join(map(str,m['prompt']+m['targets']))+'\n')
    run([root/'resources/native_llama_cuda',root/'resources'/(m['name']+'-f16.gguf'),tokens,case/'native-logits.bin',case/'native-settings.json'],case/'native.log')
    settings=json.loads((case/'native-settings.json').read_text());log=(case/'native.log').read_text(errors='replace')
    assert 'CUDA' in log and re.search(r'offloaded [1-9][0-9]*/[1-9][0-9]* layers',log),'Missing measured positive CUDA layer offload log'
    assert 'GGML_CUDA:BOOL=ON' in (root/'resources'/('llama.cpp-'+LLAMA_PIN)/('build-cuda-sm'+os.environ.get('PRECISION_CUDA_ARCH','90'))/'CMakeCache.txt').read_text()
    rows=np.fromfile(case/'native-logits.bin',dtype=np.float32).reshape(3,settings['vocab_size']);assert np.isfinite(rows).all()
    np.save(case/'native-logits.npy',rows,allow_pickle=False);save(case/'events.json',settings['events'])
    save(case/'completion.json',{'status':'completed','native_backend':'GGML_CUDA','gpu_offload_log':'native.log','build_flag_verified':'GGML_CUDA:BOOL=ON','revision':LLAMA_PIN,'full_vocab_rows':3,'prefill':1,'cached_decode':2,'thresholds':None})

def suite(root):
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=root/'runs'/('compare-inferencecuda-'+stamp);out.mkdir()
    tools_path(root);save(out/'model-specs.json',MODELS)
    source=out/'collector-source';source.mkdir()
    for name in ['suite.py','analyze.py','launch.sh','native_llama_cuda.cpp']:shutil.copy(HERE/name,source/name)
    statuses=[]
    for index,m in enumerate(MODELS):
        model_out=out/m['name'];model_out.mkdir()
        shutil.copy(root/'resources'/(m['name']+'-identity.json'),model_out/'model-identity.json')
        shutil.copy(root/'resources'/(m['name']+'-gguf-identity.json'),model_out/'gguf-identity.json')
        for lane in ['cpu','lmdeploy','llama']:
            case=model_out/lane;case.mkdir();env=dict(os.environ,PRECISION_CASE=str(case),PRECISION_NATIVE_CLASS=m['native_class'])
            for key in RANKS:env.pop(key,None)
            if lane=='cpu':env['CUDA_VISIBLE_DEVICES']=''
            started=time.monotonic()
            try:
                run([sys.executable,source/'suite.py',lane,root,case,str(index)],case/'process.log',timeout=1800,env=env)
                status='completed'
            except Exception as exc:
                status='failed';save(case/'failure.json',{'error':repr(exc),'traceback':traceback.format_exc()})
            record={'model':m['name'],'lane':lane,'status':status,'elapsed_seconds':time.monotonic()-started,'case':str(case.relative_to(out))};statuses.append(record);save(out/'status.json',statuses);print(json.dumps(record),flush=True)
    save(root/'latest-run.json',{'run':str(out),'statuses':statuses})
    run([sys.executable,source/'analyze.py',root,out],out/'analysis.log',timeout=300)

if len(sys.argv)>1 and sys.argv[1]=='lmdeploy':install_observer()
if __name__=='__main__':
    action=sys.argv[1];root=Path(sys.argv[2]).resolve();tools_path(root)
    if action=='prepare':prepare(root)
    elif action=='run':suite(root)
    else:
        case=Path(sys.argv[3]);m=MODELS[int(sys.argv[4])]
        {'lmdeploy':lmdeploy_case,'cpu':cpu_case,'llama':llama_case}[action](root,case,m)
