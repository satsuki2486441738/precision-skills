"""Real GPU RL suite entrypoint: isolated dependency installation and native training.

Launch on the CUDA allocation:
  python run_suite.py --work-root /workspace/gpu-rl --skill-root /workspace/precision-skills/skills/precision-skill
All stages are bounded subprocesses. Failures are retained and later lanes continue.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PINS = {'swift': ('https://github.com/modelscope/ms-swift.git', '2efb43ffe61294735be6816abca991fb2ca16011'),
        'openrlhf': ('https://github.com/OpenRLHF/OpenRLHF.git', '06ab51e75c0e8c5b4d6b66912996b2a611e3dc2f'),
        'nemo': ('https://github.com/NVIDIA-NeMo/RL.git', '26f651ea490ef2a343e7f298b9aa54bc7c5da67c'),
        'roll': ('https://github.com/alibaba/ROLL.git', 'd3506ea9e280ae720fb74df9f82db6efac1c72d5')}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--work-root', required=True)
    ap.add_argument('--skill-root', required=True)
    ap.add_argument('--lanes', default='swift,openrlhf')
    ap.add_argument('--model', default='Qwen/Qwen3-0.6B')
    ap.add_argument('--python', default=sys.executable)
    ap.add_argument('--skip-install', action='store_true')
    a = ap.parse_args()
    root = Path(a.work_root).resolve()
    run = root / 'runs' / ('compare-gpurl-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    run.mkdir(parents=True)
    env = dict(os.environ, PYTHONUNBUFFERED='1', TOKENIZERS_PARALLELISM='false', OMP_NUM_THREADS='2',
               HF_HOME=str(root / 'cache' / 'huggingface'), PIP_CACHE_DIR=str(root / 'cache' / 'pip'),
               DS_BUILD_OPS='0', MAX_JOBS='4')
    results = []

    def execute(name, command, timeout=3600, extra=None, cwd=None):
        start = time.time()
        with (run / (name + '.log')).open('w') as log:
            print('GPU_RL_SUITE', name, flush=True)
            try:
                result = subprocess.run([str(x) for x in command], cwd=cwd, env={**env, **(extra or {})},
                                        stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
                code = result.returncode
            except subprocess.TimeoutExpired:
                code = 124
        receipt = {'stage': name, 'command': [str(x) for x in command], 'exit_code': code,
                   'elapsed_seconds': time.time() - start}
        (run / (name + '.json')).write_text(json.dumps(receipt, indent=2))
        print(json.dumps(receipt), flush=True)
        return code == 0

    for lane in a.lanes.split(','):
        if lane not in PINS:
            results.append({'lane': lane, 'status': 'unimplemented_native_adapter'})
            continue
        source = root / 'sources' / lane
        venv = root / 'environments' / lane
        py = venv / 'bin' / 'python'
        url, pin = PINS[lane]
        source.parent.mkdir(parents=True, exist_ok=True)
        venv.parent.mkdir(parents=True, exist_ok=True)
        ok = True
        if not a.skip_install:
            if not source.exists():
                ok = execute(lane + '-clone', ['git', 'clone', '--filter=blob:none', '--no-checkout', url, source], 240)
            if ok:
                ok = execute(lane + '-checkout', ['git', 'checkout', '--detach', pin], 240, cwd=source)
            if not py.exists():
                ok = ok and execute(lane + '-venv', [a.python, '-m', 'venv', venv], 120)
            if ok:
                ok = execute(lane + '-build-tools', [py, '-m', 'pip', 'install', '-U', 'pip', 'setuptools', 'wheel', 'packaging', 'ninja'], 600)
            lock = HERE / (lane + '.requirements.lock')
            if ok and lock.exists():
                # The resolver lock retains the whole dependency combination. The
                # exact Git checkout then supplies the framework's actual source.
                torch_version, cuda_index = {'swift': ('2.9.0', 'cu128'), 'openrlhf': ('2.8.0', 'cu128'),
                    'nemo': ('2.6.0', 'cu124')}[lane]
                ok = execute(lane + '-torch', [py, '-m', 'pip', 'install', 'torch==' + torch_version,
                    '--index-url', 'https://download.pytorch.org/whl/' + cuda_index], 1800)
                ok = ok and execute(lane + '-locked-dependencies', [py, '-m', 'pip', 'install', '-r', lock,
                    '--no-build-isolation'], 2400)
                if ok:
                    ok = execute(lane + '-editable-source', [py, '-m', 'pip', 'install', '--no-deps', '-e', source], 600)
                if not ok:
                    results.append({'lane': lane, 'status': 'locked_environment_failed'})
                    continue
            if ok and not lock.exists() and lane == 'swift':
                ok = execute(lane + '-torch', [py, '-m', 'pip', 'install', 'torch==2.9.0', '--index-url', 'https://download.pytorch.org/whl/cu128'], 1800)
                ok = ok and execute(lane + '-install', [py, '-m', 'pip', 'install', '-e', source, 'transformers==5.3.0', 'trl==0.29.1', 'accelerate==1.14.0', 'msgspec==0.19.0'], 1800)
            elif ok and not lock.exists() and lane == 'nemo':
                ok = execute(lane + '-torch', [py, '-m', 'pip', 'install', 'torch==2.6.0', '--index-url', 'https://download.pytorch.org/whl/cu124'], 1800)
                ok = ok and execute(lane + '-install', [py, '-m', 'pip', 'install', '-e', source,
                    'transformers==4.51.3', 'accelerate==1.6.0', 'datasets==3.5.0', 'torchdata==0.11.0'], 1800)
            elif ok and not lock.exists():
                ok = execute(lane + '-torch', [py, '-m', 'pip', 'install', 'torch==2.8.0', '--index-url', 'https://download.pytorch.org/whl/cu128'], 1800)
                ok = ok and execute(lane + '-flash-attn', [py, '-m', 'pip', 'install', 'flash-attn==2.8.3', '--no-build-isolation'], 1800)
                if lane == 'roll':
                    ok = ok and execute(lane + '-install', [py, '-m', 'pip', 'install', '-r', 'requirements_torch280_vllm.txt',
                        '-e', '.', 'flash-attn==2.8.3', '--no-build-isolation'], 2400, cwd=source)
                else:
                    ok = ok and execute(lane + '-install', [py, '-m', 'pip', 'install', '-e', str(source) + '[vllm]'], 2400)
        if not ok:
            results.append({'lane': lane, 'status': 'environment_failed'})
            continue
        ok = execute(lane + '-pipcheck', [py, '-m', 'pip', 'check'], 120)
        ok = ok and execute(lane + '-freeze', [py, '-m', 'pip', 'freeze'], 120)
        if not ok:
            results.append({'lane': lane, 'status': 'dependency_check_failed'})
            continue
        ok = execute(lane + '-models', [py, HERE / 'prepare_models.py', '--model', a.model, '--root', root / 'models'], 1200)
        for case in ['tiny', 'pretrained'] if ok else []:
            output = run / lane / case
            output.mkdir(parents=True)
            for filename in ['pipcheck', 'freeze']:
                import shutil
                shutil.copy2(run / (lane + '-' + filename + '.log'), output / (filename + '.txt'))
            for path in [root / 'models/model-lock.json', root / 'models' / (case + '-manifest.json')]:
                shutil.copy2(path, output / path.name)
            native = HERE / {'swift': 'native_swift.py', 'openrlhf': 'native_openrlhf.py', 'nemo': 'native_nemo.py', 'roll': 'native_roll.py'}[lane]
            native_command = [py, native, '--model', root / 'models' / case]
            if lane == 'nemo':
                native_command += ['--source', source]
            ok = execute(lane + '-' + case + '-native', native_command, 1200,
                         {'GPU_RL_OUTPUT': str(output), 'GPU_RL_CAPTURE_OPEN': '1' if lane == 'openrlhf' else '0',
                          'GPU_RL_CAPTURE_NEMO': '1' if lane == 'nemo' else '0',
                          'PYTHONPATH': str(HERE) + os.pathsep + str(source),
                          'PATH': str(venv / 'bin') + os.pathsep + env.get('PATH', '')})
            if ok:
                ok = execute(lane + '-' + case + '-reference', [py, HERE / 'cpu_reference.py', '--native-output', output,
                    '--skill-root', a.skill_root], 1800)
            results.append({'lane': lane, 'case': case, 'status': 'complete' if ok else 'failed', 'output': str(output)})
        (run / 'suite-status.json').write_text(json.dumps(results, indent=2))
    (run / 'suite-status.json').write_text(json.dumps(results, indent=2))
    return 0 if results and all(x['status'] == 'complete' for x in results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
