"""Official CUDA Megatron Bridge conversion -> native checkpoint -> finetune.

Bridge v0.2.0, MCore 0.15.0 and authentic TransformerEngine 2.9.0 are selected.
No NPU fork, compatibility module or numerical operator replacement is used.
The independent CPU mode reads only reference-input.pt and the initial HF model.
Pretrained tensor capture samples the first 4096 values of each logical tensor;
the entire native model is trained and its complete logical inventory is retained.
"""
import argparse
import dataclasses
import hashlib
import importlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import sys


def dump(path,value):
    Path(path).write_text(json.dumps(value,indent=2,default=str,allow_nan=False))


def cpu(x):
    import torch
    if torch.is_tensor(x):return x.detach().cpu().clone()
    if isinstance(x,dict):return {k:cpu(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return type(x)(cpu(v) for v in x)
    return x


def fixture(root):
    import torch
    from transformers import Qwen3Config,Qwen3ForCausalLM,PreTrainedTokenizerFast
    from tokenizers import Tokenizer
    from tokenizers.models import WordLevel
    path=root/'models/bridge-tiny-qwen3-seed20261022'
    if (path/'model.safetensors').is_file():return path
    path.mkdir(parents=True,exist_ok=False)
    torch.manual_seed(20261022)
    cfg=Qwen3Config(vocab_size=128,hidden_size=128,intermediate_size=256,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,head_dim=32,max_position_embeddings=64,tie_word_embeddings=True,attention_dropout=0.0,bos_token_id=1,eos_token_id=2,pad_token_id=0,rope_theta=1000000.0)
    Qwen3ForCausalLM(cfg).to(torch.bfloat16).save_pretrained(path)
    vocab={'[PAD]':0,'[BOS]':1,'[EOS]':2,'[UNK]':3}
    vocab.update({'w'+str(i):i for i in range(4,128)})
    raw=Tokenizer(WordLevel(vocab,unk_token='[UNK]'))
    PreTrainedTokenizerFast(tokenizer_object=raw,pad_token='[PAD]',bos_token='[BOS]',eos_token='[EOS]',unk_token='[UNK]').save_pretrained(path)
    dump(path/'fixture.json',{'seed':20261022,'initialization':'seeded random BF16 stored values; not pretrained'})
    return path


def batch(hf):
    import torch
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained(hf,local_files_only=True)
    # Literal ordered token IDs deliberately avoid template/version ambiguity.
    eos=int(tok.eos_token_id)
    ids=torch.tensor([[1,7,11,5,9,17,23,eos,31,8,19,6,10,13,29,eos,0]],dtype=torch.long)
    mask=torch.ones(16,dtype=torch.float32);mask[0]=0;mask[-1]=0
    labels=ids.clone();labels[:,0]=-100;labels[:,1:][:,mask==0]=-100
    return ids,mask,labels


def native(args):
    import torch
    import megatron.bridge,megatron.core,transformer_engine
    from megatron.bridge import AutoBridge
    from megatron.core.utils import unwrap_model
    from megatron.core.transformer.enums import AttnBackend
    from megatron.bridge.training.config import ConfigContainer,TrainingConfig,OptimizerConfig,SchedulerConfig,LoggerConfig,CheckpointConfig,DistributedInitConfig,RNGConfig,DatasetProvider,DistributedDataParallelConfig
    from megatron.bridge.training.tokenizers.config import TokenizerConfig
    from megatron.bridge.training.gpt_step import forward_step
    from megatron.bridge.training.finetune import finetune
    root=Path(args.root).resolve();out=Path(args.output).resolve()
    out.mkdir(parents=True,exist_ok=False)
    hf=fixture(root) if args.model=='tiny' else Path(os.environ['PRECISION_PRETRAINED_MODEL'])
    versions={n:metadata.version(n) for n in ['torch','transformers','megatron-bridge','megatron-core','transformer-engine']}
    assert versions['megatron-bridge'].startswith('0.2.0')
    assert versions['megatron-core'].startswith('0.15.')
    assert versions['transformer-engine'].startswith('2.9.')
    assert not any(n.startswith(('torch_npu','mindspeed')) for n in sys.modules)
    files={}
    for path in sorted(hf.iterdir()):
        if path.is_file():
            h=hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda:stream.read(8<<20),b''):h.update(block)
            files[path.name]={'sha256':h.hexdigest(),'bytes':path.stat().st_size}
    dump(out/'checkpoint-identity.json',{'files':files,'model_id':os.environ.get('PRECISION_BRIDGE_MODEL_ID','Qwen/Qwen3-0.6B') if args.model=='pretrained' else 'seeded-tiny-Qwen3','requested_revision':os.environ.get('PRECISION_BRIDGE_MODEL_REVISION',os.environ.get('PRECISION_MODEL_REVISION')),'bridge_source_commit':'717c62de401bce92e913fd1c66c03f4e17bff265','local_source_revision_verified':False})
    dump(out/'runtime.json',{'versions':versions,'modules':{m.__name__:str(m.__file__) for m in [torch,megatron.bridge,megatron.core,transformer_engine]},'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(),'rank':0,'world_size':1,'tensor_parallel':1,'pipeline_parallel':1,'official_upstream_only':True})
    bridge=AutoBridge.from_hf_pretrained(str(hf))
    provider=bridge.to_megatron_provider(load_weights=True)
    provider.kv_channels=int(bridge.hf_pretrained.config.head_dim)
    provider.tensor_model_parallel_size=1;provider.pipeline_model_parallel_size=1
    provider.seq_length=16;provider.gradient_accumulation_fusion=False
    provider.cross_entropy_loss_fusion=False;provider.masked_softmax_fusion=False
    provider.bias_activation_fusion=False;provider.bias_dropout_fusion=False
    provider.attention_backend=AttnBackend.unfused
    provider.hidden_dropout=0.0;provider.attention_dropout=0.0
    provider.bf16=True;provider.params_dtype=torch.bfloat16;provider.pipeline_dtype=torch.bfloat16
    provider.finalize()
    limit=0 if args.model=='tiny' else 4096
    def export(models,inventory=False):
        values={};mapping=[]
        for row in bridge.export_hf_weights(models,cpu=True,show_progress=False):
            name=row.param_name;weight=row.weight.detach()
            mapping.append({'logical':name,'native':row.megatron_param_name,'shape':list(weight.shape),'native_dtype':str(weight.dtype),'selected_flat_indices':'all' if not limit else [0,min(limit,weight.numel())]})
            values[name]=weight.cpu().clone() if not limit else weight.flatten()[:limit].cpu().clone()
        if inventory:dump(out/'logical-inventory.json',mapping)
        return values
    if args.mode=='convert':
        models=provider.provide_distributed_model(wrap_with_ddp=False)
        converted=export(models,inventory=True)
        bridge.save_megatron_model(models,out/'converted-native')
        torch.save(converted,out/'converted-initial.pt')
        dump(out/'conversion.json',{'checkpoint_saved':True,'checkpoint':str(out/'converted-native'),'logical_tensors':len(converted),'official_api':'AutoBridge -> provider.provide_distributed_model -> save_megatron_model','source_hf':str(hf),'sample_limit':limit})
        return
    checkpoint=Path(args.checkpoint).resolve()
    ids,mask,labels=batch(hf)
    class FixedDataset(torch.utils.data.Dataset):
        def __len__(self):return 4
        def __getitem__(self,index):return {'tokens':ids[0,:-1].clone(),'labels':ids[0,1:].clone(),'loss_mask':mask.clone(),'position_ids':torch.arange(16),'attention_mask':torch.triu(torch.ones((1,16,16),dtype=torch.bool),diagonal=1)}
    @dataclasses.dataclass
    class FixedData(DatasetProvider):
        seq_length:int=16
        skip_getting_attention_mask_from_dataset:bool=False
        def build_datasets(self,context):return FixedDataset(),None,None
    cfg=ConfigContainer(model=provider,train=TrainingConfig(train_iters=1,micro_batch_size=1,global_batch_size=1,eval_iters=0,eval_interval=1000),optimizer=OptimizerConfig(optimizer='sgd',lr=0.001,min_lr=0.001,weight_decay=0.0,sgd_momentum=0.0,clip_grad=0.0,bf16=True,params_dtype=torch.bfloat16,use_distributed_optimizer=False),scheduler=SchedulerConfig(lr_decay_style='constant',lr_decay_iters=1,start_weight_decay=0.0,end_weight_decay=0.0),logger=LoggerConfig(log_interval=1,log_throughput=False),checkpoint=CheckpointConfig(pretrained_checkpoint=str(checkpoint),finetune=True,save=str(out/'finetuned-native'),save_interval=1,save_optim=False,save_rng=False,load_optim=False,load_rng=False,save_tokenizer_assets=False),dataset=FixedData(dataloader_type='single',num_workers=0,pin_memory=False),tokenizer=TokenizerConfig(tokenizer_type='HuggingFaceTokenizer',tokenizer_model=str(hf)),dist=DistributedInitConfig(distributed_backend='nccl'),rng=RNGConfig(seed=20261022),ddp=DistributedDataParallelConfig(grad_reduce_in_fp32=True,overlap_grad_reduce=False))
    captures={'batch':{'input_ids':ids,'labels':labels,'attention_mask':torch.ones_like(ids)},'frozen_before':{},'frozen_after':{},'compute_loss_controls':{'framework':'bridge','reduction':'native loss sum and token count; normalized observation is derived','num_processes':1}}
    pretrain=importlib.import_module('megatron.bridge.training.pretrain')
    original_setup=pretrain.setup
    def observed_setup(*a,**kw):
        result=original_setup(*a,**kw)
        models=result.model;raw=unwrap_model(models)
        assert all(p.device.type=='cuda' for m in raw for p in m.parameters())
        captures['before']=export(models,inventory=True)
        converted=torch.load(checkpoint.parent/'converted-initial.pt',map_location='cpu',weights_only=True)
        assert set(converted)==set(captures['before']) and all(torch.equal(v,captures['before'][n]) for n,v in converted.items()),'Native checkpoint restore differs from converted initial state'
        captures['parameter_inventory']={n:{'shape':list(p.shape),'dtype':str(p.dtype),'trainable':p.requires_grad} for m in raw for n,p in m.named_parameters()}
        def logits_hook(module,pos,output):
            value=output[0] if isinstance(output,tuple) else output
            if value is not None:captures['logits']=value.detach().cpu().transpose(0,1).clone()
        raw[0].output_layer.register_forward_hook(logits_hook)
        step=result.optimizer.step
        def observed_step(*args,**kwargs):
            # main_grad is the true accumulated native FP32 gradient buffer.
            raw_grads={id(p):getattr(p,'main_grad',p.grad) for m in raw for p in m.parameters()}
            assert all(g is not None for g in raw_grads.values())
            returned=step(*args,**kwargs)
            captures['after']=export(models)
            saved=[(p,p.data) for m in raw for p in m.parameters()]
            try:
                for p,_ in saved:p.data=raw_grads[id(p)].detach()
                captures['gradients']=export(models)
            finally:
                for p,value in saved:p.data=value
            captures['optimizer_event']=cpu(returned)
            torch.save(captures,out/'native-captures.pt')
            return returned
        result.optimizer.step=observed_step
        # Write reference input BEFORE any forward/backward/update observation.
        torch.save({'before':captures['before'],'input_ids':ids,'labels':labels,'loss_mask':mask,'model_path':str(hf),'sample_limit':limit},out/'reference-input.pt')
        return result
    pretrain.setup=observed_setup
    def observed_forward(state,data_iterator,model,return_schedule_plan=False):
        value,loss_function=forward_step(state,data_iterator,model,return_schedule_plan)
        def observed_loss(*a,**kw):
            result=loss_function(*a,**kw)
            captures['native_loss_sum']=cpu(result[0]);captures['native_loss_token_count']=cpu(result[1])
            captures['loss']=cpu(result[0]/result[1])
            return result
        return value,observed_loss
    try:finetune(cfg,observed_forward)
    finally:pretrain.setup=original_setup
    assert bool(captures['optimizer_event'][0])
    assert all(torch.isfinite(g).all() for g in captures['gradients'].values())
    torch.save(captures,out/'native-captures.pt')
    dump(out/'native-completion.json',{'status':'native_execution_complete','entrypoint_returned':True,'entrypoint':'official megatron.bridge.training.finetune.finetune after save_megatron_model checkpoint conversion/restore','framework':'bridge','model':args.model,'precision':'bf16','device':'cuda:0','versions':versions,'model_path':str(hf),'training':'full native model; all coordinates' if not limit else 'full native model; first4096 flat elements per logical tensor retained','rank':0,'world_size':1,'sample_limit':limit,'checkpoint_initial_sampled_values_equal':True,'initial_state_check_coverage':'all values' if not limit else 'first4096 flat values in every logical tensor; no equality claim for omitted elements','thresholds':None})
    dump(out/'observations.json',{'optimizer_steps':1,'native_loss':float(captures['loss']),'native_returned_loss_sum':float(captures['native_loss_sum']),'native_returned_token_count':int(captures['native_loss_token_count']),'valid_targets':int(mask.sum()),'sample_limit':limit,'sampling_coverage':'all parameters retained' if not limit else 'complete logical inventory; first4096 elements of each logical parameter captured for gradients/stored updates','native_gradient_storage':'main_grad','native_parameter_storage':'bfloat16','rank':0,'world_size':1})


def reference(args):
    import torch
    from transformers import AutoModelForCausalLM
    assert not any(n.startswith(('megatron','transformer_engine','mindspeed','torch_npu')) for n in sys.modules)
    out=Path(args.output).resolve()
    data=torch.load(out/'reference-input.pt',map_location='cpu',weights_only=True)
    model=AutoModelForCausalLM.from_pretrained(data['model_path'],torch_dtype=torch.float32,attn_implementation='eager',local_files_only=True).train()
    limit=data['sample_limit']
    def select(t):return cpu(t) if not limit else cpu(t.flatten()[:limit])
    named=dict(model.named_parameters(remove_duplicate=False))
    before={n:select(named[n]) for n in data['before']}
    assert all(torch.equal(v.float(),before[n]) for n,v in data['before'].items()),'CPU model checkpoint starting values differ'
    optimizer=torch.optim.SGD(model.parameters(),lr=0.001,momentum=0,weight_decay=0)
    output=model(input_ids=data['input_ids'],labels=data['labels'],use_cache=False)
    output.loss.backward()
    result={'before':before,'loss':cpu(output.loss),'logits':cpu(output.logits),'gradients':{n:select(named[n].grad) for n in before}}
    optimizer.step();result['after']={n:select(named[n]) for n in before}
    torch.save(result,out/'reference-captures.pt')
    dump(out/'reference-execution.json',{'device':'cpu','compute':'fp32','same_initial_trainable_state':True,'same_initial_frozen_values':True,'uses_native_gradients_or_updates':False,'reference_input_contains_native_outcomes':False,'reference_input_fields':sorted(data),'native_imports_in_reference':False,'loss':float(output.loss),'sample_limit':limit,'reference_world_size':1})
    # Provide the generic exporter's explicit starting-input identity filename.
    import shutil
    shutil.copyfile(out/'reference-input.pt',out/'reference-input-captures.pt')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',required=True);p.add_argument('--mode',choices=['convert','train','reference'],required=True)
    p.add_argument('--model',choices=['tiny','pretrained'],default='tiny');p.add_argument('--output',required=True);p.add_argument('--checkpoint')
    a=p.parse_args()
    if a.mode=='reference':reference(a)
    else:native(a)
