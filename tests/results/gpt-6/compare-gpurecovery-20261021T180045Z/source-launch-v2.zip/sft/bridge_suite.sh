#!/usr/bin/env bash
# Official NVIDIA CUDA Bridge route. Native installs/conversion/training only.
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
RUN="${1:?Pass the current suite run directory}"
ENV="$HERE/environments/bridge-cuda-v020"
BASE_PYTHON="${BASE_PYTHON:-python3}"
mkdir -p "$RUN/bridge-environment"
if [[ ! -x "$ENV/bin/python" ]]; then "$BASE_PYTHON" -m venv "$ENV"; fi
PY="$ENV/bin/python"
nvcc --version > "$RUN/bridge-environment/nvcc.txt" 2>&1
"$PY" -m pip install --upgrade pip 'setuptools<80' wheel pybind11 ninja packaging > "$RUN/bridge-environment/build-tools.log" 2>&1
"$PY" -m pip install torch==2.9.0 torchvision==0.24.0 --index-url https://download.pytorch.org/whl/cu128 > "$RUN/bridge-environment/torch.log" 2>&1
"$PY" -m pip install --dry-run --no-build-isolation --report "$RUN/bridge-environment/resolver.json" 'megatron-bridge @ https://github.com/NVIDIA-NeMo/Megatron-Bridge/archive/717c62de401bce92e913fd1c66c03f4e17bff265.tar.gz' 'megatron-core[dev,mlm]==0.15.0' 'transformer-engine[pytorch]==2.9.0' 'nvidia-modelopt[torch]==0.37.0' numpy==1.26.4 pyarrow==21.0.0 > "$RUN/bridge-environment/resolver.log" 2>&1
MAX_JOBS=4 NVTE_FRAMEWORK=pytorch "$PY" -m pip install --no-build-isolation 'megatron-bridge @ https://github.com/NVIDIA-NeMo/Megatron-Bridge/archive/717c62de401bce92e913fd1c66c03f4e17bff265.tar.gz' 'megatron-core[dev,mlm]==0.15.0' 'transformer-engine[pytorch]==2.9.0' 'nvidia-modelopt[torch]==0.37.0' numpy==1.26.4 pyarrow==21.0.0 > "$RUN/bridge-environment/install.log" 2>&1
"$PY" -m pip freeze --all > "$RUN/bridge-environment/freeze.txt"
"$PY" -m pip check > "$RUN/bridge-environment/check.txt" 2>&1
export PYTHONPATH="$HERE${PYTHONPATH:+:$PYTHONPATH}"
export CUDA_VISIBLE_DEVICES="${PRECISION_BRIDGE_DEVICE:-0}"
for model in tiny pretrained; do
  converted="$RUN/bridge-$model-convert"
  trained="$RUN/bridge-$model-bf16/rank-0"
  "$PY" -m torch.distributed.run --standalone --nnodes=1 --nproc-per-node=1 "$HERE/bridge_gpu_sft.py" --root "$HERE" --mode convert --model "$model" --output "$converted" > "$RUN/bridge-$model-convert.log" 2>&1
  "$PY" -m torch.distributed.run --standalone --nnodes=1 --nproc-per-node=1 "$HERE/bridge_gpu_sft.py" --root "$HERE" --mode train --model "$model" --checkpoint "$converted/converted-native" --output "$trained" > "$RUN/bridge-$model-train.log" 2>&1
  CUDA_VISIBLE_DEVICES='' "$PY" -B "$HERE/bridge_gpu_sft.py" --root "$HERE" --mode reference --model "$model" --output "$trained" > "$RUN/bridge-$model-reference.log" 2>&1
  "$PY" -B -c 'import sys; from pathlib import Path; from export_compare_sft import export; print(export(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3])))' "$trained" "$trained/metrics" "${PRECISION_TOOLS:-$HERE/toolchain}" > "$RUN/bridge-$model-export.log" 2>&1
done
