"""Independent CPU FP32 RL execution followed by skill comparator/export/replay.

The reference reads only fixed native-generated histories/masks/effective old
anchors and declared synthetic reward inputs. Native loss/gradients/after-state
are loaded only AFTER independent forward/backward/clipping/AdamW has finished.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np
import torch
from transformers import AutoModelForCausalLM

ap = argparse.ArgumentParser()
ap.add_argument('--native-output', required=True)
ap.add_argument('--skill-root', required=True)
a = ap.parse_args()
native = Path(a.native_output).resolve()
skill = Path(a.skill_root).resolve()
identity = json.loads((native / 'identity.json').read_text())
is_open = identity['framework'] == 'official OpenRLHF/OpenRLHF'
is_nemo = identity['framework'] == 'official NVIDIA-NeMo/RL'
is_roll = identity['framework'] == 'official alibaba/ROLL'
assert identity['framework'] in ['official modelscope/ms-swift', 'official OpenRLHF/OpenRLHF', 'official NVIDIA-NeMo/RL', 'official alibaba/ROLL']
assert not any(x in sys.modules for x in ['swift', 'openrlhf', 'torch_npu', 'nemo_reinforcer', 'roll'])
torch.set_num_threads(2)


def read_event(event, tensors=True):
    paths = sorted(native.glob(event + '-pid*-*.json'))
    if event == 'scores' and len(paths) > 1:
        paths = [p for p in paths if json.loads(p.read_text()).get('current_policy_with_grad')]
    assert len(paths) == 1, (event, paths)
    metadata = json.loads(paths[0].read_text())
    return (torch.load(native / metadata['data'], map_location='cpu', weights_only=True), metadata) if tensors else metadata


fixed, fixed_meta = read_event('fixed_inputs')
reward = None if is_open or is_roll else read_event('reward')[0]
inputs = dict(fixed['model_inputs'])
inputs.pop('logits_to_keep', None)
inputs.pop('labels', None)
inputs['use_cache'] = False
mask = fixed['completion_mask'].bool()
k = int(fixed['logits_to_keep'])
temperature = fixed_meta['temperature']
group_size = fixed_meta['group_size']
assert fixed_meta['loss_type'] == 'grpo' and fixed_meta['scale_rewards'] == 'group'
model = AutoModelForCausalLM.from_pretrained(identity['model'], torch_dtype=torch.float32,
    attn_implementation='eager', local_files_only=True, device_map={'': 'cpu'})
if identity['dtype'] == 'bfloat16':
    # Match stored initial representation using independently loaded source weights.
    model.to(torch.bfloat16).to(torch.float32)
model.train()
model.config.use_cache = False
names = dict(model.named_parameters())
# The native optimizer's coordinate declaration is metadata only; no native state
# arrays are consumed to choose or initialize the reference execution.
optimizer_meta = read_event('optimizer', tensors=False)
coordinates = optimizer_meta['coordinates']
assert all(c['name'] in names for c in coordinates), coordinates
selected = [(c['name'], names[c['name']]) for c in coordinates]
before = {n: p.detach().reshape(-1)[:8192].clone() for n, p in selected}
if is_open:
    reward_inputs, _ = read_event('reward_inputs')
    total = sum(len(item['indices']) for item in reward_inputs)
    rewards = torch.empty(total, dtype=torch.float32)
    for item in reward_inputs:
        for row, index in enumerate(item['indices']):
            rewards[index] = item['rewards'][row].float()
    reward_call, _ = read_event('reward')
    independent_rewards = torch.tensor([float(i % 2) + float(sum(ord(c) for c in str(text)) % 997) / 9970
        for i, text in enumerate(reward_call['queries'])], dtype=torch.float32)
    assert torch.equal(independent_rewards, rewards), 'Effective reward dependency disagrees with independent reward formula'
    assert fixed_meta['init_kl_coef'] == 0 and fixed_meta['reward_clip_range'] == [-10, 10]
    groups = rewards.view(-1, group_size)
    ordered_advantages = ((groups - groups.mean(-1, keepdim=True)) / (groups.std(-1, keepdim=True) + 1e-9)).reshape(-1)
    assert float(ordered_advantages.abs().max()) < 10, 'Unexpected reward clipping branch'
    order = fixed['sample_ids'].long()
    assert sorted(order.tolist()) == list(range(total)), 'Stable sample IDs must cover the entire native group'
    advantages = ordered_advantages[order]
elif is_roll:
    rewards = torch.stack([ids.float().mean() / 100. for ids in fixed['response_ids']])
    groups = rewards.view(-1, group_size)
    assert len(groups) == 1, 'This ROLL adapter deliberately captures one complete prompt group'
    advantages = ((groups - groups.mean(-1, keepdim=True)) / (groups.std(-1, keepdim=True) + 1e-6)).reshape(-1)
else:
    rewards = torch.tensor([float(i % 2) + float(sum(ord(c) for c in str(text)) % 997) / 9970
                            for i, text in enumerate(reward['completions'])], dtype=torch.float32)
    assert torch.equal(rewards, torch.tensor(reward['values'], dtype=torch.float32)), 'Reward formula mismatch'
    groups = rewards.view(-1, group_size)
    std = groups.std(-1, keepdim=True, unbiased=not is_nemo)
    advantages = ((groups - groups.mean(-1, keepdim=True)) / (std + (0. if is_nemo else 1e-4))).reshape(-1)
assert advantages.numel() == inputs['input_ids'].shape[0], 'Fixed group/order coverage must be complete'
logits = model(**inputs).logits[:, -(k + 1):-1, :] / temperature
labels = inputs['input_ids'][:, -k:]
logps = logits.log_softmax(-1).gather(-1, labels.unsqueeze(-1)).squeeze(-1)
old = logps.detach() if fixed['old_per_token_logps'] is None else fixed['old_per_token_logps'].float()
ratio = (logps - old).exp()
clip_ratio = ratio.clamp(1 - fixed_meta['epsilon_low'], 1 + fixed_meta['epsilon_high'])
terms = -torch.minimum(ratio * advantages[:, None], clip_ratio * advantages[:, None])
reduction = fixed_meta.get('loss_reduction', 'seq-mean-token-mean')
assert reduction in ['token-mean', 'seq-mean-token-mean']
loss = ((terms * mask).sum() / mask.sum()) if reduction == 'token-mean' else ((terms * mask).sum(-1) / mask.sum(-1).clamp(min=1)).mean()
loss.backward()
pre = {n: None if p.grad is None else p.grad.detach().reshape(-1)[:8192].clone() for n, p in selected}
full_pre = sum(p.grad.double().square().sum().item() for p in model.parameters() if p.grad is not None) ** .5
native_groups = optimizer_meta['groups']
# Both Swift native groups have equal AdamW settings; weight_decay explicitly zero.
settings = {key: native_groups[0][key] for key in ['lr', 'betas', 'eps', 'weight_decay']}
assert settings['weight_decay'] == 0 and all(all(g[key] == value for key, value in settings.items()) for g in native_groups)
torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
post = {n: None if p.grad is None else p.grad.detach().reshape(-1)[:8192].clone() for n, p in selected}
update_parameters = {n: torch.nn.Parameter(before[n].clone()) for n, _ in selected}
for n, parameter in update_parameters.items():
    parameter.grad = post[n].clone() if post[n] is not None else None
# AdamW is elementwise after the complete-model gradient clipping operation.
# Execute exactly the declared coordinates to bound CPU optimizer-state memory.
optimizer = torch.optim.AdamW(update_parameters.values(), **settings)
optimizer.step()
after = {n: p.detach().clone() for n, p in update_parameters.items()}
if identity['dtype'] == 'bfloat16':
    after = {n: p.to(torch.bfloat16).float() for n, p in after.items()}
reference_complete_time = time.time()
reference = {'before': before, 'after': after, 'preclip_gradients': pre, 'postclip_gradients': post,
    'loss': loss.detach(), 'logps': logps.detach(), 'rewards': rewards, 'advantages': advantages,
    'ratio': ratio.detach(), 'clipped_ratio': clip_ratio.detach(), 'full_preclip_norm': full_pre,
    'mask': mask, 'reference_complete_time': reference_complete_time}
reference_dir = native / 'reference'
reference_dir.mkdir()
torch.save(reference, reference_dir / 'independent.pt')

# Independent computation finished. Native current outputs are first consumed here.
observed, _ = read_event('optimizer')
clip, clip_meta = read_event('clip')
objective, _ = read_event('objective')
scores, _ = read_event('scores')
native_scores = scores['result'] if is_open else scores['result'][0]
out = native / 'portable'
out.mkdir()
provenance = out / 'provenance'
provenance.mkdir()
for path in sorted(native.glob('*.json')):
    shutil.copy2(path, provenance / path.name)
for path in sorted(native.glob('*.txt')):
    shutil.copy2(path, provenance / path.name)
for path in sorted(Path(__file__).resolve().parent.glob('*.py')):
    shutil.copy2(path, provenance / path.name)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    return path


input_hash = hashlib.sha256((native / fixed_meta['data']).read_bytes()).hexdigest()
common = {'model': identity['model'], 'inputs': input_hash, 'scope': 'first native GRPO optimizer event; sampled named parameters',
          'state': 'independent source reload cast to native initial storage representation'}
conditions = {'native': {'numerics': 'actual CUDA native ' + identity['dtype']},
              'reference': {'numerics': 'independent CPU FP32'}}
for side in ['native', 'reference']:
    folder = out / side
    folder.mkdir()
    write(folder / 'environment.json', {'rank': 0, 'versions': identity['versions'] if side == 'native' else {'torch': torch.__version__},
        'actual': {**common, **conditions[side]}})
    write(folder / 'status.json', {'rank': 0, 'status': 'completed'})

replay = []
reports = {}
for stage, key in [('gradients', 'preclip_gradients'), ('postclip-gradients', 'postclip_gradients'), ('updates', None)]:
    tensors = [{'name': n, 'shape': [before[n].numel()], 'present': pre[n] is not None} for n, _ in selected]
    contract = write(out / (stage + '.contract.json'), {'schema_version': 2, 'kind': 'tensors', 'common': common,
        'side_conditions': conditions, 'thresholds': None, 'expected_ranks': {'native': [0], 'reference': [0]},
        'stage': stage, 'tensors': tensors})
    for side in ['native', 'reference']:
        folder = out / side
        entries = []
        for index, tensor in enumerate(tensors):
            name = tensor['name']
            entry = {**tensor, 'shards': []}
            if tensor['present']:
                shard = {'offset': 0}
                arrays = {'before': observed['before'][name] if side == 'native' else before[name],
                          'after': observed['after'][name] if side == 'native' else after[name]} if stage == 'updates' else {
                          'value': (clip[key][name] if stage == 'gradients' else observed[key][name]) if side == 'native' else reference[key][name]}
                for kind, array in arrays.items():
                    filename = f'{stage}-{index:02d}-{kind}.npy'
                    np.save(folder / filename, array.float().numpy(), allow_pickle=False)
                    shard[kind] = {'path': filename}
                entry['shards'] = [shard]
            entries.append(entry)
        manifest = {'schema_version': 2, 'kind': 'tensors', 'side': side, 'common': common,
            'expected_ranks': [0], 'ranks': [{'rank': 0, 'environment': 'environment.json', 'status': 'status.json'}],
            'stage': stage, 'tensors': entries}
        if stage == 'updates':
            manifest['events'] = {'policy': 'applied'}
        write(folder / (stage + '.manifest.json'), manifest)
    report = out / (stage + '.report.json')
    subprocess.run([sys.executable, str(skill / 'scripts' / 'compare_tensors.py'), '--contract', str(contract),
        '--side-a', str(out / 'native' / (stage + '.manifest.json')), '--side-b', str(out / 'reference' / (stage + '.manifest.json')),
        '--output', str(report)], check=True)
    reports[stage] = json.loads(report.read_text())
    replay.append({'name': stage, 'operation': 'compare_tensors', 'inputs': {'contract': contract.name,
        'side_a': 'native/' + stage + '.manifest.json', 'side_b': 'reference/' + stage + '.manifest.json'},
        'expected': {'status': 'no_thresholds', 'global': reports[stage]['global']}})

targets = []
score_rows = {'native': [], 'reference': []}
for row, column in mask.nonzero().tolist():
    coordinate = {'sample': str(row), 'position': inputs['input_ids'].shape[1] - k + column,
                  'token': int(labels[row, column])}
    targets.append(coordinate)
    for side, values in [('native', native_scores), ('reference', logps.detach())]:
        score_rows[side].append({**coordinate, 'logprob': float(values[row, column])})
contract = write(out / 'target-scores.contract.json', {'schema_version': 1, 'kind': 'target-scores', 'common': common,
    'side_conditions': conditions, 'thresholds': None, 'expected_ranks': {'native': [0], 'reference': [0]}, 'targets': targets})
for side in ['native', 'reference']:
    write(out / side / 'target-scores.manifest.json', {'schema_version': 1, 'kind': 'target-scores', 'common': common,
        'side': side, 'expected_ranks': [0], 'ranks': [{'rank': 0, 'environment': 'environment.json', 'status': 'status.json'}],
        'scores': score_rows[side]})
subprocess.run([sys.executable, str(skill / 'scripts' / 'compare_target_scores.py'), '--contract', str(contract),
    '--side-a', str(out / 'native/target-scores.manifest.json'), '--side-b', str(out / 'reference/target-scores.manifest.json'),
    '--output', str(out / 'target-scores.report.json')], check=True)
reports['target-scores'] = json.loads((out / 'target-scores.report.json').read_text())
replay.append({'name': 'target-scores', 'operation': 'compare_target_scores', 'inputs': {
    'contract': contract.name, 'side_a': 'native/target-scores.manifest.json', 'side_b': 'reference/target-scores.manifest.json'},
    'expected': {'status': 'no_thresholds', 'metrics': reports['target-scores']['metrics']}})
write(out / 'REPLAY.json', {'cases': replay})
summary = {'status': 'independent_reference_and_comparison_complete', 'reference_device': 'cpu',
    'reference_dtype': 'float32', 'native_device': identity['device'], 'native_dtype': identity['dtype'],
    'reference_complete_before_native_output_arrays_read': True, 'reference_complete_time': reference_complete_time,
    'initial_values_exact_equal': all(torch.equal(before[n], observed['before'][n].float()) for n in before),
    'loss': {'reference': float(loss.detach()), 'native': float(objective['result'][0]),
             'abs_error': abs(float(loss.detach()) - float(objective['result'][0]))},
    'full_preclip_norm': {'reference_fp64': full_pre, 'native_fp64': clip_meta['full_fp64_preclip_norm'],
                          'native_returned': float(clip['native_returned_norm'])},
    'loss_reduction': reduction, 'reward_formula_independently_checked': not is_roll,
    'reference_optimizer_scope': 'declared flattened coordinates; elementwise AdamW after full model backward and clipping',
    'coverage': {'trajectories': mask.shape[0], 'groups': len(groups), 'actions': int(mask.sum()),
        'sampled_parameter_count': len(selected), 'sampled_elements': sum(x.numel() for x in before.values()),
        'full_model_elements': sum(p.numel() for p in model.parameters()),
        'full_model_parameter_count': len(names),
        'native_optimizer_full_parameter_elements': optimizer_meta['full_parameter_elements'],
        'selection': 'first 12 native optimizer coordinates; flattened [0,min(8192,numel)) each', 'optimizer_events': 1},
    'reward_quality_claimed': False, 'thresholds': None}
write(out / 'summary.json', summary)
assert summary['initial_values_exact_equal'], 'Initial sample values differ'
bundle = native / 'evidence.zip'
subprocess.run([sys.executable, str(skill / 'scripts/evidence_bundle.py'), 'pack', str(out), str(bundle)], check=True)
subprocess.run([sys.executable, str(skill / 'scripts/evidence_bundle.py'), 'verify', str(bundle)], check=True)
subprocess.run([sys.executable, str(skill / 'scripts/replay_bundle.py'), '--bundle', str(bundle),
    '--output-root', str(native / 'replay')], check=True)
print(json.dumps(summary, indent=2))
