"""Load the typed JSON/NPY fixed-input supplement; optionally recompute CPU loss.

python fixed_inputs_loader.py CASE_DIRECTORY --model ORIGINAL_CHECKPOINT
The old-policy anchors are fixed native inputs. Current scores and rewards are
independently recomputed; no captured current score/loss/gradient/update is read.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch


def load_tree(directory, node):
    directory = Path(directory)
    kind = node['type']
    if kind == 'tensor':
        path = directory / node['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == node['file_sha256']
        array = np.load(path, allow_pickle=False)
        assert list(array.shape) == node['shape']
        assert hashlib.sha256(array.tobytes(order='C')).hexdigest() == node['storage_sha256']
        value = torch.from_numpy(array.copy())
        dtype = getattr(torch, node['torch_dtype'].removeprefix('torch.'))
        if node['encoding'] == 'uint16-bfloat16-bits':
            value = value.view(torch.bfloat16)
        assert value.dtype == dtype
        return value
    if kind == 'dict':
        return {load_tree(directory, k): load_tree(directory, v) for k, v in node['items']}
    if kind in ['list', 'tuple']:
        values = [load_tree(directory, item) for item in node['items']]
        return tuple(values) if kind == 'tuple' else values
    assert kind == 'scalar'
    return node['value']


def load_case(directory):
    directory = Path(directory)
    descriptor = json.loads((directory / 'inputs.json').read_text())
    return load_tree(directory, descriptor['tree']), descriptor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case')
    parser.add_argument('--model', help='Original checkpoint; omit for input-only validation')
    args = parser.parse_args()
    data, descriptor = load_case(args.case)
    fixed = data['fixed_inputs']
    assert fixed['old_per_token_logps'] is not None
    reward = data['reward']
    values = torch.tensor([float(i % 2) + float(sum(ord(c) for c in str(text)) % 997) / 9970
                           for i, text in enumerate(reward['completions'])], dtype=torch.float32)
    assert torch.equal(values, data['native_rewards'].reshape(-1).float())
    group = values.view(-1, descriptor['objective']['group_size'])
    advantages = ((group - group.mean(-1, keepdim=True)) / (group.std(-1, keepdim=True) + 1e-4)).reshape(-1)
    native_advantages = data['native_group_advantages']
    assert advantages.shape == native_advantages.shape
    report = {'input_bits_verified': True, 'samples': len(values),
              'actions': int(fixed['completion_mask'].sum()),
              'old_policy': 'frozen native effective anchors; independent CPU current policy',
              'independent_group_advantages_max_abs_difference': float((advantages - native_advantages).abs().max())}
    if args.model:
        from transformers import AutoModelForCausalLM
        torch.set_num_threads(2)
        model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=torch.float32,
            attn_implementation='eager', local_files_only=True, device_map={'': 'cpu'})
        if descriptor['native_parameter_dtype'] == 'bfloat16':
            model.to(torch.bfloat16).to(torch.float32)
        model.train()
        inputs = dict(fixed['model_inputs'])
        inputs.pop('logits_to_keep', None)
        inputs.pop('labels', None)
        inputs['use_cache'] = False
        k = int(fixed['logits_to_keep'])
        logits = model(**inputs).logits[:, -(k + 1):-1, :] / descriptor['objective']['temperature']
        labels = inputs['input_ids'][:, -k:]
        current = logits.log_softmax(-1).gather(-1, labels.unsqueeze(-1)).squeeze(-1)
        ratio = (current - fixed['old_per_token_logps'].float()).exp()
        clipped = ratio.clamp(1 - descriptor['objective']['epsilon_low'], 1 + descriptor['objective']['epsilon_high'])
        terms = -torch.minimum(ratio * advantages[:, None], clipped * advantages[:, None])
        mask = fixed['completion_mask'].bool()
        loss = ((terms * mask).sum(-1) / mask.sum(-1).clamp(min=1)).mean()
        loss.backward()
        norm = sum(p.grad.double().square().sum().item() for p in model.parameters() if p.grad is not None) ** .5
        report.update({'independent_cpu_loss': float(loss.detach()), 'full_preclip_gradient_norm': norm})
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
