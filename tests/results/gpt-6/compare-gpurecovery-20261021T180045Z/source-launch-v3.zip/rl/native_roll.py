"""Official ROLL RLVRPipeline + vLLM/FSDP2, with a declared custom toy reward."""
import argparse
import importlib.metadata as md
import json
import os
from pathlib import Path

import torch
import capture
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
capture.install_optimizer_capture()

from roll.distributed.executor.worker import Worker
from roll.distributed.scheduler.decorator import Dispatch, register
from roll.distributed.scheduler.protocol import DataProto
from roll.pipeline.rlvr.actor_worker import ActorWorker
import roll.pipeline.rlvr.actor_worker as native_actor_module


class TokenMeanRewardWorker(Worker):
    @register(dispatch_mode=Dispatch.ONE_TO_ALL)
    def initialize(self, pipeline_config):
        super().initialize(pipeline_config)

    @register(dispatch_mode=Dispatch.DP_MP_COMPUTE, clear_cache=False)
    def compute_rewards(self, data):
        response_ids = data.batch['responses']
        valid = data.batch.get('response_mask', torch.ones_like(response_ids))[:, -response_ids.shape[1]:]
        scores = (response_ids.float() * valid).sum(-1) / valid.sum(-1).clamp(min=1) / 100.
        capture.save('reward', {'response_ids': response_ids, 'response_mask': valid, 'values': scores},
            semantics='synthetic generated-token mean / 100; validates execution only; no answer quality claim')
        return DataProto.from_dict(tensors={'scores': scores, 'response_level_rewards': scores.clone(),
            'token_level_rewards': torch.zeros_like(response_ids, dtype=torch.float32)}, meta_info={'metrics': {}})


class ObservedActorWorker(ActorWorker):
    def loss_func(self, data, output_tensor):
        capture.NAMES.update({id(p): n for n, p in self.strategy.model.named_parameters()})
        holder = {}
        original_old = self.get_old_log_probs_with_cache

        def old_scores(*args, **kwargs):
            result = original_old(*args, **kwargs)
            holder['old'] = result.detach()
            return result
        self.get_old_log_probs_with_cache = old_scores
        try:
            result = super().loss_func(data, output_tensor)
        finally:
            self.get_old_log_probs_with_cache = original_old
        mask = data.batch.get('final_response_mask', data.batch['response_mask'][:, 1:])
        response_mask = data.batch['response_mask'][:, 1:].bool()
        ids = data.batch['input_ids']
        model_inputs = {'input_ids': ids, 'attention_mask': data.batch['attention_mask']}
        if 'position_ids' in data.batch:
            model_inputs['position_ids'] = data.batch['position_ids']
        capture.save('fixed_inputs', {'model_inputs': model_inputs, 'completion_mask': mask,
            'logits_to_keep': ids.shape[1] - 1, 'old_per_token_logps': holder['old'],
            'response_ids': [row[valid].detach().cpu() for row, valid in zip(ids[:, 1:], response_mask)]},
            group_size=4, loss_type='grpo', temperature=1., scale_rewards='group', group_epsilon=1e-6,
            epsilon_low=float(self.pipeline_config.pg_clip), epsilon_high=float(self.pipeline_config.pg_clip),
            loss_reduction=self.pipeline_config.loss_agg_mode, native_pipeline_config=vars(self.pipeline_config))
        # This is a passive full-vocabulary normalization of actual returned native logits.
        scores = output_tensor[:, :-1].float().log_softmax(-1).gather(-1, ids[:, 1:, None]).squeeze(-1)
        capture.save('scores', {'result': [scores]}, device=str(output_tensor.device), dtype=str(output_tensor.dtype))
        capture.save('objective', {'result': result})
        capture.save('inventory', None, parameters=[{'name': n, 'shape': list(p.shape), 'numel': p.numel(),
            'dtype': str(p.dtype), 'device': str(p.device), 'trainable': p.requires_grad}
            for n, p in self.strategy.model.named_parameters()])
        capture.save('rollout', {'input_ids': ids, 'response_mask': data.batch['response_mask']},
            semantics='native vLLM-generated histories delivered by RLVRPipeline to FSDP2 actor')
        return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    a = ap.parse_args()
    assert torch.cuda.is_available() and torch.cuda.device_count() >= 2
    out = capture.OUT
    data = out / 'train.jsonl'
    data.write_text(json.dumps({'messages': [{'role': 'user', 'content': 'Name a random color.'}],
        'tag': 'toy', 'ground_truth': '', 'data_source': 'synthetic-workflow'}) + '\n')
    model = {'model_name_or_path': a.model, 'dtype': 'fp32', 'disable_gradient_checkpointing': True,
             'attn_implementation': 'eager'}
    infer_model = {**model, 'dtype': 'bf16'}
    data_cfg = {'template': 'native', 'messages': 'messages', 'preprocessing_num_workers': 1,
                'rollout_dataloader_num_workers': 0}
    system_envs = {k: v for k, v in os.environ.items() if k.startswith('GPU_RL_') or
                   k in ['PYTHONPATH', 'PATH', 'LD_LIBRARY_PATH', 'HF_HOME', 'OMP_NUM_THREADS']}
    cfg = {'exp_name': 'precision-gpu-rl', 'seed': 20261022, 'num_nodes': 1, 'num_gpus_per_node': 2,
        'max_steps': 1, 'save_steps': -1, 'eval_steps': -1, 'logging_steps': 1, 'track_with': 'stdout',
        'tracker_kwargs': {}, 'output_dir': str(out / 'native'), 'logging_dir': str(out / 'logs'),
        'pretrain': a.model, 'reward_pretrain': a.model,
        'checkpoint_config': {'type': 'file_system', 'output_dir': str(out / 'checkpoint')},
        'transfer_backend': {'backend_name': None, 'backend_config': {}}, 'rollout_batch_size': 1,
        'num_return_sequences_in_group': 4, 'prompt_length': 96, 'response_length': 8, 'ppo_epochs': 1,
        'adv_estimator': 'grpo', 'enable_reference': False, 'use_kl_loss': False, 'init_kl_coef': 0.,
        'whiten_rewards': False, 'whiten_advantages': False, 'difficulty_mask': False, 'max_len_mask': False,
        'generate_opt_level': 0, 'is_num_return_sequences_expand': True, 'max_running_requests': 4,
        'rollout_dump_dir': str(out / 'rollouts'), 'rpc_timeout': 300, 'system_envs': system_envs,
        'loss_agg_mode': 'seq-mean-token-mean', 'max_grad_norm': 1.,
        'actor_train': {'worker_cls': 'native_roll.ObservedActorWorker', 'model_args': model,
            'use_sequence_packing': False, 'training_args': {'learning_rate': .001, 'weight_decay': 0.,
                'per_device_train_batch_size': 4, 'gradient_accumulation_steps': 1, 'warmup_steps': 0,
                'num_train_epochs': 1, 'lr_scheduler_type': 'constant'},
            'data_args': {**data_cfg, 'file_name': [str(data)], 'domain_interleave_probs': {'toy_reward': 1.}},
            'strategy_args': {'strategy_name': 'fsdp2_train', 'strategy_config': {'enable_mix_precision': True,
                'param_dtype': 'float32', 'reduce_dtype': 'float32', 'fsdp_size': 1,
                'reshard_after_forward': True, 'offload_policy': False}}, 'device_mapping': [0],
            'infer_batch_size': 4, 'offload_nccl': False},
        'actor_infer': {'model_args': infer_model, 'data_args': data_cfg,
            'generating_args': {'max_new_tokens': 8, 'top_p': 1., 'top_k': 0, 'temperature': 1.,
                'do_sample': True, 'num_beams': 1, 'num_return_sequences': 4},
            'strategy_args': {'strategy_name': 'vllm', 'strategy_config': {'gpu_memory_utilization': .2,
                'max_model_len': 128, 'enforce_eager': True, 'max_num_seqs': 4}},
            'device_mapping': [1], 'infer_batch_size': 4, 'offload_nccl': False},
        'reference': {'model_args': model, 'strategy_args': {'strategy_name': 'hf_infer', 'strategy_config': {}},
            'device_mapping': [0], 'offload_nccl': False},
        'rewards': {'toy_reward': {'worker_cls': 'native_roll.TokenMeanRewardWorker', 'model_args': model,
            'data_args': data_cfg, 'tag_included': ['toy'], 'world_size': 1, 'infer_batch_size': 4,
            'offload_nccl': False}}}
    (out / 'config.json').write_text(json.dumps(cfg, indent=2))
    (out / 'identity.json').write_text(json.dumps({'model': str(Path(a.model).resolve()), 'dtype': 'float32',
        'framework': 'official alibaba/ROLL', 'source_pin': 'd3506ea9e280ae720fb74df9f82db6efac1c72d5',
        'source_identity': capture.source_identity(native_actor_module),
        'runtime': capture.runtime(['torch', 'roll', 'transformers', 'vllm', 'ray']),
        'entrypoint': 'roll.pipeline.rlvr.rlvr_pipeline.RLVRPipeline.run', 'torch': torch.__version__,
        'cuda': torch.version.cuda, 'device': torch.cuda.get_device_name(), 'native_operators_replaced': False,
        'rollout_dtype': 'bfloat16', 'versions': {n: md.version(n) for n in ['torch', 'roll', 'transformers', 'vllm', 'ray']}}, indent=2))
    import ray
    from dacite import from_dict
    from roll.pipeline.rlvr.rlvr_config import RLVRConfig
    from roll.pipeline.rlvr.rlvr_pipeline import RLVRPipeline
    from roll.utils.constants import RAY_NAMESPACE
    ray.init(address='local', num_cpus=8, num_gpus=2, namespace=RAY_NAMESPACE,
             include_dashboard=False, runtime_env={'env_vars': system_envs})
    try:
        pipeline = RLVRPipeline(pipeline_config=from_dict(data_class=RLVRConfig, data=cfg))
        pipeline.run()
        capture.save('train_returned', None)
    finally:
        ray.shutdown()
    assert all(list(out.glob(name + '-pid*-*.json')) for name in
               ['rollout', 'reward', 'fixed_inputs', 'objective', 'scores', 'clip', 'optimizer'])
    events = [json.loads(p.read_text()) for p in out.glob('optimizer-pid*-*.json')]
    assert len(events) == 1 and events[0]['nonzero_update']
    (out / 'completion.json').write_text(json.dumps({'status': 'native_cuda_workflow_complete',
        'optimizer_events': len(events), 'reward_quality_claimed': False}, indent=2))


if __name__ == '__main__':
    main()
