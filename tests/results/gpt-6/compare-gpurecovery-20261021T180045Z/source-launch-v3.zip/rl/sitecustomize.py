"""Delay observational OpenRLHF wrappers until native worker modules import."""
import importlib.abc
import importlib.machinery
import os
import sys

MODULES = {'openrlhf.trainer.ray.ppo_actor', 'openrlhf.trainer.ppo_utils.experience_maker',
    'openrlhf.models.actor', 'openrlhf.models.loss',
    'deepspeed.runtime.bf16_optimizer'}


class CaptureFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        nemo_modules = {'nemo_reinforcer.distributed.virtual_cluster',
            'nemo_reinforcer.data.hf_datasets.openmathinstruct2', 'nemo_reinforcer.environments.math_environment',
            'nemo_reinforcer.algorithms.loss_functions', 'nemo_reinforcer.models.policy.dtensor_policy_worker'}
        is_nemo = os.environ.get('GPU_RL_CAPTURE_NEMO') == '1' and fullname in nemo_modules
        is_areal = os.environ.get('GPU_RL_CAPTURE_AREAL') == '1' and fullname in {
            'areal.trainer.ppo.actor', 'areal.engine.fsdp_engine'}
        if not is_nemo and not is_areal and not (os.environ.get('GPU_RL_CAPTURE_OPEN') == '1' and fullname in MODULES):
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        if spec and spec.loader:
            original = spec.loader.exec_module

            def execute(module):
                original(module)
                if is_areal:
                    from observe_areal import patch_actor, patch_fsdp
                    (patch_actor if fullname.endswith('.actor') else patch_fsdp)(module)
                    return
                if is_nemo:
                    from observe_nemo import patch
                else:
                    from observe_openrlhf import patch
                patch(fullname, module)
            spec.loader.exec_module = execute
        return spec


if any(os.environ.get(key) == '1' for key in ['GPU_RL_CAPTURE_OPEN', 'GPU_RL_CAPTURE_NEMO', 'GPU_RL_CAPTURE_AREAL']):
    sys.meta_path.insert(0, CaptureFinder())
