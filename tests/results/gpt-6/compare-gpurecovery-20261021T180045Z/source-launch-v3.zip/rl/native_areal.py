"""Official AReaL PPOTrainer.train + RLVRWorkflow, CUDA FSDP/vLLM route."""
import argparse
import importlib.metadata as md
import json
import os
from pathlib import Path
import sys


def reward_func(prompt, completions, prompt_ids, completion_ids, **kwargs):
    import capture
    value = float(sum(completion_ids) % 997) / 997.0
    capture.save('reward_call', {'completion_ids': completion_ids, 'value': value},
                 semantics='synthetic generated-token checksum, execution only; no quality claim')
    return value


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--source', required=True)
    a = ap.parse_args()
    import torch
    import capture
    assert torch.cuda.is_available() and torch.cuda.device_count() >= 2
    assert 'torch_npu' not in sys.modules
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    from datasets import Dataset
    from omegaconf import OmegaConf
    from areal import PPOTrainer
    from areal.api.cli_args import GRPOConfig, load_expr_config
    import areal.engine.fsdp_engine as native_module
    source = Path(a.source).resolve()
    out = capture.OUT
    cfg = OmegaConf.load(source / 'examples/math/gsm8k_grpo.yaml')
    child_env = {k: os.environ[k] for k in ['GPU_RL_OUTPUT', 'PYTHONPATH', 'PATH'] if k in os.environ}
    child_env.update(GPU_RL_CAPTURE_AREAL='1', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='2',
                     TOKENIZERS_PARALLELISM='false')
    spec = [{'task_type': 'worker', 'cpu': 2, 'gpu': 1, 'mem': 32, 'port_count': 2,
             'cmd': sys.executable + ' -m areal.infra.rpc.rpc_server', 'env_vars': child_env}]
    changes = {'experiment_name': 'precision-gpurl', 'trial_name': out.name,
        'seed': 20261022, 'total_train_epochs': 1, 'total_train_steps': 1,
        'tokenizer_path': str(Path(a.model).resolve()), 'enable_offload': False,
        'cluster.n_nodes': 1, 'cluster.n_gpus_per_node': 2, 'cluster.fileroot': str(out / 'cluster'),
        'cluster.name_resolve.nfs_record_root': str(out / 'name-resolve'), 'scheduler.type': 'local',
        'actor.backend': 'fsdp:d1p1t1', 'rollout.backend': 'vllm:d1p1t1',
        'actor.path': str(Path(a.model).resolve()), 'actor.dtype': 'bfloat16',
        'actor.optimizer_dtype': 'float32', 'actor.attn_impl': 'eager',
        'actor.gradient_checkpointing': False, 'actor.scheduling_spec': spec,
        'actor.mb_spec': {'n_mbs': 4, 'granularity': 1, 'max_tokens_per_mb': None},
        'actor.optimizer.type': 'adam', 'actor.optimizer.lr': .001,
        'actor.optimizer.weight_decay': 0., 'actor.optimizer.beta1': .9,
        'actor.optimizer.beta2': .95, 'actor.optimizer.eps': 1e-8,
        'actor.optimizer.gradient_clipping': 1., 'actor.optimizer.lr_scheduler_type': 'constant',
        'actor.optimizer.warmup_steps_proportion': 0.,
        'actor.kl_ctl': 0., 'actor.reward_scaling': 1., 'actor.reward_bias': 0.,
        'actor.ppo_n_minibatches': 1, 'actor.recompute_logprob': True,
        'actor.use_decoupled_loss': False, 'actor.rejection_sampling': None,
        'actor.eps_clip': .2, 'actor.loss_aggregation': 'token_mean',
        'actor.reward_norm': {'mean_level': 'group', 'std_level': 'group',
                              'std_unbiased': False, 'group_size': 4, 'eps': 1e-4},
        'actor.adv_norm': None, 'actor.discount': 1., 'actor.gae_lambda': 1.,
        'gconfig.n_samples': 4, 'gconfig.max_new_tokens': 8, 'gconfig.max_tokens': 128,
        'gconfig.temperature': 1.5, 'gconfig.top_p': 1., 'gconfig.top_k': -1,
        'rollout.consumer_batch_size': 1, 'rollout.max_concurrent_rollouts': 4,
        'rollout.scheduling_spec': spec, 'rollout.dump_to_file': False,
        'vllm.model': str(Path(a.model).resolve()), 'vllm.dtype': 'bfloat16',
        'vllm.max_model_len': 128, 'vllm.max_num_seqs': 4,
        'vllm.enforce_eager': True, 'vllm.gpu_memory_utilization': .35,
        'train_dataset.batch_size': 1, 'train_dataset.num_workers': 0,
        'train_dataset.pin_memory': False, 'valid_dataset.num_workers': 0,
        'perf_tracer.enabled': False}
    for prefix in ['saver', 'evaluator', 'recover']:
        for key in ['freq_epochs', 'freq_steps', 'freq_secs']:
            changes[prefix + '.' + key] = None
    for key, value in changes.items():
        OmegaConf.update(cfg, key, value, merge=False, force_add=True)
    config_path = out / 'config.yaml'
    OmegaConf.save(cfg, config_path)
    config, _ = load_expr_config(['--config', str(config_path)], GRPOConfig)
    (out / 'identity.json').write_text(json.dumps({'framework': 'official inclusionAI/AReaL',
        'model': str(Path(a.model).resolve()), 'dtype': 'float32', 'compute_dtype': 'bfloat16',
        'entrypoint': 'areal.PPOTrainer.train -> areal.workflow.rlvr.RLVRWorkflow',
        'source_identity': capture.source_identity(native_module),
        'source_variant': 'official pyproject.vllm.toml at pinned checkout',
        'runtime': capture.runtime(['torch', 'areal', 'transformers', 'vllm']),
        'device': torch.cuda.get_device_name(), 'native_operators_replaced': False,
        'versions': {n: md.version(n) for n in ['torch', 'areal', 'transformers', 'vllm']}}, indent=2))
    dataset = Dataset.from_list([{'messages': [{'role': 'user', 'content':
        'Pick a random digit or letter. Reply with a short answer.'}]}])
    with PPOTrainer(config, train_dataset=dataset, valid_dataset=None) as trainer:
        trainer.train(workflow='areal.workflow.rlvr.RLVRWorkflow', workflow_kwargs={
            'reward_fn': 'native_areal.reward_func', 'gconfig': config.gconfig,
            'tokenizer': config.tokenizer_path, 'enable_thinking': False})
    required = ['rollout', 'reward_inputs', 'advantages', 'fixed_inputs', 'scores', 'objective', 'clip', 'optimizer']
    counts = {event: len(list(out.glob(event + '-pid*-*.json'))) for event in required}
    assert all(counts.values()), counts
    assert counts['optimizer'] == 1, counts
    optimizer = json.loads(next(out.glob('optimizer-pid*-*.json')).read_text())
    assert optimizer['nonzero_update']
    (out / 'completion.json').write_text(json.dumps({'status': 'native_cuda_workflow_complete',
        'events': counts, 'reward_quality_claimed': False}, indent=2))


if __name__ == '__main__':
    main()
