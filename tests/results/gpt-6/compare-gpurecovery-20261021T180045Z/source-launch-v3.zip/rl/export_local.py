"""Copy completed local RL evidence and concise machine-readable metrics."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

ap = argparse.ArgumentParser()
ap.add_argument('--run', required=True)
ap.add_argument('--destination', required=True)
a = ap.parse_args()
run = Path(a.run)
destination = Path(a.destination) / run.name
destination.mkdir(parents=True, exist_ok=True)
results = []
for case in ['swift-tiny-fp32', 'swift-pretrained-bf16']:
    source = run / case
    target = destination / case
    target.mkdir(exist_ok=True)
    for path in source.iterdir():
        if path.is_file() and path.suffix in ['.json', '.txt', '.log', '.zip']:
            shutil.copy2(path, target / path.name)
    for path in ['portable', 'replay']:
        shutil.copytree(source / path, target / path, dirs_exist_ok=True)
    summary = json.loads((source / 'portable/summary.json').read_text())
    metrics = {}
    for stage in ['gradients', 'postclip-gradients', 'updates', 'target-scores']:
        report = json.loads((source / f'portable/{stage}.report.json').read_text())
        metrics[stage] = report.get('global', report.get('metrics'))
    summary.update(case=case, metrics=metrics,
                   archive_sha256=hashlib.sha256((source / 'evidence.zip').read_bytes()).hexdigest())
    results.append(summary)
(destination / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
