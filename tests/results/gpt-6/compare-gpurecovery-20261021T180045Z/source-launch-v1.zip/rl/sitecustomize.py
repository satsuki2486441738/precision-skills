"""Delay observational OpenRLHF wrappers until native worker modules import."""
import importlib.abc
import importlib.machinery
import os
import sys

MODULES = {'openrlhf.trainer.ray.ppo_actor', 'openrlhf.trainer.ppo_utils.experience_maker',
    'openrlhf.models.actor', 'openrlhf.models.loss',
    'deepspeed.runtime.bf16_optimizer'}


class CaptureFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname not in MODULES:
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        if spec and spec.loader:
            original = spec.loader.exec_module

            def execute(module):
                original(module)
                from observe_openrlhf import patch
                patch(fullname, module)
            spec.loader.exec_module = execute
        return spec


if os.environ.get('GPU_RL_CAPTURE_OPEN') == '1':
    sys.meta_path.insert(0, CaptureFinder())
