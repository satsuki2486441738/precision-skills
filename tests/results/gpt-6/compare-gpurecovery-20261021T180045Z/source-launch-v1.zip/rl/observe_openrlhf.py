"""Passive observers of official OpenRLHF + DeepSpeed BF16 CUDA path."""
import os
import torch
import capture


def patch(name, module):
    if name == 'openrlhf.models.actor':
        original = module.Actor.forward

        def observed(self, sequences, *args, **kwargs):
            result = original(self, sequences, *args, **kwargs)
            if torch.is_grad_enabled() and kwargs.get('return_output') and isinstance(result, tuple):
                assert result[0].device.type == 'cuda'
                capture.save('scores', {'result': result[0]}, native_dtype=str(result[0].dtype),
                             device=str(result[0].device), temperature=float(self.temperature))
            return result
        module.Actor.forward = observed
    elif name == 'openrlhf.models.loss':
        original = module.PolicyLoss.forward

        def observed(self, *args, **kwargs):
            result = original(self, *args, **kwargs)
            capture.save('objective', {'result': result, 'args': args, 'kwargs': kwargs},
                clip_eps_low=self.clip_eps_low, clip_eps_high=self.clip_eps_high,
                token_level_loss=self.token_level_loss, policy_loss_type=self.policy_loss_type,
                enable_vllm_is_correction=self.enable_vllm_is_correction)
            return result
        module.PolicyLoss.forward = observed
    elif name == 'openrlhf.trainer.ppo_utils.experience_maker':
        original = module.SamplesGenerator.generate_samples

        def observed(self, *args, _original=original, **kwargs):
            result = _original(self, *args, **kwargs)
            capture.save('rollout', result)
            return result
        module.SamplesGenerator.generate_samples = observed
        original = module.RemoteExperienceMaker.compute_advantages_and_returns

        def observed(self, *args, _original=original, **kwargs):
            capture.save('reward_inputs', [{'sequences': e.sequences, 'attention_mask': e.attention_mask,
                'action_mask': e.action_mask, 'rewards': e.rewards, 'indices': e.index} for e in args[0]],
                semantics='native-generated ordered histories and effective external reward dependency before native group normalization')
            result = _original(self, *args, **kwargs)
            capture.save('advantages', result, estimator=self.advantage_estimator)
            return result
        module.RemoteExperienceMaker.compute_advantages_and_returns = observed
    elif name == 'openrlhf.trainer.ray.ppo_actor':
        original = module.ActorPPOTrainer.training_step

        def observed(self, experience, *args, **kwargs):
            engine = self.actor.model
            capture.NAMES.update({id(p): n for n, p in engine.module.named_parameters()})
            position_ids = experience.attention_mask.long().cumsum(-1) - 1
            position_ids.masked_fill_(experience.attention_mask == 0, 1)
            capture.save('fixed_inputs', {'model_inputs': {'input_ids': experience.sequences,
                'attention_mask': experience.attention_mask, 'position_ids': position_ids},
                'completion_mask': experience.action_mask, 'logits_to_keep': experience.action_mask.shape[1],
                'old_per_token_logps': experience.action_log_probs}, temperature=float(self.actor.temperature),
                group_size=int(self.args.n_samples_per_prompt), loss_type='grpo',
                epsilon_low=.2, epsilon_high=.2, scale_rewards='group',
                group_epsilon=1e-9, loss_reduction='token-mean', initial_storage='bfloat16', rank=os.environ.get('RANK'),
                old_policy_semantics='native detached actor-rescored old policy, fixed for CPU recomputation')
            capture.save('inventory', None, parameters=[{'name': n, 'shape': list(p.shape),
                'numel': p.numel(), 'dtype': str(p.dtype), 'device': str(p.device), 'trainable': p.requires_grad}
                for n, p in engine.module.named_parameters()])
            return original(self, experience, *args, **kwargs)
        module.ActorPPOTrainer.training_step = observed
    elif name == 'deepspeed.runtime.bf16_optimizer':
        original = module.BF16_Optimizer.step

        def observed(self, *args, **kwargs):
            assert all(count == 1 for count in self.partition_count), 'Observer currently defines DP=1 coordinates'
            entries = [(gi, pi, capture.NAMES.get(id(p)), p) for gi, group in enumerate(self.bf16_groups)
                       for pi, p in enumerate(group)][:12]
            assert all(name and p.device.type == 'cuda' for _, _, name, p in entries), entries

            def values(gradient=False):
                return {name: (self.fp32_groups_gradients[gi][pi] if gradient else p)
                    .detach().reshape(-1)[:8192].cpu().clone() for gi, pi, name, p in entries}

            before = values()
            pre = values(True)
            full_pre = sum(g.detach().double().square().sum().item() for group in self.fp32_groups_gradients for g in group) ** .5
            holder = {}

            def inner_pre(opt, call_args, call_kwargs):
                holder['post'] = values(True)
                holder['full_post'] = sum(g.detach().double().square().sum().item()
                    for group in self.fp32_groups_gradients for g in group) ** .5
            handle = self.optimizer.register_step_pre_hook(inner_pre)
            try:
                result = original(self, *args, **kwargs)
            finally:
                handle.remove()
            after = values()
            updates = {n: after[n].float() - before[n].float() for n in before}
            returned_norm = self._global_grad_norm
            native_norm = float(returned_norm.item() if torch.is_tensor(returned_norm) else returned_norm)
            capture.save('clip', {'preclip_gradients': pre, 'postclip_gradients': holder['post'],
                'native_returned_norm': torch.tensor(native_norm)}, max_norm=float(self.clip_grad),
                full_fp64_preclip_norm=full_pre, full_fp64_postclip_norm=holder['full_post'],
                native_coefficient=min(1., self.clip_grad / (native_norm + 1e-6)))
            capture.save('optimizer', {'before': before, 'after': after,
                'postclip_gradients': holder['post'], 'stored_updates': updates},
                optimizer=type(self.optimizer).__module__ + '.' + type(self.optimizer).__name__,
                groups=[{k: capture.cpu(v) for k, v in g.items() if k != 'params'} for g in self.optimizer.param_groups],
                coordinates=[{'name': n, 'shape': list(p.shape), 'native_parameter_dtype': str(p.dtype),
                    'native_gradient_dtype': str(self.fp32_groups_gradients[gi][pi].dtype),
                    'device': str(p.device), 'slice': [0, min(8192, p.numel())]} for gi, pi, n, p in entries],
                full_parameter_elements=sum(p.numel() for group in self.bf16_groups for p in group),
                selected_elements=sum(x.numel() for x in before.values()),
                nonzero_update=any(bool(x.ne(0).any()) for x in updates.values()), master_storage='float32')
            return result
        module.BF16_Optimizer.step = observed
