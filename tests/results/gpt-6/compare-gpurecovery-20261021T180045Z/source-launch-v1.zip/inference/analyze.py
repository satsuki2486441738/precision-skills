"""Export native rows with precision-skill tools, compare, and package portable evidence."""
import json
import os
from pathlib import Path
import shutil
import sys
import numpy as np
import torch
from safetensors.torch import load_file
from suite import HERE,MODELS,LLAMA_PIN,save,sha,tools_path

ROOT=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();TOOLS=tools_path(ROOT)
from inference_capture import FixedHistory,validate_history,export_records
from compare_distributions import compare as compare_distributions
from compare_target_scores import compare as compare_targets
from validate_artifacts import validate
from evidence_bundle import pack,verify
from replay_bundle import replay

def relative_descriptors(value,base):
    if isinstance(value,dict):
        for key,item in value.items():
            if key=='path' and isinstance(item,str) and Path(item).is_absolute():value[key]=os.path.relpath(item,base).replace('\\','/')
            else:relative_descriptors(item,base)
    elif isinstance(value,list):
        for item in value:relative_descriptors(item,base)
    return value

def export_side(case,m):
    if (case/'native-logits.safetensors').is_file():raw=load_file(str(case/'native-logits.safetensors'))['logits']
    else:raw=torch.from_numpy(np.load(case/'native-logits.npy',allow_pickle=False))
    history=FixedHistory('geography',m['prompt'],m['targets'],logprob_dtype='float64')
    records=[]
    for step,row in enumerate(raw):records.append(history.capture_and_force(row.clone(),case/f'logprobs-{step}'))
    events=json.loads((case/'events.json').read_text());coverage=validate_history(m['prompt'],m['targets'],events)
    exported=relative_descriptors(export_records(records,case,normalization_tolerance=1e-10),case)
    save(case/'records.json',records);save(case/'history-validation.json',coverage)
    return exported,{'raw_storage':str(raw.dtype),'logprobs':'FP64 offline natural-log log_softmax derived independently from retained full-vocabulary raw logits','events':events,'validation':coverage}

replay_cases=[];summary=[]
for m in MODELS:
    directory=OUT/m['name'];identity=json.loads((directory/'model-identity.json').read_text())
    common={'model':{'repo':m['repo'],'revision':m['revision'],'checkpoint_sha256':identity['files']['model.safetensors']['sha256'],'vocab_mapping':'source tokenizer integer IDs, no vocabulary remapping'},'inputs':{'prompt':m['prompt'],'continuation':m['targets'],'attention_mask':'causal, all tokens valid','positions':'absolute contiguous from zero','template':None,'bos_added':False},'scope':{'task':'fixed-history next-token scoring','sample':'geography','predictions':3,'raw_before_sampling':True}}
    available=[lane for lane in ['cpu','lmdeploy','llama'] if (directory/lane/'completion.json').is_file()]
    side_names={'cpu':'independent-cpu','lmdeploy':'lmdeploy-cuda','llama':'llama-cuda'}
    side_conditions={}
    exports={};evidence={}
    for lane in available:
        side=side_names[lane];case=directory/lane;exports[lane],evidence[lane]=export_side(case,m)
        completion=json.loads((case/'completion.json').read_text())
        side_conditions[side]={'numerics':{'weights':'same pinned pretrained checkpoint; native FP16 representation (GGUF mixed F16/F32 storage for llama); CPU FP16 then FP32','scores':evidence[lane]['raw_storage'],'normalization':'offline FP64 full-vocabulary log_softmax','cache':'measured in events.json and raw native log'},'execution':{'backend':completion.get('native_backend',completion.get('execution')),'cache_replay':True,'prefill':1,'cached_decode':2,'tp':1}}
    vocab=json.loads((ROOT/'resources'/m['name']/'config.json').read_text())['vocab_size']
    positions=[{'sample':'geography','position':len(m['prompt'])-1+i,'history':m['prompt']+m['targets'][:i]} for i in range(3)]
    targets=[{'sample':'geography','position':len(m['prompt'])+i,'token':token} for i,token in enumerate(m['targets'])]
    dc={'schema_version':1,'kind':'distributions','thresholds':None,'common':common,'side_conditions':side_conditions,'expected_ranks':{side_names[x]:[0] for x in available},'positions':positions,'vocab_size':vocab,'normalization_tolerance':1e-10,'renormalization':'none'}
    tc={k:v for k,v in dc.items() if k not in ['positions','vocab_size','normalization_tolerance','renormalization']};tc.update(kind='target-scores',targets=targets)
    save(directory/'distribution-contract.json',dc);save(directory/'target-contract.json',tc)
    for lane in available:
        side=side_names[lane];case=directory/lane
        runtime=json.loads((case/'runtime.json').read_text()) if (case/'runtime.json').is_file() else {'llama.cpp':{'revision':LLAMA_PIN,'build_flag':'GGML_CUDA=ON','actual_offload':'native.log'}}
        save(case/'environment.json',{'rank':0,'versions':runtime,'actual':{**common,**side_conditions[side]},'measured':evidence[lane]})
        save(case/'rank-status.json',{'rank':0,'status':'completed','full_vocabulary_rows':3,'native_cache_replay':True})
        base={'schema_version':1,'common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':'environment.json','status':'rank-status.json'}]}
        save(case/'distribution.json',{**base,'kind':'distributions','positions':exports[lane]['positions']});save(case/'targets.json',{**base,'kind':'target-scores','scores':exports[lane]['scores']})
        validation=validate(directory/'distribution-contract.json',case/'distribution.json');save(case/'artifact-validation.json',validation)
        assert validation['status']=='validated',validation
    if 'cpu' not in available:continue
    for lane in ['lmdeploy','llama']:
        if lane not in available:continue
        dr=compare_distributions(directory/'distribution-contract.json',directory/'cpu/distribution.json',directory/lane/'distribution.json')
        tr=compare_targets(directory/'target-contract.json',directory/'cpu/targets.json',directory/lane/'targets.json')
        save(directory/(lane+'-distribution-metrics.json'),dr);save(directory/(lane+'-target-metrics.json'),tr)
        assert dr['status']=='no_thresholds' and tr['status']=='no_thresholds',(dr,tr)
        summary.append({'model':m['name'],'lane':lane,'distributions':dr['aggregate'],'targets':tr['metrics'],'status':'metrics_computed','thresholds':None})
        rel=m['name']
        for operation,contract,manifest,expected in [('compare_distributions','distribution-contract.json','distribution.json',{'status':'no_thresholds','position_count':3,'aggregate':dr['aggregate']}),('compare_target_scores','target-contract.json','targets.json',{'status':'no_thresholds','metrics':tr['metrics']})]:
            replay_cases.append({'name':m['name']+'-'+lane+'-'+operation,'operation':operation,'inputs':{'contract':rel+'/'+contract,'side_a':rel+'/cpu/'+manifest,'side_b':rel+'/'+lane+'/'+manifest},'expected':expected})
        breakdown=[]
        for step in range(3):
            stage=directory/f'{lane}-stage-{step}';stage.mkdir()
            save(stage/'distribution-contract.json',{**dc,'positions':[positions[step]]});save(stage/'target-contract.json',{**tc,'targets':[targets[step]]})
            for source in ['cpu',lane]:
                for filename,key in [('distribution.json','positions'),('targets.json','scores')]:
                    manifest=json.loads((directory/source/filename).read_text());manifest[key]=[manifest[key][step]]
                    for rank in manifest['ranks']:
                        rank['environment']='../'+source+'/environment.json';rank['status']='../'+source+'/rank-status.json'
                    for record in manifest[key]:
                        if isinstance(record.get('scores'),dict):record['scores']['path']='../'+source+'/'+record['scores']['path']
                    save(stage/(source+'-'+filename),manifest)
            ds=compare_distributions(stage/'distribution-contract.json',stage/'cpu-distribution.json',stage/(lane+'-distribution.json'))
            ts=compare_targets(stage/'target-contract.json',stage/'cpu-targets.json',stage/(lane+'-targets.json'))
            assert ds['status']=='no_thresholds' and ts['status']=='no_thresholds'
            breakdown.append({'step':step,'stage':['prefill','first_decode','later_decode'][step],'history_length':6+step,'distribution':ds,'target':ts})
        save(directory/(lane+'-stage-breakdown.json'),breakdown)
save(OUT/'metrics-summary.json',summary)
save(OUT/'REPLAY.json',{'cases':replay_cases})
save(OUT/'scope.json',{'native_frameworks':['LMDeploy PyTorch CUDA','llama.cpp GGML_CUDA'],'models':2,'each_native_lane':'prefill + first cached decode + later cached decode','independent_reference':'separate CPU process loads same pinned source checkpoint; fixed input IDs supplied before native execution','unsupported_or_unexecuted':'TurboMind is not claimed complete; MindIE selected Ascend route is outside CUDA hardware scope; TensorRT retained older RTX5060 evidence','thresholds':None})
stage=OUT/'portable';stage.mkdir()
for item in list(OUT.iterdir()):
    if item==stage or item.name=='analysis.log':continue
    if item.is_dir():shutil.copytree(item,stage/item.name)
    else:shutil.copy(item,stage/item.name)
source=stage/'collector-source';source.mkdir()
for name in ['suite.py','analyze.py','launch.sh','native_llama_cuda.cpp']:shutil.copy(HERE/name,source/name)
provenance=stage/'preparation';provenance.mkdir()
for item in (ROOT/'logs').iterdir():
    if item.is_file() and item.name!='run.log':shutil.copy(item,provenance/item.name)
for name in ['llama-source.json']:
    shutil.copy(ROOT/'resources'/name,provenance/name)
shutil.copy(ROOT/'resources'/('llama.cpp-'+LLAMA_PIN)/('build-cuda-sm'+os.environ.get('PRECISION_CUDA_ARCH','90'))/'CMakeCache.txt',provenance/'llama-CMakeCache.txt')
bundle=OUT/'inference-cuda-evidence.zip'
receipt=pack(stage,bundle,replacements=[(str(ROOT),'<WORK_ROOT>'),(str(HERE),'<COLLECTOR_ROOT>')]);save(OUT/'pack-receipt.json',receipt)
save(OUT/'verify-receipt.json',verify(bundle))
if replay_cases:save(OUT/'replay-receipt.json',replay(bundle,OUT/'replay-validation',scripts=TOOLS))
save(OUT/'artifact-index.json',{'bundle':bundle.name,'sha256':sha(bundle),'bytes':bundle.stat().st_size,'models':2,'native_complete_model_lanes':len(summary),'comparisons':len(replay_cases),'thresholds':None})
print(json.dumps({'bundle':str(bundle),'summary':summary},indent=2))
