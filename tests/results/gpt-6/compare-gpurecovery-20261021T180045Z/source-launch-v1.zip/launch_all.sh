#!/usr/bin/env bash
# A finite native evaluation workload; the enclosing task launcher owns SSH.
set -uo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WORK_ROOT="${PRECISION_WORK_ROOT:?set an absolute persistent private work directory}"
[[ "$WORK_ROOT" == /* ]] || { echo 'PRECISION_WORK_ROOT must be absolute'; exit 64; }
mkdir -p "$WORK_ROOT/logs" "$WORK_ROOT/state"
exec 9>"$WORK_ROOT/state/native-suite.lock"
flock -n 9 || { echo 'This evaluation workspace is already active'; exit 73; }
exec > >(tee -a "$WORK_ROOT/logs/launcher.log") 2>&1
printf 'Native GPU evaluation start %s\n' "$(date -u +%FT%TZ)"
nvidia-smi --query-gpu=index,name,uuid,memory.total,driver_version --format=csv > "$WORK_ROOT/logs/hardware.csv" || exit
export PYTHONNOUSERSITE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 TOKENIZERS_PARALLELISM=false
export WANDB_MODE=disabled AXOLOTL_DO_NOT_TRACK=1 HF_HUB_DISABLE_XET=1
export PIP_CACHE_DIR="$WORK_ROOT/cache/pip"
if [[ -z "${PRECISION_BASE_PYTHON:-}" ]]; then
  python3 -m venv "$WORK_ROOT/bootstrap" || exit
  "$WORK_ROOT/bootstrap/bin/python" -m pip install --disable-pip-version-check 'uv==0.13.1' || exit
  export UV_PYTHON_INSTALL_DIR="$WORK_ROOT/python"
  "$WORK_ROOT/bootstrap/bin/uv" python install 3.11 || exit
  PRECISION_BASE_PYTHON="$("$WORK_ROOT/bootstrap/bin/uv" python find --managed-python 3.11)" || exit
fi
export BASE_PYTHON="$PRECISION_BASE_PYTHON" PRECISION_BASE_PYTHON
"$BASE_PYTHON" --version > "$WORK_ROOT/logs/bootstrap-python.txt" 2>&1
export PRECISION_TOOLS="$HERE/skill/scripts" PRECISION_SKILL_SCRIPTS="$HERE/skill/scripts"
status=0
for group in ${PRECISION_GROUPS:-sft inference rl}; do
  printf 'START GROUP %s %s\n' "$group" "$(date -u +%FT%TZ)"
  case "$group" in
    sft)
      PRECISION_DDP_WORLD=4 bash "$HERE/sft/suite.sh" > "$WORK_ROOT/logs/sft.log" 2>&1 ;;
    inference)
      bash "$HERE/inference/launch.sh" "$WORK_ROOT/inference" 0 > "$WORK_ROOT/logs/inference.log" 2>&1 ;;
    rl)
      "$BASE_PYTHON" -u "$HERE/rl/run_suite.py" --work-root "$WORK_ROOT/rl" --skill-root "$HERE/skill" --python "$BASE_PYTHON" --lanes "${PRECISION_RL_LANES:-swift,openrlhf}" > "$WORK_ROOT/logs/rl.log" 2>&1 ;;
    *) printf 'Unknown native group: %s\n' "$group"; status=1; continue ;;
  esac
  code=$?
  printf '%s\n' "$code" > "$WORK_ROOT/state/$group.exit"
  printf 'END GROUP %s exit=%s %s\n' "$group" "$code" "$(date -u +%FT%TZ)"
  [[ "$code" -eq 0 ]] || status=1
done
printf '%s\n' "$status" > "$WORK_ROOT/state/suite.exit"
printf 'Native GPU evaluation end exit=%s %s\n' "$status" "$(date -u +%FT%TZ)"
exit "$status"
