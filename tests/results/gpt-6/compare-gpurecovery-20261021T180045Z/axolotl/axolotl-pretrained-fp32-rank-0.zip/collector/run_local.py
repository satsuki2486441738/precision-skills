"""Run real one-GPU SFT cases from a read-only interpreter; write only task output.

Use: EXISTING_ENV/bin/python run_local.py --root EXT4_TASK_ROOT [--lane trl]
Native and CPU execution use separate subprocesses. Initial native outcomes are
never deserialized by the reference process. Failed attempts remain on disk.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',required=True)
    ap.add_argument('--lane',default='trl',choices=['trl','factory','swift','axolotl'])
    ap.add_argument('--models',nargs='+',default=['tiny','pretrained'])
    ap.add_argument('--precisions',nargs='+',default=['fp32','bf16'])
    args=ap.parse_args()
    root=Path(args.root).resolve()
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    run=root/'runs'/('compare-localgpusft-'+stamp)
    run.mkdir(parents=True,exist_ok=False)
    env=os.environ.copy()
    env.update(PRECISION_SFT_ROOT=str(root),PYTHONPATH=str(root),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',TOKENIZERS_PARALLELISM='false',WANDB_MODE='disabled',AXOLOTL_DO_NOT_TRACK='1',HF_HOME=str(root/'cache/huggingface'),PRECISION_MODEL_REVISION='c1899de289a04d12100db370d81485cdf75e47ca')
    for name in ['RANK','WORLD_SIZE','LOCAL_RANK','MASTER_ADDR','MASTER_PORT']:env.pop(name,None)
    def execute(label,command,reference=False):
        runtime=dict(env)
        if reference:runtime['CUDA_VISIBLE_DEVICES']=''
        receipt={'command':command,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reference':reference,'actual_world_size':1}
        (run/(label+'-command.json')).write_text(json.dumps(receipt,indent=2))
        with (run/(label+'.log')).open('xb') as stream:
            p=subprocess.run(command,env=runtime,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
        receipt['returncode']=p.returncode
        (run/(label+'-result.json')).write_text(json.dumps(receipt,indent=2))
        print(json.dumps({'label':label,'returncode':p.returncode,'run':str(run)}),flush=True)
        return p.returncode==0
    execute('fixture',[sys.executable,'-B',str(root/'native_gpu_sft.py'),'--prepare'])
    status=[]
    for model in args.models:
        if model=='pretrained':
            checkpoint=Path(env.get('PRECISION_PRETRAINED_MODEL',str(root/'models/Qwen3-0.6B')))
            env['PRECISION_PRETRAINED_MODEL']=str(checkpoint)
            if not (checkpoint/'model.safetensors').is_file():
                download='import os; from huggingface_hub import snapshot_download; snapshot_download("Qwen/Qwen3-0.6B",revision=os.environ["PRECISION_MODEL_REVISION"],local_dir=os.environ["PRECISION_PRETRAINED_MODEL"],ignore_patterns=["*.gguf","*.bin","*.msgpack","*.h5"])'
                if not execute('download',[sys.executable,'-c',download]):
                    status.append({'model':model,'stage':'download','complete':False});continue
        for precision in args.precisions:
            label=args.lane+'-'+model+'-'+precision
            case=run/label
            complete=execute(label+'-native',[sys.executable,'-B',str(root/'native_gpu_sft.py'),'--framework',args.lane,'--model',model,'--precision',precision,'--output',str(case)])
            if complete:
                complete=execute(label+'-cpu',[sys.executable,'-B',str(root/'native_gpu_sft.py'),'--reference','--model',model,'--output',str(case/'rank-0')],reference=True)
            if complete:
                exporter='import sys; from pathlib import Path; from export_compare_sft import export; print(export(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3])))'
                complete=execute(label+'-compare',[sys.executable,'-B','-c',exporter,str(case/'rank-0'),str(case/'rank-0/metrics'),str(root/'toolchain')],reference=True)
            status.append({'case':label,'complete':complete,'native_world_size':1,'reference_world_size':1,'topology':'single RTX5060; no four-GPU completion claimed'})
            (run/'suite-status.json').write_text(json.dumps(status,indent=2))
    return 0 if all(s['complete'] for s in status) else 1


if __name__=='__main__':raise SystemExit(main())
