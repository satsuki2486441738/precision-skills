"""Read-only native evidence audit followed by a new public export and CPU replay."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import struct
import sys
import zipfile

ROOT=Path(sys.argv[1]).resolve()
OUT=Path(json.loads((ROOT/'latest-run.json').read_text())['run'])
TOOLS=Path(os.environ['PRECISION_SKILL_SCRIPTS']);sys.path.insert(0,str(TOOLS))
from evidence_bundle import pack,verify
from replay_bundle import replay

def save(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def raw_dtype(path):
    with Path(path).open('rb') as stream:
        length=struct.unpack('<Q',stream.read(8))[0];header=json.loads(stream.read(length))
    return header['logits']['dtype']

metrics=json.loads((OUT/'metrics-summary.json').read_text())
cases=[]
for m in json.loads((OUT/'model-specs.json').read_text()):
    directory=OUT/m['name']
    selected=json.loads((directory/'lmdeploy/selected-coordinates.json').read_text())
    raw=json.loads((directory/'llama/native-settings.json').read_text())
    log=(directory/'llama/native.log').read_text()
    offload=re.search(r'offloaded ([1-9][0-9]*)/([1-9][0-9]*) layers',log);assert offload
    measured=[line for line in log.splitlines() if 'KV' in line or 'K (' in line or 'V (' in line]
    assert any('(f32)' in line for line in measured),measured
    for lane in ['cpu','lmdeploy','llama']:
        assert json.loads((directory/lane/'completion.json').read_text())['status']=='completed'
        assert json.loads((directory/lane/'artifact-validation.json').read_text())['status']=='validated'
        process=(directory/lane/'process.log').read_text(errors='replace')
        assert 'Traceback (most recent call last)' not in process and 'RuntimeError:' not in process,(m['name'],lane)
    caches=[row['observation']['cache'] for row in selected]
    pointers=[cache[0][0]['data_ptr'] for cache in caches]
    assert len(set(pointers))==1,'Native cache storage changed between fixed-history stages'
    cases.append({'model':m['name'],'source_checkpoint':m['repo'],'source_revision':m['revision'],'vocab_size':raw['vocab_size'],'positions':3,'target_tokens':m['targets'],'history_lengths':[6,7,8],'requested_stages':['prefill','first_cached_decode','later_cached_decode'],'native_LMDeploy':{'backend':'PyTorch CUDA','raw_storage_dtype':raw_dtype(directory/'lmdeploy/native-logits.safetensors'),'forward_input_ids':[row['observation']['input_ids'] for row in selected],'forward_positions':[row['observation']['position_ids'] for row in selected],'score_shapes':[row['score_metadata']['tensor']['shape'] for row in selected],'score_devices':[row['score_metadata']['tensor']['device'] for row in selected],'cache_storage_dtypes':[cache[0][0]['dtype'] for cache in caches],'cache_device':caches[0][0][0]['device'],'same_native_cache_storage_across_steps':True,'raw_boundary':'native model get_logits return before every sampling processor'},'native_llama':{'backend':'GGML_CUDA','source_commit':'620d2225cc436ab0b001e3200e590e3b286ef9ab','gpu_layers_offloaded':int(offload[1]),'gpu_layers_total':int(offload[2]),'raw_storage_dtype':'F32 API logits, original native-logits.bin retained','measured_cache_lines':measured,'forward_batch_tokens':[event['batch_tokens'] for event in raw['events']]},'reference':{'entrypoint':'independent Transformers CPU FP32 eager forward','raw_storage_dtype':raw_dtype(directory/'cpu/native-logits.safetensors'),'weights':'same pinned source checkpoint separately loaded; cast FP16 then FP32','native_scores_used':False,'native_parameters_used':False},'normalization':'offline FP64 natural-log log_softmax from each retained raw row','thresholds':None})
summary={'status':'native_cuda_and_independent_cpu_reference_complete','run':OUT.name,'hardware':'NVIDIA GeForce RTX 5060 8GB, sm120','dependencies':{'torch':'2.9.1+cu128','torchvision':'0.24.1+cu128','triton':'3.5.1','lmdeploy':'0.18.0','transformers':'4.57.1','native_compiler':'NVIDIA nvcc12.8.93','llama.cpp_commit':'620d2225cc436ab0b001e3200e590e3b286ef9ab'},'models':2,'native_model_lanes':4,'independent_cpu_references':2,'paired_distributions':12,'paired_targets':12,'overall_comparisons':8,'stage_comparisons':24,'validated_sides':6,'cases':cases,'metrics':metrics,'other_routes':[{'framework':'LMDeploy TurboMind0.18.0','status':'not_executed_in_new_cached_cuda_lane','coverage':'previous evidence has only fresh-prefix CUDA rows; not counted as new cached decode'},{'framework':'TensorRT-LLM','status':'reuse_existing_two_model_RTX5060_native_evidence','coverage':'not rerun or counted as new execution in this supplement'},{'framework':'MindIE selected Ascend route','status':'requires_Ascend_hardware_runtime','coverage':'not replaced by a CUDA imitation'}],'first_attempt':{'status':'diagnostic_only','finding':'Fixed-history callback originally raised on an extra post-request native processor call. Canonical fresh run returns scores unchanged after the requested history is exhausted. Both old source and errors remain in failure-history.'},'gpu_release':'All own native collector subprocesses completed and exited; subsequent finalization uses CPU only','thresholds':None}
save(OUT/'native-summary.json',summary)
lines=['# Native CUDA inference supplement','',f'Run: `{OUT.name}`. Two pinned pretrained checkpoints; four native CUDA model/backend cases and two independent CPU references completed.','', 'Every case covers one prefill distribution and two native cached-decode distributions at fixed history lengths 6, 7, and 8. Each row retains the full source vocabulary before sampling. Native raw dtypes and forward/cache observations are in `native-summary.json`; `thresholds` is null.','']
for item in metrics:
    target=item['targets'];distribution=item['distributions'];lines.append(f"- {item['model']} / {item['lane']}: JS mean={distribution['tail_merged_js']['mean']:.9g}; top-1={distribution['top1_agreement']['count']}/3; target logprob MAE={target['mae_nat']:.9g}, max={target['max_abs_nat']:.9g}.")
lines+=['','Six side manifests validate. Eight overall comparisons and 24 stage comparisons compute metrics; eight portable overall comparisons are replayed. Numeric acceptance was not assessed.','', 'The original callback-exhaustion attempt and its diagnostic source/logs are retained separately. The canonical run has no captured Python traceback or RuntimeError. TurboMind is not counted as newly cached; TensorRT keeps its earlier real two-model evidence; the selected MindIE route remains an Ascend hardware requirement.','', 'GPU collection finished and the GPU was released before this CPU-only finalization.']
(OUT/'report.md').write_text('\n'.join(lines)+'\n')
stage=OUT/'portable-final-v02';shutil.copytree(OUT/'portable',stage)
shutil.copy(Path(__file__),stage/'collector-source/finalize.py')
shutil.copy(OUT/'native-summary.json',stage/'native-summary.json');shutil.copy(OUT/'report.md',stage/'report.md')
failure=stage/'failure-history';failure.mkdir()
previous=sorted(p for p in (ROOT/'runs').glob('compare-inferencecuda-*') if p!=OUT and (p/'attempt-disposition.json').is_file())
if previous:
    old=previous[-1]
    for name in ['attempt-disposition.json','attempt01-adapter-before-exhaustion-fix.py']:shutil.copy(old/name,failure/name)
    for name in ['SmolLM2-135M-Instruct','Qwen2.5-0.5B-Instruct']:shutil.copy(old/name/'lmdeploy/process.log',failure/(name+'-lmdeploy-cleanup-error.log'))
bundle=OUT/'inference-cuda-public-evidence-v02.zip'
replacements=[(str(ROOT),'<WORK_ROOT>'),(str(ROOT/'collector'),'<COLLECTOR_ROOT>'),(str(TOOLS),'<SKILL_SCRIPTS>'),('<HOST>','<HOST>'),(socket.gethostname(),'<HOST>'),(str(Path.home()),'<HOME>'),('<USER_MOUNT>/','<USER_MOUNT>/')]
save(OUT/'public-v02-pack-receipt.json',pack(stage,bundle,replacements=replacements))
assert bundle.stat().st_size<90*1024*1024
save(OUT/'public-v02-verify-receipt.json',verify(bundle))
replay_root,replay_result=replay(bundle,OUT/'public-v02-replay-validation',scripts=TOOLS)
save(OUT/'public-v02-replay-receipt.json',replay_result)
findings=[]
with zipfile.ZipFile(bundle) as archive:
    for name in archive.namelist():
        if name.endswith(('.npy','.safetensors','.bin','.gguf')):continue
        try:text=archive.read(name).decode('utf-8')
        except UnicodeDecodeError:continue
        for forbidden in ['<HOST>','<HOME>/','<USER_MOUNT>/']:
            if forbidden in text:findings.append({'path':name,'literal':forbidden})
assert not findings,findings
save(OUT/'public-v02-scan-receipt.json',{'status':'selected_private_literals_absent','checked':['hostname','private_home_prefix','private_repository_mount_prefix'],'binary_arrays_untransformed':True,'findings':findings})
index={'run':OUT.name,'bundle':bundle.name,'bytes':bundle.stat().st_size,'sha256':sha(bundle),'models':2,'native_model_lanes':4,'references':2,'paired_distributions':12,'paired_targets':12,'overall_comparisons':8,'stage_comparisons':24,'validated_sides':6,'portable_replay_comparisons':8,'thresholds':None,'gpu_released':True}
save(OUT/'public-v02-artifact-index.json',index)
print(json.dumps({'run':str(OUT),'index':index,'cases':cases},indent=2))
