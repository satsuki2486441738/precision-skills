"""Collect exact completed inference bytes without model weights or environments."""
import hashlib
import json
from pathlib import Path
import zipfile

root=Path('/REMOTE_WORKSPACE/inference')
state=json.loads((root/'llama-native-latest.json').read_text())
attempt=Path(state['attempt']);assert attempt.is_relative_to(root/'runs')
assert all(c['status']=='native_cann_and_independent_cpu_complete' for c in state['cases'])
paths=list(attempt.rglob('*'))
paths += [root/p for p in ['llama-build-latest.json','llama-native-latest.json','scripts/llama_native.cpp','scripts/llama_setup.py','scripts/llama_run.py'] if (root/p).is_file()]
paths += list((root/'runs').glob('compare-llamabuild-*/*'))
paths += [root/'build/llama/CMakeCache.txt'] if (root/'build/llama/CMakeCache.txt').is_file() else []
files={}
archive=root/'llama-native-evidence-01.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(set(paths)):
        if not p.is_file():continue
        assert p.stat().st_size<20*1024*1024,(p,p.stat().st_size)
        data=p.read_bytes();name=str(p.relative_to(root))
        files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        z.writestr(name,data)
    z.writestr('collection-manifest.json',json.dumps({'files':files,'raw_bytes_preserved':True},indent=2))
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)},indent=2))
