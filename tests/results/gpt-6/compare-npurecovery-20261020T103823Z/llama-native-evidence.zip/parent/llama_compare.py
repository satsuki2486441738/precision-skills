"""Validate exact native captures, then run shipped comparison CLIs offline.

No native computation is replayed by this adapter. Logits stay byte-exact;
logprobs are an explicit FP64 log-softmax export cast to FP32 on both sides.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile
import numpy as np

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
TOOLS=REPO/'skills/precision-skill/scripts'
sys.path.insert(0,str(TOOLS))
from inference_capture import validate_history

def save(p,value):
    with p.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False)

def main():
    raw=HERE/'llama-native-raw-01';raw.mkdir()
    with zipfile.ZipFile(HERE/'llama-native-evidence-01.zip') as z:
        for name in z.namelist():
            assert (raw/name).resolve().is_relative_to(raw.resolve())
        z.extractall(raw)
    inventory=json.loads((raw/'collection-manifest.json').read_text())['files']
    for name,info in inventory.items():
        data=(raw/name).read_bytes()
        assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256']
    latest=json.loads((raw/'llama-native-latest.json').read_text())
    attempt=raw/'runs'/Path(latest['attempt']).name
    metrics=HERE/'llama-core-metrics-01';metrics.mkdir()
    receipts=[]
    for case in sorted(attempt.iterdir()):
        if not case.is_dir():continue
        out=metrics/case.name;out.mkdir()
        identity=json.loads((case/'input-identity.json').read_text())
        completion=json.loads((case/'completion.json').read_text())
        assert completion['status']=='native_cann_and_independent_cpu_complete'
        for name,digest in completion['files_sha256'].items():
            assert hashlib.sha256((case/name).read_bytes()).hexdigest()==digest
        prompt=identity['prompt'];continuation=identity['continuation'];rows=len(continuation)
        events=[dict(stage='prefill' if i==0 else 'decode',input_ids=prompt if i==0 else [continuation[i-1]],positions=list(range(len(prompt))) if i==0 else [len(prompt)+i-1],prefix_length=0 if i==0 else len(prompt)+i-1) for i in range(rows)]
        history_check=validate_history(prompt,continuation,events)
        save(out/'history-validation.json',dict(result=history_check,events=events))
        common=dict(model=dict(name=case.name,source_commit=identity['source_commit'],gguf_sha256=identity['gguf_sha256'],checkpoint_safetensors=identity['safetensors']),inputs=dict(prompt=prompt,continuation=continuation),numerics=dict(weights='same F16 GGUF with native F32 norms; unquantized',kv_storage='F16',logits_storage='F32',flash_attention=False),scope='native llama_decode prefill plus two fixed-history cached decode calls; TP=1')
        sides={s:dict(backend='CPU' if s=='cpu' else 'CANN',execution='independent native llama.cpp execution',arithmetic='backend default; internal accumulator dtypes not instrumented') for s in ['cpu','cann']}
        shape=None
        for side in sides:
            array=np.load(case/(side+'-logits.npy'),allow_pickle=False)
            flat=np.fromfile(case/(side+'-logits.f32'),dtype=np.float32)
            assert array.dtype==np.float32 and np.array_equal(flat.reshape(array.shape),array)
            assert array.shape[0]==rows and np.isfinite(array).all()
            if shape is None:shape=list(array.shape)
            assert list(array.shape)==shape
            np.save(out/(side+'-logits.npy'),array,allow_pickle=False)
            x=array.astype(np.float64);x-=x.max(axis=-1,keepdims=True)
            lp=(x-np.log(np.exp(x).sum(axis=-1,keepdims=True))).astype(np.float32)
            np.save(out/(side+'-logprobs.npy'),lp,allow_pickle=False)
            metadata=json.loads((case/(side+'-metadata.json')).read_text())
            assert metadata['backend']==sides[side]['backend'] and metadata['kv_storage']=='F16'
            save(out/(side+'-environment.json'),dict(rank=0,versions=dict(llama_cpp=identity['source_commit']),actual={**common,**sides[side]},native_metadata=metadata,raw_evidence=str(case.relative_to(HERE)),export_transform='logits unchanged; logprob=FP64 log-softmax cast to FP32'))
            save(out/(side+'-status.json'),dict(rank=0,status='completed',native_returncode=0,completion_sha256=hashlib.sha256((case/'completion.json').read_bytes()).hexdigest()))
        positions=[dict(sample=case.name,position=len(prompt)-1+i,history=prompt+continuation[:i]) for i in range(rows)]
        coords=dict(sample=case.name,prediction_positions=[x['position'] for x in positions],stages=['prefill','first_decode','later_decode'],token_ids='full vocabulary order')
        contracts={
            'tensors':dict(schema_version=2,kind='tensors',stage='observations',tensors=[dict(name='logits',shape=shape,present=True,coordinates=coords)]),
            'distributions':dict(schema_version=2,kind='distributions',positions=positions,vocab_size=shape[1],normalization_tolerance=1e-5,renormalization='full_vocabulary_fp64'),
            'target-scores':dict(schema_version=1,kind='target-scores',targets=[dict(sample=case.name,position=len(prompt)+i,token=t) for i,t in enumerate(continuation)])}
        for kind,spec in contracts.items():
            contract={**spec,'common':common,'side_conditions':sides,'thresholds':None,'expected_ranks':{'cpu':[0],'cann':[0]}}
            cp=out/(kind+'-contract.json');save(cp,contract)
            manifests=[]
            for side in sides:
                manifest=dict(schema_version=spec['schema_version'],kind=kind,common=common,side=side,expected_ranks=[0],ranks=[dict(rank=0,environment=side+'-environment.json',status=side+'-status.json')])
                if kind=='tensors':manifest.update(stage='observations',tensors=[dict(name='logits',shape=shape,present=True,coordinates=coords,shards=[dict(offset=0,value=dict(path=side+'-logits.npy'))])])
                elif kind=='distributions':manifest['positions']=[{**p,'scores':dict(path=side+'-logprobs.npy',row=i)} for i,p in enumerate(positions)]
                else:
                    lp=np.load(out/(side+'-logprobs.npy'),allow_pickle=False)
                    manifest['scores']=[{**p,'logprob':float(lp[i,p['token']])} for i,p in enumerate(spec['targets'])]
                mp=out/(side+'-'+kind+'.json');save(mp,manifest);manifests.append(mp)
            tool={'tensors':'compare_tensors.py','distributions':'compare_distributions.py','target-scores':'compare_target_scores.py'}[kind]
            rp=out/(kind+'-report.json')
            cmd=[sys.executable,str(TOOLS/tool),'--contract',str(cp),'--side-a',str(manifests[0]),'--side-b',str(manifests[1]),'--output',str(rp)]
            run=subprocess.run(cmd,capture_output=True,text=True)
            report=json.loads(rp.read_text()) if rp.exists() else {}
            receipts.append(dict(case=case.name,tool=tool,command=cmd,returncode=run.returncode,stdout=run.stdout,stderr=run.stderr,report=report))
            assert run.returncode==0 and report['status']=='no_thresholds',receipts[-1]
    save(metrics/'receipts.json',receipts)
    print(json.dumps([dict(case=r['case'],tool=r['tool'],returncode=r['returncode'],status=r['report']['status'],metrics=r['report'].get('global',r['report'].get('aggregate',r['report'].get('metrics')))) for r in receipts],indent=2))

if __name__=='__main__':main()
