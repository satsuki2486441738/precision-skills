"""Compare the retained Git baseline and current tool under ASCII parent stdio."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
from unittest.mock import patch

root=Path(__file__).resolve().parents[2]
target='skills/precision-skill/scripts/runtime_probe.py'
before=subprocess.check_output(['git','show','HEAD:'+target],cwd=root)
after=(root/target).read_bytes()
results={}
with tempfile.TemporaryDirectory(prefix='precision-encoding-repro-') as tmp:
    directory=Path(tmp)
    (directory/'noisy.py').write_text("print('中文' * 5000)\n",encoding='utf-8')
    for label,source in [('before',before),('after',after)]:
        p=directory/(label+'.py');p.write_bytes(source)
        spec=importlib.util.spec_from_file_location('probe_'+label,p)
        tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
        with patch.dict(os.environ,{'PYTHONIOENCODING':'ascii'}):
            result=tool.probe_runtime({'python_paths':[str(directory)],'imports':['noisy']})
        results[label]={'source_sha256':hashlib.sha256(source).hexdigest(),'status':result['status'],'returncode':result['returncode'],'diagnostic_bytes':result['diagnostic_bytes'],'tail':result['diagnostics'][-150:],'error':result.get('error')}
assert results['before']['status']=='failed'
assert results['after']['status']=='completed' and results['after']['tail'].rstrip('\r\n').endswith('中文')
out=Path(__file__).with_name('probe-encoding-before-after.json')
with out.open('x',encoding='utf-8') as f:json.dump(results,f,indent=2,allow_nan=False)
print(json.dumps(results,indent=2))
