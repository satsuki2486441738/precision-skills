#include "llama.h"
#include "ggml-backend.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <cmath>

// Copy-only observations around native prefill and cached decode. Both sides
// load exactly the same unquantized F16 GGUF and keep F16 KV storage.
int main(int argc,char **argv) {
    if(argc!=6) return 2;
    const bool npu=std::string(argv[5])=="cann";
    std::ifstream input(argv[2]); int prompt=0,rows=0; input>>prompt>>rows;
    if(prompt<=0 || rows<=0 || prompt+rows>120)return 3;
    std::vector<llama_token> ids(prompt+rows);
    for(auto &token:ids) input>>token;
    if(!input)return 4;
    ggml_backend_load_all(); llama_backend_init();
    if(npu) {
        bool found=false;
        for(size_t i=0;i<ggml_backend_dev_count();++i) {
            auto dev=ggml_backend_dev_get(i); std::string name=ggml_backend_dev_name(dev);
            if(name.find("CANN")!=std::string::npos || name.find("Ascend")!=std::string::npos)found=true;
        }
        if(!found){std::cerr<<"No native CANN backend registered\n";return 5;}
    }
    auto mp=llama_model_default_params();mp.n_gpu_layers=npu?999:0;
    mp.split_mode=LLAMA_SPLIT_MODE_NONE;mp.main_gpu=0;mp.check_tensors=true;
    auto model=llama_model_load_from_file(argv[1],mp);if(!model)return 6;
    auto cp=llama_context_default_params();cp.n_ctx=128;cp.n_batch=64;cp.n_ubatch=64;cp.n_seq_max=1;
    cp.n_threads=4;cp.n_threads_batch=4;cp.type_k=GGML_TYPE_F16;cp.type_v=GGML_TYPE_F16;
    cp.flash_attn_type=LLAMA_FLASH_ATTN_TYPE_DISABLED;cp.offload_kqv=npu;cp.op_offload=npu;
    auto ctx=llama_init_from_model(model,cp);if(!ctx)return 7;
    const int vocab=llama_vocab_n_tokens(llama_model_get_vocab(model));
    std::ofstream output(argv[3],std::ios::binary);auto batch=llama_batch_init(64,0,1);
    for(int step=0;step<rows;++step) {
        const int start=step==0?0:prompt+step-1,count=step==0?prompt:1;batch.n_tokens=count;
        for(int i=0;i<count;++i){batch.token[i]=ids[start+i];batch.pos[i]=start+i;batch.n_seq_id[i]=1;batch.seq_id[i][0]=0;batch.logits[i]=(i==count-1);}
        if(llama_decode(ctx,batch))return 8;
        const float *logits=llama_get_logits_ith(ctx,-1);if(!logits)return 9;
        for(int i=0;i<vocab;++i)if(!std::isfinite(logits[i]))return 10;
        output.write(reinterpret_cast<const char*>(logits),sizeof(float)*vocab);
    }
    output.close();if(!output)return 11;
    std::ofstream meta(argv[4]);
    meta<<"{\"vocab_size\":"<<vocab<<",\"rows\":"<<rows<<",\"prompt_length\":"<<prompt
        <<",\"native_entrypoint\":\"llama_decode -> llama_get_logits_ith\",\"backend\":\""<<(npu?"CANN":"CPU")
        <<"\",\"weight_storage\":\"F16 GGUF, no quantization\",\"kv_storage\":\"F16\",\"logits_storage\":\"F32\",\"cached_decode\":true,\"flash_attention\":false,\"gpu_layers_requested\":"<<(npu?999:0)<<"}";
    llama_batch_free(batch);llama_free(ctx);llama_model_free(model);llama_backend_free();return 0;
}
