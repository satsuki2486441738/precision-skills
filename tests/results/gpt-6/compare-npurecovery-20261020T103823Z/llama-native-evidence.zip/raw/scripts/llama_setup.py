"""Case-owned official llama.cpp CANN build; no import is native completion."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import urllib.request

ROOT=Path('/REMOTE_WORKSPACE/inference')
PIN='d8d92973c8c21bb4dd5d592f0fec26fe2cd1e654'
for part in ['sources','archives','build','cache','tmp','runs','scripts','models']:
    (ROOT/part).mkdir(parents=True,exist_ok=True)
os.environ.update(TMPDIR=str(ROOT/'tmp'),PIP_CACHE_DIR=str(ROOT/'cache'),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MAX_JOBS='4',ASCEND_RT_VISIBLE_DEVICES='0,1,2,3')

def work():
    out=ROOT/'runs'/('compare-llamabuild-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    out.mkdir()
    arc=ROOT/'archives'/('llama-'+PIN+'.tar.gz')
    source=ROOT/'sources'/('llama.cpp-'+PIN)
    failed=None
    try:
        if not arc.is_file():
            url='https://codeload.github.com/ggml-org/llama.cpp/tar.gz/'+PIN
            tmp=arc.with_suffix('.part')
            with urllib.request.urlopen(url,timeout=30) as response, tmp.open('wb') as f:
                while True:
                    b=response.read(1024*1024)
                    if not b:break
                    f.write(b)
            tmp.rename(arc)
        with tarfile.open(arc) as archive:
            if not source.is_dir():archive.extractall(ROOT/'sources',filter='data')
        assert (source/'ggml/src/ggml-cann/CMakeLists.txt').is_file()
        provenance={'repository':'https://github.com/ggml-org/llama.cpp','commit':PIN,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'source':str(source),'vendor_operators_modified':False}
        (out/'provenance.json').write_text(json.dumps(provenance,indent=2))
        stages=[
            ('configure',['cmake','-S',str(source),'-B',str(ROOT/'build/llama-cann'),'-DGGML_CANN=ON','-DSOC_TYPE=Ascend910_9382','-DUSE_ACL_GRAPH=OFF','-DLLAMA_CURL=OFF','-DLLAMA_BUILD_TESTS=OFF','-DCMAKE_BUILD_TYPE=Release','-DBUILD_SHARED_LIBS=ON']),
            ('build',['cmake','--build',str(ROOT/'build/llama-cann'),'--parallel','4']),
            ('adapter',['g++','-std=c++17','-O2',str(ROOT/'scripts/llama_native.cpp'),'-I'+str(source/'include'),'-I'+str(source/'ggml/include'),'-L'+str(ROOT/'build/llama-cann/bin'),'-Wl,-rpath,'+str(ROOT/'build/llama-cann/bin'),'-lllama','-lggml','-lggml-base','-o',str(ROOT/'build/llama-native-capture')]),
        ]
        for name,command in stages:
            with (out/(name+'.log')).open('wb') as log:
                rc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=3600).returncode
            with (out/'journal.jsonl').open('a') as f:f.write(json.dumps({'stage':name,'returncode':rc,'command':command})+'\n')
            if rc:
                failed=name
                break
    except Exception as exc:
        failed='bootstrap'
        (out/'exception.txt').write_text(repr(exc))
    status={'out':str(out),'failed_stage':failed,'native_framework_completed':False,'build_only':True}
    (out/'status.json').write_text(json.dumps(status,indent=2))
    (ROOT/'llama-build-latest.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status))
    return bool(failed)

if __name__=='__main__':
    if sys.argv[1:]==['start']:
        stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        log=ROOT/'runs'/('compare-llamalaunch-'+stamp+'.log')
        with log.open('xb') as f:p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'worker'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps({'pid':p.pid,'log':str(log),'native_framework_completed':False}))
    else:raise SystemExit(work())
