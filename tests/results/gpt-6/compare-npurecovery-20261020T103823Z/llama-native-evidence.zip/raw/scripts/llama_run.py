"""Run native CANN and CPU prefill/cached-decode on identical F16 GGUFs."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path('/REMOTE_WORKSPACE/inference')
SOURCE=ROOT/'sources/llama.cpp-d8d92973c8c21bb4dd5d592f0fec26fe2cd1e654'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b=f.read(4*1024*1024)
            if not b:break
            h.update(b)
    return h.hexdigest()

def worker():
    for k in ['LOCAL_RANK','RANK','WORLD_SIZE','LOCAL_WORLD_SIZE','MASTER_ADDR','MASTER_PORT']:os.environ.pop(k,None)
    os.environ['ASCEND_RT_VISIBLE_DEVICES']='0'
    os.environ['OMP_NUM_THREADS']='4';os.environ['OPENBLAS_NUM_THREADS']='4'
    import numpy as np
    from transformers import AutoTokenizer
    out=ROOT/'runs'/('compare-llamanative-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
    statuses=[]
    for name in ['Qwen3-0.6B','Qwen3-0.6B-Base']:
        case=out/name;case.mkdir();model=Path('/SHARED_MODELS')/name
        env=dict(os.environ,TORCH_DEVICE_BACKEND_AUTOLOAD='0',PYTHONPATH=str(SOURCE/'gguf-py')+':'+os.environ.get('PYTHONPATH',''))
        gguf=ROOT/'models'/(name+'-f16.gguf')
        commands=[]
        try:
            if not gguf.is_file():
                cmd=[sys.executable,str(SOURCE/'convert_hf_to_gguf.py'),str(model),'--outfile',str(gguf),'--outtype','f16']
                with (case/'convert.log').open('wb') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=1800).returncode
                commands.append({'stage':'convert','command':cmd,'returncode':rc});assert rc==0,'GGUF conversion failed'
            tok=AutoTokenizer.from_pretrained(model,local_files_only=True)
            prompt=tok.encode('Name one color.',add_special_tokens=False)
            continuation=tok.encode(' Blue and green.',add_special_tokens=False)[:3]
            assert len(continuation)==3
            (case/'tokens.txt').write_text(str(len(prompt))+' 3\n'+' '.join(map(str,prompt+continuation))+'\n')
            identity={'model':name,'config_sha256':sha(model/'config.json'),'safetensors':{p.name:sha(p) for p in model.glob('*.safetensors')},'gguf_sha256':sha(gguf),'gguf_conversion':'official convert_hf_to_gguf.py --outtype f16; no quantization','prompt':prompt,'continuation':continuation,'positions':list(range(len(prompt)+2)),'kv_storage':'F16','source_commit':'d8d92973c8c21bb4dd5d592f0fec26fe2cd1e654','thresholds':None}
            (case/'input-identity.json').write_text(json.dumps(identity,indent=2))
            for side in ['cpu','cann']:
                cmd=[str(ROOT/'build/llama-native-capture'),str(gguf),str(case/'tokens.txt'),str(case/(side+'-logits.f32')),str(case/(side+'-metadata.json')),side]
                with (case/(side+'.log')).open('wb') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1200).returncode
                commands.append({'stage':side,'command':cmd,'returncode':rc});assert rc==0,side+' native capture failed'
                info=json.loads((case/(side+'-metadata.json')).read_text())
                logits=np.fromfile(case/(side+'-logits.f32'),dtype=np.float32).reshape(info['rows'],info['vocab_size'])
                assert np.isfinite(logits).all()
                np.save(case/(side+'-logits.npy'),logits,allow_pickle=False)
            native_log=(case/'cann.log').read_text(errors='replace')
            m=re.search(r'offloaded\s+(\d+)/(\d+)\s+layers',native_log)
            assert m and int(m[1])==int(m[2]) and int(m[1])>0,'No complete native layer-offload evidence'
            report={'status':'native_cann_and_independent_cpu_complete','model':name,'native_entrypoint':'llama_decode prefill plus two cached decode calls','layer_offload':[int(m[1]),int(m[2])],'logits_dtype':'native F32 output','thresholds':None,'files_sha256':{p.name:sha(p) for p in case.iterdir() if p.is_file()},'commands':commands}
            (case/'completion.json').write_text(json.dumps(report,indent=2));statuses.append(report)
        except Exception as exc:
            failure={'status':'failed','model':name,'error':repr(exc),'commands':commands}
            (case/'failure.json').write_text(json.dumps(failure,indent=2));statuses.append(failure)
    summary={'attempt':str(out),'cases':statuses,'thresholds':None}
    (out/'status.json').write_text(json.dumps(summary,indent=2));(ROOT/'llama-native-latest.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))

if __name__=='__main__':
    if sys.argv[1:]==['start']:
        log=ROOT/'runs'/('compare-llamanativelaunch-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.log')
        with log.open('xb') as f:p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'worker'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps({'pid':p.pid,'log':str(log)}))
    else:worker()
