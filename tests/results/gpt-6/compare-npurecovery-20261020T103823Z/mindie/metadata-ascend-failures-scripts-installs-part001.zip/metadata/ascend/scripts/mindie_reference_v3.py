"""Independent CPU FP32 forward at the actual native MindIE token histories.

This is a reference execution, never a substitute for the MindIE native run.
Requires its completed native-result.json and original capture from one TP=1
request. Native generation is left untouched. The CPU run conditions on the
native chosen IDs and recomputes the full prefix without a KV cache; that cache
difference is explicit. Does not claim independent greedy rollout equality.
"""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--native-output', required=True)
    ap.add_argument('--model', required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--checkpoint-identity', required=True)
    args = ap.parse_args()
    native = Path(args.native_output).resolve()
    identity=json.loads(Path(args.checkpoint_identity).read_text())
    assert identity['all_file_bytes_equal']
    def checkpoint_hash(path):
        h=hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
        return h.hexdigest()
    for item in identity['files']:
        for location in [Path(identity['source']),Path(identity['private_copy'])]:
            assert checkpoint_hash(location/item['name'])==item['source_sha256'],str(location/item['name'])
    model_path = Path(args.model).resolve()
    out = Path(args.output).resolve()
    result = json.loads((native / 'native-result.json').read_text())
    assert result['status'] == 'native_execution_complete' and result['framework'] == 'MindIE-LLM'
    assert result['world_size'] == 1 and result['rank'] == 0
    out.mkdir(parents=True, exist_ok=False)
    import torch
    from transformers import AutoModelForCausalLM
    # Only task-owned recorded tensors are deserialized. Their native outcomes
    # are used for comparison and common history, never for reference weights.
    captured = torch.load(native / result['captures'], map_location='cpu', weights_only=False)
    calls = captured['forward_calls']
    tokens = result['generated_token_ids']
    assert len(calls) == len(tokens) and len(tokens) == 4, 'Native invocation/step mapping must be unambiguous'
    config = json.loads((model_path / 'config.json').read_text())
    vocab = config['vocab_size']
    model = AutoModelForCausalLM.from_pretrained(str(model_path), torch_dtype=torch.float32, attn_implementation='eager', device_map={'': 'cpu'}, local_files_only=True)
    model.eval()
    assert all(p.device.type == 'cpu' and p.dtype == torch.float32 for p in model.parameters())
    prefix = list(result['input_ids'])
    native_rows = []
    reference_rows = []
    native_scores = []
    reference_scores = []
    boundaries = []
    with torch.inference_mode():
        for step, (call, target) in enumerate(zip(calls, tokens)):
            assert call['native_logits_device'].startswith('npu:'), 'Original native logits must come from an actual NPU'
            tensor = call['native_logits']
            assert tensor.shape[-1] == vocab, 'Padded/sharded vocabulary needs an explicit logical mapping before comparison'
            rows = tensor.reshape(-1, vocab)
            if rows.shape[0] == 1:
                index = 0
            elif step == 0 and rows.shape[0] == len(prefix):
                index = len(prefix) - 1
            else:
                raise AssertionError('Native row selection is ambiguous: ' + str(tuple(tensor.shape)))
            native_row = rows[index].clone()
            assert torch.isfinite(native_row).all()
            native_ids = call['inputs'].get('input_ids')
            if torch.is_tensor(native_ids):
                actual = native_ids.reshape(-1).tolist()
                assert actual == (prefix if step == 0 else prefix[-1:]), 'Native call token inputs differ from the declared request history'
            output = model(input_ids=torch.tensor([prefix], dtype=torch.long), attention_mask=torch.ones(1, len(prefix), dtype=torch.long), use_cache=False)
            reference_row = output.logits[0, -1].detach().clone()
            native_rows.append(native_row)
            reference_rows.append(reference_row)
            coordinate = {'sample_id': 'mindie-request-0', 'prediction_position': len(prefix) - 1, 'target_position': len(prefix), 'token_id': int(target), 'generation_step': step}
            native_scores.append(dict(coordinate, logprob=float(native_row.float().log_softmax(-1)[target])))
            reference_scores.append(dict(coordinate, logprob=float(reference_row.float().log_softmax(-1)[target])))
            boundaries.append(dict(coordinate, native_shape=list(tensor.shape), selected_native_row=index, common_input_ids=list(prefix)))
            prefix.append(int(target))
    torch.save({'full_vocab_logits': torch.stack(reference_rows), 'boundaries': boundaries}, out / 'reference-captures.pt')
    (out / 'native-target-score-records.json').write_text(json.dumps(native_scores, indent=2))
    (out / 'reference-target-score-records.json').write_text(json.dumps(reference_scores, indent=2))
    native_logprobs = torch.stack(native_rows).float().log_softmax(-1)
    reference_logprobs = torch.stack(reference_rows).float().log_softmax(-1)
    errors = torch.tensor([abs(a['logprob'] - b['logprob']) for a, b in zip(native_scores, reference_scores)], dtype=torch.float64)
    evidence = {'status': 'independent_reference_complete', 'framework_native': 'MindIE-LLM', 'reference': 'Transformers CPU FP32', 'reference_model_path': str(model_path), 'reference_config_sha256': hashlib.sha256((model_path / 'config.json').read_bytes()).hexdigest(), 'native_captures_sha256': hashlib.sha256((native / result['captures']).read_bytes()).hexdigest(), 'common_request_histories': boundaries, 'reference_device': 'cpu', 'reference_compute': 'fp32', 'native_cache_retained': True, 'reference_use_cache': False, 'cache_condition_difference_explicit': True, 'native_arithmetic_changed': False, 'reference_loaded_native_parameters_or_optimizer_outcomes': False, 'native_generated_tokens_used_only_as_common_conditioning_histories': True, 'valid_target_count': len(tokens), 'native_nll': -sum(x['logprob'] for x in native_scores) / len(tokens), 'reference_nll': -sum(x['logprob'] for x in reference_scores) / len(tokens), 'target_logprob_mae': float(errors.mean()), 'target_logprob_maximum_error': float(errors.max()), 'full_vocab_logprob_finite': bool(torch.isfinite(native_logprobs).all() and torch.isfinite(reference_logprobs).all()), 'thresholds': None, 'coverage_limit': 'Four fixed-history prediction rows of one native generated request; no all-context-row, independent greedy token agreement or throughput claim.'}
    evidence['checkpoint_identity']=identity
    evidence['native_checkpoint_after_generation_matches_original']=True
    evidence['logprob_derivation']='FP32 full-vocabulary log_softmax of original native BF16 or reference FP32 raw logits, before sampling processors'
    for item in identity['files']:
        assert checkpoint_hash(model_path/item['name'])==item['source_sha256']
    evidence['reference_checkpoint_unchanged_after_execution']=True
    (out / 'reference-execution.json').write_text(json.dumps(evidence, indent=2))
    print(json.dumps(evidence, indent=2))


if __name__ == '__main__':
    main()
