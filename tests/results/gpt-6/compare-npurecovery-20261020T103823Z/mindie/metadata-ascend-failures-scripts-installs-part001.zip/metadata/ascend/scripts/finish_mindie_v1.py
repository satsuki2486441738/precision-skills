"""Independent checkpoint-hash-verified CPU replay followed by core comparison."""
from pathlib import Path
import subprocess
import sys
root = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
python = str(root / 'envs/mindie-torch2.9.0-npu2.9.0.post6/bin/python')
subprocess.run([python, '-B', str(root / 'scripts/mindie_reference_v3.py'), '--native-output', str(root / 'results/mindie-native-attempt07'), '--model', '/host-model/Qwen3-0.6B', '--output', str(root / 'results/mindie-reference-attempt01'), '--checkpoint-identity', str(root / 'results/mindie-owned-checkpoint-identity.json')], check=True)
subprocess.run([python, '-B', str(root / 'scripts/compare_mindie_reference_v1.py')], check=True)
