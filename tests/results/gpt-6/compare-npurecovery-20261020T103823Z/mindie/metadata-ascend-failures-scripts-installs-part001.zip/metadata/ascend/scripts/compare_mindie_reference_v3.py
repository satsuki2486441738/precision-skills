"""Export native ATB/independent CPU rows; run all applicable core comparators."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import torch
from safetensors.torch import save_file

root = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z')
asc = root / 'ascend'
native = asc / 'results/mindie-native-attempt07'
reference = asc / 'results/mindie-reference-attempt01'
out = asc / 'metrics/mindie-qwen3-06b-attempt03'
out.mkdir(parents=True, exist_ok=False)
proof = json.loads((reference / 'reference-execution.json').read_text())
assert proof['status'] == 'independent_reference_complete'
result = json.loads((native / 'native-result.json').read_text())
n = torch.load(native / 'rank-0-native-captures.pt', map_location='cpu', weights_only=False)
r = torch.load(reference / 'reference-captures.pt', map_location='cpu', weights_only=False)
boundaries = r['boundaries']
native_rows = torch.stack([call['native_logits'].reshape(-1, 151936)[b['selected_native_row']] for call, b in zip(n['forward_calls'], boundaries)])
assert native_rows.shape == r['full_vocab_logits'].shape == (4, 151936)
coordinates = [{'sample': 'mindie-request-0', 'position': row['prediction_position'], 'history': row['common_input_ids']} for row in boundaries]
targets = [{'sample': 'mindie-request-0', 'position': row['target_position'], 'token': row['token_id']} for row in boundaries]
scores = {}
original_normalization = {}
for side, logits in [('native', native_rows), ('reference', r['full_vocab_logits'])]:
    logprobs = logits.float().log_softmax(-1)
    original_normalization[side] = logprobs.double().logsumexp(-1).tolist()
    chosen = torch.stack([logprobs[i, row['token']] for i, row in enumerate(targets)])
    save_file({'logits': logits.contiguous(), 'logprobs': logprobs.contiguous(), 'target_nll': -chosen, 'mean_nll': -chosen.mean().reshape(1)}, str(out / (side + '.safetensors')))
    scores[side] = [{**row, 'logprob': float(chosen[i])} for i, row in enumerate(targets)]
identity = proof['checkpoint_identity']
common = {'model': {'checkpoint_file_hashes': identity['files'], 'family': 'Qwen3-0.6B', 'unquantized': True}, 'inputs': {'request_input_ids': result['input_ids'], 'actual_native_generated_token_ids': result['generated_token_ids'], 'histories': coordinates, 'native_logits_boundary': 'ModelRunner.forward return before sampling/postprocessor, warmup excluded'}, 'scope': {'rank': 0, 'world_size': 1, 'requests': 1, 'paired_prediction_rows': 4, 'training': False}}
conditions = {'native': {'numerics': {'device': 'npu', 'raw_logits_dtype': 'bfloat16', 'logprob_dtype': 'float32', 'backend': 'MindIE-LLM native ATB PagedAttention', 'native_kv_cache_retained': True, 'rows': 'native available generation prediction rows only'}}, 'reference': {'numerics': {'device': 'cpu', 'raw_logits_dtype': 'float32', 'logprob_dtype': 'float32', 'backend': 'Transformers CPU FP32 eager', 'use_cache': False, 'conditioning': 'Same actual native histories; no independent greedy rollout equality claim'}}}


def dump(path, value): path.write_text(json.dumps(value, indent=2))


for side in conditions:
    runtime = json.loads((native / 'native-runtime.json').read_text()) if side == 'native' else {'transformers': '4.51.3', 'torch': torch.__version__}
    dump(out / (side + '-environment.json'), {'rank': 0, 'versions': runtime, 'actual': {**common, **conditions[side]}})
    dump(out / (side + '-status.json'), {'rank': 0, 'status': 'completed', 'evidence': str(native if side == 'native' else reference)})
commands = []
for stage, kind in [('observations', 'tensors'), ('distributions', 'distributions'), ('targets', 'target-scores')]:
    schema = 1 if kind == 'target-scores' else 2
    spec = {'schema_version': schema, 'kind': kind, 'thresholds': None, 'common': common, 'side_conditions': conditions, 'expected_ranks': {side: [0] for side in conditions}}
    tensors = [{'name': 'logits', 'shape': [4, 151936], 'present': True}, {'name': 'target_nll', 'shape': [4], 'present': True}, {'name': 'mean_nll', 'shape': [1], 'present': True}]
    for tensor in tensors:
        tensor['coordinates']={'stage':'inference','boundary':'native ModelRunner.forward logits before processors, or explicit FP32 score-derived NLL','prediction_rows':coordinates,'targets':targets,'reduction':'one scalar mean over four targets' if tensor['name']=='mean_nll' else 'none'}
    if kind == 'tensors': spec.update(stage=stage, tensors=tensors)
    elif kind == 'distributions': spec.update(vocab_size=151936, positions=coordinates, normalization_tolerance=1e-3, renormalization='full_vocabulary_fp64')
    else: spec.update(targets=targets)
    dump(out / (stage + '-contract.json'), spec)
    for side in conditions:
        manifest = {'schema_version': schema, 'kind': kind, 'side': side, 'common': common, 'expected_ranks': [0], 'ranks': [{'rank': 0, 'environment': side + '-environment.json', 'status': side + '-status.json'}]}
        if kind == 'tensors': manifest.update(stage=stage, tensors=[{**t, 'shards': [{'offset': 0, 'value': {'path': side + '.safetensors', 'key': t['name']}}]} for t in tensors])
        elif kind == 'distributions': manifest.update(positions=[{**row, 'scores': {'path': side + '.safetensors', 'key': 'logprobs', 'row': i}} for i, row in enumerate(coordinates)])
        else: manifest.update(scores=scores[side])
        dump(out / (stage + '-' + side + '.json'), manifest)
    filename = {'tensors': 'compare_tensors.py', 'distributions': 'compare_distributions.py', 'target-scores': 'compare_target_scores.py'}[kind]
    tool = root / 'sft/core-tools' / filename
    command = [sys.executable, '-B', str(tool), '--contract', str(out / (stage + '-contract.json')), '--side-a', str(out / (stage + '-native.json')), '--side-b', str(out / (stage + '-reference.json')), '--output', str(out / (stage + '-comparison.json'))]
    with (out / (stage + '-comparison.log')).open('xb') as f: code = subprocess.run(command, stdout=f, stderr=subprocess.STDOUT).returncode
    commands.append({'argv': command, 'returncode': code, 'core_sha256': hashlib.sha256(tool.read_bytes()).hexdigest()})
dump(out / 'capture-provenance.json', {'native_result': result, 'independent_reference': proof, 'native_raw_logits_dtype_preserved': True, 'logprob_derivation': proof['logprob_derivation'], 'coverage_limit': result['coverage_limit'], 'cache_condition_difference': conditions, 'thresholds': None, 'commands': commands, 'distribution_normalization': {'stored_scores': 'original FP32 full-vocabulary log_softmax unchanged', 'original_log_normalizers': original_normalization, 'declared_core_policy': 'full_vocabulary_fp64', 'normalization_invariant_tolerance': 1e-3, 'reason': 'Actual original FP32 large-vocabulary softmax mass deviations up to1.03e-4; original scores retained; distribution comparator explicitly renormalizes full vocabulary in FP64. This is not a native operator change or numerical acceptance threshold.'}, 'raw_native_sha256': hashlib.sha256((native / 'rank-0-native-captures.pt').read_bytes()).hexdigest(), 'raw_reference_sha256': hashlib.sha256((reference / 'reference-captures.pt').read_bytes()).hexdigest()})
assert all(c['returncode'] == 0 for c in commands), commands
print(json.dumps({'status': 'native_and_independent_reference_core_metrics_complete', 'output': str(out), 'commands': commands, 'thresholds': None}, indent=2))
