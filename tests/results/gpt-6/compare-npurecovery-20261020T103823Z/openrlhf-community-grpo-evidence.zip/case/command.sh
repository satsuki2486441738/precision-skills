#!/bin/bash
set -Euo pipefail
source /usr/local/Ascend/cann/set_env.sh
unset LOCAL_RANK RANK WORLD_SIZE LOCAL_WORLD_SIZE GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE NODE_RANK MASTER_ADDR MASTER_PORT
export PATH=/REMOTE_WORKSPACE/rlar/environments/openrlhf-community/bin:"$PATH" PIP_CACHE_DIR=/REMOTE_WORKSPACE/rlar/cache/pip TMPDIR=/REMOTE_WORKSPACE/rlar/tmp/openrlhf-community DS_BUILD_OPS=0 MAX_JOBS=4 OMP_NUM_THREADS=1 TORCH_EXTENSIONS_DIR=/REMOTE_WORKSPACE/rlar/cache/torch_extensions
export PYTHONPATH=/REMOTE_WORKSPACE/rlar/drivers/attempt12:/REMOTE_WORKSPACE/rlar/sources/openrlhf-community-archive:"${PYTHONPATH:-}"
export ASCEND_RT_VISIBLE_DEVICES=8,9,10,11 RLAR_OUTPUT=/REMOTE_WORKSPACE/rlar/results/openrlhf-community-native-dtfs-20261020T112322Z RLAR_SOURCE=/REMOTE_WORKSPACE/rlar/sources/openrlhf-community-archive RLAR_FRAMEWORK=openrlhf-community RLAR_WORKER_CLASSES=1 TOKENIZERS_PARALLELISM=false PYTHONUNBUFFERED=1
export VLLM_ASCEND_ENABLE_NZ=0 HCCL_OP_EXPANSION_MODE=HOST HCCL_CONNECT_TIMEOUT=120 HCCL_NPU_SOCKET_PORT_RANGE=auto
mkdir -p "$TMPDIR" "$TORCH_EXTENSIONS_DIR"
true
rc=$?
if [ "$rc" -eq 0 ]; then
 date -u > /REMOTE_WORKSPACE/rlar/logs/openrlhf-community-install-ready.txt
 export RLAR_CAPTURE=1 PYTORCH_NPU_ALLOC_CONF=expandable_segments:False TMPDIR=/tmp/rlar-openrlhf-community-20261020T112322Z
 mkdir -p "$TMPDIR"
 export HF_HOME=/REMOTE_WORKSPACE/rlar/cache/huggingface XDG_CACHE_HOME=/REMOTE_WORKSPACE/rlar/cache VLLM_CACHE_ROOT=/REMOTE_WORKSPACE/rlar/cache/vllm TRITON_CACHE_DIR=/REMOTE_WORKSPACE/rlar/cache/triton TORCHINDUCTOR_CACHE_DIR=/REMOTE_WORKSPACE/rlar/cache/torchinductor
 exec 9>/REMOTE_WORKSPACE/rlar/native.lock
 flock 9
 python -m pip freeze > /REMOTE_WORKSPACE/rlar/results/openrlhf-community-native-dtfs-20261020T112322Z/installed_freeze.txt
 timeout --signal=TERM --kill-after=40s 1000s python /REMOTE_WORKSPACE/rlar/drivers/attempt12/native_open.py train && python /REMOTE_WORKSPACE/rlar/drivers/attempt12/native_open.py verify
 rc=$?
fi
printf '{"exit_code":%s}\n' "$rc" > /REMOTE_WORKSPACE/rlar/results/openrlhf-community-native-dtfs-20261020T112322Z/process_exit.json
exit "$rc"
