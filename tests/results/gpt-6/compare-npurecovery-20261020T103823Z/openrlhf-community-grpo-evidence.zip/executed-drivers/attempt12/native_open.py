"""Actual community OpenRLHF Ray PPO entry. Identity is separate from upstream."""
import json,os,sys,time,uuid,runpy
from pathlib import Path
def emit(name,**kw):
 d={"event":name,"pid":os.getpid(),"time":time.time(),"identity":"zhuo97/OpenRLHF@06ac74cf1ea896c379ef4cb6a39dbd8488fb16fd",**kw}
 out=Path(os.environ["RLAR_OUTPUT"]);out.mkdir(parents=True,exist_ok=True)
 (out/(name+".json")).write_text(json.dumps(d,indent=2,default=str));print("RLAR_STAGE "+json.dumps(d,default=str),flush=True)
def reward_func(queries,prompts,labels):
 import torch
 vals=[sum(ord(c) for c in q[-96:])%997/997.0 for q in queries]
 result=torch.tensor(vals,dtype=torch.float32)
 emit("reward_observed",values=vals,query_count=len(queries),reward_fn="sum utf8 codepoints of actual final 96 generated/query chars modulo 997 / 997")
 return result
def train():
 import ray,torch,torch_npu,importlib.metadata as md
 out=Path(os.environ["RLAR_OUTPUT"]);rows=[{"prompt":"Count 1 2 3 then continue briefly.","label":"4"},{"prompt":"Write three small numbers.","label":"1"}]
 (out/"data.jsonl").write_text("\n".join(json.dumps(x) for x in rows)+"\n")
 emit("runtime",torch=torch.__version__,torch_path=torch.__file__,torch_npu=md.version("torch-npu"),python=sys.version,visible=os.environ.get("ASCEND_RT_VISIBLE_DEVICES"),devices=[torch.npu.get_device_name(i) for i in range(torch.npu.device_count())],recipe_mismatch="Community recipe tested Torch2.5.1/CANN8.1/A2; this explicit compatibility attempt uses host CANN9.1/A3 with private TorchNPU2.9post6")
 raytmp="/tmp/rlar-open-"+uuid.uuid4().hex[:8]
 ray.init(address="local",num_cpus=4,num_gpus=0,object_store_memory=2147483648,resources={"NPU":4},include_dashboard=False,namespace="rlar-open-"+uuid.uuid4().hex[:8],_temp_dir=raytmp,runtime_env={"env_vars":{k:v for k,v in os.environ.items() if k.startswith("RLAR_") or k in ("PYTHONPATH","ASCEND_RT_VISIBLE_DEVICES","OMP_NUM_THREADS","PATH","LD_LIBRARY_PATH","ASCEND_HOME_PATH")}})
 args=["--actor_num_nodes","1","--actor_num_gpus_per_node","1","--vllm_num_engines","1","--vllm_tensor_parallel_size","1","--vllm_gpu_memory_utilization","0.2","--enforce_eager","--pretrain","/SHARED_MODELS/Qwen3-0.6B","--save_path",str(out/"checkpoint"),"--prompt_data",str(out/"data.jsonl"),"--input_key","prompt","--label_key","label","--apply_chat_template","--remote_rm_url",str(Path(__file__).resolve()),"--micro_train_batch_size","4","--train_batch_size","4","--micro_rollout_batch_size","4","--rollout_batch_size","2","--n_samples_per_prompt","2","--max_samples","2","--max_epochs","1","--num_episodes","1","--prompt_max_len","128","--generate_max_len","8","--max_len","256","--zero_stage","0","--bf16","--actor_learning_rate","0.001","--lr_warmup_ratio","0","--init_kl_coef","0","--advantage_estimator","group_norm","--seed","20261020","--save_steps","-1","--eval_steps","-1"]
 (out/"argv.json").write_text(json.dumps(args,indent=2));sys.argv=["openrlhf.cli.train_ppo_ray"]+args
 try:
  runpy.run_module("openrlhf.cli.train_ppo_ray",run_name="__main__")
  emit("native_train_returned",entry="openrlhf.cli.train_ppo_ray")
 finally:
  ray.shutdown()
  import shutil
  for logs in Path(raytmp).glob("session_*/logs"):
   if not logs.parent.is_symlink():shutil.copytree(logs,out/"ray"/logs.parent.name/"logs",dirs_exist_ok=True,symlinks=True)
 emit("rank_complete",role="driver",rank=0)
def verify():
 out=Path(os.environ["RLAR_OUTPUT"])
 events=[json.loads(p.read_text()) for p in (out/"optimizer").glob("*.json")]
 assert events and all(x["finite_updates"] for x in events) and any(x["update_l2"]>0 for x in events)
 for name in ("rollout_observed","advantages_observed","objective_returned","reward_observed","native_train_returned","rank_complete"):assert (out/(name+".json")).is_file(),name
 emit("completion",status="community_native_rollout_reward_advantage_loss_optimizer_complete",optimizer_steps=len(events),update_l2=[x["update_l2"] for x in events],upstream_native_pass=False)
if __name__=="__main__":
 if sys.argv[1]=="train":train()
 elif sys.argv[1]=="verify":verify()
 else:raise ValueError(sys.argv[1])
