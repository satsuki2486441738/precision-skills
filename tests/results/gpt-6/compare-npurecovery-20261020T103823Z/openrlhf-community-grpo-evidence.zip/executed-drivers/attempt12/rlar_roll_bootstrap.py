"""Official torch_npu CUDA-named API migration, executed only in native ROLL workers."""
import os, pathlib, json, hashlib, time
def install():
    from roll.platforms import current_platform
    assert current_platform.device_type == "npu", type(current_platform).__name__
    import torch, torch_npu
    from torch_npu.contrib import transfer_to_npu
    f=pathlib.Path(transfer_to_npu.__file__)
    out=pathlib.Path(os.environ['RLAR_OUTPUT'])/'vendor-adapter';out.mkdir(parents=True,exist_ok=True)
    record={'event':'official_torch_npu_transfer_to_npu_enabled','pid':os.getpid(),'time':time.time(),'adapter_file':str(f),'adapter_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'torch_npu_version':torch_npu.__version__,'torch_version':torch.__version__,'torch_build_cuda':torch.version.cuda,'actual_npu_available':torch.npu.is_available(),'actual_npu_count':torch.npu.device_count(),'actual_npu_name':torch.npu.get_device_name(0) if torch.npu.device_count() else None,'native_core_source_modified':False,'cuda_emulated':False,'scope':'official torch_npu migration adapter translates CUDA-named tensor/device APIs to genuine NPU operations'}
    (out/f'pid{os.getpid()}.json').write_text(json.dumps(record,indent=2))
