"""Delayed passive native wrappers; no eager Torch/DeepSpeed imports in Ray agents."""
import os,sys,json,uuid,time,traceback,importlib.abc,importlib.machinery
from pathlib import Path

def save(name,data,**meta):
 import torch
 def convert(v):
  if torch.is_tensor(v):return v.detach().cpu().clone()
  if isinstance(v,dict):return {k:convert(x) for k,x in v.items() if torch.is_tensor(x) or isinstance(x,(dict,list,tuple))}
  if isinstance(v,(list,tuple)):return [convert(x) for x in v]
  if hasattr(v,'__dict__'):return convert(vars(v))
  return v
 out=Path(os.environ['RLAR_OUTPUT']);folder=out/'native-tensors';folder.mkdir(parents=True,exist_ok=True)
 fn=folder/(name+'-pid'+str(os.getpid())+'-'+uuid.uuid4().hex+'.pt');torch.save(convert(data),fn)
 d={'event':name,'pid':os.getpid(),'time':time.time(),'artifact':str(fn),'native_call_stack':traceback.format_stack(limit=20),**meta}
 (out/(name+'.json')).write_text(json.dumps(d,indent=2,default=str));print('RLAR_NATIVE '+json.dumps(d,default=str),flush=True)

def patch(name,module):
 if name=='openrlhf.models.actor':
  cls=module.Actor;original=cls.forward
  def observed_actor(self,sequences,*args,**kwargs):
   result=original(self,sequences,*args,**kwargs)
   import torch
   if kwargs.get('return_output') and torch.is_grad_enabled() and isinstance(result,tuple):
    logps,output=result;mask=kwargs.get('action_mask',args[0] if args else None)
    if mask is not None:
     coords=[]
     for row in range(mask.shape[0]):
      positions=torch.nonzero(mask[row],as_tuple=False).flatten()
      for ix in (positions[0],positions[-1]):coords.append((row,sequences.shape[1]-1-mask.shape[1]+int(ix)))
     coords=torch.tensor(coords,dtype=torch.long,device=output.logits.device)
     save('policy_forward_observed',{'native_full_vocab_rows':output.logits[coords[:,0],coords[:,1]],'row_coordinates':coords,'native_action_log_probs':logps},temperature=float(self.temperature),native_logits_dtype=str(output.logits.dtype),native_action_logprob_dtype=str(logps.dtype),actual_device=str(output.logits.device),capture='passive original Actor.forward returned logits rows and exact returned target logprobs during native gradient-enabled training')
   return result
  cls.forward=observed_actor
 elif name=='openrlhf.models.loss':
  cls=module.PolicyLoss;original=cls.forward
  def observed(self,log_probs,old_log_probs,advantages,action_mask=None):
   result=original(self,log_probs,old_log_probs,advantages,action_mask)
   save('objective_returned',{'log_probs':log_probs,'old_log_probs':old_log_probs,'advantages':advantages,'action_mask':action_mask,'loss':result},loss=float(result.detach().item()),loss_dtype=str(result.dtype),loss_device=str(result.device));return result
  cls.forward=observed
 elif name=='openrlhf.trainer.ppo_utils.experience_maker':
  cls=module.RemoteExperienceMaker;generate=cls.generate_samples;adv=cls.compute_advantages_and_returns
  def observed_generate(self,*args,**kwargs):
   result=generate(self,*args,**kwargs);save('rollout_observed',result);return result
  def observed_adv(self,*args,**kwargs):
   result=adv(self,*args,**kwargs);save('advantages_observed',result);return result
  cls.generate_samples=observed_generate;cls.compute_advantages_and_returns=observed_adv
 elif name=='openrlhf.trainer.ray.ppo_actor':
  cls=module.ActorPPOTrainer;original=cls.training_step
  def observed_step(self,*args,**kwargs):
   engine=self.actor.model
   names={id(p):name for name,p in engine.module.named_parameters()}
   groups=getattr(engine.optimizer,'bf16_groups',None)
   if groups is not None:
    mapping=[]
    for gi,group in enumerate(groups):
     offset=0;items=[]
     for parameter in group:
      items.append({'name':names.get(id(parameter)),'shape':list(parameter.shape),'numel':parameter.numel(),'flat_offset':offset,'dtype':str(parameter.dtype),'requires_grad':parameter.requires_grad});offset+=parameter.numel()
     mapping.append({'group':gi,'parameters':items,'total_numel':offset})
    metadata={'event':'native_deepspeed_bf16_flat_parameter_layout','pid':os.getpid(),'rank':os.environ.get('RANK'),'groups':mapping,'source':'actual native DeepSpeed BF16Optimizer.bf16_groups linked to actor module named_parameters by identity','loss_args':vars(self.args)}
    (Path(os.environ['RLAR_OUTPUT'])/'deepspeed-flat-layout.json').write_text(json.dumps(metadata,indent=2,default=str))
   save('training_step_inputs',args[0])
   result=original(self,*args,**kwargs);save('actor_rank_step_complete',{},rank=os.environ.get('RANK'),result=result);return result
  cls.training_step=observed_step

class NativeFinder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname not in ('openrlhf.models.actor','openrlhf.models.loss','openrlhf.trainer.ppo_utils.experience_maker','openrlhf.trainer.ray.ppo_actor'):return None
  spec=importlib.machinery.PathFinder.find_spec(fullname,path)
  if spec and spec.loader:
   original=spec.loader.exec_module
   def execute(module):original(module);patch(fullname,module)
   spec.loader.exec_module=execute
  return spec
sys.meta_path.insert(0,NativeFinder())
