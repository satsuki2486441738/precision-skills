"""Portable interfaces from one immutable native capture and its clean CPU reference."""
import os,sys,pathlib,argparse,json,subprocess,shlex,datetime,hashlib,zipfile
ap=argparse.ArgumentParser();ap.add_argument('--framework',choices=['roll','openrlhf-community'],required=True);ap.add_argument('--case',required=True);a=ap.parse_args();r=pathlib.Path(os.environ['PRECISION_REMOTE_ROOT'])/'rlar'
if os.environ.get('RL_PORTABLE_WORKER')!='1':
 env=os.environ.copy();env['RL_PORTABLE_WORKER']='1';env.pop('RLAR_CAPTURE',None);driver=r/'drivers/portable01/export_rl_portable.py';assert driver.exists();cmd='source /usr/local/Ascend/cann/set_env.sh && '+shlex.join([str(r/'environments'/a.framework/'bin/python'),str(driver)]+sys.argv[1:]);p=subprocess.run(['bash','-lc',cmd],env=env,capture_output=True,text=True,timeout=180);print(p.stdout);print(p.stderr,file=sys.stderr);raise SystemExit(p.returncode)
import torch,numpy as np,importlib.metadata as md
from safetensors.torch import save_file
n=r/'results'/a.case;reference=sorted((n/'reference').glob('*'))[-1]
assert json.loads((n/'process_exit.json').read_text())['exit_code']==0 and json.loads((reference/'process_exit.json').read_text())['exit_code']==0
def load(p):return torch.load(p,map_location='cpu',weights_only=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def thash(t):return sha(t.contiguous().numpy().tobytes())
def write(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
ref=load(reference/'reference-tensors.pt');native=load(reference/'native-comparison-tensors.pt');result=json.loads((reference/'reference-completion.json').read_text());optimizer=json.loads(next((n/'optimizer').glob('*.json')).read_text());ids=[];attention=[];masks=[];sources=[]
if a.framework=='roll':
 for meta_path in sorted((n/'native-tensors').glob('native-current-policy*.json'),key=lambda p:p.stat().st_mtime_ns):
  meta=json.loads(meta_path.read_text());data=load(n/'native-tensors'/meta['inputs_file']);ids.extend(data['input_ids'].tolist());attention.extend(data['attention_mask'].tolist());masks.extend(data.get('final_response_mask',data['response_mask'][:,1:]).tolist());sources += [meta_path,n/'native-tensors'/meta['inputs_file'],n/'native-tensors'/meta['policy_file']]
 objective={'clip':.2,'group_unbiased_std_eps':1e-6,'reduction':'sum per-sequence valid-token mean / global4 samples; sum two microbatches; apply_loss_scale2 then gradient_accumulation/2','kl_loss':False,'train_infer_is_weight':False,'old_policy':'native actual get_old_log_probs_with_cache returned anchor (first current forward detached)'}
else:
 data=load(next((n/'native-tensors').glob('training_step_inputs*.pt')));ids=data['sequences'].tolist();attention=data['attention_mask'].tolist();masks=data['action_mask'].tolist();sources=list((n/'native-tensors').glob('*.pt'))+[n/'deepspeed-flat-layout.json',n/'source-compatibility-patch.json'];objective={'clip':.2,'group_unbiased_std_eps':1e-9,'reduction':'masked sum /32 valid actions','kl_loss':False,'old_policy':'fixed captured native experience-maker preupdate target logprobs'}
common={'model':{'id':'Qwen3-0.6B','config_sha256':sha(pathlib.Path('/SHARED_MODELS/Qwen3-0.6B/config.json').read_bytes())},'inputs':{'ids_sha256':sha(json.dumps(ids).encode()),'attention_mask_sha256':sha(json.dumps(attention).encode()),'effective_action_mask_sha256':sha(json.dumps(masks).encode()),'old_policy_anchor_sha256':thash(ref['old_policy_anchors']),'temperature':1.0,'group_size':2,'objective':objective},'scope':{'framework':a.framework,'task':'native GRPO optimizer_step0','trajectories':result['coverage']['trajectories'],'complete_groups':result['coverage']['complete_groups'],'valid_actions':result['coverage']['valid_actions'],'parameter_capture':('first min(numel,8192) values of first12 optimizer parameters' if a.framework=='roll' else '8192 exact deterministic evenly spaced indices in each of two native DeepSpeed FP32 flat optimizer groups'),'no_full_model_update_conclusion':True},'state':{'initial_weights':'same original pretrained BF16 checkpoint promoted to FP32 native master/reference values; sampled initial values exactly paired','optimizer':'zero-state first AdamW/FusedAdam step lr.001 eps1e-8 weight_decay0','clip':'full-model global gradient clipping1'}}
side_conditions={'native':{'numerics':{'forward':'genuine Ascend NPU BF16 '+('ROLL FSDP2' if a.framework=='roll' else 'community OpenRLHF DeepSpeed BF16'),'parameter_dtype':'float32 master','captured_optimizer_gradient_dtype':'float32','loss_dtype':'float32','distribution_export':'original selected native logits converted to FP64 and normalized across full vocabulary; original native target scores preserved'}},'reference':{'numerics':{'forward':'independent CPU FP32 eager Transformers, no native framework/Swift imports','parameter_dtype':'float32','captured_optimizer_gradient_dtype':'float32','loss_dtype':'float32','distribution_export':'independent CPU FP32 selected logits converted to FP64 and normalized across full vocabulary','optimizer':'independent zero-state first AdamW update formula on selected coordinates'}}}
spec={'schema_version':2,'common':common,'side_conditions':side_conditions,'thresholds':None,'expected_ranks':{'native':[0],'reference':[0]}}
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=n/'portable'/('compare-'+stamp);out.mkdir(parents=True);stores={s:{} for s in ('native','reference')};entries={s:{'postclip-gradients':[],'updates':[],'observations':[]} for s in stores};coverage=[]
for i,param in enumerate(ref['selected']):
 count=param['before'].numel();name=param['name']+('/flat[0:'+str(count)+']' if a.framework=='roll' else '');key='p'+str(i).zfill(3);coverage.append({'name':name,'captured_elements':count,'full_shape':param['shape'],'index_policy':common['scope']['parameter_capture'],'indices_sha256':thash(param['flat_indices'])})
 for side in stores:
  values={'before':native['before'][i],'after':native['after'][i],'gradient':native['postclip_gradients'][i]} if side=='native' else {'before':param['before'],'after':param['after'],'gradient':param['gradient']}
  for suffix,value in values.items():stores[side][key+'.'+suffix]=value.contiguous()
  stores[side][key+'.flat_indices']=param['flat_indices'].contiguous()
  entries[side]['postclip-gradients'].append({'name':name,'shape':[count],'present':True,'shards':[{'offset':0,'value':{'path':'values.safetensors','key':key+'.gradient'}}]})
  entries[side]['updates'].append({'name':name,'shape':[count],'present':True,'shards':[{'offset':0,'before':{'path':'values.safetensors','key':key+'.before'},'after':{'path':'values.safetensors','key':key+'.after'}}]})
for side in stores:
 values=native if side=='native' else ref
 for name in ('losses','advantages','target_logprobs'):
  value=values[name].contiguous();stores[side][name]=value;entries[side]['observations'].append({'name':name,'shape':list(value.shape),'present':True,'coordinates':{'boundary':{'losses':'native returned policy loss before backward scaling','advantages':'all effective native group-normalized actions','target_logprobs':'original native current actor scoring'}[name],'execution_stage':'optimizer_step0'},'shards':[{'offset':0,'value':{'path':'values.safetensors','key':name}}]})
for stage in entries['native']:
 tensors=[{k:e[k] for k in ('name','shape','present')} for e in entries['native'][stage]]
 if stage=='observations':
  for t,e in zip(tensors,entries['native'][stage]):t['coordinates']=e['coordinates']
 write(out/(stage+'.contract.json'),dict(spec,kind='tensors',stage=stage,tensors=tensors))
positions=[{'sample':str(row['sample']),'position':row['position'],'history':ids[int(row['sample'])][:row['position']]} for row in ref['distribution_coordinates']]
write(out/'distributions.contract.json',dict(spec,kind='distributions',vocab_size=151936,normalization_tolerance=1e-12,renormalization='none',positions=positions))
write(out/'target-scores.contract.json',dict(spec,schema_version=1,kind='target-scores',targets=ref['target_coordinates']))
for side in stores:
 folder=out/side;folder.mkdir();save_file(stores[side],str(folder/'values.safetensors'));values=native if side=='native' else ref
 versions={package:md.version(package) for package in ('torch','torch-npu','transformers','numpy','pyarrow')};write(folder/'environment.json',{'rank':0,'versions':versions,'actual':dict(common,**side_conditions[side]),'native_capture_identity':n.name,'independent_reference_identity':reference.name})
 write(folder/'status.json',{'rank':0,'status':'completed','evidence':'native pipeline returned, optimizer verified and exit0' if side=='native' else 'clean independent CPU forward/backward/update finished and exit0'})
 for stage in entries[side]:
  manifest={'schema_version':2,'kind':'tensors','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':'environment.json','status':'status.json'}],'stage':stage,'tensors':entries[side][stage]}
  if stage=='updates':manifest['events']={'actor':'applied'}
  write(folder/(stage+'.manifest.json'),manifest)
 write(folder/'target-scores.manifest.json',{'schema_version':1,'kind':'target-scores','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':'environment.json','status':'status.json'}],'scores':[dict(coords,logprob=float(value)) for coords,value in zip(ref['target_coordinates'],values['target_logprobs'])]})
 rows=values['prediction_rows_logprobs'].double().numpy();assert np.max(np.abs(np.exp(rows).sum(-1)-1))<1e-12;np.save(folder/'distribution-logprobs.npy',rows,allow_pickle=False)
 write(folder/'distributions.manifest.json',{'schema_version':2,'kind':'distributions','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':'environment.json','status':'status.json'}],'positions':[dict(pos,scores={'path':'distribution-logprobs.npy','row':i}) for i,pos in enumerate(positions)]})
write(out/'capture-coverage.json',{'reference_result':result,'parameter_slices':coverage,'distribution_rows':len(positions),'distribution_policy':result['distribution_export_policy'],'effective_action_masks':masks,'attention_masks':attention,'input_ids':ids,'actual_native_optimizer_event':optimizer,'no_full_model_update_conclusion':True})
sources += [next((n/'optimizer').glob('*.pt')),next((n/'optimizer').glob('*.json')),reference/'reference-tensors.pt',reference/'native-comparison-tensors.pt',reference/'reference-completion.json',r/'drivers/cpu-reference01/rl_cpu_reference.py']
write(out/'capture-identity.json',{'native_case':n.name,'native_optimizer_pid':optimizer['pid'],'native_optimizer_step':optimizer['step'],'reference':reference.name,'producer_sources':[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sources],'core_comparison_side_order':{'side_a':'reference','side_b':'native'},'portable_tensor_values_are_exact_copies_of_named_source_values':True})
files=[p for p in out.rglob('*') if p.is_file()];write(out/'file-manifest.json',{'files':[{'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]});target=r/'exports'/(a.framework+'-portable-'+stamp+'.zip')
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for p in out.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(out).as_posix())
print(json.dumps({'portable_root':str(out),'archive':str(target),'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'native_case':n.name,'reference':reference.name},indent=2))
