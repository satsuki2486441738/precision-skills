from pathlib import Path
import datetime,zipfile,json,hashlib,subprocess,sys
p=Path(__file__).parent;repo=p.parents[1];stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');run=repo/'runs'/('compare-rlar-portable-causalcoords-'+stamp);run.mkdir();receipts=[]
failed=repo/'runs/compare-rlar-portable-20261020T113732Z/roll/distributions.report.json';assert json.loads(failed.read_text())['reason']=='prediction/history offset mismatch'
for framework,archive in [('roll','roll-portable-evidence01.zip'),('openrlhf-community','open-portable-evidence01.zip')]:
 target=run/framework;target.mkdir()
 with zipfile.ZipFile(p/archive) as z:z.extractall(target)
 original_manifest=(target/'file-manifest.json').read_bytes();(target/'source-file-manifest.json').write_bytes(original_manifest);changes=[]
 for rel in ('distributions.contract.json','native/distributions.manifest.json','reference/distributions.manifest.json'):
  path=target/rel;before=path.read_bytes();obj=json.loads(before)
  if rel=='distributions.contract.json':(target/'source-distribution-coordinate-contract.json').write_bytes(before)
  for row in obj['positions']:
   assert len(row['history'])==row['position'];old=row['position'];row['position']-=1;assert len(row['history'])==row['position']+1;changes.append({'path':rel,'sample':row['sample'],'old_target_token_index':old,'new_prediction_index':row['position'],'history_length':len(row['history'])})
  path.write_text(json.dumps(obj,indent=2)+'\n')
 failure=target/'historical-interface-failure';failure.mkdir();(failure/'roll-original-distributions.report.json').write_bytes(failed.read_bytes())
 (target/'coordinate-adapter.json').write_text(json.dumps({'source_archive_sha256':hashlib.sha256((p/archive).read_bytes()).hexdigest(),'reason':'Core compare_distributions uses prediction index j and requires history length j+1. Producer rows stored next-token target index j+1, unlike distribution interface. Correct metadata index by -1; actual history and all score/tensor bytes unchanged. Target-scores coordinates retain their target-token convention.','native_or_reference_computation_changed':False,'tensor_arrays_changed':False,'changes':changes},indent=2))
 commands=[]
 for stage,tool in [('postclip-gradients','compare_tensors.py'),('updates','compare_tensors.py'),('observations','compare_tensors.py'),('target-scores','compare_target_scores.py'),('distributions','compare_distributions.py')]:
  argv=[sys.executable,str(repo/'skills/precision-skill/scripts'/tool),'--contract',stage+'.contract.json','--side-a','reference/'+stage+'.manifest.json','--side-b','native/'+stage+'.manifest.json','--output',stage+'.report.json'];proc=subprocess.run(argv,cwd=target,capture_output=True,text=True);assert proc.returncode==0,(framework,stage,proc.stderr)
  report=json.loads((target/(stage+'.report.json')).read_text());assert report['status']=='no_thresholds' and report['sides']=={'side_a':'reference','side_b':'native'}
  commands.append({'argv':argv,'cwd':str(target),'exit_code':0,'stdout':proc.stdout,'stderr':proc.stderr,'report':stage+'.report.json','report_sha256':hashlib.sha256((target/(stage+'.report.json')).read_bytes()).hexdigest(),'tool_sha256':hashlib.sha256((repo/'skills/precision-skill/scripts'/tool).read_bytes()).hexdigest()})
 receipt={'framework':framework,'path':str(target),'capture_identity':json.loads((target/'capture-identity.json').read_text()),'core_cli':commands};(target/'core-cli-receipt.json').write_text(json.dumps(receipt,indent=2));receipts.append(receipt)
 allfiles=[x for x in target.rglob('*') if x.is_file() and x.name!='file-manifest.json'];(target/'file-manifest.json').write_text(json.dumps({'files':[{'path':x.relative_to(target).as_posix(),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in allfiles]},indent=2))
receipt={'path':str(run),'cases':[{'framework':x['framework'],'path':x['path'],'native_case':x['capture_identity']['native_case'],'reference':x['capture_identity']['reference'],'actual_core_cli_count':5,'status':'all_exit0_no_thresholds'} for x in receipts]};(p/'rl-portable-core-receipt02.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
