"""Independent clean CPU FP32 replay for genuine ROLL or community OpenRLHF captures."""
import argparse,pathlib,json,inspect,sys,hashlib
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer
from transformers.models.qwen3.modeling_qwen3 import Qwen3RMSNorm
ap=argparse.ArgumentParser();ap.add_argument('--framework',choices=['roll','openrlhf-community'],required=True);ap.add_argument('--native-output',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
n=pathlib.Path(a.native_output);out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=True)
assert not any(x in sys.modules for x in ('roll','openrlhf','swift','areal'))
assert 'npu_rms_norm' not in inspect.getsource(Qwen3RMSNorm.forward)
torch.set_num_threads(2);torch.manual_seed(20261020)
def load(p):return torch.load(p,map_location='cpu',weights_only=True)
def signature(ids,attention):return tuple(ids[attention.bool()].tolist())
records=[];sources=[];raw_reward=[];reward_map={};native_adv=[];masks=[];native_target=[];old_anchors=[];native_losses=[];targets=[];native_rows=[];row_keys=[]
if a.framework=='roll':
 paths=sorted((n/'native-tensors').glob('native-current-policy*.json'),key=lambda p:p.stat().st_mtime_ns)
 assert len(paths)==2
 for meta_path in paths:
  meta=json.loads(meta_path.read_text());data=load(n/'native-tensors'/meta['inputs_file']);policy=load(n/'native-tensors'/meta['policy_file']);records.append((data,policy,meta));sources += [meta_path.name,meta['inputs_file'],meta['policy_file']]
 cfg=records[0][2]['pipeline_config'];assert cfg['loss_agg_mode']=='seq-mean-token-mean' and cfg['importance_sampling']=='token' and not cfg['add_token_level_kl'] and not cfg['use_kl_loss'] and not cfg['whiten_advantages'] and not cfg['whiten_rewards'];assert not cfg['train_infer_correction']['is_weight']['enabled'] and not cfg['train_infer_correction']['filters']
 groups={}
 for bi,(data,policy,meta) in enumerate(records):
  for i in range(data['input_ids'].shape[0]):
   seq=data['input_ids'][i];response=data['response_mask'][i].bool();attention=data['attention_mask'][i].bool();prompt=tuple(seq[attention&~response].tolist());reward=seq[response].float().mean()/100.0;key=(bi,i);groups.setdefault(prompt,[]).append((key,reward));raw_reward.append(float(reward))
 for members in groups.values():
  assert len(members)==2;rewards=torch.stack([v for _,v in members]);norm=(rewards-rewards.mean())/(rewards.std(unbiased=True)+1e-6)
  for (key,_),v in zip(members,norm):reward_map[key]=v
 group_count=len(groups);clip=float(cfg['pg_clip']);maxnorm=float(cfg['max_grad_norm']);accum=cfg['actor_train']['training_args']['gradient_accumulation_steps'];scale=(len(records) if cfg['actor_train']['apply_loss_scale'] else 1)/accum
else:
 data=load(next((n/'native-tensors').glob('training_step_inputs*.pt')));policy=load(next((n/'native-tensors').glob('policy_forward_observed*.pt')));policy_meta=json.loads((n/'policy_forward_observed.json').read_text());lossdata=load(next((n/'native-tensors').glob('objective_returned*.pt')));records=[(data,policy,policy_meta)];layout=json.loads((n/'deepspeed-flat-layout.json').read_text());args=layout['loss_args'];assert args['advantage_estimator']=='group_norm' and not args['use_kl_loss'] and args['lr_warmup_ratio']==0
 raw=load(next((n/'native-tensors').glob('rollout_observed*.pt')))[0];tokenizer=AutoTokenizer.from_pretrained('/SHARED_MODELS/Qwen3-0.6B',local_files_only=True);queries=tokenizer.batch_decode(raw['sequences'],skip_special_tokens=False);rewards=torch.tensor([sum(ord(c) for c in q[-96:])%997/997.0 for q in queries],dtype=torch.float32);raw_reward=rewards.tolist();normalized=(rewards.reshape(-1,2)-rewards.reshape(-1,2).mean(-1,keepdim=True))/(rewards.reshape(-1,2).std(-1,keepdim=True)+1e-9)
 for seq,attention,value in zip(raw['sequences'],raw['attention_mask'],normalized.flatten()):reward_map[signature(seq,attention)]=value
 group_count=len(rewards)//2;clip=float(args['eps_clip']);maxnorm=float(args['max_norm']);scale=1
model=AutoModelForCausalLM.from_pretrained('/SHARED_MODELS/Qwen3-0.6B',dtype=torch.float32,attn_implementation='eager',local_files_only=True,device_map={'':'cpu'});model.train();model.config.use_cache=False
ref_losses=[];ref_adv=[];ref_target=[];ref_rows=[];batch_index=0
for bi,(data,policy,meta) in enumerate(records):
 if a.framework=='roll':
  ids=data['input_ids'].long();attention=data['attention_mask'];position=data['position_ids'];mask=data.get('final_response_mask',data['response_mask'][:,1:]).bool();response=data['response_mask'][:,1:].bool();adv=torch.stack([reward_map[(bi,i)].expand(mask.shape[1]) for i in range(ids.shape[0])])*mask;old=policy['old_log_probs_actual'].float();coords=policy['distribution_row_coordinates'].long();nr=policy['distribution_rows'];nt=policy['current_log_probs'];native_loss=policy['native_loss'];den=float(meta['meta_info']['global_valid_samples']['final_response_mask'])
 else:
  ids=data['sequences'].long();attention=data['attention_mask'];position=attention.long().cumsum(-1)-1;position.masked_fill_(attention==0,1);mask=data['action_mask'].bool();response=mask;adv=torch.stack([reward_map[signature(seq,att)].expand(mask.shape[1]) for seq,att in zip(ids,attention)])*mask;old=data['action_log_probs'].float();coords=policy['row_coordinates'].long();nr=policy['native_full_vocab_rows'];nt=policy['native_action_log_probs'];native_loss=lossdata['loss'];den=float(mask.sum())
 logits=model(input_ids=ids,attention_mask=attention,position_ids=position,use_cache=False).logits
 logps=logits[:,:-1].log_softmax(-1).gather(-1,ids[:,1:,None]).squeeze(-1)
 if a.framework=='openrlhf-community':logps=logps[:,-mask.shape[1]:]*mask
 else:logps=logps*response
 ratio=(logps-old).exp();loss_mat=-torch.minimum(ratio*adv,ratio.clamp(1-clip,1+clip)*adv)
 if a.framework=='roll':loss=((loss_mat*mask).sum(-1)/mask.sum(-1).clamp_min(1)).sum()/den
 else:loss=(loss_mat*mask).sum()/den
 (loss*scale).backward();ref_losses.append(loss.detach());native_losses.append(native_loss);ref_adv.append(adv[mask]);native_adv.append(data['advantages'][mask]);ref_target.append(logps.detach()[mask]);native_target.append(nt[mask]);old_anchors.append(old[mask]);masks.append(mask)
 for i,j in torch.nonzero(mask,as_tuple=False).tolist():
  pos=j+1 if a.framework=='roll' else ids.shape[1]-mask.shape[1]+j
  targets.append({'sample':str(batch_index+i),'position':pos,'token':int(ids[i,pos])})
 for k,(i,j) in enumerate(coords.tolist()):
  row_keys.append({'sample':str(batch_index+i),'position':j+1,'token':int(ids[i,j+1])});native_rows.append(nr[k].double().log_softmax(-1));ref_rows.append(logits.detach()[i,j].double().log_softmax(-1))
 batch_index+=ids.shape[0]
preclip=torch.nn.utils.clip_grad_norm_(model.parameters(),maxnorm);named=dict(model.named_parameters());selected=[]
if a.framework=='roll':
 for name,param in list(named.items())[:12]:
  before=param.detach().reshape(-1)[:8192].clone();grad=param.grad.detach().reshape(-1)[:8192].clone();selected.append({'name':name,'shape':list(param.shape),'before':before,'gradient':grad,'after':before-.001*grad/(grad.abs()+1e-8),'flat_indices':torch.arange(before.numel())})
else:
 for group in layout['groups']:
  total=group['total_numel'];ix=torch.arange(min(total,8192),dtype=torch.long)*(total-1)//max(min(total,8192)-1,1);before=torch.empty(ix.numel());grad=torch.empty_like(before)
  for row in group['parameters']:
   chosen=(ix>=row['flat_offset'])&(ix<row['flat_offset']+row['numel'])
   if not chosen.any():continue
   param=named[row['name']];assert list(param.shape)==row['shape'];local=ix[chosen]-row['flat_offset'];before[chosen]=param.detach().reshape(-1)[local];grad[chosen]=param.grad.detach().reshape(-1)[local]
  selected.append({'name':'deepspeed-flat-group'+str(group['group'])+'/evenly-spaced8192','shape':[total],'before':before,'gradient':grad,'after':before-.001*grad/(grad.abs()+1e-8),'flat_indices':ix})
# All independent reward/advantage/model/loss/backward/clipping/update computation is complete.
observed=load(next((n/'optimizer').glob('*.pt')))
assert len(selected)==len(observed['before'])
for ref,coords,before in zip(selected,observed['coordinates'],observed['before']):assert ref['shape']==coords['shape'];ref['initial_max_abs']=float((ref['before']-before.float()).abs().max())
canonical={'selected':selected,'losses':torch.stack(ref_losses),'advantages':torch.cat(ref_adv),'target_logprobs':torch.cat(ref_target),'prediction_rows_logprobs':torch.stack(ref_rows),'target_coordinates':targets,'distribution_coordinates':row_keys,'old_policy_anchors':torch.cat(old_anchors)}
native_values={'before':observed['before'],'after':observed['after'],'postclip_gradients':observed['postclip_gradients'],'coordinates':observed['coordinates'],'flat_indices':observed.get('flat_indices'),'losses':torch.stack(native_losses),'advantages':torch.cat(native_adv),'target_logprobs':torch.cat(native_target),'prediction_rows_logprobs':torch.stack(native_rows)}
def compare(x,y):
 x=x.double().flatten();y=y.double().flatten();d=y-x;return {'reference_norm':float(x.norm()),'native_norm':float(y.norm()),'error_norm':float(d.norm()),'cosine':float(torch.nn.functional.cosine_similarity(x,y,dim=0)) if x.norm() and y.norm() else None,'max_abs':float(d.abs().max()),'finite':bool(torch.isfinite(x).all() and torch.isfinite(y).all())}
result={'status':'independent_cpu_fp32_reference_complete','framework':a.framework,'native_case':n.name,'clean_model_norm_module':Qwen3RMSNorm.forward.__module__,'native_framework_imported':False,'native_gradients_read_only_after_reference_computation':True,'raw_rewards_recomputed_from_generated_ids':raw_reward,'preclip_gradient_norm':float(preclip),'coverage':{'trajectories':batch_index,'complete_groups':group_count,'valid_actions':len(targets),'distribution_rows':len(row_keys),'selected_parameter_elements':sum(x['before'].numel() for x in selected),'whole_model_parameters':sum(p.numel() for p in model.parameters())},'diagnostics':{'losses':compare(canonical['losses'],native_values['losses']),'advantages':compare(canonical['advantages'],native_values['advantages']),'target_logprobs':compare(canonical['target_logprobs'],native_values['target_logprobs']),'gradients':compare(torch.cat([r['gradient'] for r in selected]),torch.cat(native_values['postclip_gradients'])),'updates':compare(torch.cat([r['after']-r['before'] for r in selected]),torch.cat([x.float()-y.float() for x,y in zip(observed['after'],observed['before'])]))},'initial_values_max_abs':max(r['initial_max_abs'] for r in selected),'native_sources':sources,'loss_scale_after_native_microbatch_accumulation':scale,'alignment_thresholds_applied':False,'distribution_export_policy':'both original selected full-vocabulary logits converted to FP64 and normalized across full vocabulary; no native target score is modified'}
torch.save(canonical,out/'reference-tensors.pt');torch.save(native_values,out/'native-comparison-tensors.pt');(out/'reference-completion.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
