#!/bin/bash
set -Euo pipefail
source /usr/local/Ascend/cann/set_env.sh
unset LOCAL_RANK RANK WORLD_SIZE LOCAL_WORLD_SIZE GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE NODE_RANK MASTER_ADDR MASTER_PORT
export PATH=/REMOTE_WORKSPACE/rlar/environments/roll/bin:"$PATH" PIP_CACHE_DIR=/REMOTE_WORKSPACE/rlar/cache/pip TMPDIR=/REMOTE_WORKSPACE/rlar/tmp/roll DS_BUILD_OPS=0 MAX_JOBS=4 OMP_NUM_THREADS=1 TORCH_EXTENSIONS_DIR=/REMOTE_WORKSPACE/rlar/cache/torch_extensions
export PYTHONPATH=/REMOTE_WORKSPACE/rlar/drivers/attempt02:/REMOTE_WORKSPACE/rlar/sources/roll-archive040
export ASCEND_RT_VISIBLE_DEVICES=8,9,10,11 RLAR_OUTPUT=/REMOTE_WORKSPACE/rlar/results/roll-native-dtfs-20261020T095745Z RLAR_SOURCE=/REMOTE_WORKSPACE/rlar/sources/roll-archive040 RLAR_FRAMEWORK=roll RLAR_WORKER_CLASSES=1 TOKENIZERS_PARALLELISM=false PYTHONUNBUFFERED=1
mkdir -p "$TMPDIR" "$TORCH_EXTENSIONS_DIR"
/REMOTE_WORKSPACE/rlar/environments/roll/bin/python -m pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple --timeout 15 --retries 1 torch-npu==2.9.0.post6 uv_build==0.9.18 tensorboardX swanlab openai==2.24.0 uvloop blosc dacite imageio pybase64 aiofiles httpx colorlog setproctitle tabulate orjson msgspec sentencepiece ninja packaging einops numba h5py redis flask pylatexenc python-dotenv math-verify==0.8.0 word2number timeout-decorator pebble prettytable tenacity colorama json5 zstandard distro-info python-debian matplotlib nltk anthropic blake3 cachetools cbor2 depyf==0.20.0 diskcache==5.6.3 gguf ijson lark==1.2.2 llguidance==1.3.0 lm-format-enforcer==0.11.3 mcp model-hosting-container-standards openai-harmony opentelemetry-exporter-otlp opentelemetry-semantic-conventions-ai outlines_core==0.2.11 partial-json-parser prometheus-fastapi-instrumentator py-cpuinfo python-json-logger watchfiles fastapi==0.123.10 starlette==0.50.0 transformers==4.57.6 huggingface-hub==0.36.0 datasets==3.1.0 accelerate==0.34.2 peft==0.12.0 trl==0.9.6 TransferQueue==0.1.6 'ray[default,cgraph]==2.48.0' modelscope loralib more-itertools deprecated codetiming pyarrow==21.0.0
rc=$?
if [ "$rc" -eq 0 ]; then
 date -u > /REMOTE_WORKSPACE/rlar/logs/roll-install-ready.txt
 export RLAR_CAPTURE=1 PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
 exec 9>/REMOTE_WORKSPACE/rlar/native.lock
 flock 9
 python -m pip freeze > /REMOTE_WORKSPACE/rlar/results/roll-native-dtfs-20261020T095745Z/installed_freeze.txt
 python /REMOTE_WORKSPACE/rlar/drivers/attempt02/native_rlar.py assets && timeout --signal=TERM --kill-after=40s 1000s python /REMOTE_WORKSPACE/rlar/drivers/attempt02/native_rlar.py roll && python /REMOTE_WORKSPACE/rlar/drivers/attempt02/native_rlar.py verify
 rc=$?
fi
printf '{"exit_code":%s}\n' "$rc" > /REMOTE_WORKSPACE/rlar/results/roll-native-dtfs-20261020T095745Z/process_exit.json
exit "$rc"
