#!/bin/bash
set -Euo pipefail
source /usr/local/Ascend/cann/set_env.sh
unset LOCAL_RANK RANK WORLD_SIZE LOCAL_WORLD_SIZE GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE NODE_RANK MASTER_ADDR MASTER_PORT
export PATH=/REMOTE_WORKSPACE/rlar/environments/openrlhf-community/bin:"$PATH" PIP_CACHE_DIR=/REMOTE_WORKSPACE/rlar/cache/pip TMPDIR=/REMOTE_WORKSPACE/rlar/tmp/openrlhf-community DS_BUILD_OPS=0 MAX_JOBS=4 OMP_NUM_THREADS=1 TORCH_EXTENSIONS_DIR=/REMOTE_WORKSPACE/rlar/cache/torch_extensions
export PYTHONPATH=/REMOTE_WORKSPACE/rlar/drivers/attempt02:/REMOTE_WORKSPACE/rlar/sources/openrlhf-community-archive
export ASCEND_RT_VISIBLE_DEVICES=8,9,10,11 RLAR_OUTPUT=/REMOTE_WORKSPACE/rlar/results/openrlhf-community-native-dtfs-20261020T100553Z RLAR_SOURCE=/REMOTE_WORKSPACE/rlar/sources/openrlhf-community-archive RLAR_FRAMEWORK=openrlhf-community RLAR_WORKER_CLASSES=1 TOKENIZERS_PARALLELISM=false PYTHONUNBUFFERED=1
mkdir -p "$TMPDIR" "$TORCH_EXTENSIONS_DIR"
/REMOTE_WORKSPACE/rlar/environments/openrlhf-community/bin/python -m pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple --timeout 15 --retries 1 torch-npu==2.9.0.post6 uv_build==0.9.18 tensorboardX swanlab openai==2.24.0 uvloop blosc dacite imageio pybase64 aiofiles httpx colorlog setproctitle tabulate orjson msgspec sentencepiece ninja packaging einops numba h5py redis flask pylatexenc python-dotenv math-verify==0.8.0 word2number timeout-decorator pebble prettytable tenacity colorama json5 zstandard distro-info python-debian matplotlib nltk anthropic blake3 cachetools cbor2 depyf==0.20.0 diskcache==5.6.3 gguf ijson lark==1.2.2 llguidance==1.3.0 lm-format-enforcer==0.11.3 mcp model-hosting-container-standards openai-harmony opentelemetry-exporter-otlp opentelemetry-semantic-conventions-ai outlines_core==0.2.11 partial-json-parser prometheus-fastapi-instrumentator py-cpuinfo python-json-logger watchfiles fastapi==0.123.10 starlette==0.50.0 transformers==4.52.2 peft==0.15.2 datasets==3.1.0 accelerate tensorboard jsonlines optimum torchmetrics transformers_stream_generator loralib deepspeed==0.16.7 pyarrow==21.0.0 numpy==1.26.4 matplotlib==3.10.9 contourpy==1.3.3 &&
/REMOTE_WORKSPACE/rlar/environments/openrlhf-community/bin/python -m pip install --no-deps --no-build-isolation -e /REMOTE_WORKSPACE/rlar/sources/ring-attn-ascend-dd912ad
rc=$?
if [ "$rc" -eq 0 ]; then
 date -u > /REMOTE_WORKSPACE/rlar/logs/openrlhf-community-install-ready.txt
 export RLAR_CAPTURE=1 PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
 exec 9>/REMOTE_WORKSPACE/rlar/native.lock
 flock 9
 python -m pip freeze > /REMOTE_WORKSPACE/rlar/results/openrlhf-community-native-dtfs-20261020T100553Z/installed_freeze.txt
 timeout --signal=TERM --kill-after=40s 1000s python /REMOTE_WORKSPACE/rlar/drivers/attempt02/native_open.py train && python /REMOTE_WORKSPACE/rlar/drivers/attempt02/native_open.py verify
 rc=$?
fi
printf '{"exit_code":%s}\n' "$rc" > /REMOTE_WORKSPACE/rlar/results/openrlhf-community-native-dtfs-20261020T100553Z/process_exit.json
exit "$rc"
