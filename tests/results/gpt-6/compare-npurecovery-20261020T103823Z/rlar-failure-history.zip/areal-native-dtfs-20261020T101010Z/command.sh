#!/bin/bash
set -Euo pipefail
source /usr/local/Ascend/cann/set_env.sh
unset LOCAL_RANK RANK WORLD_SIZE LOCAL_WORLD_SIZE GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE NODE_RANK MASTER_ADDR MASTER_PORT
export PATH=/REMOTE_WORKSPACE/rlar/environments/areal/bin:"$PATH" PIP_CACHE_DIR=/REMOTE_WORKSPACE/rlar/cache/pip TMPDIR=/REMOTE_WORKSPACE/rlar/tmp/areal DS_BUILD_OPS=0 MAX_JOBS=4 OMP_NUM_THREADS=1 TORCH_EXTENSIONS_DIR=/REMOTE_WORKSPACE/rlar/cache/torch_extensions
export PYTHONPATH=/REMOTE_WORKSPACE/rlar/drivers/attempt02:/REMOTE_WORKSPACE/rlar/sources/areal-archive104
export ASCEND_RT_VISIBLE_DEVICES=8,9,10,11 RLAR_OUTPUT=/REMOTE_WORKSPACE/rlar/results/areal-native-dtfs-20261020T101010Z RLAR_SOURCE=/REMOTE_WORKSPACE/rlar/sources/areal-archive104 RLAR_FRAMEWORK=areal RLAR_WORKER_CLASSES=1 TOKENIZERS_PARALLELISM=false PYTHONUNBUFFERED=1
mkdir -p "$TMPDIR" "$TORCH_EXTENSIONS_DIR"
/REMOTE_WORKSPACE/rlar/environments/areal/bin/python -m pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple --timeout 15 --retries 1 torch-npu==2.9.0.post6 uv_build==0.9.18 tensorboardX swanlab openai==2.24.0 uvloop blosc dacite imageio pybase64 aiofiles httpx colorlog setproctitle tabulate orjson msgspec sentencepiece ninja packaging einops numba h5py redis flask pylatexenc python-dotenv math-verify==0.8.0 word2number timeout-decorator pebble prettytable tenacity colorama json5 zstandard distro-info python-debian matplotlib nltk anthropic blake3 cachetools cbor2 depyf==0.20.0 diskcache==5.6.3 gguf ijson lark==1.2.2 llguidance==1.3.0 lm-format-enforcer==0.11.3 mcp model-hosting-container-standards openai-harmony opentelemetry-exporter-otlp opentelemetry-semantic-conventions-ai outlines_core==0.2.11 partial-json-parser prometheus-fastapi-instrumentator py-cpuinfo python-json-logger watchfiles fastapi==0.123.10 starlette==0.50.0 hydra-core==1.4.0.dev1 omegaconf==2.4.0.dev2 peft==0.18.1 pyarrow==21.0.0 numpy==1.26.4 matplotlib==3.10.9 contourpy==1.3.3 trackio==0.26.0 &&
/REMOTE_WORKSPACE/rlar/environments/areal/bin/python -m pip install --no-deps --no-build-isolation -e /REMOTE_WORKSPACE/rlar/sources/areal-archive104
rc=$?
if [ "$rc" -eq 0 ]; then
 date -u > /REMOTE_WORKSPACE/rlar/logs/areal-install-ready.txt
 export RLAR_CAPTURE=1 PYTORCH_NPU_ALLOC_CONF=expandable_segments:True TMPDIR=/tmp/rlar-areal-20261020T101010Z
 mkdir -p "$TMPDIR"
 export HF_HOME=/REMOTE_WORKSPACE/rlar/cache/huggingface XDG_CACHE_HOME=/REMOTE_WORKSPACE/rlar/cache VLLM_CACHE_ROOT=/REMOTE_WORKSPACE/rlar/cache/vllm TRITON_CACHE_DIR=/REMOTE_WORKSPACE/rlar/cache/triton TORCHINDUCTOR_CACHE_DIR=/REMOTE_WORKSPACE/rlar/cache/torchinductor
 exec 9>/REMOTE_WORKSPACE/rlar/native.lock
 flock 9
 python -m pip freeze > /REMOTE_WORKSPACE/rlar/results/areal-native-dtfs-20261020T101010Z/installed_freeze.txt
 python /REMOTE_WORKSPACE/rlar/drivers/attempt02/native_npu_rlar.py assets && timeout --signal=TERM --kill-after=40s 1000s python /REMOTE_WORKSPACE/rlar/drivers/attempt02/native_npu_rlar.py train --config /REMOTE_WORKSPACE/rlar/results/areal-native-dtfs-20261020T101010Z/areal.yaml && python /REMOTE_WORKSPACE/rlar/drivers/attempt02/native_npu_rlar.py verify
 rc=$?
fi
printf '{"exit_code":%s}\n' "$rc" > /REMOTE_WORKSPACE/rlar/results/areal-native-dtfs-20261020T101010Z/process_exit.json
exit "$rc"
