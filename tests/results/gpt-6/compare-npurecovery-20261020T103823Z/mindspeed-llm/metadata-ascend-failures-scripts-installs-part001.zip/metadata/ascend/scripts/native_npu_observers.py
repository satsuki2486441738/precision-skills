"""Copy-only observers around official MindSpeed-LLM and MindIE native paths.

Use only after the actual NPU/runtime probe and release matching. These are
adapters, not replacement model, loss, optimizer or device implementations.
"""
import argparse
import functools
import importlib
import importlib.metadata as metadata
import importlib.util
import inspect
import json
import os
from pathlib import Path
import sys


def write_json(path,value):
    Path(path).write_text(json.dumps(value,indent=2,default=str))


def runtime():
    import torch
    import torch_npu
    result={"python":sys.version,"executable":sys.executable,"torch":torch.__version__,"torch_path":torch.__file__,"torch_npu":getattr(torch_npu,"__version__",None),"torch_npu_path":torch_npu.__file__,"npu_available":torch.npu.is_available(),"npu_count":torch.npu.device_count(),"npu_name":torch.npu.get_device_name(torch.npu.current_device()),"packages":{}}
    for name in ["mindspeed","mindspeed-llm","mindspeed-rl","mindie-llm","transformers","ray","megatron-core","numpy"]:
        try:result["packages"][name]=metadata.version(name)
        except metadata.PackageNotFoundError:pass
    assert result["npu_available"], "Actual Ascend runtime is unavailable"
    return result


def as_cpu(value):
    import torch
    if torch.is_tensor(value):return value.detach().cpu().clone()
    if isinstance(value,dict):return {k:as_cpu(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return type(value)(as_cpu(v) for v in value)
    return value


def summary(before,after):
    import torch
    changed=0
    maximum=0.0
    for name in before:
        delta=after[name].float()-before[name].float()
        changed+=int(torch.count_nonzero(delta))
        maximum=max(maximum,float(delta.abs().max()))
    return {"trainable_tensors":len(before),"trainable_elements":sum(t.numel() for t in before.values()),"changed_elements":changed,"maximum_stored_update":maximum}


def mindspeed_llm(source,out,native_args):
    import torch
    def option(name):
        for i,arg in enumerate(native_args):
            if arg==name and i+1<len(native_args):return native_args[i+1]
            if arg.startswith(name+"="):return arg.split("=",1)[1]
        return None
    assert option("--train-iters")=="1","Explicit --train-iters 1 is required for this bounded collector"
    assert "--bf16" in native_args and "--fp16" not in native_args,"Collector's gradient boundary requires BF16 without FP16 loss scaling"
    assert option("--clip-grad") is not None and float(option("--clip-grad"))==0.0,"Explicit --clip-grad 0 is required"
    source=Path(source).resolve()
    sys.path.insert(0,str(source))
    sys.argv=[str(source/"pretrain_gpt.py")]+native_args
    spec=importlib.util.spec_from_file_location("precision_official_pretrain_gpt",source/"pretrain_gpt.py")
    native=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    write_json(out/"native-runtime.json",runtime())
    write_json(out/"native-command.json",{"entrypoint":str(source/"pretrain_gpt.py"),"arguments":native_args,"observer":str(Path(__file__).resolve()),"native_module_path":native.__file__})
    payload={"batch":[],"native_per_target_losses":[]}
    original_batch=native.get_batch
    def observed_batch(*args,**kwargs):
        batch=tuple(original_batch(*args,**kwargs))
        payload["batch"].append(as_cpu(dict(zip(["tokens","labels","loss_mask","attention_mask","position_ids"],batch))))
        return batch
    native.get_batch=observed_batch
    original_forward=native.forward_step
    @functools.wraps(original_forward)
    def observed_forward(*args,**kwargs):
        output,loss_function=original_forward(*args,**kwargs)
        payload["native_per_target_losses"].append(as_cpu(output))
        return output,loss_function
    native.forward_step=observed_forward
    training=importlib.import_module("mindspeed_llm.training.training")
    original_step=training.train_step
    signature=inspect.signature(original_step)
    @functools.wraps(original_step)
    def observed_step(*args,**kwargs):
        bound=signature.bind_partial(*args,**kwargs).arguments
        models=bound.get("model")
        optimizer=bound.get("optimizer")
        assert models is not None and optimizer is not None, (str(signature),list(bound))
        if not isinstance(models,(list,tuple)):models=[models]
        params={"chunk"+str(i)+"."+n:p for i,m in enumerate(models) for n,p in m.named_parameters() if p.requires_grad}
        assert params and all(p.device.type=="npu" for p in params.values()),"Native training parameters must actually reside on the assigned NPU"
        payload["before"]={n:as_cpu(p) for n,p in params.items()}
        payload["parameter_devices"]={n:str(p.device) for n,p in params.items()}
        payload["parameter_inventory"]={"chunk"+str(i)+"."+n:{"shape":list(p.shape),"dtype":str(p.dtype),"device":str(p.device),"trainable":p.requires_grad} for i,m in enumerate(models) for n,p in m.named_parameters(remove_duplicate=False)}
        payload["optimizer_state_before"]=as_cpu(optimizer.state_dict())
        actual_optimizer_step=optimizer.step
        def observed_optimizer_step(*optargs,**optkwargs):
            payload["gradients"]={}
            for n,p in params.items():
                grad=getattr(p,"main_grad",None)
                if grad is None:grad=p.grad
                payload["gradients"][n]=as_cpu(grad)
            event=actual_optimizer_step(*optargs,**optkwargs)
            torch.npu.synchronize()
            payload["optimizer_event"]=as_cpu(event)
            payload["after"]={n:as_cpu(p) for n,p in params.items()}
            payload["optimizer_state_after"]=as_cpu(optimizer.state_dict())
            return event
        optimizer.step=observed_optimizer_step
        try:result=original_step(*args,**kwargs)
        finally:optimizer.step=actual_optimizer_step
        payload["native_train_step_result"]=as_cpu(result)
        payload["optimizer_class"]=type(optimizer).__module__+"."+type(optimizer).__qualname__
        return result
    training.train_step=observed_step
    native.main()
    assert {"before","gradients","after","optimizer_event"}.issubset(payload),list(payload)
    event=payload["optimizer_event"]
    applied=bool(event[0] if isinstance(event,(tuple,list)) else event)
    assert applied,"Native optimizer reported skipped update"
    inventory=summary(payload["before"],payload["after"])
    assert inventory["changed_elements"]>0,inventory
    assert any(v is not None and bool(torch.count_nonzero(v)) for v in payload["gradients"].values()),"No nonzero native gradients captured"
    assert all(v is None or bool(torch.isfinite(v).all()) for v in payload["gradients"].values())
    assert payload["native_per_target_losses"] and all(bool(torch.isfinite(v).all()) for v in payload["native_per_target_losses"])
    rank=int(os.environ.get("RANK","0"))
    torch.save(payload,out/("rank-"+str(rank)+"-native-captures.pt"))
    result={"status":"native_execution_complete","framework":"MindSpeed-LLM","entrypoint":"official pretrain_gpt.py main -> mindspeed_llm.training.training.pretrain","runtime":"native-runtime.json","rank":rank,"world_size":int(os.environ.get("WORLD_SIZE","1")),"training_steps":1,"optimizer":payload["optimizer_class"],"optimizer_applied":applied,"gradients_present":sum(v is not None for v in payload["gradients"].values()),"valid_targets":sum(int(b["loss_mask"].sum()) for b in payload["batch"]),"inventory":inventory,"gradient_boundary":"Native Megatron optimizer.step entry; synchronized main_grad; require BF16 and clip_grad=0 in effective native arguments","update_boundary":"Native optimizer.step return and native parameter copyback","captures":"rank-"+str(rank)+"-native-captures.pt","coverage_limit":"Tiny seeded random native pretraining unless effective native command supplies a converted checkpoint; no pretrained SFT parity claim."}
    write_json(out/("rank-"+str(rank)+"-result.json"),result)
    if rank==0:write_json(out/"native-result.json",result)
    print(json.dumps(result,indent=2),flush=True)


def mindie(source,out,model,memory_fraction):
    # All selected switches are public knobs in the pinned native env.py.
    os.environ["NPU_MEMORY_FRACTION"]=str(memory_fraction)
    os.environ["ATB_LLM_BENCHMARK_ENABLE"]="0"
    import torch
    source=Path(source).resolve()
    sys.path.insert(0,str(source))
    native=importlib.import_module("examples.run_pa")
    runner_module=importlib.import_module("atb_llm.runner.model_runner")
    write_json(out/"native-runtime.json",runtime())
    payload={"forward_calls":[],"requests":[]}
    active=False
    original_forward=runner_module.ModelRunner.forward
    @functools.wraps(original_forward)
    def observed_forward(self,*args,**kwargs):
        result=original_forward(self,*args,**kwargs)
        if active:
            if torch.is_tensor(result):logits=result
            elif hasattr(result,"logits"):logits=result.logits
            else:raise TypeError("Native forward output does not expose unambiguous logits: "+str(type(result)))
            assert logits.device.type=="npu","Native MindIE logits did not come from the assigned NPU"
            payload["forward_calls"].append({"native_logits":as_cpu(logits),"inputs":as_cpu({k:v for k,v in kwargs.items() if k in ["input_ids","position_ids","is_prefill","prefill_head_indices","lm_head_indices","input_lengths","slot_mapping","block_tables"]}),"native_logits_dtype":str(logits.dtype),"native_logits_device":str(logits.device),"shape":list(logits.shape)})
        return result
    runner_module.ModelRunner.forward=observed_forward
    original_generate=native.generate_req
    @functools.wraps(original_generate)
    def observed_generate(*args,**kwargs):
        result=original_generate(*args,**kwargs)
        if active:
            requests=args[0] if args else kwargs["req_list"]
            payload["requests"].append([{ "req_id":r.req_id,"input_ids":as_cpu(r.input_ids),"out_token_list":as_cpu(r.out_token_list),"input_length":r.input_length} for r in requests])
        return result
    native.generate_req=observed_generate
    native_args=["--model_path",str(Path(model).resolve()),"--input_ids","1,4,5,6","--max_batch_size","1","--max_input_length","16","--max_output_length","4","--max_prefill_tokens","32","--ignore_eos"]
    sys.argv=[str(source/"examples/run_pa.py")]+native_args
    args=native.parse_arguments()
    settings={"rank":native.ENV.rank,"local_rank":native.ENV.local_rank,"world_size":native.ENV.world_size,**vars(args)}
    assert int(settings["world_size"])==1,"Initial collector requires TP=1 so vocabulary rows need no shard reconstruction"
    write_json(out/"native-command.json",{"entrypoint":"examples.run_pa.PARunner (same native construction, warmup, infer sequence as official CLI)","native_source":native.__file__,"runner_source":runner_module.__file__,"arguments":native_args,"NPU_MEMORY_FRACTION":os.environ["NPU_MEMORY_FRACTION"],"benchmark_disabled":os.environ["ATB_LLM_BENCHMARK_ENABLE"]=="0"})
    (out/"examples/models").mkdir(parents=True,exist_ok=True)
    previous_cwd=Path.cwd()
    os.chdir(out)
    try:
        runner=native.PARunner(**settings)
        runner.warm_up()
        active=True
        generated_text,token_counts,timing=runner.infer(inputs=args.input_ids,batch_size=1,max_output_length=4,ignore_eos=True,is_chat_model=False)
        torch.npu.synchronize()
    finally:
        active=False
        os.chdir(previous_cwd)
        runner_module.ModelRunner.forward=original_forward
        native.generate_req=original_generate
    assert payload["forward_calls"],"No actual native logit rows captured after warmup"
    assert payload["requests"],"No actual native request completion captured"
    assert all(bool(torch.isfinite(c["native_logits"]).all()) for c in payload["forward_calls"])
    final_request=payload["requests"][-1][0]
    assert len(final_request["out_token_list"])==4,final_request["out_token_list"]
    payload.update(generated_text=generated_text,token_counts=token_counts,native_timing=as_cpu(timing))
    torch.save(payload,out/"rank-0-native-captures.pt")
    tokens=[int(v) for v in final_request["out_token_list"]]
    result={"status":"native_execution_complete","framework":"MindIE-LLM","backend":"Native ModelRunner -> ATB / PagedAttention; no HF forward substitution","runtime":"native-runtime.json","input_ids":[1,4,5,6],"generated_token_ids":tokens,"native_forward_calls":len(payload["forward_calls"]),"native_logits_shapes":[c["shape"] for c in payload["forward_calls"]],"native_logits_dtypes":[c["native_logits_dtype"] for c in payload["forward_calls"]],"warmup_excluded":True,"capture_boundary":"ModelRunner.forward return, before native sampling/postprocessor","native_cache_retained":True,"rank":0,"world_size":1,"captures":"rank-0-native-captures.pt","coverage_limit":"One native request with 4 generated tokens; capture includes native available rows, not all context-token rows; no fixed-continuation replay or production throughput claim."}
    write_json(out/"native-result.json",result)
    print(json.dumps(result,indent=2),flush=True)


def main():
    os.environ["PATH"]=str(Path(sys.executable).parent)+os.pathsep+os.environ.get("PATH","")
    ap=argparse.ArgumentParser()
    ap.add_argument("mode",choices=["mindspeed_llm","mindie"])
    ap.add_argument("--source",required=True)
    ap.add_argument("--out",required=True)
    ap.add_argument("--model")
    ap.add_argument("--memory-fraction",type=float,default=0.25)
    a,remaining=ap.parse_known_args()
    out=Path(a.out).resolve()
    out.mkdir(parents=True,exist_ok=False)
    if remaining and remaining[0]=="--":remaining=remaining[1:]
    if a.mode=="mindspeed_llm":mindspeed_llm(a.source,out,remaining)
    else:
        if not a.model:ap.error("mindie requires --model")
        if remaining:ap.error("Unexpected arguments: "+repr(remaining))
        mindie(a.source,out,a.model,a.memory_fraction)


if __name__=="__main__":main()
