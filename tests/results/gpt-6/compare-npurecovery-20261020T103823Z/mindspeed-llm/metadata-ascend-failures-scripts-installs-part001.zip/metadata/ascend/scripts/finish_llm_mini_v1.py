"""Finish the compact native case with its own independent CPU and core replay."""
from pathlib import Path
import subprocess,sys,time,json
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z')
asc=root/'ascend';out=asc/'results/llm-native-mini-attempt01'
for attempt in range(24):
 if (out/'native-result.json').is_file():break
 time.sleep(5)
assert (out/'native-result.json').is_file(),'Native compact job has not completed; original logs retained'
python=str(root/'sft/environments/swift-trl/bin/python')
subprocess.run([python,'-B',str(asc/'scripts/llm_cpu_reference_v1.py'),'--native-output',str(out),'--output',str(asc/'results/llm-mini-reference-attempt01')],check=True)
subprocess.run([python,'-B',str(asc/'scripts/compare_llm_mini_reference_v1.py')],check=True)
