"""Build the unchanged official dataset helper for this interpreter's actual ABI.

The copied source tree carried a cp310 helper while the host runs Python 3.12;
its make target used the system python3-config and incorrectly reused cp310.
This uses the running task interpreter's headers and suffix, keeping the old
binary and all official source bytes. Then launches a fresh native attempt.
"""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import sysconfig

root = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
source = root / 'sources/MindSpeed-LLM-b80e42f0/megatron/core/datasets'
cpp = source / 'helpers.cpp'
target = source / ('helpers_cpp' + sysconfig.get_config_var('EXT_SUFFIX'))
include = subprocess.check_output([sys.executable, '-m', 'pybind11', '--includes'], text=True)
command = ['g++', '-O3', '-Wall', '-shared', '-std=c++11', '-fPIC'] + shlex.split(include) + [str(cpp), '-o', str(target)]
print('OFFICIAL_DATASET_HELPER_BUILD', json.dumps(command), flush=True)
subprocess.run(command, check=True)
record = {'source': str(cpp), 'source_sha256': hashlib.sha256(cpp.read_bytes()).hexdigest(), 'output': str(target), 'output_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'python_abi': sysconfig.get_config_var('SOABI'), 'compiler_command': command, 'native_source_modified': False}
(root / 'results').mkdir(exist_ok=True)
(root / 'results/llm-dataset-helper-build-cp312.json').write_text(json.dumps(record, indent=2))
plan = json.loads((root / 'jobs/llm-native-20261020T100956Z-eb3609/command.json').read_text())
argv = plan['argv']
argv[argv.index('--out') + 1] = str(root / 'results/llm-native-attempt02')
subprocess.run([sys.executable, '-B', str(root / 'scripts/ascend_jobs_v3.py'), 'launch', '--native', '--label', 'llm-native-cp312', '--devices', '7', '--argv-json', json.dumps(argv)], check=True)
