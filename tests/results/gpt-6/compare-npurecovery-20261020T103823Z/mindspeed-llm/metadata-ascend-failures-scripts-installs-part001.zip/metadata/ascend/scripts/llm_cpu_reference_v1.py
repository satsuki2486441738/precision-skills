"""Independent HF Llama CPU FP32 replay of the native Megatron GPT coordinates.

Only accepted before values, batches, config and empty initial Adam state enter
the reference input. Native gradients, logits, losses and updates never do.
Full original padded vocabulary participates in CE, exactly as native TP=1.
"""
import argparse
import hashlib
import json
from pathlib import Path
import torch
from transformers import LlamaConfig, LlamaForCausalLM


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--native-output', required=True)
    ap.add_argument('--output', required=True)
    a = ap.parse_args()
    native_path, out = Path(a.native_output), Path(a.output)
    out.mkdir(parents=True, exist_ok=False)
    raw = native_path / 'rank-0-native-captures.pt'
    native = torch.load(raw, map_location='cpu', weights_only=False)
    args = json.loads((native_path / 'native-effective-arguments.json').read_text())
    cfg = json.loads((native_path / 'native-model-config.json').read_text())
    assert len(native['batch']) == 1
    assert not native['optimizer_state_before']['optimizer']['state']
    accepted = {'before': native['before'], 'batch': native['batch'][0], 'arguments': args, 'model_config': cfg, 'initial_optimizer': native['optimizer_state_before']}
    assert not {'after', 'gradients', 'native_logits', 'native_per_target_losses'} & set(accepted)
    torch.save(accepted, out / 'reference-input-captures.pt')
    del native, accepted
    data = torch.load(out / 'reference-input-captures.pt', map_location='cpu', weights_only=False)
    before, batch = data['before'], data['batch']
    prefix = 'chunk0.module.module.'
    assert all(n.startswith(prefix) for n in before)
    assert args['normalization'] == 'RMSNorm' and args['swiglu']
    assert args['position_embedding_type'] == 'rope' and args['rotary_percent'] == 1.0
    assert args['hidden_dropout'] == 0 and args['attention_dropout'] == 0
    assert args['tensor_model_parallel_size'] == args['pipeline_model_parallel_size'] == 1
    assert not cfg.get('add_bias_linear') and not cfg.get('layernorm_zero_centered_gamma')
    assert not cfg.get('apply_residual_connection_post_layernorm')
    hidden, ffn, heads = args['hidden_size'], args['ffn_hidden_size'], args['num_attention_heads']
    groups = cfg['num_query_groups']
    assert groups == heads, 'This reference requires standard MHA; GQA needs its own explicit coordinate map'
    head = cfg['kv_channels']
    vocab = before[prefix + 'embedding.word_embeddings.weight'].shape[0]
    assert batch['attention_mask'] is None, 'Explicit noncausal/packed masks need separate mapping'
    assert int(batch['tokens'].min()) >= 0 and int(batch['tokens'].max()) < vocab
    assert int(batch['labels'][batch['loss_mask'].bool()].max()) < vocab
    config = LlamaConfig(vocab_size=vocab, hidden_size=hidden, intermediate_size=ffn, num_hidden_layers=args['num_layers'], num_attention_heads=heads, num_key_value_heads=heads, head_dim=head, max_position_embeddings=args['max_position_embeddings'], rms_norm_eps=cfg['layernorm_epsilon'], rope_theta=args['rotary_base'], attention_bias=False, mlp_bias=False, attention_dropout=0.0, tie_word_embeddings=False, use_cache=False)
    config._attn_implementation = 'eager'
    torch.manual_seed(1729)
    model = LlamaForCausalLM(config).float().cpu().train()
    mapping = {}
    mapping[prefix + 'embedding.word_embeddings.weight'] = [('model.embed_tokens.weight', None)]
    mapping[prefix + 'decoder.final_layernorm.weight'] = [('model.norm.weight', None)]
    mapping[prefix + 'output_layer.weight'] = [('lm_head.weight', None)]
    for i in range(args['num_layers']):
        mg, hf = prefix + f'decoder.layers.{i}.', f'model.layers.{i}.'
        for m, h in [('input_layernorm.weight', 'input_layernorm.weight'), ('pre_mlp_layernorm.weight', 'post_attention_layernorm.weight'), ('self_attention.linear_proj.weight', 'self_attn.o_proj.weight'), ('mlp.linear_fc2.weight', 'mlp.down_proj.weight')]:
            mapping[mg + m] = [(hf + h, None)]
        mapping[mg + 'self_attention.linear_qkv.weight'] = [(hf + 'self_attn.' + name + '_proj.weight', ('qkv', j)) for j, name in enumerate(['q', 'k', 'v'])]
        mapping[mg + 'mlp.linear_fc1.weight'] = [(hf + 'mlp.' + name + '_proj.weight', ('fc1', j)) for j, name in enumerate(['gate', 'up'])]
    assert set(mapping) == set(before), (set(mapping) - set(before), set(before) - set(mapping))
    params = dict(model.named_parameters())
    with torch.no_grad():
        for name, parts in mapping.items():
            value = before[name].float()
            for target, spec in parts:
                if spec is None: selected = value
                elif spec[0] == 'qkv': selected = value.view(heads, 3, head, hidden)[:, spec[1]].reshape(hidden, hidden)
                else: selected = value.view(2, ffn, hidden)[spec[1]]
                assert params[target].shape == selected.shape
                params[target].copy_(selected)
        assert {n for parts in mapping.values() for n, _ in parts} == set(params)
    # Verify every native FP32 optimizer master before value equals the accepted
    # BF16 parameter converted exactly, without loading native optimizer after.
    ordered = [n for n in before if before[n].ndim > 1] + [n for n in before if before[n].ndim == 1]
    masters = [v for group in data['initial_optimizer']['fp32_from_fp16_params'] for v in group]
    assert len(ordered) == len(masters)
    for name, master in zip(ordered, masters): assert torch.equal(before[name].float(), master), name
    groups = data['initial_optimizer']['optimizer']['param_groups']
    assert all(g['lr'] == 0.001 and tuple(g['betas']) == (0.9, 0.95) and g['eps'] == 1e-8 and g['weight_decay'] == 0 and not g['amsgrad'] for g in groups)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, betas=(0.9, 0.95), eps=1e-8, weight_decay=0, foreach=False, fused=False)
    assert not optimizer.state
    logits = model(input_ids=batch['tokens'], position_ids=batch['position_ids'], use_cache=False).logits
    per_target = torch.nn.functional.cross_entropy(logits.reshape(-1, vocab), batch['labels'].reshape(-1), reduction='none').reshape_as(batch['labels'])
    loss = (per_target * batch['loss_mask']).sum() / batch['loss_mask'].sum()
    loss.backward()

    def backmap(field):
        result = {}
        for name, parts in mapping.items():
            values = [getattr(params[n], field) if field else params[n] for n, _ in parts]
            assert all(v is not None for v in values)
            values = [v.detach().clone() for v in values]
            if parts[0][1] is None: value = values[0]
            elif parts[0][1][0] == 'qkv': value = torch.stack([v.view(heads, head, hidden) for v in values], dim=1).reshape(3 * hidden, hidden)
            else: value = torch.cat(values, dim=0)
            result[name] = value
        return result

    gradients = backmap('grad')
    optimizer.step()
    output = {'before': {n: v.float().clone() for n, v in before.items()}, 'gradients': gradients, 'after': backmap(None), 'logits': logits.detach(), 'per_target_losses': per_target.detach(), 'loss': loss.detach(), 'optimizer_state_after': optimizer.state_dict()}
    assert all(torch.isfinite(v).all() for v in gradients.values())
    torch.save(output, out / 'reference-captures.pt')
    proof = {'status': 'independent_reference_complete', 'reference': 'Transformers LlamaForCausalLM CPU FP32, exact architecture/parameter coordinate mapping', 'native': 'MindSpeed-LLM Megatron GPT', 'native_capture_sha256': sha(raw), 'reference_input_sha256': sha(out / 'reference-input-captures.pt'), 'reference_capture_sha256': sha(out / 'reference-captures.pt'), 'reference_input_keys': sorted(data), 'reference_input_contains_native_outcomes': False, 'same_initial_trainable_values': True, 'native_master_initial_values_equal': True, 'all_model_parameters_mapped': True, 'native_qkv_layout': '[query_group, Q/K/V, head_dimension, hidden]', 'native_swiglu_layout': '[gate/up, ffn, hidden]', 'vocabulary': vocab, 'valid_targets': int(batch['loss_mask'].sum()), 'labels_already_shifted': True, 'optimizer_steps': 1, 'reference_optimizer': 'torch.optim.Adam', 'reference_loss': float(loss.detach()), 'native_dtype': 'bfloat16 parameters and forward; FP32 optimizer masters/accumulated gradients', 'reference_dtype': 'float32', 'thresholds': None, 'mapping': mapping, 'model_config': config.to_dict(), 'coverage': 'One valid random-model pretraining batch; no pretrained/SFT or throughput claim'}
    (out / 'reference-execution.json').write_text(json.dumps(proof, indent=2))
    print(json.dumps(proof, indent=2))


if __name__ == '__main__': main()
