"""Bounded private hardware/source probe and detached, logged task commands.

launch defaults to installation (no device lock). Pass --native to hold the
assigned physical device lock in the monitor and its child, including if the
monitor is interrupted. Does not change services, shared sources or drivers.
"""
import argparse
import datetime as dt
import fcntl
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import sys
import uuid

ROOT = Path(os.environ.get('PRECISION_ASCEND_ROOT', '/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')).resolve()


def run(command):
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
        return {'returncode': result.returncode, 'output': result.stdout[-16000:]}
    except Exception as error:
        return {'error': str(error)}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action', choices=['probe', 'launch', 'monitor', 'status'])
    ap.add_argument('--label', default='job')
    ap.add_argument('--argv-json')
    ap.add_argument('--devices', default='7')
    ap.add_argument('--native', action='store_true')
    ap.add_argument('--path')
    args = ap.parse_args()
    assert set(args.devices.split(',')) <= {'4', '5', '6', '7'}
    if args.action == 'probe':
        result = {'hostname': platform.node(), 'uid': os.getuid(), 'python': sys.version, 'executable': sys.executable, 'root': str(ROOT), 'root_parent_exists': ROOT.parent.is_dir(), 'devices_scope': args.devices, 'machine': platform.machine(), 'packages': {}}
        for name in ['torch', 'torch-npu', 'transformers', 'mindspeed', 'vllm', 'vllm-ascend', 'ray']:
            try:
                result['packages'][name] = metadata.version(name)
            except metadata.PackageNotFoundError:
                pass
        result['mount'] = run(['findmnt', '-T', str(ROOT.parent), '-o', 'TARGET,SOURCE,FSTYPE,FSROOT,OPTIONS'])
        result['disk_bytes'] = dict(zip(['total', 'used', 'free'], shutil.disk_usage(ROOT.parent)))
        result['npu_smi'] = run(['npu-smi', 'info'])
        result['sources'] = {}
        for prefix in ['/workspace', '/host-model/workspace', '/mnt/host-model/workspace']:
            for name in ['MindSpeed', 'MindSpeed-LLM', 'Megatron-LM']:
                path = Path(prefix) / name
                if path.is_dir():
                    result['sources'][str(path)] = run(['git', '-c', 'safe.directory=' + str(path), '-C', str(path), 'rev-parse', 'HEAD'])
        result['models'] = {}
        for name in ['/host-model/Qwen3-0.6B', '/mnt/host-model/Qwen3-0.6B', '/host-model/workspace/Qwen3-0.6B']:
            path = Path(name)
            if (path / 'config.json').is_file():
                result['models'][name] = {'config': json.loads((path / 'config.json').read_text()), 'names': sorted(p.name for p in path.iterdir())[:40]}
        os.environ['ASCEND_RT_VISIBLE_DEVICES'] = args.devices
        import torch
        import torch_npu
        value = torch.tensor([2., 3.], device='npu:0')
        result['runtime'] = {'torch': torch.__version__, 'torch_npu': torch_npu.__version__, 'count': torch.npu.device_count(), 'name': torch.npu.get_device_name(0), 'actual_device': str(value.device), 'squared': value.square().cpu().tolist()}
        print(json.dumps(result, indent=2)); return
    ROOT.mkdir(parents=True, exist_ok=True)
    if args.action == 'status':
        path = Path(args.path).resolve()
        assert path.is_relative_to(ROOT)
        result = {'directory': str(path), 'status': json.loads((path / 'status.json').read_text()) if (path / 'status.json').is_file() else None}
        log = path / 'full.log'
        if log.is_file():
            with log.open('rb') as stream:
                stream.seek(max(0, log.stat().st_size - 65536))
                result['tail'] = '\n'.join(stream.read().decode(errors='replace').splitlines()[-90:])
            result['log_bytes'] = log.stat().st_size
        print(json.dumps(result, indent=2)); return
    argv = json.loads(args.argv_json)
    assert isinstance(argv, list) and argv and all(isinstance(value, str) for value in argv)
    if args.action == 'monitor':
        out = Path(args.path).resolve()
        assert out.is_relative_to(ROOT)
        locks = []
        if args.native:
            for device in sorted(args.devices.split(',')):
                lock = Path('/tmp/precision-native-device-' + device + '.lock').open('a')
                fcntl.flock(lock, fcntl.LOCK_EX)
                locks.append(lock)
        code = subprocess.run(argv, pass_fds=tuple(lock.fileno() for lock in locks)).returncode
        (out / 'status.json').write_text(json.dumps({'returncode': code, 'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'native_completed': False, 'meaning': 'Process return code; inspect framework native-result/capture evidence separately'}, indent=2))
        raise SystemExit(code)
    out = ROOT / 'jobs' / (args.label + '-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:6])
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, PRECISION_ASCEND_ROOT=str(ROOT), ASCEND_RT_VISIBLE_DEVICES=args.devices, MAX_JOBS='2', OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2', PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1', TOKENIZERS_PARALLELISM='false', WANDB_MODE='disabled')
    for var, name in [('TMPDIR', 'tmp'), ('PIP_CACHE_DIR', 'pip'), ('HF_HOME', 'hf'), ('TORCH_EXTENSIONS_DIR', 'torch-extensions'), ('TORCHINDUCTOR_CACHE_DIR', 'inductor'), ('XDG_CACHE_HOME', 'xdg'), ('ASCEND_CACHE_PATH', 'ascend')]:
        path = ROOT / 'cache' / name
        path.mkdir(parents=True, exist_ok=True)
        env[var] = str(path)
    command = [sys.executable, '-B', str(Path(__file__).resolve()), 'monitor', '--path', str(out), '--argv-json', args.argv_json, '--devices', args.devices] + (['--native'] if args.native else [])
    shell = 'source /usr/local/Ascend/cann/set_env.sh && source /usr/local/Ascend/nnal/atb/set_env.sh && exec ' + shlex.join(command)
    with (out / 'full.log').open('xb') as log:
        process = subprocess.Popen(['/bin/bash', '-c', shell], cwd=out, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    result = {'pid': process.pid, 'directory': str(out), 'devices': args.devices, 'native_lock_requested': args.native, 'argv': argv, 'log': str(out / 'full.log')}
    (out / 'command.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
