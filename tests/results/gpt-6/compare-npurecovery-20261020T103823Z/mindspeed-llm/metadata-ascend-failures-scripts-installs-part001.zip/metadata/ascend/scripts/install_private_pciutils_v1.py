"""Use official Ubuntu userspace PCI tools; no host packages/config are changed."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
packages=json.loads((root/'cache/host-pciutils-package-provenance-01.json').read_text())
prefix=root/'host-tools/pciutils-3.7.0';prefix.mkdir(parents=True,exist_ok=False)
for entry in packages:
 package=root/'cache'/entry['filename'];assert hashlib.sha256(package.read_bytes()).hexdigest()==entry['sha256']
 subprocess.run(['dpkg-deb','-x',str(package),str(prefix)],check=True)
lib=prefix/'usr/lib/aarch64-linux-gnu';binary=prefix/'usr/bin/lspci';ids=prefix/'usr/share/misc/pci.ids'
assert binary.is_file() and ids.is_file()
wrapper=prefix/'bin';wrapper.mkdir()
(wrapper/'lspci').write_text('#!/bin/sh\nexec '+str(binary)+' -i '+str(ids)+' "$@"\n');(wrapper/'lspci').chmod(0o750)
env=dict(os.environ,LD_LIBRARY_PATH=str(lib)+':'+os.environ.get('LD_LIBRARY_PATH',''))
result=subprocess.run([str(wrapper/'lspci')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
assert result.returncode==0,result.stdout
(root/'results/mindie-native-pciutils-probe.json').write_text(json.dumps({'package_sources':packages,'userspace_prefix':str(prefix),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'pci_ids_sha256':hashlib.sha256(ids.read_bytes()).hexdigest(),'wrapper_sha256':hashlib.sha256((wrapper/'lspci').read_bytes()).hexdigest(),'wrapper_semantics':'exec actual Ubuntu lspci binary with exact official pci.ids database argument; no invented hardware output','actual_lspci_returncode':result.returncode,'actual_lspci_output':result.stdout,'global_system_packages_changed':False},indent=2))
previous=root/'jobs/mindie-native-owned-checkpoint-20261020T104628Z-161537';assert (previous/'status.json').is_file()
argv=json.loads((previous/'command.json').read_text())['argv'];argv=[a.replace('mindie-native-attempt06','mindie-native-attempt07') for a in argv]
assert argv[0]=='bash' and argv[1]=='-c'
argv[2]='export PATH='+str(wrapper)+':$PATH LD_LIBRARY_PATH='+str(lib)+':${LD_LIBRARY_PATH:-}; '+argv[2]
subprocess.run([sys.executable,'-B',str(root/'scripts/ascend_jobs_v4.py'),'launch','--native','--label','mindie-native-pciutils','--devices','7','--argv-json',json.dumps(argv)],check=True)
