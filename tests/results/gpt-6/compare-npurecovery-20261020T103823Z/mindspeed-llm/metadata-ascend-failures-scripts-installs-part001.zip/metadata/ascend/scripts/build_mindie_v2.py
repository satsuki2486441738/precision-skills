import hashlib,json,os,pathlib,shutil,subprocess,sys,zipfile
ROOT=pathlib.Path(os.environ.get('PRECISION_ASCEND_ROOT','/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend'))
source=ROOT/'sources/MindIE-LLM-3.1.0/examples/atb_models'
py=ROOT/'envs/mindie-torch2.9.0-npu2.9.0.post6/bin/python'
os.environ['PATH']=str(py.parent)+':'+os.environ['PATH']
os.environ['CMAKE_BUILD_PARALLEL_LEVEL']='3'
os.environ['PYTHONWARNINGS']='ignore::SyntaxWarning'
def run(a,cwd=None):
 print('COMMAND',json.dumps(list(map(str,a))),flush=True);r=subprocess.run(list(map(str,a)),cwd=cwd);print('RETURN',r.returncode,flush=True);r.check_returncode()
run([py,'-m','pip','install','--no-compile','--retries','1','--timeout','15','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','cmake==3.31.10','wheel'])
cm=source/'CMakeLists.txt';manifest=source/'precision-build-safety.json'
block='execute_process(\n    COMMAND sudo sh -c "echo 2 > /proc/sys/kernel/randomize_va_space"\n    RESULT_VARIABLE result\n)\nif(NOT result EQUAL 0)\n    message(WARNING "Failed to set ASLR level.")\nendif()'
if not manifest.exists():
 raw=cm.read_bytes();text=raw.decode();assert text.count(block)==1
 cm.write_text(text.replace(block,'# Task-local build: global ASLR mutation omitted.'))
 manifest.write_text(json.dumps({'reason':'Do not mutate global kernel ASLR on a shared host','changed_file':'CMakeLists.txt','removed_block':block,'original_sha256':hashlib.sha256(raw).hexdigest(),'modified_sha256':hashlib.sha256(cm.read_bytes()).hexdigest(),'native_operator_sources_modified':False},indent=2))
third=source/'third_party';third.mkdir(exist_ok=True)
for name,dest in [('mindie-nlohmann-3.11.2.zip',third/'nlohmannJson'),('mindie-spdlog-1.12.0.zip',third/'spdlog')]:
 if not (dest/'include').exists():
  temp=ROOT/'cache'/('extract-'+name);temp.mkdir(exist_ok=True)
  expected={'mindie-nlohmann-3.11.2.zip':'e5c7a9f49a16814be27e4ed0ee900ecd0092bfb7dbfca65b5a421b774dccaaed','mindie-spdlog-1.12.0.zip':'6174bf8885287422a6c6a0312eb8a30e8d22bcfcee7c48a6d02d1835d7769232'}[name]
  assert hashlib.sha256((ROOT/'cache'/name).read_bytes()).hexdigest()==expected,'Third-party archive SHA mismatch'
  with zipfile.ZipFile(ROOT/'cache'/name) as z:z.extractall(temp)
  origin=temp if name.startswith('mindie-nlohmann') else temp/'spdlog-1.12.0'
  shutil.copytree(origin,dest,dirs_exist_ok=True)
if (source/'build/Makefile').exists():
 run(['cmake','--build',source/'build','--parallel','3'])
 run(['cmake','--install',source/'build'])
else:run(['bash','scripts/build.sh','master'],source)
libraries={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'output').rglob('*.so')}
assert libraries,'No actual native shared libraries built'
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'results/mindie-native-build.json').write_text(json.dumps({'shared_libraries':libraries,'build_only_change':json.loads(manifest.read_text())},indent=2))
print('NATIVE_LIBRARIES',json.dumps(libraries),flush=True)
