"""Map actual native/CPU Megatron coordinates to the unchanged core contracts."""
from pathlib import Path
import json,sys,hashlib,importlib.util
import torch
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z')
asc=root/'ascend';n=asc/'results/llm-native-attempt04-valid-vocab';r=asc/'results/llm-reference-attempt01'
assert json.loads((r/'reference-execution.json').read_text())['status']=='independent_reference_complete'
view=asc/'comparison/llm-tiny-bf16-derived-view-attempt01';view.mkdir(parents=True,exist_ok=False)
x=torch.load(n/'rank-0-native-captures.pt',map_location='cpu',weights_only=False)
y=torch.load(r/'reference-captures.pt',map_location='cpu',weights_only=False)
assert len(x['native_logits'])==1 and x['native_logits'][0]['axes']==['sequence','batch','vocabulary']
b=x['batch'][0];valid=b['loss_mask'].bool();assert valid.all()
loss=x['native_train_step_result'][0]['lm loss'].detach().clone()
v={'before':x['before'],'gradients':x['gradients'],'after':x['after'],'parameter_inventory':x['parameter_inventory'],'frozen_before':{},'frozen_after':{},'compute_loss_controls':{'native_loss_mask_sum':int(b['loss_mask'].sum()),'already_shifted_labels':True,'native_optimizer':'Adam'},'batch':{'input_ids':b['tokens'],'labels':b['labels']},'logits':x['native_logits'][0]['value'].transpose(0,1).contiguous(),'loss':loss}
torch.save(v,view/'native-captures.pt');torch.save(y,view/'reference-captures.pt')
import shutil;shutil.copyfile(r/'reference-input-captures.pt',view/'reference-input-captures.pt')
proof=json.loads((r/'reference-execution.json').read_text());proof.update(same_initial_trainable_state=True,same_initial_frozen_values=True,frozen_base_unchanged=True)
(view/'reference-execution.json').write_text(json.dumps(proof,indent=2))
versions=json.loads((n/'native-runtime.json').read_text())
complete={'status':'native_execution_complete','framework':'MindSpeed-LLM','entrypoint':'official pretrain_gpt.py -> native Megatron/MindSpeed pretrain','entrypoint_returned':True,'model':'tiny','precision':'bf16','versions':versions,'model_path':'accepted random Megatron GPT parameter coordinates, all15337984 parameters mapped to independent CPU Llama','training':'full native Adam one-step pretraining','label_alignment':'already_shifted_native_targets','reference_implementation':'independent Transformers LlamaForCausalLM CPU FP32, exact native weight mapping, direct already-shifted-label CE backward and Adam'}
(view/'native-completion.json').write_text(json.dumps(complete,indent=2))
observations={'optimizer_steps':1,'valid_targets':int(valid.sum()),'native_loss':float(loss),'native_vocab_actual':v['logits'].shape[-1],'native_objective_boundary':'Actual native train_step result lm loss at TP1DP1/Microbatch1, before optimizer copyback; original per-target loss captures preserved','frozen_parameters':0}
(view/'observations.json').write_text(json.dumps(observations,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(view/'derived-view-provenance.json').write_text(json.dumps({'raw_native':str(n/'rank-0-native-captures.pt'),'raw_native_sha256':sha(n/'rank-0-native-captures.pt'),'raw_reference_sha256':sha(r/'reference-captures.pt'),'transformations':['logits exact transpose sequence,batch,vocab -> batch,sequence,vocab','native already-shifted labels retained with explicit contract switch','all native before/gradient/after values retained original dtype','native actual scalar lm loss copied without forward recomputation'],'native_arithmetic_changed':False},indent=2))
spec=importlib.util.spec_from_file_location('precision_export_training',asc/'scripts/export_compare_training_v3.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.export(view,asc/'metrics/llm-tiny-bf16-attempt01',root/'sft/core-tools');print(json.dumps(result,indent=2))
