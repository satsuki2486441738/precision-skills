"""Install missing actual MindIE Python dependencies and retry native generation."""
from pathlib import Path
import datetime,json,os,subprocess,sys
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
python=str(root/'envs/mindie-torch2.9.0-npu2.9.0.post6/bin/python')
out=root/'runs'/('compare-mindie-python-extras-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
env=dict(os.environ,PYTHONPATH='')
commands=[('install',[python,'-m','pip','install','--no-compile','--prefer-binary','--retries','1','--timeout','15','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','numpy==1.26.4','numba==0.61.2','posix_ipc==1.2.0','loguru==0.7.2','pandas==2.2.2','attrs==23.2.0','pyyaml','tabulate==0.9.0']),('freeze',[python,'-m','pip','freeze','--all']),('check',[python,'-m','pip','check'])]
events=[]
for name,cmd in commands:
 with (out/(name+'.log')).open('xb') as f:code=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 events.append({'stage':name,'command':cmd,'returncode':code});(out/'stages.json').write_text(json.dumps(events,indent=2))
 if code:raise SystemExit(code)
previous=root/'jobs/mindie-native-public-env-20261020T103441Z-fef1a2';assert (previous/'status.json').is_file()
argv=[a.replace('mindie-native-attempt03','mindie-native-attempt04') for a in json.loads((previous/'command.json').read_text())['argv']]
subprocess.run([sys.executable,'-B',str(root/'scripts/ascend_jobs_v4.py'),'launch','--native','--label','mindie-native-python-extras','--devices','7','--argv-json',json.dumps(argv)],check=True)
