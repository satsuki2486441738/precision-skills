"""Create a task-owned byte-identical checkpoint for native MindIE ownership checks."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,uuid
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
origin=Path('/host-model/Qwen3-0.6B');target=root/'models/qwen3-0.6b-owned-identical';target.mkdir(parents=True,exist_ok=True);target.chmod(0o750)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
files=[]
for source in sorted(origin.iterdir()):
 if not source.is_file():continue
 destination=target/source.name
 before=sha(source)
 if destination.exists():assert sha(destination)==before,'Existing private checkpoint differs: '+str(destination)
 else:
  staging=target/(source.name+'.copy-'+uuid.uuid4().hex)
  shutil.copyfile(source,staging);staging.chmod(0o640)
  assert sha(staging)==before
  staging.rename(destination)
 assert destination.stat().st_uid==os.getuid()
 assert sha(source)==before,'Shared read-only checkpoint changed externally'
 files.append({'name':source.name,'source_sha256':before,'private_sha256':sha(destination),'bytes':source.stat().st_size,'private_owner_uid':destination.stat().st_uid})
(root/'results/mindie-owned-checkpoint-identity.json').write_text(json.dumps({'source':str(origin),'private_copy':str(target),'shared_modified':False,'reason':'Official native check_owner rejected shared checkpoint ownership; use actual owned copy without bypassing framework checks','all_file_bytes_equal':True,'files':files},indent=2))
previous=root/'jobs/mindie-native-python-extras-v2-20261020T104200Z-8b30de';assert (previous/'status.json').is_file()
argv=[a.replace('mindie-native-attempt05','mindie-native-attempt06').replace('--model /host-model/Qwen3-0.6B','--model '+str(target)) for a in json.loads((previous/'command.json').read_text())['argv']]
subprocess.run([sys.executable,'-B',str(root/'scripts/ascend_jobs_v4.py'),'launch','--native','--label','mindie-native-owned-checkpoint','--devices','7','--argv-json',json.dumps(argv)],check=True)
