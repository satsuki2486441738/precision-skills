"""Seeded checkpoint/data/config preparation for an actual native GRPO run.

Hugging Face is used only to serialize an initial tiny Qwen3 checkpoint. Both
checkpoint conversion and the actual training/rollout use official native code.
"""
import hashlib,json,os,pathlib,subprocess,sys
ROOT=pathlib.Path(os.environ.get('PRECISION_ASCEND_ROOT','/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend'))
rl=ROOT/'sources/MindSpeed-RL-26c21e64';llm=ROOT/'sources/MindSpeed-LLM-a2c0733b';work=ROOT/'inputs/rl-tiny-qwen3';hf=work/'hf';mg=work/'mcore'
work.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(rl));os.environ['PATH']=str(pathlib.Path(sys.executable).parent)+':'+os.environ['PATH'];os.environ['PYTHONPATH']=str(rl)+':'+os.environ.get('PYTHONPATH','')
import torch,yaml
from tokenizers import Tokenizer,models,pre_tokenizers
from transformers import Qwen3Config,Qwen3ForCausalLM,PreTrainedTokenizerFast
if not (hf/'precision-initialization.json').exists():
 hf.mkdir(exist_ok=True)
 vocab={'[PAD]':0,'[EOS]':1,'[UNK]':2,'prompt':3}
 vocab.update({'Step '+str(i)+':':i+3 for i in range(1,129)})
 vocab.update({'word'+str(i):i for i in range(132,256)})
 assert len(vocab)==256 and sorted(vocab.values())==list(range(256))
 backend=Tokenizer(models.WordLevel(vocab,unk_token='[UNK]'));backend.pre_tokenizer=pre_tokenizers.WhitespaceSplit()
 tokenizer=PreTrainedTokenizerFast(tokenizer_object=backend,pad_token='[PAD]',eos_token='[EOS]',unk_token='[UNK]',model_max_length=128)
 assert tokenizer.encode(tokenizer.decode([3,132,133]),add_special_tokens=False)==[3,132,133],'Native vLLM prompt decode/re-encode must preserve the actual input IDs'
 tokenizer.save_pretrained(hf)
 torch.manual_seed(1729)
 config=Qwen3Config(vocab_size=256,hidden_size=256,intermediate_size=768,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=4,head_dim=64,max_position_embeddings=128,rope_theta=10000.,rms_norm_eps=1e-6,tie_word_embeddings=False,pad_token_id=0,eos_token_id=1,bos_token_id=None,attention_dropout=0.)
 model=Qwen3ForCausalLM(config).to(torch.bfloat16);model.save_pretrained(hf,safe_serialization=True)
 (hf/'precision-initialization.json').write_text(json.dumps({'semantics':'seeded random Qwen3 native execution fixture, not pretrained capability','seed':1729,'dtype':'bfloat16','parameter_elements':sum(p.numel() for p in model.parameters()),'reward_fixture':'Official native step verifier sees synthetic vocabulary tokens Step n:, so actual sampled responses can have different rewards; no task-quality claim.'},indent=2))
if not (mg/'latest_checkpointed_iteration.txt').exists():
 command=[sys.executable,str(llm/'convert_ckpt_v2.py'),'--load-model-type','hf','--save-model-type','mg','--target-tensor-parallel-size','1','--target-pipeline-parallel-size','1','--load-dir',str(hf),'--save-dir',str(mg),'--model-type-hf','qwen3','--transformer-impl','local']
 print('NATIVE_CONVERSION',json.dumps(command),flush=True);subprocess.run(command,cwd=llm,check=True)
from mindspeed_rl.datasets.indexed_dataset import IndexedDatasetBuilder
data=work/'data';data.mkdir(exist_ok=True);prefix=data/'fixture'
for key,values in [('input_ids',[3,132,133]),('labels',[134])]:
 base=pathlib.Path(str(prefix)+'_packed_'+key+'_document')
 if not pathlib.Path(str(base)+'.idx').exists():
  builder=IndexedDatasetBuilder(str(base)+'.bin')
  for _ in range(8):builder.add_item(torch.tensor(values));builder.end_document()
  builder.finalize(str(base)+'.idx')
model_config=dict(use_mcore_models=True,num_layers=2,hidden_size=256,ffn_hidden_size=768,num_attention_heads=4,kv_channels=64,num_query_groups=4,group_query_attention=True,rotary_base=10000,max_position_embeddings=128,make_vocab_size_divisible_by=1,padded_vocab_size=256,untie_embeddings_and_output_weights=True,disable_bias_linear=True,position_embedding_type='rope',normalization='RMSNorm',norm_epsilon=1e-6,swiglu=True,attention_softmax_in_fp32=True,attention_bias=False,qk_layernorm=True)
training=dict(model='precision_tiny',use_mcore_models=True,use_fused_rmsnorm=True,use_flash_attn=True,no_masked_softmax_fusion=True,no_gradient_accumulation_fusion=True,use_fused_swiglu=True,use_fused_rotary_pos_emb=True,bf16=True,use_distributed_optimizer=False,tokenizer_type='PretrainedFromHF',tokenizer_name_or_path=str(hf),global_batch_size=1,seq_length=16,save_interval=10000,train_iters=1,eval_iters=0,stage='ray_grpo',attention_dropout=0.,hidden_dropout=0.,distributed_backend='hccl',no_shared_storage=False,dataset_additional_keys=['labels'],data_path=str(prefix),split='100,0,0',no_shuffle=True,seed=1729,reuse_fp32_param=False,num_workers=0,log_interval=1)
actor=dict(model='precision_tiny',micro_batch_size=1,tensor_model_parallel_size=1,pipeline_model_parallel_size=1,lr=0.001,lr_decay_style='constant',min_lr=0.,weight_decay=0.,lr_warmup_fraction=0.,clip_grad=0.,adam_beta1=.9,adam_beta2=.95,finetune=True,load=str(mg),save=str(work/'trained'),no_load_optim=True,no_load_rng=True)
rl_config=dict(guarantee_order=True,use_integrated_worker=True,blocking=True,async_engine=False,actor_forward_micro_batch_size=1,ref_forward_micro_batch_size=1,adv_estimator='group_norm',kl_penalty='low_var_kl',kl_ctrl_type='fixed',init_kl_coef=.001,mini_batch_size=1,max_prompt_length=8,epochs=1,clip_ratio=.2,entropy_coeff=0.,shuffle_mini_batch=False,n_samples_per_prompt=4,rule_reward=True,verifier_function=['step'],verifier_weight=[1.],log_max_throughput=False,num_cpus_for_local_task=1.,num_cpus_for_placement_group=2,use_tensorboard=False,actor_resource={'num_npus':1},share_backbone=False,runtime_env_path='configs/envs/precision-runtime.yaml')
generation=dict(tokenizer_name_or_path=str(hf),trust_remote_code=False,offload_train_optimizer=False,offload_train_grad=False,offload_train_param=False,infer_tensor_parallel_size=1,infer_pipeline_parallel_size=1,infer_expert_parallel_size=1,max_num_seqs=4,max_model_len=16,max_num_batched_tokens=32,dtype='bfloat16',gpu_memory_utilization=.15,enforce_eager=True,enable_prefix_caching=False,sampling_config=dict(logprobs=1,max_tokens=4,top_p=1.,top_k=-1,min_p=0.,temperature=1.,detokenize=False,seed=1729))
config={'model':{'precision_tiny':model_config},'megatron_training':training,'actor_config':actor,'rl_config':rl_config,'generate_config':generation}
target=rl/'configs/precision_tiny_grpo.yaml';target.write_text(yaml.safe_dump(config,sort_keys=False))
runtime=yaml.safe_load((rl/'configs/envs/runtime_env.yaml').read_text());runtime['env_vars'].update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'scripts/rl-observer')+':'+str(rl)+':'+os.environ.get('PYTHONPATH',''),PRECISION_NATIVE_CAPTURE_ROOT=str(ROOT/'results/rl-native-captures'),HCCL_IF_BASE_PORT='29345',LCAL_COMM_ID='127.0.0.1:29346',TOKENIZERS_PARALLELISM='false')
(rl/'configs/envs/precision-runtime.yaml').write_text(yaml.safe_dump(runtime,sort_keys=False))
manifest={'checkpoint_initialization':json.loads((hf/'precision-initialization.json').read_text()),'config':str(target),'native_converter':str(llm/'convert_ckpt_v2.py'),'files':{str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file() and p.suffix in ['.json','.safetensors','.idx','.bin','.txt']}}
(work/'precision-input-manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2),flush=True)
