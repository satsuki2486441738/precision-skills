"""Bounded task-owned Ray/NPU mapping probe; no framework success claim."""
import datetime,json,os,pathlib
ROOT=pathlib.Path(os.environ.get('PRECISION_ASCEND_ROOT','/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend'))
visible=os.environ.get('ASCEND_RT_VISIBLE_DEVICES','').split(',')
assert len(visible)==1 and visible[0] in ['4','5','6','7'],'Probe one explicitly task-assigned physical device'
import ray
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');temp=pathlib.Path('/tmp')/('precision-map-'+stamp);temp.mkdir(mode=0o700,parents=True,exist_ok=False)
@ray.remote(resources={'NPU':1})
def probe():
 import torch,torch_npu
 raw=ray.get_runtime_context().get_accelerator_ids().get('NPU',[])
 worker_visible=os.environ.get('ASCEND_RT_VISIBLE_DEVICES','').split(',')
 assert worker_visible==visible,'Ray changed the actual assigned-device visibility unexpectedly'
 assert len(raw)==1
 if str(raw[0]) in visible:translated=visible.index(str(raw[0]))
 else:
  translated=int(raw[0]);assert 0<=translated<len(visible)
 torch.npu.set_device(translated)
 x=torch.tensor([2.,3.],device='npu:'+str(translated));result=x.square();torch.npu.synchronize()
 return {'ray_raw_npu_ids':raw,'assigned_visibility':worker_visible,'torch_visible_count':torch.npu.device_count(),'torch_logical_device':translated,'requires_physical_to_logical_translation':str(raw[0])!=str(translated),'torch':torch.__version__,'torch_npu':torch_npu.__version__,'native_device':str(result.device),'native_square':result.cpu().tolist(),'scope':'Runtime/resource mapping proof only; not native framework training'}
try:
 ray.init(address='local',num_cpus=2,resources={'NPU':1},runtime_env={'env_vars':{'ASCEND_RT_VISIBLE_DEVICES':visible[0],'RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES':'true','PYTHONDONTWRITEBYTECODE':'1'}},namespace='precision-map-'+stamp,include_dashboard=False,_temp_dir=str(temp),object_store_memory=128*(1<<20),_node_ip_address='127.0.0.1')
 result=ray.get(probe.remote());result['status']='actual_mapping_probe_complete'
 out=ROOT/'results'/('ray-device-mapping-'+stamp+'.json');out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
finally:ray.shutdown()
