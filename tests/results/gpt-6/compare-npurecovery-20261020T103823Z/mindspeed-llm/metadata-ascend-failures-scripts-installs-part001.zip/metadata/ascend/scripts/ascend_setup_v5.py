"""Resumable private Ascend native environments; source/runtime are never mocked.

Source CANN before running. Upload the pinned source archives to ROOT/cache.
Mode llm copies only the checked official source commits, with no mutations of
the shared checkout; other modes extract verified immutable source archives.
"""
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import uuid
import venv

ROOT = Path(os.environ.get('PRECISION_ASCEND_ROOT', '/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')).resolve()
INDEX = 'https://pypi.tuna.tsinghua.edu.cn/simple'
ARCHIVES = {
 'MindIE-LLM-3.1.0': ('MindIE-LLM-3.1.0.tar.gz', 'b58ff9d99618381dd0c48df093b6943cd5c2c4c30eaadb6d607b3fce3ed77771'),
 'MindSpeed-RL-26c21e64': ('MindSpeed-RL-26c21e64.tar.gz', '87f24b68d23c41eabd7c84a2928caaa1687c50a68535c894e63321ba0fd44de7'),
 'MindSpeed-ac9f0e74': ('MindSpeed-ac9f0e74.tar.gz', '457e7e438bc767dc75aa7baa90e836f3c98b505745f5f09a664230ffda044706'),
 'MindSpeed-LLM-a2c0733b': ('MindSpeed-LLM-a2c0733b.tar.gz', 'bcbac0225513fa25163ca2fd4da99f2cf3d497df2aaf18fa89749505f3380e89'),
 'Megatron-core-v0121': ('Megatron-core-v0121.tar.gz', '3e83d4a79014d77c121b257c03ba592b55bcc68ed24bece705e54978942e04d8'),
 'vllm-b8b302c': ('vllm-b8b302c.tar.gz', 'e672d797fadb21bf6b18baa300d4b1dacb60d8a68a31c9b3ce421dc3f1b2dd56'),
 'vllm-ascend-1b16c01': ('vllm-ascend-1b16c01.tar.gz', 'd40e99bad661e8e34587ca8f23ca0f3271083c425e1ece1fbf70e86f98d09dca'),
}


def write(path, obj):
    path.write_text(json.dumps(obj, indent=2))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extract(name):
    filename, expected = ARCHIVES[name]
    archive = ROOT / 'cache' / filename
    assert digest(archive) == expected, 'Source archive SHA256 mismatch: ' + filename
    dest = ROOT / 'sources' / name
    if (dest / '.precision-extracted.json').is_file():
        assert json.loads((dest / '.precision-extracted.json').read_text())['sha256'] == expected
        return dest
    assert not dest.exists(), 'Preserve partial source and choose an explicit retry directory: ' + str(dest)
    staging = ROOT / 'tmp' / ('extract-' + name + '-' + uuid.uuid4().hex)
    staging.mkdir()
    with tarfile.open(archive) as stream:
        prefix = stream.getnames()[0].split('/')[0]
        stream.extractall(staging, filter='data')
    unpacked = staging / prefix
    write(unpacked / '.precision-extracted.json', {'archive': filename, 'sha256': expected})
    unpacked.rename(dest)
    return dest


def checked_copy(origin, name, commit):
    result = subprocess.run(['git', '-c', 'safe.directory=' + str(origin), '-C', str(origin), 'rev-parse', 'HEAD'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    assert result.returncode == 0 and result.stdout.strip() == commit, 'Official source commit mismatch at ' + str(origin) + ': ' + result.stdout + result.stderr
    target = ROOT / 'sources' / name
    marker = target / '.precision-copy-complete.json'
    if marker.is_file():
        assert json.loads(marker.read_text())['commit'] == commit
        return target
    assert not target.exists(), 'Preserve partial source: ' + str(target)
    temp = ROOT / 'sources' / (name + '-copy-' + uuid.uuid4().hex)
    shutil.copytree(origin, temp, ignore=shutil.ignore_patterns('.git', 'logs', '__pycache__'))
    write(temp / '.precision-copy-complete.json', {'origin': str(origin), 'commit': commit, 'requirements_sha256': digest(temp / 'requirements.txt')})
    temp.rename(target)
    return target


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=['llm', 'mindie', 'rl'])
    ap.add_argument('--official-workspace', default='/workspace')
    args = ap.parse_args()
    for name in ['envs', 'sources', 'state', 'runs', 'cache/pip', 'tmp']:
        (ROOT / name).mkdir(parents=True, exist_ok=True)
    out = ROOT / 'runs' / ('compare-setup-' + args.mode + '-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:6])
    out.mkdir()
    lock = (ROOT / 'state' / (args.mode + '-setup.lock')).open('a')
    fcntl.flock(lock, fcntl.LOCK_EX)
    torch_version = '2.9.0' if args.mode == 'mindie' else '2.7.1'
    npu_version = '2.9.0.post6' if args.mode == 'mindie' else '2.7.1.post8'
    envdir = ROOT / 'envs' / (args.mode + '-torch' + torch_version + '-npu' + npu_version)
    if not (envdir / 'bin/python').is_file():
        venv.EnvBuilder(with_pip=True).create(envdir)
    python = str(envdir / 'bin/python')
    env = dict(os.environ, PIP_CACHE_DIR=str(ROOT / 'cache/pip'), TMPDIR=str(ROOT / 'tmp'), MAX_JOBS='2', OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', PATH=str(envdir / 'bin') + os.pathsep + os.environ['PATH'], PIP_DISABLE_PIP_VERSION_CHECK='1', PIP_NO_COMPILE='1')
    package_env = dict(env, PYTHONPATH='')
    pip = [python, '-m', 'pip', 'install', '--no-compile', '--prefer-binary', '--retries', '1', '--timeout', '15']
    stages = [
      ('tools', pip + ['--index-url', INDEX, 'setuptools<80,>=77.0.3', 'setuptools-scm>=8', 'wheel', 'cmake==3.31.10', 'pybind11', 'ninja', 'decorator'], None),
      ('torch', pip + ['--index-url', 'https://download.pytorch.org/whl/cpu', '--extra-index-url', INDEX, 'torch==' + torch_version] + ([] if args.mode == 'mindie' else ['torchvision==0.22.1']), None),
      ('npu', pip + ['--index-url', INDEX, 'torch-npu==' + npu_version], None),
    ]
    state = ROOT / 'state' / (args.mode + '-setup')
    state.mkdir(exist_ok=True)
    failed = None
    events = []
    try:
        if args.mode == 'llm':
            workspace = Path(args.official_workspace)
            source = checked_copy(workspace / 'MindSpeed-LLM', 'MindSpeed-LLM-b80e42f0', 'b80e42f0a578424a07c03c65424d431e563295a6')
            mindspeed = checked_copy(workspace / 'MindSpeed', 'MindSpeed-7af9baed', '7af9baed954934d896274323932ec5a8f6dd9c23')
            constraints = envdir / 'precision-constraints-v5.txt'
            constraints.write_text('torch==2.7.1+cpu\ntorch-npu==2.7.1.post8\ntorchvision==0.22.1\ntransformers==5.2.0\nnumpy==1.26.0\npyarrow==21.0.0\n')
            stages += [('requirements', pip + ['--index-url', INDEX, '-c', str(constraints), '-r', str(mindspeed / 'requirements.txt'), '-r', str(source / 'requirements.txt'), 'tensorboard'], None), ('mindspeed', pip + ['--index-url', INDEX, '--no-deps', '--no-build-isolation', '-e', str(mindspeed)], None)]
        elif args.mode == 'mindie':
            source = extract('MindIE-LLM-3.1.0')
            stages += [('requirements', pip + ['--index-url', INDEX, 'transformers==4.51.3', 'accelerate==0.27.2', 'scipy==1.11.4', 'numpy==1.26.4', 'tiktoken==0.5.2', 'einops==0.7.0', 'transformers_stream_generator==0.0.4', 'sentencepiece', 'safetensors', 'psutil'], None)]
        else:
            source = extract('MindSpeed-RL-26c21e64')
            ms, llm, mg, vllm, ascend = [extract(name) for name in ['MindSpeed-ac9f0e74', 'MindSpeed-LLM-a2c0733b', 'Megatron-core-v0121', 'vllm-b8b302c', 'vllm-ascend-1b16c01']]
            for origin, name in [(ms, 'mindspeed'), (llm, 'mindspeed_llm'), (mg, 'megatron')]:
                if not (source / name).exists():
                    shutil.copytree(origin / name, source / name, ignore=shutil.ignore_patterns('__pycache__'))
            constraints = envdir / 'precision-constraints-v5.txt'
            constraints.write_text('torch==2.7.1+cpu\ntorch-npu==2.7.1.post8\ntorchvision==0.22.1\ntransformers==4.57.1\nnumpy==1.26.4\nopencv-python-headless==4.11.0.86\npyarrow==21.0.0\nmatplotlib==3.10.9\ncontourpy==1.3.3\n')
            official_requirements = source / 'requirements.txt'
            selected_requirements = out / 'requirements-private-av144.txt'
            original = official_requirements.read_text()
            assert original.count('av==14.3.0') == 1
            selected_requirements.write_text(original.replace('av==14.3.0', 'av==14.4.0'))
            write(out / 'dependency-selection.json', {'official_requirements': str(official_requirements), 'official_sha256': digest(official_requirements), 'selected_requirements': str(selected_requirements), 'selected_sha256': digest(selected_requirements), 'deviation': 'av14.3.0 has no distributions on PyPI; text-only GRPO uses published official PyAV14.4.0 wheel. No training, optimizer, rollout, or model operators changed.', 'primary_evidence': ['https://pypi.org/pypi/av/14.3.0/json', 'https://pypi.org/pypi/av/14.4.0/json'], 'scope': 'dependency substitution; audiovisual functionality not exercised'})
            stages += [('requirements', pip + ['--index-url', INDEX, '-c', str(constraints), '-r', str(selected_requirements)], None), ('vllm-requirements', pip + ['--index-url', INDEX, '-c', str(constraints), '-r', str(vllm / 'requirements/common.txt'), 'quart', 'decorator', 'antlr4-python3-runtime==4.9.3', 'einops', 'gpytorch'], None), ('vllm', pip + ['--index-url', INDEX, '--no-build-isolation', '--no-deps', str(vllm)], {'VLLM_TARGET_DEVICE': 'empty', 'SETUPTOOLS_SCM_PRETEND_VERSION': '0.11.0'}), ('vllm-ascend', pip + ['--index-url', INDEX, '--no-build-isolation', '--no-deps', str(ascend)], {'COMPILE_CUSTOM_KERNELS': '1', 'SETUPTOOLS_SCM_PRETEND_VERSION': '0.11.0.dev0', 'MAX_JOBS': '2'})]
        write(out / 'source-plan.json', {'mode': args.mode, 'source': str(source), 'environment': str(envdir), 'torch': torch_version, 'torch_npu': npu_version, 'system_site_packages': False})
        for name, command, extra in stages:
            key = hashlib.sha256(json.dumps([command, extra], sort_keys=True).encode()).hexdigest()
            marker = state / (name + '-success.json')
            if marker.is_file() and json.loads(marker.read_text()).get('command_sha256') == key:
                event = {'stage': name, 'returncode': 0, 'reused_success': json.loads(marker.read_text())}
            else:
                with (out / (name + '.log')).open('xb') as stream:
                    code = subprocess.run(command, env=dict(package_env, **(extra or {})), stdout=stream, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),)).returncode
                event = {'stage': name, 'returncode': code, 'command': command, 'extra_environment': extra, 'command_sha256': key, 'log': str(out / (name + '.log'))}
                if code == 0:
                    write(marker, event)
            events.append(event)
            with (out / 'journal.jsonl').open('a') as stream:
                stream.write(json.dumps(event) + '\n')
            if event['returncode']:
                failed = name
                break
    except Exception as error:
        failed = 'source-or-setup-exception'
        write(out / 'exception.json', {'type': type(error).__name__, 'message': str(error)})
    finally:
        for name, command in [('freeze', [python, '-m', 'pip', 'freeze', '--all']), ('check', [python, '-m', 'pip', 'check'])]:
            with (out / (name + '.log')).open('xb') as stream:
                code = subprocess.run(command, env=package_env, stdout=stream, stderr=subprocess.STDOUT).returncode
            events.append({'stage': name, 'returncode': code, 'log': str(out / (name + '.log'))})
            if code and failed is None:
                failed = name
        vendor_checks = {}
        for label, command in [('runtime-freeze', [python, '-m', 'pip', 'freeze', '--all']), ('runtime-check', [python, '-m', 'pip', 'check'])]:
            with (out / (label + '.log')).open('xb') as stream:
                vendor_checks[label] = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
        write(out / 'package-scope.json', {'isolated_environment_check': 'PYTHONPATH empty', 'vendor_runtime_pythonpath': env.get('PYTHONPATH', ''), 'vendor_runtime_checks': vendor_checks})
        result = {'vendor_checks': vendor_checks, 'mode': args.mode, 'environment': str(envdir), 'attempt': str(out), 'ready': failed is None, 'failed_stage': failed, 'native_completed': False, 'events': events}
        write(out / 'status.json', result)
        write(state / 'latest.json', result)
        print(json.dumps(result), flush=True)
    raise SystemExit(bool(failed))


if __name__ == '__main__':
    main()
