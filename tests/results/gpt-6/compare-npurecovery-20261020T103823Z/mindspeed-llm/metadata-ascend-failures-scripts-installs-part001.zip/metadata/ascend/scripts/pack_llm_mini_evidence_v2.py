"""Pack all actual SFT cases as independently hashed <45MiB evidence volumes.

Original tensor bytes are unchanged. Large individual files are split into
ordered binary chunks, with full-file SHA256 and offsets for exact reassembly.
No pretrained weights, environments or caches enter these task-owned volumes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'sft/scripts'))
from collect_native_evidence_v2 import sanitize, sanitize_text

LIMIT = 40 * (1 << 20)
CHUNK = 32 * (1 << 20)


def sha(data): return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--ascend-root', required=True)
    ap.add_argument('--include-pt', action='store_true')
    ap.add_argument('--output', required=True)
    a = ap.parse_args()
    root, out = Path(a.ascend_root), Path(a.output)
    out.mkdir(parents=True, exist_ok=False)
    index = {'schema': 'precision-sft-evidence-volumes-v1', 'maximum_volume_bytes': 45 * (1 << 20), 'tensor_bytes_unchanged': True, 'thresholds': None, 'cases': [], 'volumes': [], 'reassembly': 'Extract all volumes into a new directory. For every chunked file, concatenate chunk records in offset order into its logical_path; verify source_sha256 before replay. Text is sanitized and has a separate archived_sha256.'}

    def pack(label, files):
        parts, entries, budget, z = 0, [], 0, None
        def close():
            nonlocal z, entries
            if z is None: return
            z.writestr('volume-manifest.json', json.dumps({'label': label, 'entries': entries, 'tensor_bytes_unchanged': True}, indent=2))
            name = Path(z.filename)
            z.close()
            raw = name.read_bytes()
            assert len(raw) < 45 * (1 << 20), name
            index['volumes'].append({'filename': name.name, 'bytes': len(raw), 'sha256': sha(raw), 'label': label, 'entries': entries})
            z, entries = None, []
        for logical, path in files:
            raw = path.read_bytes()
            text = path.suffix in {'.json', '.jsonl', '.log', '.txt', '.yaml', '.yml', '.py', '.sh', '.md', '.toml'}
            selected = raw
            if text:
                value = raw.decode('utf-8', errors='replace')
                if path.suffix == '.json':
                    try: value = json.dumps(sanitize(json.loads(value)), indent=2)
                    except ValueError: value = sanitize_text(value)
                else: value = sanitize_text(value)
                selected = value.encode()
            total, digest = len(selected), sha(selected)
            for offset in range(0, max(total, 1), CHUNK):
                block = selected[offset:offset + CHUNK]
                if z is not None and budget + len(block) > LIMIT: close()
                if z is None:
                    parts += 1
                    z = zipfile.ZipFile(out / f'{label}-part{parts:03d}.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=3)
                    budget = 0
                archive_name = logical if total <= CHUNK else 'chunks/' + logical + f'.offset{offset:012d}.bin'
                z.writestr(archive_name, block)
                entry = {'logical_path': logical, 'archive_path': archive_name, 'offset': offset, 'chunk_bytes': len(block), 'chunk_sha256': sha(block), 'archived_file_bytes': total, 'archived_file_sha256': digest, 'source_bytes': len(raw), 'source_sha256': sha(raw), 'sanitized_text': text, 'tensor_bytes_unchanged': not text, 'chunked': total > CHUNK}
                entries.append(entry)
                budget += len(block)
        close()

    files=[];retained=[]
    for relative,logical in [('results/llm-native-mini-attempt01','native'),('results/llm-mini-reference-attempt01','reference'),('comparison/llm-mini-bf16-derived-view-attempt01','derived'),('metrics/llm-mini-bf16-attempt01','metrics')]:
        for path in sorted((root/relative).iterdir()):
            if not path.is_file():continue
            if path.suffix=='.pt' and not a.include_pt:
                retained.append({'private_path':sanitize_text(str(path)),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())});continue
            if path.suffix in {'.json','.log','.yaml','.yml','.txt','.safetensors','.pt'}:
                files.append(('cases/llm-mini/'+logical+'/'+path.name,path))
    index['cases']=[{'framework':'MindSpeed-LLM','model':'tiny-native-GPT','precision':'bf16','canonical':True,'label':'canonical-mindspeed-llm-mini-bf16','logical_root':'cases/llm-mini/'}]
    index['retained_private_raw_pt']=retained
    pack('canonical-mindspeed-llm-mini-bf16',files)
    metadata=[]
    for top in ['scripts','runs','state','jobs']:
        for path in sorted((root/top).rglob('*')):
            if path.is_file() and not path.is_symlink() and path.suffix in {'.json','.jsonl','.py','.sh','.log','.txt','.yaml','.yml'}:
                metadata.append(('metadata/ascend/'+path.relative_to(root).as_posix(),path))
    for path in sorted((root/'results').rglob('*.json')):
        if path.is_file():metadata.append(('metadata/ascend/'+path.relative_to(root).as_posix(),path))
    for path in sorted((root.parent/'sft/core-tools').glob('*.py')):
        metadata.append(('metadata/core-tools/'+path.name,path))
    for relative in ['sources/MindSpeed-LLM-b80e42f0/megatron/core/transformer/attention.py','sources/MindSpeed-LLM-b80e42f0/megatron/core/transformer/mlp.py','sources/MindSpeed-LLM-b80e42f0/megatron/core/models/common/embeddings/rope_utils.py','sources/MindSpeed-LLM-b80e42f0/megatron/core/tensor_parallel/cross_entropy.py','sources/MindSpeed-LLM-b80e42f0/megatron/core/optimizer/optimizer.py','sources/MindIE-LLM-3.1.0/examples/atb_models/precision-build-safety.json']:
        path=root/relative
        if path.is_file():metadata.append(('metadata/source-reference/'+relative,path))
    pack('metadata-ascend-failures-scripts-installs',metadata)
    index['canonical_case_count'] = sum(c['canonical'] for c in index['cases'])
    index['historical_completed_case_count'] = sum(not c['canonical'] for c in index['cases'])
    (out / 'archive-index.json').write_text(json.dumps(index, indent=2))
    print(json.dumps({'directory': str(out), 'index_sha256': sha((out / 'archive-index.json').read_bytes()), 'volumes': [{k: v[k] for k in ['filename', 'bytes', 'sha256', 'label']} for v in index['volumes']], 'canonical_case_count': index['canonical_case_count'], 'historical_completed_case_count': index['historical_completed_case_count']}, indent=2))


if __name__ == '__main__': main()
