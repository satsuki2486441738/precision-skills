"""Pack all actual SFT cases as independently hashed <45MiB evidence volumes.

Original tensor bytes are unchanged. Large individual files are split into
ordered binary chunks, with full-file SHA256 and offsets for exact reassembly.
No pretrained weights, environments or caches enter these task-owned volumes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile
from collect_native_evidence_v2 import sanitize, sanitize_text

LIMIT = 40 * (1 << 20)
CHUNK = 32 * (1 << 20)


def sha(data): return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--sft-root', required=True)
    ap.add_argument('--metrics-root', required=True)
    ap.add_argument('--output', required=True)
    a = ap.parse_args()
    root, metrics, out = Path(a.sft_root), Path(a.metrics_root), Path(a.output)
    out.mkdir(parents=True, exist_ok=False)
    index = {'schema': 'precision-sft-evidence-volumes-v1', 'maximum_volume_bytes': 45 * (1 << 20), 'tensor_bytes_unchanged': True, 'thresholds': None, 'cases': [], 'volumes': [], 'reassembly': 'Extract all volumes into a new directory. For every chunked file, concatenate chunk records in offset order into its logical_path; verify source_sha256 before replay. Text is sanitized and has a separate archived_sha256.'}

    def pack(label, files):
        parts, entries, budget, z = 0, [], 0, None
        def close():
            nonlocal z, entries
            if z is None: return
            z.writestr('volume-manifest.json', json.dumps({'label': label, 'entries': entries, 'tensor_bytes_unchanged': True}, indent=2))
            name = Path(z.filename)
            z.close()
            raw = name.read_bytes()
            assert len(raw) < 45 * (1 << 20), name
            index['volumes'].append({'filename': name.name, 'bytes': len(raw), 'sha256': sha(raw), 'label': label, 'entries': entries})
            z, entries = None, []
        for logical, path in files:
            raw = path.read_bytes()
            text = path.suffix in {'.json', '.jsonl', '.log', '.txt', '.yaml', '.yml', '.py', '.sh', '.md', '.toml'}
            selected = raw
            if text:
                value = raw.decode('utf-8', errors='replace')
                if path.suffix == '.json':
                    try: value = json.dumps(sanitize(json.loads(value)), indent=2)
                    except ValueError: value = sanitize_text(value)
                else: value = sanitize_text(value)
                selected = value.encode()
            total, digest = len(selected), sha(selected)
            for offset in range(0, max(total, 1), CHUNK):
                block = selected[offset:offset + CHUNK]
                if z is not None and budget + len(block) > LIMIT: close()
                if z is None:
                    parts += 1
                    z = zipfile.ZipFile(out / f'{label}-part{parts:03d}.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=3)
                    budget = 0
                archive_name = logical if total <= CHUNK else 'chunks/' + logical + f'.offset{offset:012d}.bin'
                z.writestr(archive_name, block)
                entry = {'logical_path': logical, 'archive_path': archive_name, 'offset': offset, 'chunk_bytes': len(block), 'chunk_sha256': sha(block), 'archived_file_bytes': total, 'archived_file_sha256': digest, 'source_bytes': len(raw), 'source_sha256': sha(raw), 'sanitized_text': text, 'tensor_bytes_unchanged': not text, 'chunked': total > CHUNK}
                entries.append(entry)
                budget += len(block)
        close()

    for receipt in sorted((root / 'runs').glob('compare-abi-retry-*/*-captures/native-completion.json')):
        case = receipt.parent
        if not (case / 'reference-execution.json').is_file(): continue
        attempt, name = case.parent.name, case.name
        completed = json.loads(receipt.read_text())
        framework = completed['framework']
        canonical = not ((framework == 'factory' and completed['model'] == 'pretrained' and completed['precision'] == 'fp32' and '095452Z' in attempt) or (framework == 'axolotl' and '101250Z' in attempt))
        label = ('canonical-' if canonical else 'historical-') + framework + '-' + completed['model'] + '-' + completed['precision']
        logical_prefix = 'cases/' + attempt + '/' + name + '/'
        files = [(logical_prefix + path.name, path) for path in sorted(case.iterdir()) if path.is_file() and path.suffix in {'.pt', '.json', '.yaml', '.yml', '.txt'}]
        log = case.with_name(name.removesuffix('-captures') + '.log')
        if log.is_file(): files.append((logical_prefix + 'native-full.log', log))
        metric_case = metrics / attempt / name
        assert (metric_case / 'capture-provenance.json').is_file(), 'Missing actual core metric case: ' + str(metric_case)
        files += [(logical_prefix + 'metrics/' + path.name, path) for path in sorted(metric_case.iterdir()) if path.is_file()]
        index['cases'].append({'framework': framework, 'model': completed['model'], 'precision': completed['precision'], 'source_attempt': attempt, 'canonical': canonical, 'label': label, 'logical_root': logical_prefix, 'native_completion_sha256': sha(receipt.read_bytes())})
        pack(label, files)
    metadata = []
    for top in ['scripts', 'state', 'runs', 'core-tools']:
        for path in sorted((root / top).rglob('*')):
            if path.is_file() and not path.is_symlink() and path.suffix in {'.py', '.sh', '.log', '.txt', '.json', '.jsonl', '.yaml', '.yml'}:
                relative = path.relative_to(root)
                if any(p in {'trained', '__pycache__', 'models', 'cache', 'environments', 'dataset-prepared', 'datasets'} for p in relative.parts): continue
                metadata.append(('metadata/' + relative.as_posix(), path))
    pack('metadata-failures-scripts-installs', metadata)
    index['canonical_case_count'] = sum(c['canonical'] for c in index['cases'])
    index['historical_completed_case_count'] = sum(not c['canonical'] for c in index['cases'])
    (out / 'archive-index.json').write_text(json.dumps(index, indent=2))
    print(json.dumps({'directory': str(out), 'index_sha256': sha((out / 'archive-index.json').read_bytes()), 'volumes': [{k: v[k] for k in ['filename', 'bytes', 'sha256', 'label']} for v in index['volumes']], 'canonical_case_count': index['canonical_case_count'], 'historical_completed_case_count': index['historical_completed_case_count']}, indent=2))


if __name__ == '__main__': main()
