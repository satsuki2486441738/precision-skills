"""Install the upstream unconditional QAT import's missing aarch64 dependency.

Axolotl excludes torchao from aarch64 package metadata, but imports QATCallback
unconditionally. No QAT or quantization is selected in this native recipe.
"""
import datetime as dt
import fcntl
import json
import os
from pathlib import Path
import subprocess
import uuid

root = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/sft')
out = root / 'runs' / ('compare-axolotl-qat-dependency-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:6])
out.mkdir()
env = dict(os.environ, PYTHONPATH='', PIP_CACHE_DIR=str(root / 'cache/pip'), TMPDIR=str(root / 'tmp'))
python = str(root / 'environments/axolotl/bin/python')
events = []
with (root / 'state/axolotl.install.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    for name, command in [('install', [python, '-m', 'pip', 'install', '--no-compile', '--retries', '1', '--timeout', '15', '--index-url', 'https://pypi.tuna.tsinghua.edu.cn/simple', 'torchao==0.17.0']), ('freeze', [python, '-m', 'pip', 'freeze', '--all']), ('check', [python, '-m', 'pip', 'check'])]:
        with (out / (name + '.log')).open('xb') as stream:
            code = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),)).returncode
        events.append({'stage': name, 'command': command, 'returncode': code})
        (out / 'events.json').write_text(json.dumps(events, indent=2))
        if code:
            raise RuntimeError('Dependency stage failed: ' + name)
print(json.dumps({'environment_repaired': True, 'native_completed': False, 'output': str(out)}))
