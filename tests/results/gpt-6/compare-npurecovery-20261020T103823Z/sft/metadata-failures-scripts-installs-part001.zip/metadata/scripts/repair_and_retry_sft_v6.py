"""Repair confirmed PyArrow/NumPy ABI mismatch, then retry native SFT unchanged.

Runs alongside the existing coordinator, whose TRL/Swift/Factory queues have
already finished with import errors. Per-device locks still serialize native
work; Axolotl remains owned by that coordinator. All retries use fresh outputs.
"""
import argparse
import datetime as dt
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import uuid

ROOT = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/sft')
HERE = ROOT / 'scripts'
DEVICES = {'trl': '4', 'swift': '5', 'factory': '6', 'axolotl': '7'}


def worker(selected):
    out = ROOT / 'runs' / ('compare-abi-retry-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:6])
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, PRECISION_SFT_ROOT=str(ROOT), PRECISION_PRETRAINED_MODEL='/host-model/Qwen3-0.6B', TMPDIR=str(ROOT / 'tmp'), PIP_CACHE_DIR=str(ROOT / 'cache/pip'), HF_HOME=str(ROOT / 'cache/huggingface'), OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false', PYTHONWARNINGS='ignore::SyntaxWarning')
    for variable, name in [('TORCH_EXTENSIONS_DIR', 'torch-extensions'), ('TORCHINDUCTOR_CACHE_DIR', 'inductor'), ('TRITON_CACHE_DIR', 'triton'), ('XDG_CACHE_HOME', 'xdg'), ('ASCEND_CACHE_PATH', 'ascend')]:
        cache = ROOT / 'cache' / name
        cache.mkdir(parents=True, exist_ok=True)
        env[variable] = str(cache)
    events = []
    for lane in sorted({f if f in ['factory','axolotl'] else 'swift-trl' for f in selected}):
        python = str(ROOT / 'environments' / lane / 'bin/python')
        with (ROOT / 'state' / (lane + '.install.lock')).open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            isolated = dict(env, PYTHONPATH='')
            commands = [('abi-repair', [python, '-m', 'pip', 'install', '--no-compile', '--retries', '1', '--timeout', '15', '--index-url', 'https://pypi.tuna.tsinghua.edu.cn/simple', 'pyarrow==21.0.0']), ('freeze', [python, '-m', 'pip', 'freeze', '--all']), ('check', [python, '-m', 'pip', 'check']), ('import-proof', [python, '-B', '-c', 'import numpy,pyarrow,datasets,json; print(json.dumps({"numpy":numpy.__version__,"pyarrow":pyarrow.__version__,"datasets":datasets.__version__}))'])]
            for stage, command in commands:
                with (out / (lane + '-' + stage + '.log')).open('xb') as stream:
                    code = subprocess.run(command, env=isolated, stdout=stream, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),)).returncode
                events.append({'lane': lane, 'stage': stage, 'returncode': code, 'command': command})
                (out / 'install-events.json').write_text(json.dumps(events, indent=2))
                if code:
                    raise RuntimeError('Repair failed: ' + lane + '/' + stage)
    def train(framework):
        python = str(ROOT / 'environments' / (framework if framework in ['factory','axolotl'] else 'swift-trl') / 'bin/python')
        for precision in ['bf16', 'fp32']:
            for model in ['tiny', 'pretrained']:
                if framework == 'factory' and (precision != 'fp32' or model != 'pretrained'):
                    continue
                key = framework + '-' + model + '-' + precision
                capture = out / (key + '-captures')
                adapter = HERE / ('axolotl_native_v3.py' if framework=='axolotl' else 'root_sft_native_v3.py')
                command = [python, str(HERE / 'native_single_process_v6.py'), str(adapter)] + ([] if framework=='axolotl' else ['--framework', framework]) + ['--model', model, '--precision', precision, '--output', str(capture)]
                with Path('/tmp/precision-native-device-' + DEVICES[framework] + '.lock').open('a') as lock:
                    fcntl.flock(lock, fcntl.LOCK_EX)
                    with (out / (key + '.log')).open('xb') as stream:
                        code = subprocess.run(command, env=dict(env, ASCEND_RT_VISIBLE_DEVICES=DEVICES[framework]), stdout=stream, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),)).returncode
                result = {'framework': framework, 'model': model, 'precision': precision, 'returncode': code, 'output': str(capture), 'log': str(out / (key + '.log')), 'native_completed': (capture / 'native-completion.json').is_file(), 'reference_completed': (capture / 'reference-execution.json').is_file()}
                (out / (key + '-status.json')).write_text(json.dumps(result, indent=2))
                print(json.dumps(result), flush=True)
    threads = [threading.Thread(target=train, args=(framework,)) for framework in selected]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    (out / 'controller-finished.json').write_text(json.dumps({'finished': True, 'meaning': 'Inspect each native/reference status; this is not a native success flag'}))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=['start', 'worker'])
    ap.add_argument('--frameworks', default='swift,factory,axolotl')
    args = ap.parse_args()
    selected = args.frameworks.split(',')
    assert set(selected) <= set(DEVICES)
    if args.mode == 'worker':
        worker(selected)
    else:
        log = ROOT / 'runs' / ('compare-abi-launch-' + uuid.uuid4().hex[:8] + '.log')
        with log.open('xb') as stream:
            process = subprocess.Popen([sys.executable, '-B', str(Path(__file__).resolve()), 'worker', '--frameworks', args.frameworks], stdout=stream, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
        print(json.dumps({'pid': process.pid, 'log': str(log), 'native_completed': False}))


if __name__ == '__main__':
    main()
