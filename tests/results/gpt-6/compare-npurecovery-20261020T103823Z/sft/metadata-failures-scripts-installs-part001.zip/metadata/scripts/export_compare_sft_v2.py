"""Export actual native/reference SFT captures and run the unchanged core tools.

Native .pt files are untouched. Safetensors retain their original native dtypes,
including BF16. Full-vocabulary FP64 logprobs are derived only for distribution
comparison. Each logical trainable tensor, absent gradient, and unchanged stored
update remains in the inventory. No numerical acceptance threshold is invented.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import torch
from safetensors.torch import save_file


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False, default=str))


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()


def export(case, out, tools):
    native = torch.load(case / 'native-captures.pt', map_location='cpu', weights_only=True)
    reference = torch.load(case / 'reference-captures.pt', map_location='cpu', weights_only=True)
    complete = json.loads((case / 'native-completion.json').read_text())
    reference_execution = json.loads((case / 'reference-execution.json').read_text())
    observations = json.loads((case / 'observations.json').read_text())
    assert complete['entrypoint_returned'] and observations['optimizer_steps'] == 1
    assert reference_execution['same_initial_trainable_state'] and reference_execution['same_initial_frozen_values']
    assert native['frozen_before'] == native['frozen_after']
    assert set(native['before']) == set(reference['before']) == set(native['gradients']) == set(reference['gradients'])
    assert all(torch.equal(native['before'][name].float(), reference['before'][name].float()) for name in native['before'])
    out.mkdir(parents=True, exist_ok=False)
    labels = native['batch']['labels']
    inputs = native['batch']['input_ids']
    mask = native['batch'].get('attention_mask', torch.ones_like(inputs)).bool()
    coordinates = []
    indices = []
    for batch in range(labels.shape[0]):
        for target in range(1, labels.shape[1]):
            if int(labels[batch, target]) == -100:
                continue
            prediction = target - 1
            history = inputs[batch, :target][mask[batch, :target]].tolist()
            assert history
            coordinates.append({'sample': 'batch-' + str(batch), 'position': len(history) - 1, 'history': history, 'target_token_id': int(labels[batch, target]), 'native_prediction_index': prediction})
            indices.append((batch, prediction))
    assert len(indices) == observations['valid_targets'] and indices
    arrays = {}
    for side, data in [('native', native), ('reference', reference)]:
        values = {}
        for kind in ['before', 'after', 'gradients']:
            for name, tensor in data[kind].items():
                if tensor is not None:
                    values[kind + '/' + name] = tensor.detach().contiguous().clone()
        values['logits'] = torch.stack([data['logits'][batch, position] for batch, position in indices]).contiguous()
        values['loss'] = data['loss'].detach().reshape(1).contiguous().clone()
        values['logprobs'] = values['logits'].double().log_softmax(-1).contiguous()
        save_file(values, str(out / (side + '.safetensors')))
        arrays[side] = values
    common = {'model': {'checkpoint': complete['model_path'], 'training': complete['training'], 'trainable_tensors': len(native['before'])}, 'inputs': {'accepted_reference_input_sha256': sha(case / 'reference-input-captures.pt'), 'valid_targets': len(indices), 'meaning': 'actual native prepared batch and captured effective objective denominator'}, 'scope': {'optimizer_steps': 1, 'rank': 0, 'world_size': 1}, 'state': {'starting_trainable_values': 'accepted native initial coordinates copied exactly to independent CPU', 'frozen_numeric_values': 'equal and unchanged hashes checked', 'frozen_tensors': len(native['frozen_before'])}}
    side_conditions = {'native': {'numerics': {'device': 'npu', 'requested_precision': complete['precision'], 'logits_dtype': str(native['logits'].dtype), 'stored_parameter_dtypes': sorted({str(t.dtype) for t in native['before'].values()}), 'all_model_parameter_dtypes': sorted({value['dtype'] for value in native['parameter_inventory'].values()}), 'implementation': complete['entrypoint']}}, 'reference': {'numerics': {'device': 'cpu', 'requested_precision': 'fp32', 'logits_dtype': str(reference['logits'].dtype), 'stored_parameter_dtypes': sorted({str(t.dtype) for t in reference['before'].values()}), 'all_model_parameter_dtypes': ['torch.float32'], 'implementation': 'independent CPU FP32 eager forward causal CE backward and SGD'}}}
    ranks = {'native': [0], 'reference': [0]}
    for side in ranks:
        dump(out / (side + '-environment.json'), {'rank': 0, 'versions': complete['versions'], 'actual': {**common, **side_conditions[side]}, 'native_dtype_preserved_in_safetensors': side == 'native', 'independent_reference_evidence': reference_execution if side == 'reference' else observations})
        dump(out / (side + '-status.json'), {'rank': 0, 'status': 'completed', 'evidence': str(case), 'native_entrypoint_returned': True, 'independent_reference_returned': True})
    commands = []
    def compare(kind, stage, tensors=None):
        spec = {'schema_version': 2, 'kind': kind, 'thresholds': None, 'common': common, 'side_conditions': side_conditions, 'expected_ranks': ranks}
        if kind == 'tensors':
            spec.update(stage=stage, tensors=tensors)
        else:
            spec.update(vocab_size=arrays['native']['logits'].shape[-1], normalization_tolerance=1e-10, renormalization='none', positions=[{k: row[k] for k in ['sample', 'position', 'history']} for row in coordinates])
        contract = out / (stage + '-contract.json')
        dump(contract, spec)
        paths = []
        for side in ranks:
            manifest = {'schema_version': 2, 'kind': kind, 'side': side, 'common': common, 'expected_ranks': [0], 'ranks': [{'rank': 0, 'environment': side + '-environment.json', 'status': side + '-status.json'}]}
            if kind == 'tensors':
                records = []
                for expected in tensors:
                    entry = dict(expected)
                    name = expected['name']
                    if stage == 'gradients':
                        present = (native if side == 'native' else reference)['gradients'][name] is not None
                        entry['present'] = present
                        entry['shards'] = [{'offset': 0, 'value': {'path': side + '.safetensors', 'key': 'gradients/' + name}}] if present else []
                    elif stage == 'updates':
                        entry['shards'] = [{'offset': 0, 'before': {'path': side + '.safetensors', 'key': 'before/' + name}, 'after': {'path': side + '.safetensors', 'key': 'after/' + name}}]
                    else:
                        entry['shards'] = [{'offset': 0, 'value': {'path': side + '.safetensors', 'key': name}}]
                    records.append(entry)
                manifest.update(stage=spec['stage'], tensors=records)
                if stage == 'updates':
                    manifest['events'] = {'policy': 'applied'}
            else:
                manifest['positions'] = [{**{key: row[key] for key in ['sample', 'position', 'history']}, 'scores': {'path': side + '.safetensors', 'key': 'logprobs', 'row': index}} for index, row in enumerate(coordinates)]
            path = out / (stage + '-' + side + '.json')
            dump(path, manifest)
            paths.append(path)
        script = tools / ('compare_tensors.py' if kind == 'tensors' else 'compare_distributions.py')
        command = [sys.executable, '-B', str(script), '--contract', str(contract), '--side-a', str(paths[0]), '--side-b', str(paths[1]), '--output', str(out / (stage + '-comparison.json'))]
        with (out / (stage + '-comparison.log')).open('xb') as log:
            code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
        commands.append({'command': command, 'returncode': code, 'core_script_sha256': sha(script)})
    compare('tensors', 'gradients', [{'name': name, 'shape': list(value.shape), 'present': native['gradients'][name] is not None or reference['gradients'][name] is not None} for name, value in native['before'].items()])
    compare('tensors', 'updates', [{'name': name, 'shape': list(value.shape), 'present': True} for name, value in native['before'].items()])
    # Both objective scalars and full logical selected logit rows are observations.
    compare('tensors', 'observations', [{'name': 'loss', 'shape': [1], 'present': True, 'coordinates': {'stage': 'objective', 'boundary': 'effective native trainer objective', 'invocation': 0}}, {'name': 'logits', 'shape': list(arrays['native']['logits'].shape), 'present': True, 'coordinates': {'stage': 'objective', 'boundary': 'preloss full-vocabulary logits', 'targets': coordinates, 'invocation': 0}}])
    compare('distributions', 'distributions')
    dump(out / 'capture-provenance.json', {'source_case': str(case), 'source_sha256': {name: sha(case / name) for name in ['native-captures.pt', 'reference-input-captures.pt', 'reference-captures.pt', 'native-completion.json', 'reference-execution.json', 'observations.json']}, 'native_parameter_inventory': native['parameter_inventory'], 'native_frozen_before': native['frozen_before'], 'native_frozen_after': native['frozen_after'], 'gradient_presence': {name: {'native': native['gradients'][name] is not None, 'reference': reference['gradients'][name] is not None} for name in native['before']}, 'native_loss_controls': {k: (v.tolist() if torch.is_tensor(v) else v) for k, v in native['compute_loss_controls'].items()}, 'native_raw_tensor_dtype_unchanged': True, 'native_logprob_derivation': 'FP64 full-vocabulary log_softmax of captured original-dtype native logits', 'reference_input_contains_native_gradients_or_updates': False, 'independent_reference': reference_execution, 'optimizer_steps': observations['optimizer_steps'], 'commands': commands, 'core_tool_sha256': {name: sha(tools / name) for name in ['compare_tensors.py', 'compare_distributions.py', 'artifact_io.py', 'conditions.py']}, 'thresholds': None})
    return {'case': str(case), 'output': str(out), 'commands': commands, 'numeric_pass_not_claimed': True}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--sft-root', required=True)
    ap.add_argument('--tools-root', required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--frameworks', default='')
    args = ap.parse_args()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    cases = [path.parent for path in sorted((Path(args.sft_root) / 'runs').glob('compare-abi-retry-*/*-captures/native-completion.json')) if (path.parent / 'reference-execution.json').is_file()]
    if args.frameworks:
        selected = set(args.frameworks.split(','))
        cases = [case for case in cases if json.loads((case / 'native-completion.json').read_text())['framework'] in selected]
    results = []
    for case in cases:
        result = export(case, out / case.parent.name / case.name, Path(args.tools_root))
        results.append(result)
        dump(out / 'metric-index.json', {'cases': results, 'thresholds': None, 'numeric_precision_pass_not_claimed': True})
        print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
