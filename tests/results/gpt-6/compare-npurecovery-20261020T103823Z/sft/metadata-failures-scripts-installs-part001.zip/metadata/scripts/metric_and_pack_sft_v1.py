"""Run unchanged actual core tools, then freeze the complete SFT evidence export."""
from pathlib import Path
import subprocess,sys,json
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/sft')
metrics=root/'metrics/compare-core-metrics-attempt03'
subprocess.run([sys.executable,'-B',str(root/'scripts/export_compare_sft_v2.py'),'--sft-root',str(root),'--tools-root',str(root/'core-tools'),'--output',str(metrics)],check=True)
subprocess.run([sys.executable,'-B',str(root/'scripts/pack_sft_evidence_v1.py'),'--sft-root',str(root),'--metrics-root',str(metrics),'--output',str(root/'exports/sft-evidence-volumes-attempt01')],check=True)
