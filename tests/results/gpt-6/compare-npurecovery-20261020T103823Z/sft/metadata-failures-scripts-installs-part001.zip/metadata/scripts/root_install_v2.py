"""Resumable, isolated pinned SFT environments on the task's persistent mount.

Run ``python root_install_v2.py swift-trl|factory|axolotl`` after CANN set_env.
Successful command stages are reused only for the identical profile/command.
Every invocation keeps fresh command logs, freeze, pip check and alignment JSON.
An interrupted command has no success marker and is retried in the same venv.
"""
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid
import venv


ROOT = Path(os.environ.get('PRECISION_SFT_ROOT', '/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/sft')).resolve()
PROFILES = {
    'swift-trl': {'torch': '2.9.0', 'npu': '2.9.0.post6', 'packages': ['transformers==5.3.0', 'accelerate==1.14.0', 'datasets==4.8.4', 'peft==0.20.0', 'trl==0.29.1', 'ms-swift==4.6.0', 'numpy==1.26.4']},
    'factory': {'torch': '2.9.0', 'npu': '2.9.0.post6', 'packages': ['torchvision==0.24.0', 'torchaudio==2.9.0', 'transformers==5.3.0', 'accelerate==1.11.0', 'datasets==4.0.0', 'peft==0.18.1', 'trl==0.24.0', 'llamafactory==0.9.5', 'numpy==1.26.4']},
    'axolotl': {'torch': '2.10.0', 'npu': '2.10.0.post4', 'packages': ['axolotl==0.17.0', 'numpy==2.2.6']},
}
INDEX = 'https://pypi.tuna.tsinghua.edu.cn/simple'


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write(path, value):
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temporary.write_text(json.dumps(value, indent=2))
    temporary.replace(path)


def main():
    lane = sys.argv[1]
    profile = PROFILES[lane]
    attempt = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
    out = ROOT / 'runs' / ('compare-install-' + lane + '-' + attempt)
    out.mkdir(parents=True, exist_ok=False)
    for part in ['cache/pip', 'tmp', 'state', 'environments']:
        (ROOT / part).mkdir(parents=True, exist_ok=True)
    os.environ.update(PIP_CACHE_DIR=str(ROOT / 'cache/pip'), TMPDIR=str(ROOT / 'tmp'), MAX_JOBS='4', OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', PIP_DISABLE_PIP_VERSION_CHECK='1', PIP_NO_COMPILE='1')
    lock = (ROOT / 'state' / (lane + '.install.lock')).open('a')
    fcntl.flock(lock, fcntl.LOCK_EX)
    envdir = ROOT / 'environments' / lane
    state = ROOT / 'state' / lane
    state.mkdir(exist_ok=True)
    # Python's venv creation is itself idempotent and does not remove packages.
    # Repeat only when the interpreter/pip bootstrap was interrupted.
    python = str(envdir / 'bin/python')
    if not (envdir / 'bin/python').is_file():
        venv.EnvBuilder(with_pip=True).create(envdir)
    if subprocess.run([python, '-m', 'pip', '--version'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
        subprocess.run([python, '-m', 'ensurepip', '--upgrade'], check=True)
    write(out / 'profile.json', {'profile': profile, 'root': str(ROOT), 'environment': str(envdir), 'system_site_packages': False})
    install = [python, '-m', 'pip', 'install', '--no-compile', '--retries', '1', '--timeout', '15']
    stages = [
        ('pip', install + ['--upgrade', 'pip', 'setuptools', 'wheel', '--index-url', INDEX]),
        ('torch', install + ['torch==' + profile['torch'], '--index-url', 'https://download.pytorch.org/whl/cpu', '--extra-index-url', INDEX]),
        ('npu', install + ['torch-npu==' + profile['npu'], '--index-url', INDEX]),
        # CPU index is intentionally limited to obtaining the CPU torch wheel.
        ('frameworks', install + ['--no-build-isolation'] + profile['packages'] + ['--index-url', INDEX]),
    ]
    failed = None
    events = []
    for stage, command in stages:
        if failed:
            continue
        key = hashlib.sha256(json.dumps({'profile': profile, 'command': command}, sort_keys=True).encode()).hexdigest()
        marker = state / (stage + '-success.json')
        cached = json.loads(marker.read_text()) if marker.is_file() else None
        if cached and cached.get('command_sha256') == key:
            event = {'stage': stage, 'utc': utc(), 'returncode': 0, 'reused_success': cached}
        else:
            with (out / (stage + '.log')).open('xb') as log:
                code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),)).returncode
            event = {'stage': stage, 'utc': utc(), 'returncode': code, 'command': command, 'command_sha256': key, 'log': str(out / (stage + '.log'))}
            if code == 0:
                write(marker, event)
            else:
                failed = stage
        events.append(event)
        with (out / 'journal.jsonl').open('a') as stream:
            stream.write(json.dumps(event) + '\n')
        write(out / 'live-status.json', {'lane': lane, 'stage': stage, 'failed_stage': failed, 'events': events, 'utc': utc()})
    for stage, command in [('freeze', [python, '-m', 'pip', 'freeze']), ('check', [python, '-m', 'pip', 'check'])]:
        with (out / (stage + '.log')).open('xb') as log:
            code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
        event = {'stage': stage, 'utc': utc(), 'returncode': code, 'command': command, 'log': str(out / (stage + '.log'))}
        events.append(event)
        with (out / 'journal.jsonl').open('a') as stream:
            stream.write(json.dumps(event) + '\n')
        if code and failed is None:
            failed = stage
    expected = {'torch': profile['torch'], 'torch-npu': profile['npu']}
    expected.update(dict(package.split('==') for package in profile['packages']))
    inspect = 'import importlib.metadata as m,json; expected=' + repr(expected) + '; actual={}; errors={};\nfor n,v in expected.items():\n try:\n  actual[n]=m.version(n)\n  if actual[n].split("+")[0]!=v: errors[n]={"expected":v,"actual":actual[n]}\n except m.PackageNotFoundError: errors[n]={"expected":v,"actual":None}\nprint(json.dumps({"expected":expected,"actual":actual,"errors":errors}));\nraise SystemExit(bool(errors))'
    with (out / 'alignment.json').open('xb') as stream:
        code = subprocess.run([python, '-c', inspect], stdout=stream, stderr=subprocess.STDOUT).returncode
    if code and failed is None:
        failed = 'alignment'
    result = {'lane': lane, 'environment': str(envdir), 'failed_stage': failed, 'ready': failed is None, 'native_completed': False, 'attempt': str(out), 'utc': utc(), 'events': events, 'alignment_returncode': code}
    write(out / 'status.json', result)
    write(state / 'latest-install.json', result)
    if failed is None:
        write(state / 'ready.json', result)
    elif (state / 'ready.json').exists():
        # Preserve any previous readiness evidence; never reuse it after a failure.
        (state / 'ready.json').rename(state / ('ready-before-failed-' + attempt + '.json'))
    print(json.dumps(result))
    raise SystemExit(bool(failed))


if __name__ == '__main__':
    main()
