"""Run independent CPU replay in a clean interpreter after native Swift exits.

Swift installs NPU RMSNorm model patches globally. Its native step is complete;
the CPU reference must not inherit those NPU-only global model replacements.
This process imports only the case reference module, Torch/Transformers/PEFT.
"""
import argparse
import json
from pathlib import Path
import sys

root = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/sft')
sys.path.insert(0, str(root / 'scripts'))
import root_sft_native_v4 as capture

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--case-root', required=True)
args = ap.parse_args()
for file in sorted(Path(args.case_root).glob('swift-*-captures/native-completion.json')):
    case = file.parent
    if (case / 'reference-execution.json').is_file():
        continue
    completed = json.loads(file.read_text())
    assert completed['entrypoint_returned'] and completed['framework'] == 'swift'
    capture.reference(case, completed['model_path'], completed['model'] == 'pretrained')
    receipt = json.loads((case / 'reference-execution.json').read_text())
    receipt['clean_interpreter_without_swift_native_model_monkeypatches'] = True
    receipt['native_step_was_not_reexecuted'] = True
    (case / 'reference-execution.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps({'case': str(case), 'independent_reference_complete': True}), flush=True)
