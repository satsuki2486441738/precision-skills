"""Actual Axolotl v0.17 CLI SFT, observed through its public callback plugin.

The complete do_cli -> native preprocessing/model/trainer/save path runs.
The plugin only attaches the existing passive native capture; it never creates
a replacement trainer, computes training loss or changes the optimizer.
"""
import argparse
import hashlib
import importlib.metadata as metadata
import inspect
import json
import os
from pathlib import Path
import sys

os.environ.setdefault('AXOLOTL_DO_NOT_TRACK', '1')
os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('HF_DATASETS_OFFLINE', '1')
os.environ.setdefault('WANDB_MODE', 'disabled')
os.environ.setdefault('ASCEND_RT_VISIBLE_DEVICES', '7')
import root_sft_native_v4 as capture
from axolotl.integrations.base import BasePlugin

CAPTURE = None


class PrecisionPlugin(BasePlugin):
    def add_callbacks_post_trainer(self, cfg, trainer):
        assert CAPTURE is not None, 'Task capture context is not initialized'
        assert not cfg.sample_packing and not cfg.rl
        assert not cfg.lora_mlp_kernel and not cfg.lora_qkv_kernel and not cfg.lora_o_kernel and not cfg.lora_embedding_kernel
        assert not cfg.liger_cross_entropy and not cfg.liger_fused_linear_cross_entropy
        assert trainer.args.gradient_accumulation_steps == 1 and trainer.args.world_size == 1
        assert trainer.args.max_grad_norm == 0.0 and trainer.args.label_smoothing_factor == 0.0
        CAPTURE.attach_trainer(trainer)
        return [CAPTURE]


def main():
    global CAPTURE
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--model', choices=['tiny', 'pretrained'], required=True)
    ap.add_argument('--precision', choices=['bf16', 'fp32'], default='bf16')
    ap.add_argument('--output', required=True)
    args = ap.parse_args()
    assert metadata.version('axolotl') == '0.17.0'
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    model = capture.ROOT / 'models/tiny-qwen2-seed20261020' if args.model == 'tiny' else capture.PRETRAINED
    assert (model / 'config.json').is_file(), 'Checkpoint must exist before native CLI execution'
    rows = [{'text': 'Name a color ' + color} for color in ['red', 'blue', 'green', 'yellow']]
    dataset = out / 'train.jsonl'
    dataset.write_text(''.join(json.dumps(row) + '\n' for row in rows))
    config = {
      'base_model': str(model), 'model_type': 'AutoModelForCausalLM', 'tokenizer_type': 'AutoTokenizer',
      'datasets': [{'path': str(dataset), 'type': 'completion', 'field': 'text'}],
      'dataset_prepared_path': str(out / 'prepared-data'), 'dataset_num_proc': 1, 'val_set_size': 0,
      'output_dir': str(out / 'trained'), 'sequence_len': 128, 'sample_packing': False, 'pad_to_sequence_len': False,
      'micro_batch_size': 1, 'gradient_accumulation_steps': 1, 'max_steps': 1, 'num_epochs': 1,
      'optimizer': 'sgd', 'learning_rate': 0.001, 'weight_decay': 0.0, 'max_grad_norm': 0.0,
      'lr_scheduler': 'constant', 'warmup_steps': 0, 'gradient_checkpointing': False,
      'bf16': args.precision == 'bf16', 'fp16': False, 'tf32': False,
      'attn_implementation': 'eager', 'torch_compile': False, 'load_in_4bit': False, 'load_in_8bit': False,
      'lora_mlp_kernel': False, 'lora_qkv_kernel': False, 'lora_o_kernel': False, 'lora_embedding_kernel': False,
      'liger_cross_entropy': False, 'liger_fused_linear_cross_entropy': False,
      'lora_dropout': 0.0, 'train_on_inputs': True, 'label_smoothing_factor': 0.0,
      'dataloader_num_workers': 0, 'dataloader_pin_memory': False,
      'save_strategy': 'no', 'eval_strategy': 'no', 'logging_steps': 1, 'seed': 20261020,
      'use_wandb': False, 'use_tensorboard': False, 'use_trackio': False, 'include_tkps': False,
      'plugins': ['axolotl_native_v2.PrecisionPlugin'],
    }
    if args.model == 'pretrained':
        config.update(adapter='lora', lora_r=4, lora_alpha=8, lora_target_modules=['q_proj', 'v_proj'])
    native_config = out / 'native-config.yaml'
    native_config.write_text(json.dumps(config, indent=2))  # JSON is valid YAML.
    CAPTURE = capture.Capture(out, 'axolotl')
    # Public plugin loader imports this exact task module. Preserve the one
    # capture instance rather than importing a second independent __main__.
    sys.modules['axolotl_native_v2'] = sys.modules[__name__]
    import axolotl.cli.config as native_configuration
    original_fp8_probe = native_configuration.compute_supports_fp8
    def actual_fp8_capability():
        try:
            return original_fp8_probe()
        except AssertionError:
            if not capture.torch.cuda.is_available():
                return False
            raise
    native_configuration.compute_supports_fp8 = actual_fp8_capability
    capture.dump(out / 'platform-capability-guard.json', {'reason': 'Upstream CUDA capability discovery catches RuntimeError but CPU-distribution torch raises AssertionError; no CUDA means no CUDA FP8', 'native_function': 'axolotl.cli.config.compute_supports_fp8', 'original_source': inspect.getsource(original_fp8_probe), 'original_file_sha256': hashlib.sha256(Path(inspect.getsourcefile(original_fp8_probe)).read_bytes()).hexdigest(), 'guard_only': True, 'native_model_loss_optimizer_unmodified': True})
    from axolotl.cli.train import do_cli
    native_file = Path(inspect.getsourcefile(do_cli)).resolve()
    capture.dump(out / 'native-entrypoint-provenance.json', {'entrypoint': 'axolotl.cli.train.do_cli', 'source': str(native_file), 'source_sha256': hashlib.sha256(native_file.read_bytes()).hexdigest(), 'official_source': 'https://github.com/axolotl-ai-cloud/axolotl/blob/v0.17.0/src/axolotl/cli/train.py', 'capture_plugin': 'axolotl_native_v2.PrecisionPlugin.add_callbacks_post_trainer', 'native_arithmetic_replaced': False})
    capture.set_seed(20261020)
    sys.argv = [str(native_file)]
    do_cli(str(native_config))
    assert (out / 'observations.json').is_file(), 'No actual optimizer step observed'
    versions = {name: metadata.version(name) for name in ['axolotl', 'torch', 'torch-npu', 'transformers', 'accelerate', 'peft', 'trl', 'datasets']}
    capture.dump(out / 'native-completion.json', {'status': 'native_execution_complete', 'framework': 'axolotl', 'entrypoint': 'axolotl.cli.train.do_cli complete native SFT workflow', 'entrypoint_returned': True, 'model': args.model, 'precision': args.precision, 'device': str(next(CAPTURE.model.parameters()).device), 'versions': versions, 'model_path': str(model), 'initialization': 'seeded_random' if args.model == 'tiny' else 'pretrained', 'training': 'full' if args.model == 'tiny' else 'LoRA_q_v_r4', 'rank': 0, 'world_size': 1, 'captures': 'native-captures.pt', 'thresholds': None})
    capture.reference(out, str(model), args.model == 'pretrained')
    print(json.dumps({'native_complete': True, 'reference_complete': True, 'output': str(out)}))


if __name__ == '__main__':
    main()
