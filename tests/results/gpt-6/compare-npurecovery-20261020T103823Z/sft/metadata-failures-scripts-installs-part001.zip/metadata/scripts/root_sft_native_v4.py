"""Native TRL, Swift and LLaMAFactory SFT with passive state/tensor capture.

Use --prepare once, then --framework trl|swift|factory --model tiny|pretrained
--precision fp32|bf16 --output FRESH. A successful import is never completion.
The reference independently reloads the checkpoint and initial trainable state;
it never reads native gradients or post-update state to perform its execution.
"""
import argparse
import datetime as dt
import hashlib
import importlib.metadata as metadata
import functools
import inspect
import json
import os
from pathlib import Path
import sys

ROOT=Path(os.environ.get('PRECISION_SFT_ROOT','/home/<user>/material/precision-gpt6-npu-20261020/root'))
PRETRAINED=Path(os.environ.get('PRECISION_PRETRAINED_MODEL','/host-model/Qwen3-0.6B'))
os.environ.setdefault('ASCEND_RT_VISIBLE_DEVICES','0,1,2,3')
os.environ.setdefault('OMP_NUM_THREADS','4')
os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('HF_DATASETS_OFFLINE','1')
os.environ.setdefault('WANDB_MODE','disabled')
os.environ.setdefault('HF_HOME',str(ROOT/'cache/huggingface'))
os.environ.setdefault('TMPDIR',str(ROOT/'tmp'))
Path(os.environ['TMPDIR']).mkdir(parents=True,exist_ok=True)
Path(os.environ['HF_HOME']).mkdir(parents=True,exist_ok=True)

import torch
import torch_npu
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainerCallback, set_seed


def dump(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False,default=str))


def cpu(value):
    if torch.is_tensor(value):return value.detach().cpu().clone()
    if isinstance(value,dict):return {k:cpu(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return type(value)(cpu(v) for v in value)
    return value


def parameters(model):
    return {n:p for n,p in model.named_parameters() if p.requires_grad}


def frozen_fingerprints(model):
    # Normalize only the identity hash view to FP32. Captured native tensors
    # themselves retain their dtype; BF16 and FP32 values must agree exactly.
    return {n:{'shape':list(p.shape),'fp32_value_sha256':hashlib.sha256(p.detach().cpu().float().contiguous().numpy().tobytes()).hexdigest()}
            for n,p in model.named_parameters() if not p.requires_grad}


def logical_inventory(model):
    aliases={};result={}
    for name,p in model.named_parameters(remove_duplicate=False):
        canonical=aliases.setdefault(id(p),name)
        result[name]={'canonical':canonical,'shape':list(p.shape),'dtype':str(p.dtype),'device':str(p.device),'trainable':p.requires_grad}
    return result


def prepare():
    from tokenizers import Tokenizer
    from tokenizers.models import WordLevel
    from tokenizers.pre_tokenizers import WhitespaceSplit
    from transformers import PreTrainedTokenizerFast, Qwen2Config, Qwen2ForCausalLM
    path=ROOT/'models/tiny-qwen2-seed20261020'
    if path.exists():
        assert (path/'fixture-identity.json').is_file(),'Incomplete fixture; preserve and select a new fixture path'
        print(json.dumps({'fixture_already_present':str(path)}));return
    path.mkdir(parents=True)
    set_seed(20261020)
    words=['<|endoftext|>','<unk>','<|im_start|>','<|im_end|>','user','assistant','system','red','blue','green','yellow','Name','a','color','Answer','with','one','word','What','is','two','plus','three','five','Hello','Say','yes','no']
    words += ['token'+str(i) for i in range(256-len(words))]
    raw=Tokenizer(WordLevel(vocab={w:i for i,w in enumerate(words)},unk_token='<unk>'))
    raw.pre_tokenizer=WhitespaceSplit()
    tok=PreTrainedTokenizerFast(tokenizer_object=raw,pad_token=words[0],unk_token=words[1],bos_token=words[2],eos_token=words[3],additional_special_tokens=words[2:4],model_max_length=256)
    tok.chat_template="{% for message in messages %}{{ '<|im_start|>' + message['role'] + '\\n' + message['content'] + '<|im_end|>\\n' }}{% endfor %}{% if add_generation_prompt %}{{ '<|im_start|>assistant\\n' }}{% endif %}"
    tok.save_pretrained(path)
    cfg=Qwen2Config(vocab_size=256,hidden_size=128,intermediate_size=256,num_hidden_layers=2,num_attention_heads=2,num_key_value_heads=2,max_position_embeddings=256,attention_dropout=0.0,tie_word_embeddings=False,bos_token_id=2,eos_token_id=3,pad_token_id=0)
    model=Qwen2ForCausalLM(cfg)
    model.save_pretrained(path,safe_serialization=True)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in path.iterdir() if p.is_file()}
    dump(path/'fixture-identity.json',{'initialization':'seeded_random_not_pretrained','seed':20261020,'files_sha256':hashes,'config':cfg.to_dict()})
    print(json.dumps({'prepared':str(path),'files_sha256':hashes}))


class Capture(TrainerCallback):
    def __init__(self,out,framework):
        self.out=out;self.framework=framework;self.payload={};self.events=[];self.steps=0;self.handles=[];self.trainer=None

    def attach_trainer(self,trainer):
        assert self.trainer is None or self.trainer is trainer
        if self.trainer is trainer:return
        self.trainer=trainer
        original=trainer.compute_loss;signature=inspect.signature(original)
        try:source_sha=hashlib.sha256(inspect.getsource(original).encode('utf-8')).hexdigest()
        except (OSError,TypeError):source_sha=None
        self.payload['native_trainer_identity']={'class':type(trainer).__module__+'.'+type(trainer).__qualname__,'compute_loss':original.__module__+'.'+original.__qualname__,'source':inspect.getsourcefile(original),'compute_loss_source_sha256':source_sha,'original_signature':str(signature)}
        @functools.wraps(original)
        def observed_compute_loss(*args,**kwargs):
            bound=signature.bind_partial(*args,**kwargs).arguments
            # LLaMAFactory's override exposes controls through **kwargs.
            for name,param in signature.parameters.items():
                if param.kind==inspect.Parameter.VAR_KEYWORD:bound.update(bound.get(name,{}))
            model=bound['model'];inputs=bound['inputs']
            observing=model.training and 'compute_loss_controls' not in self.payload
            if observing:
                self.payload['batch']={k:cpu(v) for k,v in inputs.items() if torch.is_tensor(v)}
                self.payload['compute_loss_controls']={'num_items_in_batch':cpu(bound.get('num_items_in_batch')),'return_outputs':bound.get('return_outputs',False),'has_custom_loss':inputs.get('compute_loss_func') is not None or getattr(trainer,'compute_loss_func',None) is not None,'label_smoothing_factor':float(getattr(trainer.args,'label_smoothing_factor',0.)),'enable_dft_loss':bool(getattr(trainer.args,'enable_dft_loss',False)),'enable_channel_loss':bool(getattr(trainer.args,'enable_channel_loss',False)),'num_processes':int(trainer.accelerator.num_processes),'framework':self.framework}
            result=original(*args,**kwargs)
            if observing:
                loss=result[0] if isinstance(result,tuple) else result
                assert torch.is_tensor(loss) and loss.numel()==1
                self.payload['loss']=cpu(loss)
            return result
        trainer.compute_loss=observed_compute_loss

    def on_train_begin(self,args,state,control,model=None,**kwargs):
        assert all(p.device.type=='npu' for p in parameters(model).values()),'Native model not on NPU'
        assert self.trainer is not None,'Native trainer must be attached before training begins'
        assert args.world_size==1 and args.gradient_accumulation_steps==1
        self.model=model
        self.payload['before']={n:cpu(p) for n,p in parameters(model).items()}
        self.payload['parameter_inventory']=logical_inventory(model)
        self.payload['native_model_config']=json.loads(model.config.to_json_string())
        self.payload['frozen_before']=frozen_fingerprints(model)
        self.payload['peft_configuration']=json.loads(json.dumps({k:v.to_dict() for k,v in getattr(model,'peft_config',{}).items()},default=lambda v:sorted(v) if isinstance(v,set) else getattr(v,'value',str(v))))
        self.settings=args.to_dict()
        def before(module,pos,kw):
            if 'model_forward_arguments' not in self.payload and module.training and 'batch' in self.payload:
                assert not pos,'Selected native model call unexpectedly uses positional arguments'
                assert kw.get('past_key_values') is None,'Selected SFT reference requires no pre-existing KV state'
                self.payload['model_forward_arguments']={k:cpu(v) for k,v in kw.items() if torch.is_tensor(v) or isinstance(v,(int,float,bool,str,type(None)))}
        def after(module,pos,kw,output):
            if 'logits' not in self.payload and module.training and 'batch' in self.payload and getattr(output,'logits',None) is not None:
                self.payload['logits']=cpu(output.logits)
                self.payload['model_forward_loss']=cpu(output.loss)
        self.handles=[model.register_forward_pre_hook(before,with_kwargs=True),model.register_forward_hook(after,with_kwargs=True)]

    def on_pre_optimizer_step(self,args,state,control,model=None,optimizer=None,**kwargs):
        self.payload['gradients']={n:cpu(p.grad) for n,p in parameters(model).items()}
        self.payload['optimizer_before']=cpu(optimizer.state_dict())
        inner=optimizer
        while hasattr(inner,'optimizer'):inner=inner.optimizer
        assert isinstance(inner,torch.optim.SGD),'Reference is configured for actual native SGD only'
        assert all(float(g.get('momentum',0.))==0. and float(g.get('weight_decay',0.))==0. and not g.get('nesterov',False) and not g.get('maximize',False) and float(g['lr'])==0.001 for g in inner.param_groups)
        self.optimizer_class=type(inner).__module__+'.'+type(inner).__qualname__

    def on_optimizer_step(self,args,state,control,model=None,optimizer=None,**kwargs):
        self.steps+=1
        self.payload['after']={n:cpu(p) for n,p in parameters(model).items()}
        self.payload['optimizer_after']=cpu(optimizer.state_dict())

    def on_log(self,args,state,control,logs=None,**kwargs):
        self.events.append({'step':state.global_step,'logs':logs})

    def on_train_end(self,args,state,control,**kwargs):
        for handle in self.handles:handle.remove()
        assert state.global_step==1 and self.steps==1,(state.global_step,self.steps)
        assert {'before','batch','logits','loss','gradients','after'}.issubset(self.payload),self.payload.keys()
        labels=self.payload['batch']['labels'][:,1:]
        valid=labels.ne(-100)
        assert int(valid.sum())>0,'No active training targets'
        updates={n:self.payload['after'][n].float()-p.float() for n,p in self.payload['before'].items()}
        gradients=[g for g in self.payload['gradients'].values() if g is not None]
        changed=sum(int(torch.count_nonzero(x)) for x in updates.values())
        assert changed>0,'Optimizer did not change stored parameters'
        assert gradients and all(torch.isfinite(g).all() for g in gradients)
        assert torch.isfinite(self.payload['loss']) and torch.isfinite(self.payload['logits']).all()
        self.payload['frozen_after']=frozen_fingerprints(self.model)
        assert self.payload['frozen_before']==self.payload['frozen_after'],'A frozen base parameter changed during the native step'
        torch.save(self.payload,self.out/'native-captures.pt')
        # The reference does not even deserialize native outcomes. Its file
        # contains only common starting state, native inputs and loss controls.
        torch.save({k:self.payload[k] for k in ['before','batch','model_forward_arguments','compute_loss_controls','frozen_before','peft_configuration','native_model_config']},self.out/'reference-input-captures.pt')
        dump(self.out/'observations.json',{'optimizer_steps':self.steps,'training_steps':state.global_step,'optimizer':self.optimizer_class,'native_loss':float(self.payload['loss']),'valid_targets':int(valid.sum()),'changed_elements':changed,'gradient_l2':sum(float(g.double().square().sum()) for g in gradients)**0.5,'stored_update_l2':sum(float(d.double().square().sum()) for d in updates.values())**0.5,'logits_dtype':str(self.payload['logits'].dtype),'parameter_dtypes':sorted(set(str(p.dtype) for p in self.payload['before'].values())),'events':self.events,'effective_training_arguments':self.settings,'frozen_base_unchanged':True,'frozen_base_tensors':len(self.payload['frozen_before']),'gradient_boundary':'native Trainer on_pre_optimizer_step; max_grad_norm=0','objective_boundary':'Original selected native trainer.compute_loss return; model forward loss retained separately','update_boundary':'native Trainer on_optimizer_step before zero_grad','rank':0,'world_size':1,'status':'observed_native_step_pending_entrypoint_return'})


def reference(out,model_path,lora):
    from peft import LoraConfig,get_peft_model
    data=torch.load(out/'reference-input-captures.pt',map_location='cpu',weights_only=True)
    set_seed(20261020)
    model=AutoModelForCausalLM.from_pretrained(model_path,torch_dtype=torch.float32,attn_implementation='eager',local_files_only=True,device_map={'':'cpu'})
    if lora:
        assert set(data['peft_configuration'])=={'default'},'Selected reference requires one unmerged default LoRA adapter'
        native_adapter=data['peft_configuration']['default']
        for key,expected in {'r':4,'lora_alpha':8,'lora_dropout':0.0,'bias':'none','use_rslora':False,'use_dora':False,'modules_to_save':None}.items():
            actual = native_adapter.get(key)
            assert (actual is None or actual == []) if key=='modules_to_save' else actual==expected,(key,actual,expected)
        assert sorted(native_adapter['target_modules'])==['q_proj','v_proj']
        model=get_peft_model(model,LoraConfig(r=4,lora_alpha=8,lora_dropout=0.0,target_modules=['q_proj','v_proj'],task_type='CAUSAL_LM'))
    named=parameters(model)
    assert set(named)==set(data['before']), 'Reference trainable names differ'
    with torch.no_grad():
        for name,p in named.items():p.copy_(data['before'][name])
    assert all(torch.equal(p.detach(),data['before'][name].float()) for name,p in named.items())
    assert all(p.device.type=='cpu' and p.dtype==torch.float32 for p in model.parameters())
    assert frozen_fingerprints(model)==data['frozen_before'],'Reference frozen base differs from the actual native initial base'
    model.train();optimizer=torch.optim.SGD(named.values(),lr=0.001,weight_decay=0.0)
    controls=data['compute_loss_controls'];forward=data['model_forward_arguments'];batch=data['batch']
    assert controls['num_processes']==1 and not any(controls[k] for k in ['has_custom_loss','label_smoothing_factor','enable_dft_loss','enable_channel_loss'])
    inputs={k:v for k,v in forward.items() if k in ['input_ids','attention_mask','position_ids','cache_position','logits_to_keep']}
    assert not inputs.get('logits_to_keep',0),'Selected reference requires full sequence logits (Swift public use_logits_to_keep=false)'
    use_cache=forward.get('use_cache',data['native_model_config'].get('use_cache',True))
    output=model(**inputs,use_cache=use_cache)
    labels=batch['labels'];logits=output.logits.float();weights=batch.get('loss_scale')
    assert logits.shape[:-1]==labels.shape,'Native selected row coordinates do not match reference full sequence'
    if controls['framework']=='swift' and weights is not None:
        shifted=torch.roll(labels,shifts=-1,dims=-1)
        terms=torch.nn.functional.cross_entropy(logits.reshape(-1,logits.shape[-1]),shifted.reshape(-1),ignore_index=-100,reduction='none').reshape_as(labels)
        terms=terms*torch.roll(weights,shifts=-1,dims=-1)
        denominator=controls['num_items_in_batch']
        if denominator is None:denominator=labels.ne(-100).sum()
        loss=terms.sum()/denominator
        reduction='native Swift weighted per-token CE / original effective denominator'
    else:
        shifted=torch.nn.functional.pad(labels,(0,1),value=-100)[...,1:].contiguous()
        terms=torch.nn.functional.cross_entropy(logits.reshape(-1,logits.shape[-1]),shifted.reshape(-1),ignore_index=-100,reduction='none').reshape_as(labels)
        denominator=forward.get('num_items_in_batch')
        if denominator is None:denominator=shifted.ne(-100).sum()
        loss=terms.sum()/denominator
        reduction='native causal CE sum / original model denominator (or shifted-valid-token mean)'
        if controls['framework']=='swift' and controls['num_items_in_batch'] is not None:
            loss=loss*(shifted.ne(-100).sum()/controls['num_items_in_batch'])
            reduction+='; native Swift template valid-target/num_items multiplier'
    assert float(denominator)>0 and torch.isfinite(loss),'Invalid original native loss denominator'
    loss.backward()
    result={'logits':cpu(output.logits),'loss':cpu(loss),'native_denominator_replayed':cpu(denominator),'per_target_loss_terms':cpu(terms),'gradients':{n:cpu(p.grad) for n,p in named.items()},'before':{n:cpu(p) for n,p in named.items()}}
    optimizer.step();result['after']={n:cpu(p) for n,p in named.items()}
    torch.save(result,out/'reference-captures.pt')
    assert frozen_fingerprints(model)==data['frozen_before'],'Reference frozen base changed'
    dump(out/'reference-execution.json',{'device':'cpu','compute':'fp32','loss':float(loss),'same_initial_trainable_state':True,'same_initial_frozen_values':True,'frozen_base_unchanged':True,'uses_native_gradients_or_updates':False,'reference_optimizer':'torch.optim.SGD','objective_reduction':reduction,'thresholds':None})


def run(args):
    from peft import LoraConfig
    from datasets import Dataset
    out=Path(args.output)
    out.mkdir(parents=True,exist_ok=False)
    model_path=str(ROOT/'models/tiny-qwen2-seed20261020') if args.model=='tiny' else str(PRETRAINED)
    lora=args.model=='pretrained';bf16=args.precision=='bf16'
    rows=[{'messages':[{'role':'user','content':'Name a color'},{'role':'assistant','content':c}]} for c in ['red','blue','green','yellow']]
    (out/'train.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    (out/'train.json').write_text(json.dumps(rows))
    cb=Capture(out,args.framework)
    set_seed(20261020)
    common={'output_dir':str(out/'trained'),'max_steps':1,'learning_rate':0.001,'weight_decay':0.0,'max_grad_norm':0.0,'gradient_accumulation_steps':1,'per_device_train_batch_size':1,'optim':'sgd','lr_scheduler_type':'constant','warmup_steps':0,'bf16':bf16,'fp16':False,'gradient_checkpointing':False,'save_strategy':'no','eval_strategy':'no','report_to':'none','logging_steps':1,'seed':20261020,'dataloader_num_workers':0,'dataloader_pin_memory':False,'label_smoothing_factor':0.0}
    if args.framework=='trl':
        from trl import SFTConfig,SFTTrainer
        model=AutoModelForCausalLM.from_pretrained(model_path,torch_dtype=torch.float32,attn_implementation='eager',local_files_only=True)
        tok=AutoTokenizer.from_pretrained(model_path,local_files_only=True)
        config=SFTConfig(**common,max_length=128,packing=False,padding_free=False)
        trainer=SFTTrainer(model=model,args=config,train_dataset=Dataset.from_list(rows),processing_class=tok,callbacks=[cb],peft_config=LoraConfig(r=4,lora_alpha=8,lora_dropout=0.0,target_modules=['q_proj','v_proj'],task_type='CAUSAL_LM') if lora else None)
        cb.attach_trainer(trainer)
        trainer.train()
        entrypoint='trl.SFTTrainer.train with native dataset preparation'
    elif args.framework=='factory':
        from llamafactory.train.tuner import run_exp
        from llamafactory.train.sft.trainer import CustomSeq2SeqTrainer
        dump(out/'dataset_info.json',{'native_fixture':{'file_name':'train.json','formatting':'sharegpt','columns':{'messages':'messages'},'tags':{'role_tag':'role','content_tag':'content','user_tag':'user','assistant_tag':'assistant'}}})
        config=dict(common,stage='sft',do_train=True,model_name_or_path=model_path,template='qwen3' if lora else 'qwen',dataset_dir=str(out),dataset='native_fixture',cutoff_len=128,preprocessing_num_workers=1,finetuning_type='lora' if lora else 'full',flash_attn='disabled',overwrite_cache=True)
        if lora:config.update(lora_rank=4,lora_alpha=8,lora_dropout=0.0,lora_target='q_proj,v_proj')
        dump(out/'native-config.json',config)
        original_init=CustomSeq2SeqTrainer.__init__
        @functools.wraps(original_init)
        def observed_init(trainer,*pos,**kw):
            original_init(trainer,*pos,**kw);cb.attach_trainer(trainer)
        CustomSeq2SeqTrainer.__init__=observed_init
        try:run_exp(args=config,callbacks=[cb])
        finally:CustomSeq2SeqTrainer.__init__=original_init
        entrypoint='llamafactory.train.tuner.run_exp complete native SFT workflow'
    else:
        from swift.callbacks import callbacks_map
        from swift.pipelines.train.sft import sft_main
        def callback_factory(training_args,trainer):cb.attach_trainer(trainer);return cb
        callbacks_map['precision_native']=callback_factory
        cli=['--model',model_path,'--model_type','qwen3' if lora else 'qwen2','--tuner_type','lora' if lora else 'full','--dataset',str(out/'train.jsonl'),'--max_length','128','--torch_dtype','float32','--attn_impl','eager','--callbacks','precision_native','--add_version','false','--use_hf','true','--use_logits_to_keep','false','--template','qwen3' if lora else 'qwen','--dataset_num_proc','1']
        for key,value in common.items():cli+=['--'+key,str(value).lower() if isinstance(value,bool) else str(value)]
        if lora:cli+=['--lora_rank','4','--lora_alpha','8','--lora_dropout','0','--target_modules','q_proj','v_proj']
        dump(out/'native-arguments.json',cli)
        sft_main(cli)
        entrypoint='swift.pipelines.train.sft.sft_main complete native SFT workflow'
    assert (out/'observations.json').is_file(),'No actual native step was observed'
    versions={}
    for name in ['torch','torch-npu','transformers','accelerate','trl','ms-swift','llamafactory','peft','datasets']:
        try:versions[name]=metadata.version(name)
        except metadata.PackageNotFoundError:pass
    dump(out/'native-completion.json',{'status':'native_execution_complete','entrypoint_returned':True,'entrypoint':entrypoint,'framework':args.framework,'model':args.model,'precision':args.precision,'device':str(next(cb.model.parameters()).device),'torch_path':torch.__file__,'torch_npu_path':torch_npu.__file__,'versions':versions,'model_path':model_path,'initialization':'seeded_random' if args.model=='tiny' else 'pretrained','training':'full' if not lora else 'LoRA_q_v_r4','rank':0,'world_size':1,'thresholds':None,'captures':'native-captures.pt'})
    reference(out,model_path,lora)
    print(json.dumps({'native_complete':True,'reference_complete':True,'output':str(out)}))


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--prepare',action='store_true')
    ap.add_argument('--framework',choices=['trl','swift','factory'])
    ap.add_argument('--model',choices=['tiny','pretrained'],default='tiny')
    ap.add_argument('--precision',choices=['fp32','bf16'],default='bf16')
    ap.add_argument('--output')
    args=ap.parse_args()
    if args.prepare:prepare()
    else:
        assert args.framework and args.output
        run(args)
