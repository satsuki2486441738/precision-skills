"""Task-private detached installer/native scheduler; no remote connection logic.

``python native_pipeline_v2.py start`` launches an independent controller.
``... status`` reads bounded job/result metadata. Repeated starts take a task
lock and reuse successful installs/jobs, never overwrite old attempt outputs.
The original native adapter and arithmetic are unmodified. Device scope 4-7.
"""
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time
import uuid

ROOT = Path(os.environ.get('PRECISION_SFT_ROOT', '/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/sft')).resolve()
HERE = Path(__file__).resolve().parent
DEVICES = {'trl': '4', 'swift': '5', 'factory': '6', 'axolotl': '7'}


def environment_lane(framework):
    return framework if framework in ['factory', 'axolotl'] else 'swift-trl'


def write(path, value):
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temporary.write_text(json.dumps(value, indent=2))
    temporary.replace(path)


def timestamp():
    return dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]


def child(command, log, env, held_lock=None):
    # All Python imports run after the vendor's environment initialization.
    script = 'source /usr/local/Ascend/cann/set_env.sh && exec ' + shlex.join(command)
    with log.open('xb') as stream:
        return subprocess.Popen(['/bin/bash', '-c', script], stdout=stream, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True, env=env, pass_fds=(() if held_lock is None else (held_lock.fileno(),)))


def execute(args):
    for part in ['state', 'runs', 'cache/huggingface', 'tmp']:
        (ROOT / part).mkdir(parents=True, exist_ok=True)
    lock = (ROOT / 'state/pipeline.lock').open('a')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print(json.dumps({'already_running': True})); return
    out = ROOT / 'runs' / ('compare-pipeline-' + timestamp())
    out.mkdir()
    env = dict(os.environ, PRECISION_SFT_ROOT=str(ROOT), PRECISION_PRETRAINED_MODEL=args.model, OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2', MAX_JOBS='4', TOKENIZERS_PARALLELISM='false', HF_HOME=str(ROOT / 'cache/huggingface'), TMPDIR=str(ROOT / 'tmp'))
    jobs = {}
    installers = {}
    for lane in ['swift-trl', 'factory', 'axolotl']:
        installers[lane] = child([sys.executable, str(HERE / 'root_install_v2.py'), lane], out / ('install-' + lane + '.log'), env)
        jobs['install-' + lane] = {'pid': installers[lane].pid, 'log': str(out / ('install-' + lane + '.log')), 'stage': 'installing', 'native_completed': False}
    # One prepare process avoids concurrent partial creation of the shared fixture.
    prepared = (ROOT / 'models/tiny-qwen2-seed20261020/fixture-identity.json').is_file()
    prepare_job = None
    active = {}
    queues = {framework: [(precision, model) for precision in args.precisions.split(',') for model in ['tiny', 'pretrained']] for framework in DEVICES}
    failures = []
    while True:
        for lane, process in installers.items():
            code = process.poll()
            jobs['install-' + lane]['returncode'] = code
            jobs['install-' + lane]['stage'] = 'installing' if code is None else ('ready' if code == 0 else 'installation_failed')
        if not prepared and prepare_job is None:
            # Prefer swift/TRL, but the factory environment can create the same
            # seed fixture if its install finishes first. All use TF 5.3.0.
            ready_lane = next((lane for lane in ['swift-trl', 'factory'] if installers[lane].poll() == 0), None)
            if ready_lane:
                prepare_env = dict(env, ASCEND_RT_VISIBLE_DEVICES='7')
                prepare_job = child([str(ROOT / 'environments' / ready_lane / 'bin/python'), str(HERE / 'root_sft_native_reviewed.py'), '--prepare'], out / 'prepare.log', prepare_env)
                jobs['prepare'] = {'pid': prepare_job.pid, 'log': str(out / 'prepare.log'), 'stage': 'preparing'}
        if prepare_job is not None and prepare_job.poll() is not None and not prepared:
            code = prepare_job.returncode
            prepared = code == 0 and (ROOT / 'models/tiny-qwen2-seed20261020/fixture-identity.json').is_file()
            jobs['prepare'].update(returncode=code, stage='prepared' if prepared else 'prepare_failed')
            if not prepared:
                failures.append({'stage': 'prepare', 'returncode': code})
                break
        for framework, (process, key, capture, device_lock) in list(active.items()):
            code = process.poll()
            if code is None:
                continue
            complete = code == 0 and (capture / 'native-completion.json').is_file() and (capture / 'reference-execution.json').is_file()
            jobs[key].update(returncode=code, stage='native_and_reference_complete' if complete else 'execution_failed', native_completed=(capture / 'native-completion.json').is_file(), reference_completed=(capture / 'reference-execution.json').is_file())
            if complete:
                write(ROOT / 'state' / (key + '-complete.json'), jobs[key])
            else:
                failures.append({'stage': key, 'returncode': code, 'output': str(capture)})
            device_lock.close()
            del active[framework]
        for framework in DEVICES:
            lane = environment_lane(framework)
            if framework in active or not prepared or installers[lane].poll() != 0:
                continue
            while queues[framework]:
                precision, model = queues[framework].pop(0)
                key = framework + '-' + model + '-' + precision
                adapter = HERE / ('axolotl_native_v2.py' if framework == 'axolotl' else 'root_sft_native_reviewed.py')
                model_path = ROOT / 'models/tiny-qwen2-seed20261020' if model == 'tiny' else Path(args.model).resolve()
                execution_key = {'adapter_sha256': hashlib.sha256(adapter.read_bytes()).hexdigest(), 'model_path': str(model_path), 'model_config_sha256': hashlib.sha256((model_path / 'config.json').read_bytes()).hexdigest(), 'precision': precision, 'environment': str(ROOT / 'environments' / lane)}
                marker = ROOT / 'state' / (key + '-complete.json')
                if marker.is_file():
                    previous = json.loads(marker.read_text())
                    capture = Path(previous['output'])
                    if previous.get('execution_key') == execution_key and (capture / 'native-completion.json').is_file() and (capture / 'reference-execution.json').is_file():
                        jobs[key] = dict(previous, reused_success=True)
                        continue
                # Global lock per assigned physical device, held until process
                # exits. Installs run concurrently and never acquire this lock.
                device_lock = Path('/tmp/precision-native-device-' + DEVICES[framework] + '.lock').open('a')
                try:
                    fcntl.flock(device_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    device_lock.close(); queues[framework].insert(0, (precision, model)); break
                capture = out / (key + '-captures')
                command = [str(ROOT / 'environments' / lane / 'bin/python'), str(adapter)] + ([] if framework == 'axolotl' else ['--framework', framework]) + ['--model', model, '--precision', precision, '--output', str(capture)]
                process = child(command, out / (key + '.log'), dict(env, ASCEND_RT_VISIBLE_DEVICES=DEVICES[framework]), held_lock=device_lock)
                jobs[key] = {'pid': process.pid, 'command': command, 'device': DEVICES[framework], 'output': str(capture), 'log': str(out / (key + '.log')), 'stage': 'native_running', 'native_completed': False, 'execution_key': execution_key, 'adapter_sha256': execution_key['adapter_sha256']}
                active[framework] = (process, key, capture, device_lock)
                break
        summary = {'attempt': str(out), 'root': str(ROOT), 'pretrained_model': args.model, 'jobs': jobs, 'failures': failures, 'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'controller_pid': os.getpid()}
        write(out / 'status.json', summary)
        write(ROOT / 'state/pipeline-latest.json', summary)
        # An unavailable environment cannot make more progress this invocation.
        done = all(process.poll() is not None for process in installers.values()) and not active and all(not queues[f] or installers[environment_lane(f)].poll() != 0 for f in queues)
        if done:
            break
        time.sleep(5)
    final = {'attempt': str(out), 'root': str(ROOT), 'pretrained_model': args.model, 'jobs': jobs, 'failures': failures, 'controller_finished': True, 'controller_pid': os.getpid(), 'utc': dt.datetime.now(dt.timezone.utc).isoformat()}
    write(out / 'status.json', final)
    write(ROOT / 'state/pipeline-latest.json', final)
    print(json.dumps(final))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action', choices=['start', 'worker', 'status'])
    ap.add_argument('--model', default='/host-model/Qwen3-0.6B')
    ap.add_argument('--precisions', default='bf16,fp32')
    args = ap.parse_args()
    assert args.precisions and set(args.precisions.split(',')) <= {'bf16', 'fp32'}
    if args.action == 'worker':
        execute(args)
    elif args.action == 'status':
        path = ROOT / 'state/pipeline-latest.json'
        print(path.read_text() if path.is_file() else json.dumps({'not_started': True}))
    else:
        (ROOT / 'runs').mkdir(parents=True, exist_ok=True)
        log = ROOT / 'runs' / ('compare-controller-launch-' + timestamp() + '.log')
        process = child([sys.executable, str(Path(__file__).resolve()), 'worker', '--model', args.model, '--precisions', args.precisions], log, dict(os.environ, PRECISION_SFT_ROOT=str(ROOT)))
        print(json.dumps({'controller_pid': process.pid, 'log': str(log), 'root': str(ROOT), 'native_completed': False}))


if __name__ == '__main__':
    main()
