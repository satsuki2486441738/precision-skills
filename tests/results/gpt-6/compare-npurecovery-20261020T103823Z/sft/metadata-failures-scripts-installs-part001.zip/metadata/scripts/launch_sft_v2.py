"""Stdio-transport entrypoint after the three SFT scripts have been uploaded.

The pipeline needs its real saved __file__; executing it from Python stdin
would point at <stdin>. This entrypoint runs the saved script with runpy.
"""
import os
from pathlib import Path
import runpy
import sys

root = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/sft')
os.environ['PRECISION_SFT_ROOT'] = str(root)
script = root / 'scripts/native_pipeline_v2.py'
sys.argv = [str(script), 'start'] + sys.argv[1:]
runpy.run_path(str(script), run_name='__main__')
