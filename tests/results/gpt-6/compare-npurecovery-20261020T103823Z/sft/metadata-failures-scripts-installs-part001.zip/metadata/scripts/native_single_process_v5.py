"""Single-process task launcher: remove malformed inherited cluster rank lists.

Model/loss/optimizer code is unchanged. Distributed launchers must establish
their own per-worker ranks; this wrapper is for the selected world-size-1 SFT.
"""
import json
import os
from pathlib import Path
import runpy
import sys

root = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z').resolve()
script = Path(sys.argv[1]).resolve()
assert script.is_relative_to(root) and script.is_file()
keys = ['LOCAL_RANK', 'RANK', 'WORLD_SIZE', 'LOCAL_WORLD_SIZE', 'GROUP_RANK', 'ROLE_RANK', 'ROLE_WORLD_SIZE', 'MASTER_ADDR', 'MASTER_PORT', 'RANK_TABLE_FILE', 'RANK_ID']
before = {key: os.environ[key] for key in keys if key in os.environ}
for key in keys:
    os.environ.pop(key, None)
os.environ['RANK_SIZE'] = '1'
assert set(os.environ['ASCEND_RT_VISIBLE_DEVICES'].split(',')) <= {'4', '5', '6', '7'}
if '--output' in sys.argv:
    output = Path(sys.argv[sys.argv.index('--output') + 1])
    assert output.resolve().is_relative_to(root)
    receipt = output.with_name(output.name + '-launcher-environment.json')
    assert not receipt.exists()
    receipt.write_text(json.dumps({'removed_inherited_rank_environment': before, 'effective_rank_size': '1', 'effective_visible_devices': os.environ['ASCEND_RT_VISIBLE_DEVICES'], 'native_script': str(script), 'single_process': True, 'native_math_modified': False}, indent=2))
sys.argv = [str(script)] + sys.argv[2:]
runpy.run_path(str(script), run_name='__main__')
