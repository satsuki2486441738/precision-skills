"""Single-process task launcher: remove malformed inherited cluster rank lists.

Model/loss/optimizer code is unchanged. Distributed launchers must establish
their own per-worker ranks; this wrapper is for the selected world-size-1 SFT.
"""
import hashlib
import uuid
import tempfile
import json
import os
from pathlib import Path
import runpy
import sys

root = Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z').resolve()
script = Path(sys.argv[1]).resolve()
assert script.is_relative_to(root) and script.is_file()
keys = ['LOCAL_RANK', 'RANK', 'WORLD_SIZE', 'LOCAL_WORLD_SIZE', 'GROUP_RANK', 'ROLE_RANK', 'ROLE_WORLD_SIZE', 'MASTER_ADDR', 'MASTER_PORT', 'RANK_TABLE_FILE', 'RANK_ID']
before = {key: os.environ[key] for key in keys if key in os.environ}
for key in keys:
    os.environ.pop(key, None)
os.environ['RANK_SIZE'] = '1'
ipc = Path('/tmp') / ('precision-sft-' + uuid.uuid4().hex[:8])
ipc.mkdir(mode=0o700)
os.environ['TMPDIR'] = str(ipc)
tempfile.tempdir = str(ipc)
if '--framework' in sys.argv and sys.argv[sys.argv.index('--framework') + 1] == 'factory' and '--precision' in sys.argv and sys.argv[sys.argv.index('--precision') + 1] == 'fp32' and '--model' in sys.argv and sys.argv[sys.argv.index('--model') + 1] == 'pretrained':
    source = Path('/host-model/Qwen3-0.6B')
    alias = root / 'sft/models/qwen3-pretrained-fp32-loading'
    alias.mkdir(parents=True, exist_ok=True)
    for original in source.iterdir():
        target = alias / original.name
        if original.is_file() and original.name != 'config.json' and not target.exists():
            target.symlink_to(original)
    config = json.loads((source / 'config.json').read_text())
    config['torch_dtype'] = 'float32'
    config['dtype'] = 'float32'
    config_file = alias / 'config.json'
    desired = json.dumps(config, indent=2)
    if config_file.exists():
        assert config_file.read_text() == desired
    else:
        config_file.write_text(desired)
    os.environ['PRECISION_PRETRAINED_MODEL'] = str(alias)
    receipt = alias / 'precision-loading-alias.json'
    identity = {'source': str(source), 'source_config_sha256': hashlib.sha256((source / 'config.json').read_bytes()).hexdigest(), 'loading_config_sha256': hashlib.sha256(config_file.read_bytes()).hexdigest(), 'only_config_dtype_changed': True, 'weights': 'unchanged readonly source symlink; native frozen numeric-value hash must match independent CPU'}
    if not receipt.exists():
        receipt.write_text(json.dumps(identity, indent=2))
assert set(os.environ['ASCEND_RT_VISIBLE_DEVICES'].split(',')) <= {'4', '5', '6', '7'}
if '--output' in sys.argv:
    output = Path(sys.argv[sys.argv.index('--output') + 1])
    assert output.resolve().is_relative_to(root)
    receipt = output.with_name(output.name + '-launcher-environment.json')
    assert not receipt.exists()
    receipt.write_text(json.dumps({'removed_inherited_rank_environment': before, 'effective_rank_size': '1', 'effective_visible_devices': os.environ['ASCEND_RT_VISIBLE_DEVICES'], 'native_script': str(script), 'single_process': True, 'native_math_modified': False}, indent=2))
sys.argv = [str(script)] + sys.argv[2:]
runpy.run_path(str(script), run_name='__main__')
