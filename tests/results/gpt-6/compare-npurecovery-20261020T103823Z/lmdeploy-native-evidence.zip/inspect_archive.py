from pathlib import Path
import zipfile,json,hashlib
p=Path(__file__).parent;archive=p.parents[1]/'runs/compare-npurecovery-20261020T090915Z/lmdeploy-native-evidence-01.zip';expected='b3e78fcb76679fde544a456b3fbaefd0c47c85fec74d70f5f8bdf3ff36e77142';assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
raw=p/'raw';raw.mkdir()
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():assert (raw/name).resolve().is_relative_to(raw.resolve())
 z.extractall(raw)
manifest=json.loads((raw/'collection-manifest.json').read_text());verified=[]
for name,row in manifest['files'].items():
 data=(raw/name).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],name;verified.append(name)
latest=json.loads((raw/'lmdeploy-native-latest.json').read_text());attempt=raw/'runs/compare-lmdeploynative-20261020T112656Z';output={'archive_sha256':expected,'verified_files':len(verified),'latest':latest,'identity':json.loads((raw/'model-identity.json').read_text()),'runtime':json.loads((raw/'runtime-versions.json').read_text()),'cases':{}}
for case in sorted(attempt.iterdir()):
 if not case.is_dir():continue
 output['cases'][case.name]={name:json.loads((case/name).read_text()) for name in ('completion.json','reference-completion.json','reference-input.json','score-boundary-check.json','selected-score-coordinates.json','requested-config.json','sampled-output.json','native-requests.json')}
(p/'intake.json').write_text(json.dumps(output,indent=2));print(json.dumps(output,indent=2))
