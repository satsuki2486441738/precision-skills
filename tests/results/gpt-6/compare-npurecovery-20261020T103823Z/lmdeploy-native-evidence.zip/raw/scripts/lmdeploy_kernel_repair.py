"""Install unchanged official kernel sources with their authentic Git metadata.

The source's old declared Torch/Triton pins are preserved, including pip-check
conflicts. This is an explicit dependency compatibility experiment.
"""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
root=Path('/REMOTE_WORKSPACE/inference')
def worker():
    out=root/'runs'/('compare-kernelrepair-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
    bundle=root/'archives/triton-ascend-kernels-7acb9c4.bundle'
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='e495ff641fff338c6ad9b8aa9f60e9b7ba68520ce7be6a11e5a10afbbca9234e'
    src=root/'sources/triton-ascend-kernels-git-7acb9c40'
    env=dict(os.environ,PYTHONPATH='',PYTHONNOUSERSITE='1',PIP_CACHE_DIR=str(root/'cache'),TMPDIR=str(root/'tmp'),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',TORCHINDUCTOR_COMPILE_THREADS='1')
    for k in ['LOCAL_RANK','RANK','WORLD_SIZE','LOCAL_WORLD_SIZE','MASTER_ADDR','MASTER_PORT']:env.pop(k,None)
    if not src.exists():
        with (out/'clone.log').open('wb') as log:subprocess.run(['git','clone',str(bundle),str(src)],stdout=log,stderr=subprocess.STDOUT,check=True,env=env)
    pin=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],env=env,text=True).strip()
    assert pin=='7acb9c40a6ca827e885d902b7eaee5d45457b230'
    assert not subprocess.check_output(['git','-C',str(src),'diff','--name-only'],env=env).strip()
    py=str(root/'environments/lmdeploy-py311/bin/python')
    commands=[('install',[py,'-m','pip','install','--no-compile','--no-deps','--no-build-isolation','-e',str(src)]),('check',[py,'-m','pip','check']),('freeze',[py,'-m','pip','freeze'])]
    records=[]
    for stage,cmd in commands:
        with (out/(stage+'.log')).open('wb') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=300)
        records.append({'stage':stage,'returncode':r.returncode,'command':cmd})
        if stage=='install' and r.returncode:break
    summary={'attempt':str(out),'records':records,'source_commit':pin,'source_tree_diff_empty':True,'native_operators_changed':False,'old_dependency_pins_overridden':False,'pip_check_conflicts_must_be_retained':True,'claim':'Kernel dependency installation, not native generation'}
    (out/'status.json').write_text(json.dumps(summary,indent=2));(root/'lmdeploy-kernel-latest.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
if __name__=='__main__':
    if sys.argv[1:]==['start']:
        log=root/'runs'/('compare-kernellaunch-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.log')
        with log.open('xb') as f:p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'worker'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps({'pid':p.pid,'log':str(log)}))
    else:worker()
