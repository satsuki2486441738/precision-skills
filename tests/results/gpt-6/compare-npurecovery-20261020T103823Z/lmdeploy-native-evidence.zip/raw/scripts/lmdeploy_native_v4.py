"""Official LMDeploy Ascend pipeline, passive model observations and CPU replay."""
import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
ROOT=Path('/REMOTE_WORKSPACE/inference')
PY=ROOT/'environments/lmdeploy-py311/bin/python'
RANKS=['LOCAL_RANK','RANK','WORLD_SIZE','LOCAL_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE']

def install_passive_observer():
    import functools
    import inspect
    import torch
    from lmdeploy.pytorch.models.qwen3 import Qwen3ForCausalLM
    original=Qwen3ForCausalLM.forward
    signature=inspect.signature(original)
    calls=0
    def meta(x):
        if torch.is_tensor(x):return {'shape':list(x.shape),'dtype':str(x.dtype),'device':str(x.device)}
        if isinstance(x,(list,tuple)):return [meta(v) for v in x]
        return str(type(x))
    @functools.wraps(original)
    def forward(self,*args,**kwargs):
        nonlocal calls
        bound=signature.bind(self,*args,**kwargs).arguments
        result=original(self,*args,**kwargs)
        calls+=1
        case=os.environ.get('PRECISION_LMDEPLOY_OUTPUT')
        if case and calls<=64:
            record={'native_class':type(self).__module__+'.'+type(self).__name__,'pid':os.getpid(),'call':calls,'input_ids':bound['input_ids'].detach().cpu().tolist(),'position_ids':bound['position_ids'].detach().cpu().tolist(),'kv_storage':meta(bound['past_key_values']),'output':meta(result)}
            if calls==1:record['parameters']={n:meta(p) for n,p in self.named_parameters()}
            p=Path(case)/('model-forward-'+str(os.getpid())+'-'+str(calls)+'.json');p.write_text(json.dumps(record,indent=2))
        return result
    Qwen3ForCausalLM.forward=forward
    original_logits=Qwen3ForCausalLM.get_logits
    score_calls=0
    @functools.wraps(original_logits)
    def observe_logits(self,*args,**kwargs):
        nonlocal score_calls
        result=original_logits(self,*args,**kwargs)
        score_calls+=1
        destination=os.environ.get('PRECISION_LMDEPLOY_OUTPUT')
        if destination and score_calls<=64 and result.numel()<=128*result.shape[-1]:
            from safetensors.torch import save_file
            base=Path(destination)/('model-logits-'+str(os.getpid())+'-'+str(score_calls))
            save_file({'logits':result.detach().cpu().contiguous().clone()},str(base)+'.safetensors')
            Path(str(base)+'.json').write_text(json.dumps({'pid':os.getpid(),'call':score_calls,'forward_call':calls,'logits':meta(result),'boundary':'Qwen3ForCausalLM.get_logits return before engine score processors'},indent=2))
        return result
    Qwen3ForCausalLM.get_logits=observe_logits

# multiprocessing spawn executes the main module as __mp_main__; install the
# same copy-only wrapper there without deleting native worker rank assignments.
if sys.argv[1:2]==['case']:
    if __name__=='__main__':
        for key in RANKS:os.environ.pop(key,None)
    install_passive_observer()

def execute_case(model,case):
    import torch
    from lmdeploy import pipeline,PytorchEngineConfig,GenerationConfig
    from safetensors.torch import save_file,load_file
    os.environ['PRECISION_LMDEPLOY_OUTPUT']=str(case)
    cfg=PytorchEngineConfig(dtype='float16',tp=1,device_type='ascend',eager_mode=True,session_len=128,max_batch_size=1,cache_max_entry_count=0.03,enable_prefix_caching=False)
    gen=GenerationConfig(max_new_tokens=4,min_new_tokens=4,ignore_eos=True,do_sample=False,temperature=1.0,top_k=0,top_p=1.0,repetition_penalty=1.0,output_logits=None,random_seed=20261020)
    (case/'requested-config.json').write_text(json.dumps({'backend':vars(cfg),'generation':vars(gen)},indent=2,default=str))
    pipe=pipeline(str(model),backend_config=cfg)
    original=pipe.async_engine.preprocess
    requests=[]
    async def observe_request(*args,**kwargs):
        request=await original(*args,**kwargs)
        requests.append({'input_ids':list(request.inputs['input_ids']),'input_token_len':request.input_token_len})
        (case/'native-requests.json').write_text(json.dumps(requests,indent=2))
        return request
    pipe.async_engine.preprocess=observe_request
    try:
        response=pipe('Name one color. Answer with one word.',gen_config=gen,do_preprocess=False)
        if isinstance(response,list):
            assert len(response)==1;response=response[0]
        assert response.finish_reason!='error' and len(response.token_ids)==4
        from transformers import AutoConfig
        vocab=AutoConfig.from_pretrained(str(model),local_files_only=True).vocab_size
        (case/'sampled-output.json').write_text(json.dumps({'token_ids':response.token_ids,'text':response.text,'finish_reason':response.finish_reason,'generation_API_logits_available':torch.is_tensor(response.logits)},indent=2))
        logits=response.logits.detach().cpu().clone() if torch.is_tensor(response.logits) else None
        if logits is not None:save_file({'logits':logits},str(case/'engine-generation-logits.safetensors'))
        assert len(requests)==1
        inp={'model_path':str(model),'prompt_ids':requests[0]['input_ids'],'generated_ids':list(response.token_ids)}
        (case/'reference-input.json').write_text(json.dumps(inp,indent=2))
        rows=[];selected=[]
        scores=[(p,json.loads(p.read_text())) for p in case.glob('model-logits-*.json')]
        scores.sort(key=lambda item:(item[1]['pid'],item[1]['call']))
        for step in range(4):
            expected=inp['prompt_ids'] if step==0 else [inp['generated_ids'][step-1]]
            expected_positions=list(range(len(inp['prompt_ids']))) if step==0 else [len(inp['prompt_ids'])+step-1]
            found=[]
            for p,record in scores:
                fp=case/('model-forward-'+str(record['pid'])+'-'+str(record['forward_call'])+'.json')
                if not fp.is_file():continue
                forward_record=json.loads(fp.read_text())
                ids=forward_record['input_ids'];positions=forward_record['position_ids']
                if ids not in [expected,[expected]] or positions not in [expected_positions,[expected_positions]]:continue
                found.append((p,record,forward_record))
            assert len(found)==1,('Ambiguous/missing native score coordinate',step,len(found))
            p,record,forward_record=found[0]
            raw=load_file(str(p.with_suffix('.safetensors')))['logits'].reshape(-1,vocab)[-1]
            assert torch.isfinite(raw).all()
            rows.append(raw);selected.append({'step':step,'score_file':p.name,'forward':forward_record,'score':record})
        native_raw=torch.stack(rows)
        save_file({'logits':native_raw},str(case/'native-logits.safetensors'))
        (case/'selected-score-coordinates.json').write_text(json.dumps(selected,indent=2))
        (case/'score-boundary-check.json').write_text(json.dumps({'native_raw_dtype':str(native_raw.dtype),'engine_response_dtype':str(logits.dtype) if logits is not None else 'not_exposed_by_generation_API','engine_response_exactly_equals_raw':torch.equal(native_raw.float(),logits.float()) if logits is not None else None,'boundary':'copy before sampling, EOS/min-token and score processors'},indent=2))
        (case/'native-response.json').write_text(json.dumps({'token_ids':response.token_ids,'text':response.text,'input_token_len':response.input_token_len,'generated_token_len':response.generate_token_len,'finish_reason':response.finish_reason,'logits_dtype':str(native_raw.dtype)},indent=2))
    finally:pipe.close()
    observations=[json.loads(p.read_text()) for p in case.glob('model-forward-*.json')]
    assert observations,'No actual native model observation'
    assert any(d['output'].get('device','').startswith('npu') for d in observations),'Native outputs not observed on NPU'
    assert any(d['input_ids']==[inp['prompt_ids']] or d['input_ids']==inp['prompt_ids'] for d in observations),'Native request did not match captured prefill'
    env=dict(os.environ,TORCH_DEVICE_BACKEND_AUTOLOAD='0',PYTHONPATH='',PYTHONNOUSERSITE='1')
    for key in RANKS:env.pop(key,None)
    with (case/'reference.log').open('wb') as log:rc=subprocess.run([str(PY),str(ROOT/'scripts/lmdeploy_reference.py'),str(case)],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=1200).returncode
    assert rc==0,'Independent reference failed'
    (case/'completion.json').write_text(json.dumps({'status':'native_ascend_generation_and_independent_cpu_complete','native_entrypoint':'lmdeploy.pipeline -> preprocess -> native Ascend Qwen3 -> sampled output','tokens':4,'native_model_forwards':len(observations),'sampling_controls':'greedy native generation; scores copied at actual get_logits return before all processors','thresholds':None},indent=2))

def worker():
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=ROOT/'runs'/('compare-lmdeploynative-'+stamp);out.mkdir()
    result=[]
    for name in ['Qwen3-0.6B','Qwen3-0.6B-Base']:
        case=out/name;case.mkdir()
        ipc=tempfile.mkdtemp(prefix='p-lmd-',dir='/tmp')
        env=dict(os.environ,TORCHINDUCTOR_COMPILE_THREADS='1',ASCEND_RT_VISIBLE_DEVICES='1',PRECISION_LMDEPLOY_OUTPUT=str(case),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',TMPDIR=ipc)
        for key in RANKS:env.pop(key,None)
        cmd=[str(PY),str(ROOT/'scripts/lmdeploy_native_v4.py'),'case',str(Path('/SHARED_MODELS')/name),str(case)]
        with (case/'native.log').open('wb') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=2400).returncode
        result.append({'model':name,'returncode':rc,'case':str(case),'native_complete':(case/'completion.json').is_file()})
    summary={'attempt':str(out),'cases':result,'thresholds':None};(out/'status.json').write_text(json.dumps(summary,indent=2));(ROOT/'lmdeploy-native-latest.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))

if __name__=='__main__':
    if sys.argv[1:2]==['case']:execute_case(Path(sys.argv[2]),Path(sys.argv[3]))
    elif sys.argv[1:]==['start']:
        log=ROOT/'runs'/('compare-lmdeploynativelaunch-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.log')
        with log.open('xb') as f:p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'worker'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps({'pid':p.pid,'log':str(log)}))
    else:worker()
