"""Install the official Ascend source route in a private Python 3.11 env."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/REMOTE_WORKSPACE/inference')
PY311='/REMOTE_WORKSPACE/rlmg/python/cpython311-offline/python/bin/python3.11'
SPECS=[('lmdeploy','110965c7706bbbeb31e21df5d7ef2531fe01c935','579feae73e9795c5c3d75c48a660875186b26cc9c3350b3f0aa111577314c5d0'),('dlinfer','bd37fd38c7831525d962c29925db7244113b7bcf','a8b18975807a99b58270815ef6769172993034eb464117145178f85a2f8d82e1')]
RANKS=['LOCAL_RANK','RANK','WORLD_SIZE','LOCAL_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE']

def worker():
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out=ROOT/'runs'/('compare-lmdeployinstall-'+stamp);out.mkdir()
    inherited={k:os.environ.pop(k) for k in RANKS if k in os.environ}
    (out/'inherited-distributed-controls.json').write_text(json.dumps(inherited,indent=2))
    env=dict(os.environ,PYTHONPATH='',PYTHONNOUSERSITE='1',PIP_CACHE_DIR=str(ROOT/'cache'),TMPDIR=str(ROOT/'tmp'),DEVICE='ascend',LMDEPLOY_TARGET_DEVICE='ascend',DLINFER_BUILD_DICP='OFF',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MAX_JOBS='4',PIP_DISABLE_PIP_VERSION_CHECK='1')
    sources={}
    for name,pin,digest in SPECS:
        arc=ROOT/'archives'/(name+'-'+pin+'.tar.gz')
        assert hashlib.sha256(arc.read_bytes()).hexdigest()==digest
        src=ROOT/'sources'/(name+'-'+pin)
        if not src.is_dir():
            with tarfile.open(arc) as t:t.extractall(ROOT/'sources',filter='data')
        sources[name]=src
    venv=ROOT/'environments/lmdeploy-py311';venv.parent.mkdir(parents=True,exist_ok=True)
    if not (venv/'bin/python').is_file():subprocess.run([PY311,'-m','venv',str(venv)],check=True,env=env)
    py=str(venv/'bin/python')
    constraints=out/'constraints.txt'
    constraints.write_text('torch==2.9.0\ntorch-npu==2.9.0.post6\ntorchvision==0.24.0\nnumpy==1.26.4\ntransformers==4.51.3\npeft==0.11.1\n')
    pip=[py,'-m','pip','install','--no-compile','--retries','1','--timeout','15']
    index=['--index-url','https://pypi.tuna.tsinghua.edu.cn/simple']
    stages=[('pip',pip+['--upgrade','pip','setuptools','wheel']+index),
            ('torch',pip+['torch==2.9.0','--index-url','https://download.pytorch.org/whl/cpu']),
            ('npu',pip+['torch-npu==2.9.0.post6','torchvision==0.24.0','numpy==1.26.4']+index),
            ('builddeps',pip+['-r',str(sources['dlinfer']/'requirements/ascend/full.txt'),'-r',str(sources['lmdeploy']/'requirements/build.txt'),'-c',str(constraints)]+index),
            ('dlinfer',pip+['--no-build-isolation','-e',str(sources['dlinfer']),'-c',str(constraints)]+index),
            ('lmdeploy',pip+['--no-build-isolation','-e',str(sources['lmdeploy']),'-c',str(constraints)]+index)]
    state=ROOT/'state/lmdeploy-install';state.mkdir(parents=True,exist_ok=True)
    failure=None
    for name,cmd in stages:
        signature=hashlib.sha256(json.dumps(cmd).encode()).hexdigest()
        marker=state/(name+'.json')
        if marker.is_file() and json.loads(marker.read_text()).get('signature')==signature:continue
        with (out/(name+'.log')).open('wb') as log:
            try:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=3600,env=env).returncode
            except subprocess.TimeoutExpired:code=124
        event={'stage':name,'returncode':code,'command':cmd,'signature':signature}
        with (out/'journal.jsonl').open('a') as f:f.write(json.dumps(event)+'\n')
        if code:failure=name;break
        marker.write_text(json.dumps(event))
    for name,cmd in [('freeze',[py,'-m','pip','freeze']),('check',[py,'-m','pip','check'])]:
        with (out/(name+'.log')).open('wb') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env).returncode
        if code and failure is None:failure=name
    status={'attempt':str(out),'failed_stage':failure,'environment':str(venv),'native_framework_completed':False,'installation_only':True,'source_pins':SPECS}
    (out/'status.json').write_text(json.dumps(status,indent=2));(ROOT/'lmdeploy-install-latest.json').write_text(json.dumps(status,indent=2));print(json.dumps(status))
    return bool(failure)

if __name__=='__main__':
    if sys.argv[1:]==['start']:
        log=ROOT/'runs'/('compare-lmdeploylaunch-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.log')
        with log.open('xb') as f:p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'worker'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps({'pid':p.pid,'log':str(log)}))
    else:raise SystemExit(worker())
