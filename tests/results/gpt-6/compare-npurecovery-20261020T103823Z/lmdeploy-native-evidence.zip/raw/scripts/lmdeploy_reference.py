"""Independent CPU FP32 cached reference; reads only input/identity JSON."""
import json
import os
from pathlib import Path
import sys
os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD']='0'
import torch
from transformers import AutoModelForCausalLM
from safetensors.torch import save_file
case=Path(sys.argv[1]);data=json.loads((case/'reference-input.json').read_text())
torch.set_num_threads(4)
model=AutoModelForCausalLM.from_pretrained(data['model_path'],torch_dtype=torch.float16,attn_implementation='eager',local_files_only=True).float().cpu().eval()
prompt=data['prompt_ids'];targets=data['generated_ids'];rows=[];cache=None
with torch.no_grad():
    for step in range(len(targets)):
        ids=prompt if step==0 else [targets[step-1]]
        start=0 if step==0 else len(prompt)+step-1
        output=model(input_ids=torch.tensor([ids]),attention_mask=torch.ones((1,start+len(ids)),dtype=torch.long),position_ids=torch.arange(start,start+len(ids)).unsqueeze(0),past_key_values=cache,use_cache=True)
        cache=output.past_key_values;rows.append(output.logits[0,-1].clone());assert rows[-1].device.type=='cpu'
save_file({'logits':torch.stack(rows)},str(case/'reference-logits.safetensors'))
(case/'reference-completion.json').write_text(json.dumps({'status':'reference_execution_complete','weights':'checkpoint cast to F16 then FP32, matching native weight conversion','compute':'CPU FP32 eager','kv_storage':'CPU FP32 high-precision baseline; native KV storage is independently observed','history':'same prefill then generated-history single-token cached decode','uses_native_scores':False,'uses_native_parameters':False,'thresholds':None},indent=2))
