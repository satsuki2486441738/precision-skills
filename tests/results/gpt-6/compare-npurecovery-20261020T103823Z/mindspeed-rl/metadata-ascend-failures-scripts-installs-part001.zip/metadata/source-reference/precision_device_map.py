"""Task-scoped physical Ray NPU ID to visible Torch ordinal translation.

The actual completed Ray worker probe recorded physical7, visibility7,
torch_visible_count1 and successful NPU tensor computation at logical0.
"""
import os


def visible_npu_ordinal(raw):
    visible = os.environ.get('ASCEND_RT_VISIBLE_DEVICES', '').split(',')
    assert len(visible) == 1 and visible[0] == '7', visible
    assert str(raw) in {visible[0], '0'}, (raw, visible)
    return 0
