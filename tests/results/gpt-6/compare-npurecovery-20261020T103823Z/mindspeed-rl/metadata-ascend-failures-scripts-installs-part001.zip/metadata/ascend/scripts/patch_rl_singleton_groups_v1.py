"""Repair task-private singleton process-group initialization using native vLLM API."""
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
p=root/'sources/MindSpeed-RL-26c21e64/mindspeed_rl/models/rollout/vllm_adapter/vllm_parallel_state.py'
original=p.read_bytes()
old='        initialize_model_parallel(infer_tensor_model_parallel_size, infer_pipeline_model_parallel_size, backend)'
new='        ps.initialize_model_parallel(infer_tensor_model_parallel_size, infer_pipeline_model_parallel_size, backend=backend)'
assert original.decode().count(old)==1
backup=p.with_name(p.name+'.precision-singleton-original');assert not backup.exists()
backup.write_bytes(original);p.write_text(original.decode().replace(old,new))
manifest={'before_sha256':hashlib.sha256(original).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_commit':'26c21e64f84ae8cd26de9483292349a1850099cf','file':str(p),'backup':str(backup),'replacement':{'before':old,'after':new},'reason':'Native singleton helper only initializes TP/PP. Pinned vLLM-Ascend forward context requires a real DP group. Native vLLM initialize_model_parallel creates TP/DCP/PP/DP/EP using real process groups; no tensor operator, model, loss, reward or optimizer is replaced. The singleton world/TP/PP sizes remain one.','primary_sources':['https://raw.githubusercontent.com/Ascend/MindSpeed-RL/26c21e64f84ae8cd26de9483292349a1850099cf/mindspeed_rl/models/rollout/vllm_adapter/vllm_parallel_state.py','https://raw.githubusercontent.com/vllm-project/vllm/b8b302c/vllm/distributed/parallel_state.py','https://raw.githubusercontent.com/vllm-project/vllm-ascend/1b16c01/vllm_ascend/ascend_forward_context.py']}
(root/'results/rl-singleton-native-groups-adapter.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
argv=['/usr/bin/env','PRECISION_RAY_DEVICE_MAPPING_VALIDATED=1','PYTHONWARNINGS=ignore::SyntaxWarning',str(root/'envs/rl-torch2.7.1-npu2.7.1.post8/bin/python'),'-B',str(root/'scripts/run_mindspeed_rl_v6.py')]
subprocess.run([sys.executable,'-B',str(root/'scripts/ascend_jobs_v4.py'),'launch','--native','--label','mindspeed-rl-native-grpo-singleton-groups','--devices','7','--argv-json',json.dumps(argv)],check=True)
