"""Publish real singleton vLLM groups to the RL adapter's communication registry."""
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
previous=root/'jobs/mindspeed-rl-native-grpo-singleton-groups-20261020T112648Z-e7f5ae/status.json'
assert json.loads(previous.read_text())['returncode']==1
p=root/'sources/MindSpeed-RL-26c21e64/mindspeed_rl/models/rollout/vllm_adapter/vllm_parallel_state.py';raw=p.read_bytes()
old='        ps.initialize_model_parallel(infer_tensor_model_parallel_size, infer_pipeline_model_parallel_size, backend=backend)'
new=old+'''
        # Task-private singleton registry: retain the real native group objects.
        global _TP, _PP, _DP, _EP, _TP_GROUP_RANKS
        assert world_size == infer_tensor_model_parallel_size == infer_pipeline_model_parallel_size == 1
        _TP, _PP = ps.get_tp_group(), ps.get_pp_group()
        _DP, _EP = ps.get_dp_group(), ps.get_ep_group()
        _TP_GROUP_RANKS = [[0]]'''
assert raw.decode().count(old)==1
backup=p.with_name(p.name+'.precision-registry-original');assert not backup.exists();backup.write_bytes(raw);p.write_text(raw.decode().replace(old,new))
manifest={'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'backup':str(backup),'reason':'Native vLLM initialization now completed model warmup. Upstream RL communication bookkeeping still expected its singleton TP-rank registry. Publish the actual vLLM TP/PP/DP/EP group objects and the verified world-one rank layout; no group or numerical tensor is fabricated.','previous_native_outcome':'Passed real Ascend model warmup; rejected only by get_vllm_tp_group_ranks() returning None in actor communication setup.','world_size':1,'tensor_parallel_size':1,'pipeline_parallel_size':1}
(root/'results/rl-singleton-native-registry-adapter.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
argv=['/usr/bin/env','PRECISION_RAY_DEVICE_MAPPING_VALIDATED=1','PYTHONWARNINGS=ignore::SyntaxWarning',str(root/'envs/rl-torch2.7.1-npu2.7.1.post8/bin/python'),'-B',str(root/'scripts/run_mindspeed_rl_v7.py')]
subprocess.run([sys.executable,'-B',str(root/'scripts/ascend_jobs_v4.py'),'launch','--native','--label','mindspeed-rl-native-grpo-singleton-registry','--devices','7','--argv-json',json.dumps(argv)],check=True)
