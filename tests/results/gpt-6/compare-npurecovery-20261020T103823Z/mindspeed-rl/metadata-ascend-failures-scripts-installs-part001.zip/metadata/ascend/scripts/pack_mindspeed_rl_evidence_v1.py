"""Pack all actual SFT cases as independently hashed <45MiB evidence volumes.

Original tensor bytes are unchanged. Large individual files are split into
ordered binary chunks, with full-file SHA256 and offsets for exact reassembly.
No pretrained weights, environments or caches enter these task-owned volumes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'sft/scripts'))
from collect_native_evidence_v2 import sanitize, sanitize_text

LIMIT = 40 * (1 << 20)
CHUNK = 32 * (1 << 20)


def sha(data): return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--ascend-root', required=True)
    ap.add_argument('--include-pt', action='store_true')
    ap.add_argument('--native-output',required=True)
    ap.add_argument('--reference-output',required=True)
    ap.add_argument('--view',required=True)
    ap.add_argument('--metrics',required=True)
    ap.add_argument('--output', required=True)
    a = ap.parse_args()
    root, out = Path(a.ascend_root), Path(a.output)
    out.mkdir(parents=True, exist_ok=False)
    index = {'schema': 'precision-sft-evidence-volumes-v1', 'maximum_volume_bytes': 45 * (1 << 20), 'tensor_bytes_unchanged': True, 'thresholds': None, 'cases': [], 'volumes': [], 'reassembly': 'Extract all volumes into a new directory. For every chunked file, concatenate chunk records in offset order into its logical_path; verify source_sha256 before replay. Text is sanitized and has a separate archived_sha256.'}

    def pack(label, files):
        parts, entries, budget, z = 0, [], 0, None
        def close():
            nonlocal z, entries
            if z is None: return
            z.writestr('volume-manifest.json', json.dumps({'label': label, 'entries': entries, 'tensor_bytes_unchanged': True}, indent=2))
            name = Path(z.filename)
            z.close()
            raw = name.read_bytes()
            assert len(raw) < 45 * (1 << 20), name
            index['volumes'].append({'filename': name.name, 'bytes': len(raw), 'sha256': sha(raw), 'label': label, 'entries': entries})
            z, entries = None, []
        for logical, path in files:
            raw = path.read_bytes()
            text = '.precision-' in path.name or path.suffix in {'.json', '.jsonl', '.log', '.txt', '.yaml', '.yml', '.py', '.sh', '.md', '.toml', '.out', '.err'}
            selected = raw
            if text:
                value = raw.decode('utf-8', errors='replace')
                if path.suffix == '.json':
                    try: value = json.dumps(sanitize(json.loads(value)), indent=2)
                    except ValueError: value = sanitize_text(value)
                else: value = sanitize_text(value)
                selected = value.encode()
            total, digest = len(selected), sha(selected)
            for offset in range(0, max(total, 1), CHUNK):
                block = selected[offset:offset + CHUNK]
                if z is not None and budget + len(block) > LIMIT: close()
                if z is None:
                    parts += 1
                    z = zipfile.ZipFile(out / f'{label}-part{parts:03d}.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=3)
                    budget = 0
                archive_name = logical if total <= CHUNK else 'chunks/' + logical + f'.offset{offset:012d}.bin'
                z.writestr(archive_name, block)
                entry = {'logical_path': logical, 'archive_path': archive_name, 'offset': offset, 'chunk_bytes': len(block), 'chunk_sha256': sha(block), 'archived_file_bytes': total, 'archived_file_sha256': digest, 'source_bytes': len(raw), 'source_sha256': sha(raw), 'sanitized_text': text, 'tensor_bytes_unchanged': not text, 'chunked': total > CHUNK}
                entries.append(entry)
                budget += len(block)
        close()

    files=[];retained=[]
    for selected,logical in [(a.native_output,'native'),(a.reference_output,'reference'),(a.view,'derived'),(a.metrics,'metrics')]:
        selected=Path(selected).resolve();assert selected.is_relative_to(root)
        for path in sorted(selected.rglob('*')):
            if not path.is_file():continue
            if path.suffix=='.pt' and not a.include_pt:
                retained.append({'private_path':sanitize_text(str(path)),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())});continue
            if path.suffix in {'.json','.log','.yaml','.yml','.txt','.safetensors','.pt'}:
                files.append(('cases/mindspeed-rl/'+logical+'/'+path.relative_to(selected).as_posix(),path))
    index['cases']=[{'framework':'MindSpeed-RL','model':'tiny-native-Qwen3','precision':'bf16','canonical':True,'label':'canonical-mindspeed-rl-grpo-bf16','logical_root':'cases/mindspeed-rl/','stages':['gradients','updates','observations','distributions','targets']}]
    index['retained_private_raw_pt']=retained
    pack('canonical-mindspeed-rl-grpo-bf16',files)
    metadata=[]
    for top in ['scripts','runs','state','jobs']:
        for path in sorted((root/top).rglob('*')):
            if path.is_file() and not path.is_symlink() and path.suffix in {'.json','.jsonl','.py','.sh','.log','.txt','.yaml','.yml'}:
                metadata.append(('metadata/ascend/'+path.relative_to(root).as_posix(),path))
    for path in sorted((root/'results').rglob('*.json')):
        if path.is_file():metadata.append(('metadata/ascend/'+path.relative_to(root).as_posix(),path))
    for attempt in sorted((root/'results').glob('rl-native-*')):
        for path in sorted(attempt.rglob('*')):
            if path.is_file() and not path.is_symlink() and path.suffix in {'.log','.out','.err','.txt'}:
                metadata.append(('metadata/ascend/'+path.relative_to(root).as_posix(),path))
    for path in sorted((root.parent/'sft/core-tools').glob('*.py')):
        metadata.append(('metadata/core-tools/'+path.name,path))
    chosen=root/'sources/MindSpeed-RL-26c21e64'
    source_files=['mindspeed_rl/models/rollout/vllm_adapter/vllm_parallel_state.py','mindspeed_rl/trainer/utils/transfer_dock.py','cli/train_grpo.py','mindspeed_rl/workers/base_worker.py','mindspeed_rl/models/rollout/vllm_engine.py','mindspeed_rl/models/base/base_training_engine.py','mindspeed_rl/models/loss/grpo_actor_loss_func.py','mindspeed_rl/models/loss/logprob_computer.py','mindspeed_rl/utils/compute.py','mindspeed_rl/utils/torch_functional.py','mindspeed_rl/models/rule_verifier.py','configs/precision_tiny_grpo.yaml','configs/precision_tiny_grpo_backendv2.yaml','configs/envs/precision-runtime.yaml','precision_device_map.py']
    for relative in source_files:
        path=chosen/relative
        if path.is_file():metadata.append(('metadata/source-reference/'+relative,path))
        for backup in path.parent.glob(path.name+'.precision-*'):
            if backup.is_file():metadata.append(('metadata/source-reference/'+relative+'.'+backup.name.split('.precision-',1)[-1]+'.txt',backup))
    for path in sorted((root/'inputs/rl-tiny-qwen3').rglob('*')):
        if path.is_file() and path.suffix in {'.json','.txt','.idx','.bin'} and 'trained' not in path.parts:
            metadata.append(('metadata/fixture/'+path.relative_to(root/'inputs/rl-tiny-qwen3').as_posix(),path))
    pack('metadata-ascend-failures-scripts-installs',metadata)
    index['canonical_case_count'] = sum(c['canonical'] for c in index['cases'])
    index['historical_completed_case_count'] = sum(not c['canonical'] for c in index['cases'])
    (out / 'archive-index.json').write_text(json.dumps(index, indent=2))
    print(json.dumps({'directory': str(out), 'index_sha256': sha((out / 'archive-index.json').read_bytes()), 'volumes': [{k: v[k] for k in ['filename', 'bytes', 'sha256', 'label']} for v in index['volumes']], 'canonical_case_count': index['canonical_case_count'], 'historical_completed_case_count': index['historical_completed_case_count']}, indent=2))


if __name__ == '__main__': main()
