"""Passive native MindSpeed-RL frame/optimizer observers, activated by explicit env.

No loss/model/rollout/optimizer result is replaced. Python profiling callbacks
only copy tensors and bind a wrapper that invokes the original optimizer step.
"""
import os
if os.environ.get('PRECISION_NATIVE_CAPTURE_ROOT'):
 import functools,hashlib,json,pathlib,sys
 root=pathlib.Path(os.environ['PRECISION_NATIVE_CAPTURE_ROOT']);root.mkdir(parents=True,exist_ok=True)
 active={};rollouts=[];counter=0
 def cpu(value):
  import torch
  if torch.is_tensor(value):return value.detach().cpu().clone()
  if isinstance(value,dict):return {k:cpu(v) for k,v in value.items()}
  if isinstance(value,(list,tuple)):return type(value)(cpu(v) for v in value)
  return value
 def rank():
  import torch
  return torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
 def dump(path,value):path.write_text(json.dumps(value,indent=2,default=str))
 def profile(frame,event,arg):
  global counter
  filename=frame.f_code.co_filename.replace('\\','/');name=frame.f_code.co_name
  is_engine=filename.endswith('/mindspeed_rl/models/base/base_training_engine.py')
  if is_engine and name=='update' and event=='call':
   import torch
   engine=frame.f_locals['self']
   if engine.role!='actor':return
   config=engine.megatron_config
   assert getattr(config,'bf16',False) and not getattr(config,'fp16',False),'Observer requires native BF16 without FP16 scaling'
   assert float(config.clip_grad)==0.,'Observer requires native clip_grad=0'
   counter+=1;folder=root/('actor-rank'+str(rank())+'-pid'+str(os.getpid())+'-update'+str(counter));folder.mkdir(exist_ok=False)
   params={'chunk'+str(i)+'.'+n:p for i,m in enumerate(engine.model) for n,p in m.named_parameters() if p.requires_grad}
   assert params and all(p.device.type=='npu' for p in params.values()),'Native actor parameters must reside on the assigned NPU'
   payload={'batch_at_update_entry':cpu(frame.f_locals['data']),'before':{n:cpu(p) for n,p in params.items()},'parameter_devices':{n:str(p.device) for n,p in params.items()},'optimizer_state_before':cpu(engine.optimizer.state_dict()),'native_forward_outputs':[],'native_policy_loss_locals':[],'optimizer_step_count':0,'parameter_inventory':{'chunk'+str(i)+'.'+n:{'shape':list(p.shape),'dtype':str(p.dtype),'device':str(p.device),'trainable':p.requires_grad} for i,m in enumerate(engine.model) for n,p in m.named_parameters(remove_duplicate=False)}}
   original=engine.optimizer.step
   @functools.wraps(original)
   def observed_step(*a,**kw):
    payload['optimizer_step_count']+=1
    assert payload['optimizer_step_count']==1,'This case requires exactly one optimizer step per native actor update'
    payload['gradients']={n:cpu(getattr(p,'main_grad',None) if getattr(p,'main_grad',None) is not None else p.grad) for n,p in params.items()}
    result=original(*a,**kw);torch.npu.synchronize()
    payload['optimizer_event']=cpu(result);payload['after']={n:cpu(p) for n,p in params.items()};payload['optimizer_state_after']=cpu(engine.optimizer.state_dict())
    return result
   engine.optimizer.step=observed_step;active[id(frame)]={'folder':folder,'payload':payload,'engine':engine,'original_step':original}
  elif is_engine and name=='update' and event=='return' and id(frame) in active:
   import torch,torch_npu
   item=active.pop(id(frame));p=item['payload'];engine=item['engine'];engine.optimizer.step=item['original_step'];p['native_update_metrics']=cpu(arg)
   folder=item['folder'];torch.save(p,folder/'native-captures.pt')
   event_=p.get('optimizer_event');applied=bool(event_[0]) if isinstance(event_,(tuple,list)) else bool(event_)
   changed=sum(int(torch.count_nonzero(p['after'][n].float()-v.float())) for n,v in p['before'].items()) if 'after' in p else 0
   grads=p.get('gradients',{});finite=all(v is None or bool(torch.isfinite(v).all()) for v in grads.values());nonzero=sum(int(torch.count_nonzero(v)) for v in grads.values() if v is not None)
   result={'framework':'MindSpeed-RL','status':'native_execution_complete' if applied and changed and finite and nonzero else 'native_capture_incomplete','optimizer_applied':applied,'optimizer_steps':p['optimizer_step_count'],'process_group_backend':torch.distributed.get_backend() if torch.distributed.is_initialized() else None,'changed_elements':changed,'nonzero_gradient_elements':nonzero,'finite_gradients':finite,'trainable_tensors':len(p['before']),'trainable_elements':sum(v.numel() for v in p['before'].values()),'gradients_present':sum(v is not None for v in grads.values()),'optimizer_class':type(engine.optimizer).__module__+'.'+type(engine.optimizer).__qualname__,'gradient_boundary':'Native BaseTrainingEngine optimizer.step entry; original BF16 main_grad with clip_grad=0','update_boundary':'Original native optimizer.step return/copyback','native_loss_boundary':'GRPOActorLossFunc._compute_grpo_policy_loss return locals, original dtype','torch':torch.__version__,'torch_npu':torch_npu.__version__,'npu_name':torch.npu.get_device_name(torch.npu.current_device()),'rank':rank(),'captures':'native-captures.pt','sha256':hashlib.sha256((folder/'native-captures.pt').read_bytes()).hexdigest(),'rollout_claim_requires':'A separate successful native rollout result from this run; this actor result alone does not prove generation.'}
   dump(folder/'native-result.json',result);print('PRECISION_NATIVE_RL_ACTOR',json.dumps(result),flush=True)
   assert result['status']=='native_execution_complete',result
  elif event=='return' and is_engine and name=='forward_step':
   if isinstance(arg,tuple) and arg:
    for item in active.values():item['payload']['native_forward_outputs'].append(cpu(arg[0]))
  elif event=='return' and filename.endswith('/mindspeed_rl/models/loss/grpo_actor_loss_func.py') and name=='_compute_grpo_policy_loss':
   keys=['old_log_prob','log_prob','ref_log_prob','advantages','eos_mask','negative_approx_kl','ratio','pg_losses','pg_losses2','kl_losses','pg_mean_loss','kl_mean_loss','pg_loss']
   for item in active.values():item['payload']['native_policy_loss_locals'].append(cpu({k:frame.f_locals[k] for k in keys if k in frame.f_locals}))
  elif event=='return' and filename.endswith('/mindspeed_rl/models/rollout/vllm_engine.py') and name=='_post_process_outputs':
   import torch,torch_npu
   if not isinstance(arg,tuple) or len(arg)!=2:return
   ids,chosen_logprobs=arg
   if not torch.is_tensor(ids) or ids.numel()==0:return
   folder=root/('rollout-rank'+str(rank())+'-pid'+str(os.getpid())+'-call'+str(len(rollouts)+1));folder.mkdir(exist_ok=False)
   payload={'generated_token_ids':cpu(ids),'native_selected_logprobs':cpu(chosen_logprobs)};torch.save(payload,folder/'native-captures.pt');rollouts.append(str(folder))
   import vllm,vllm_ascend
   from vllm.platforms import current_platform
   result={'framework':'MindSpeed-RL','stage':'native_rollout','status':'native_execution_complete','entrypoint':'mindspeed_rl.models.rollout.vllm_engine._post_process_outputs','generation_backend':type(current_platform).__module__+'.'+type(current_platform).__qualname__,'vllm_version':vllm.__version__,'ascend_plugin':vllm_ascend.__file__,'torch':torch.__version__,'torch_npu':torch_npu.__version__,'generated_shape':list(ids.shape),'generated_tokens':int(ids.numel()),'logprob_boundary':'Native chosen-token logprobs after vLLM sampling; not a full-vocabulary logits claim','captures':'native-captures.pt','sha256':hashlib.sha256((folder/'native-captures.pt').read_bytes()).hexdigest()}
   assert 'ascend' in result['generation_backend'].lower(),result
   assert torch.is_tensor(chosen_logprobs) and bool(torch.isfinite(chosen_logprobs).all())
   dump(folder/'native-result.json',result);print('PRECISION_NATIVE_RL_ROLLOUT',json.dumps(result),flush=True)
 sys.setprofile(profile)
