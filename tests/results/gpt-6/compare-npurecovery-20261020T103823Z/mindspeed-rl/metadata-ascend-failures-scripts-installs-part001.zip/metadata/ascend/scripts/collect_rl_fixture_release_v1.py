"""Verify fixture hashes and release of this completed native Ray/device scope."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend');fixture=root/'inputs/rl-tiny-qwen3';old=json.loads((fixture/'precision-input-manifest.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for rel,digest in old['files'].items():
 p=fixture/rel;actual=sha(p);files[rel]={'initial_sha256':digest,'after_native_and_reference_sha256':actual,'unchanged':actual==digest};assert actual==digest,rel
session='/tmp/precision-ray-20261020T114211Z';remaining=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=os.getuid():continue
  command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
  if session in command:remaining.append({'pid':int(p.name),'command':command})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not remaining,remaining
lock=Path('/tmp/precision-native-device-7.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initial_fixture_files_unchanged':True,'files':files,'mcore_checkpoint_current_hashes_after_execution':{p.relative_to(fixture).as_posix():sha(p) for p in sorted((fixture/'mcore').rglob('*.pt'))},'mcore_initial_hash_before_execution_was_not_collected':True,'native_parameter_identity_proof':'Every accepted native initial parameter and optimizer master exactly equals the independently stored initial HF checkpoint value after explicit QKV/SwiGLU/QK-norm coordinate mapping, verified by independent CPU reference.','task_owned_ray_session_remaining_processes':remaining,'native_actor_pid_absent':not Path('/proc/491693').exists(),'native_device_7_lock_free':True,'no_global_service_or_unrelated_process_changes':True}
assert record['native_actor_pid_absent']
(root/'results/rl-fixture-and-release-proof.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
