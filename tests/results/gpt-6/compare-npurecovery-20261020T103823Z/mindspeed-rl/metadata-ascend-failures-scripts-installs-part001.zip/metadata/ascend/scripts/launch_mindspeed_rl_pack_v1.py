"""Pack canonical real RL arrays and all failures/rank logs into bounded volumes."""
from pathlib import Path
import json,subprocess,sys
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
assert json.loads((root/'jobs/mindspeed-rl-core-comparisons-20261020T115214Z-f080c5/status.json').read_text())['returncode']==0
for stage in ['gradients','updates','observations','distributions','targets']:
 assert json.loads((root/'metrics/rl-grpo-bf16-attempt02'/(stage+'-comparison.json')).read_text())['status']=='no_thresholds'
for script in ['collect_rl_fixture_release_v1.py']:
 subprocess.run([sys.executable,'-B',str(root/'scripts'/script)],check=True)
common=['--ascend-root',str(root),'--native-output',str(root/'results/rl-native-20261020T114211Z'),'--reference-output',str(root/'results/rl-reference-attempt01'),'--view',str(root/'comparison/rl-grpo-derived-view-attempt02'),'--metrics',str(root/'metrics/rl-grpo-bf16-attempt02')]
for output,extra in [('rl-compact-public-attempt01',[]),('rl-full-private-attempt01',['--include-pt'])]:
 command=[sys.executable,'-B',str(root/'scripts/pack_mindspeed_rl_evidence_v2.py'),*common,'--output',str(root/'exports'/output),*extra]
 subprocess.run(command,check=True)
