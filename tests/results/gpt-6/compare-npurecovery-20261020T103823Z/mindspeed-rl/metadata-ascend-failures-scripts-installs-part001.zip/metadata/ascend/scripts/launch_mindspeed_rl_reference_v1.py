"""Launch the fresh CPU interpreter after actual native actor/rollout completion."""
from pathlib import Path
import json,subprocess,sys
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend');native=root/'results/rl-native-20261020T114211Z'
actors=list(native.glob('captures/actor-*/native-result.json'));rollouts=list(native.glob('captures/rollout-*/native-result.json'));assert len(actors)==len(rollouts)==1
for p in actors+rollouts:assert json.loads(p.read_text())['status']=='native_execution_complete'
argv=['/usr/bin/env','PYTHONPATH=','PRECISION_NATIVE_CAPTURE_ROOT=',str(root/'envs/rl-torch2.7.1-npu2.7.1.post8/bin/python'),'-B',str(root/'scripts/mindspeed_rl_cpu_reference_v2.py'),'--native',str(actors[0].parent/'native-captures.pt'),'--model',str(root/'inputs/rl-tiny-qwen3/hf'),'--output',str(root/'results/rl-reference-attempt01')]
subprocess.run([sys.executable,'-B',str(root/'scripts/ascend_jobs_v4.py'),'launch','--label','mindspeed-rl-independent-cpu-reference','--devices','7','--argv-json',json.dumps(argv)],check=True)
