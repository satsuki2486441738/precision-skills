"""Run the official GRPO CLI in a task-owned local Ray session.

The selected NPU visibility must be validated against the Ray accelerator-ID
mapping on the actual host before this launcher is used.
"""
import datetime,json,os,pathlib,runpy,sys
ROOT=pathlib.Path(os.environ.get('PRECISION_ASCEND_ROOT','/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend'));source=ROOT/'sources/MindSpeed-RL-26c21e64'
assert os.environ.get('PRECISION_RAY_DEVICE_MAPPING_VALIDATED')=='1','Validate actual Ray NPU IDs against task-assigned devices before launch'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=ROOT/'results'/('rl-native-'+stamp);out.mkdir(parents=True,exist_ok=False)
os.environ['PATH']=str(pathlib.Path(sys.executable).parent)+':'+os.environ['PATH']
os.environ['PYTHONPATH']=str(ROOT/'scripts/rl-observer-v2')+':'+str(source)+':'+os.environ.get('PYTHONPATH','')
os.environ['PRECISION_NATIVE_CAPTURE_ROOT']=str(out/'captures')
sys.path.insert(0,str(source))
import ray,yaml
runtime=yaml.safe_load((source/'configs/envs/precision-runtime.yaml').read_text())
runtime['env_vars']['PRECISION_NATIVE_CAPTURE_ROOT']=os.environ['PRECISION_NATIVE_CAPTURE_ROOT']
runtime['env_vars']['PYTHONPATH']=os.environ['PYTHONPATH']
runtime['env_vars']['PYTHONWARNINGS']='ignore::SyntaxWarning'
runtime['env_vars']['PYTHONDONTWRITEBYTECODE']=''
runtime['env_vars']['PYTHONPYCACHEPREFIX']='/tmp/precision-rl-pycache'
temp=pathlib.Path('/tmp')/('precision-ray-'+stamp);temp.mkdir(mode=0o700,parents=True,exist_ok=False)
plan={'entrypoint':str(source/'cli/train_grpo.py'),'config':'precision_tiny_grpo_backendv2','observer_hook':str(ROOT/'scripts/rl-observer/sitecustomize.py'),'selected_visibility':os.environ.get('ASCEND_RT_VISIBLE_DEVICES'),'ray_temp':str(temp),'output':str(out),'native_math_modified':False}
(out/'native-command.json').write_text(json.dumps(plan,indent=2));print('NATIVE_RL_PLAN',json.dumps(plan),flush=True)
try:
 ray.init(address='local',num_cpus=6,resources={'NPU':1},runtime_env=runtime,namespace='precision-native-'+stamp,include_dashboard=False,_temp_dir=str(temp),object_store_memory=256*(1<<20),_node_ip_address='127.0.0.1')
 previous=os.getcwd();os.chdir(source);sys.argv=[str(source/'cli/train_grpo.py'),'--config-name','precision_tiny_grpo_backendv2','hydra.run.dir='+str(out/'hydra')]
 runpy.run_path(str(source/'cli/train_grpo.py'),run_name='__main__')
finally:
 ray.shutdown()
 import shutil
 logs=(temp/'session_latest/logs').resolve()
 if logs.is_dir():
  assert logs.is_relative_to(temp)
  shutil.copytree(logs,out/'ray-logs',ignore=shutil.ignore_patterns('*.sock'),symlinks=False)
 print('TASK_OWNED_RAY_SHUTDOWN',flush=True)
