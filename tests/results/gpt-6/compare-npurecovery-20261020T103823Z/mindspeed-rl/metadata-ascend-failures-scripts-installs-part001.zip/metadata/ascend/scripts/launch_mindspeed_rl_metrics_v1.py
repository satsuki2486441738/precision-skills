"""Execute the actual core comparisons after independent CPU reference completion."""
from pathlib import Path
import json,subprocess,sys
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
argv=['/usr/bin/env','PYTHONPATH=','PRECISION_NATIVE_CAPTURE_ROOT=',str(root/'envs/rl-torch2.7.1-npu2.7.1.post8/bin/python'),'-B',str(root/'scripts/compare_mindspeed_rl_reference_v1.py'),'--ascend-root',str(root),'--native',str(root/'results/rl-native-20261020T114211Z'),'--reference',str(root/'results/rl-reference-attempt01'),'--job',str(root/'jobs/mindspeed-rl-native-grpo-bounded-dock-20261020T114155Z-b4eb26'),'--view',str(root/'comparison/rl-grpo-derived-view-attempt01'),'--output',str(root/'metrics/rl-grpo-bf16-attempt01')]
subprocess.run([sys.executable,'-B',str(root/'scripts/ascend_jobs_v4.py'),'launch','--label','mindspeed-rl-core-comparisons','--devices','7','--argv-json',json.dumps(argv)],check=True)
