"""Map real GRPO captures to unchanged core tools, retaining original tensor dtypes."""
import argparse,hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
import torch
from safetensors.torch import save_file


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,default=str))


def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--ascend-root',required=True);ap.add_argument('--native',required=True);ap.add_argument('--reference',required=True);ap.add_argument('--job',required=True);ap.add_argument('--view',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
 root,nat,ref,job,view,out=map(Path,[a.ascend_root,a.native,a.reference,a.job,a.view,a.output]);view.mkdir(parents=True,exist_ok=False)
 assert json.loads((job/'status.json').read_text())['returncode']==0
 actors=list(nat.glob('captures/actor-*/native-result.json'));rollouts=list(nat.glob('captures/rollout-*/native-result.json'));assert len(actors)==len(rollouts)==1
 actor_result=json.loads(actors[0].read_text());rollout_result=json.loads(rollouts[0].read_text());assert actor_result['status']==rollout_result['status']=='native_execution_complete';assert actor_result['optimizer_steps']==1
 raw=actors[0].parent/'native-captures.pt';x=torch.load(raw,map_location='cpu',weights_only=False);y=torch.load(ref/'reference-captures.pt',map_location='cpu',weights_only=False);proof=json.loads((ref/'reference-execution.json').read_text())
 assert proof['status']=='independent_reference_complete'
 batch=x['batch_at_update_entry'];ids=batch['input_ids'];responses=batch['responses'];bs,width=responses.shape;assert bs==4 and len(x['native_forward_outputs'])==len(x['native_policy_loss_locals'])==4
 logits=torch.cat(x['native_forward_outputs'],dim=0);assert logits.shape==y['logits'].shape and logits.shape[:2]==ids.shape
 labels=torch.full_like(ids,-100);targets=[];selected_native=[];selected_reference=[]
 for i in range(bs):
  prompt,count=int(batch['prompt_length'][i].item()),int(batch['response_length'][i].item());assert torch.equal(ids[i,prompt:prompt+count],responses[i,:count])
  labels[i,prompt-1:prompt+count-1]=responses[i,:count]
  frame=x['native_policy_loss_locals'][i];assert frame['log_prob'].shape==(1,width)
  for j in range(count):
   targets.append({'sample':'batch-'+str(i),'position':prompt+j,'token':int(responses[i,j])});selected_native.append(frame['log_prob'][0,j]);selected_reference.append(y['action_logprobs'][i,j])
 loss=torch.stack([f['pg_loss'].detach().reshape(()) for f in x['native_policy_loss_locals']]).mean()
 v={'before':x['before'],'gradients':x['gradients'],'after':x['after'],'parameter_inventory':x['parameter_inventory'],'frozen_before':{},'frozen_after':{},'batch':{'input_ids':ids,'labels':labels},'logits':logits,'loss':loss,'compute_loss_controls':{'algorithm':'GRPO','fixed_dependencies':['old/ref action logprobs','advantages'],'clip_ratio':.2,'kl_coefficient':.001,'entropy_coefficient':0.,'microbatches':4,'native_minibatch_responses':4,'native_loss_reduction':'arithmetic mean of four per-microbatch masked action losses','native_optimizer_class':actor_result['optimizer_class'],'native_generated_response_ids':responses}}
 torch.save(v,view/'native-captures.pt');torch.save(y,view/'reference-captures.pt')
 import shutil
 shutil.copyfile(ref/'reference-input-captures.pt',view/'reference-input-captures.pt')
 proof.update(same_initial_trainable_state=True,same_initial_frozen_values=True,frozen_base_unchanged=True)
 dump(view/'reference-execution.json',proof)
 complete={'status':'native_execution_complete','framework':'MindSpeed-RL','entrypoint':'official cli/train_grpo.py -> native IntegratedWorker actor/GRPO objective/native vLLM-Ascend rollout/Adam','entrypoint_returned':True,'model':'tiny-Qwen3','precision':'bf16','versions':{'torch':actor_result['torch'],'torch_npu':actor_result['torch_npu'],'vllm':rollout_result['vllm_version'],'actor_backend':actor_result['process_group_backend']},'model_path':'seeded random Qwen3; native before values equal independent initial HF checkpoint','training':'full native GRPO Adam one step with four real generated responses','label_alignment':'already_shifted_native_targets','reference_implementation':'independent CPU Qwen3 FP32 eager forward, fixed-objective GRPO backward, Adam; no native outcomes consumed'}
 dump(view/'native-completion.json',complete)
 dump(view/'observations.json',{'optimizer_steps':1,'valid_targets':len(targets),'native_loss':float(loss),'reference_loss':float(y['loss']),'native_rollout':rollout_result,'native_actor':actor_result,'full_trainable_elements':sum(v.numel() for v in x['before'].values()),'frozen_parameters':0,'reference_scope':'Fixed native trajectories/old/ref anchors/advantages; independent reward/group replay is separately labelled derived in reference evidence'})
 dump(view/'derived-view-provenance.json',{'raw_native_sha256':sha(raw),'raw_reference_sha256':sha(ref/'reference-captures.pt'),'transformations':['Concatenate the four native microbatch forward outputs in actual unshuffled order','Select original logits at actual valid response prediction coordinates','Arithmetic mean of four captured native pg_loss scalars; native individual loss scalars retained','Original before/gradient/after values and dtypes retained; no native arithmetic replaced'],'native_observations_not_recomputed':True})
 spec=importlib.util.spec_from_file_location('precision_training_export',root/'scripts/export_compare_training_v3.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 result=module.export(view,out,root.parent/'sft/core-tools');assert all(c['returncode']==0 for c in result['commands'])
 # All fixed objective tensors are available without Torch/pickle for audit.
 objective={k:t.contiguous() for k,t in batch.items() if torch.is_tensor(t)}
 for i,frame in enumerate(x['native_policy_loss_locals']):
  for k,t in frame.items():
   if torch.is_tensor(t):objective[f'microbatch-{i}/{k}']=t.contiguous().clone()
 objective['reference/action_logprobs']=y['action_logprobs'].contiguous();objective['reference/microbatch_losses']=y['microbatch_losses'].contiguous()
 save_file(objective,str(out/'objective-inputs-and-native-loss-states.safetensors'))
 scores={'native':selected_native,'reference':selected_reference};common={'model':{'seeded_checkpoint_sha256':proof['initial_checkpoint_sha256'],'family':'Qwen3'},'inputs':{'actual_targets':targets,'fixed_reference_input_sha256':proof['reference_input_sha256']},'scope':{'optimizer_steps':1,'trajectories':4,'groups':1,'paired_actions':len(targets)}}
 sides={'native':{'numerics':{'device':'npu','boundary':'Captured native GRPOActorLossFunc current-policy action logprobs before objective construction','dtype':str(selected_native[0].dtype)}},'reference':{'numerics':{'device':'cpu','boundary':'Independent Qwen3 FP32 eager full-vocab log_softmax at identical response histories','dtype':'torch.float32'}}}
 contract={'schema_version':1,'kind':'target-scores','thresholds':None,'common':common,'side_conditions':sides,'expected_ranks':{s:[0] for s in sides},'targets':targets};dump(out/'targets-contract.json',contract)
 for side in sides:
  dump(out/(side+'-action-environment.json'),{'rank':0,'actual':{**common,**sides[side]}})
  manifest={'schema_version':1,'kind':'target-scores','side':side,'common':common,'expected_ranks':[0],'ranks':[{'rank':0,'environment':side+'-action-environment.json','status':side+'-status.json'}],'scores':[{**row,'logprob':float(value)} for row,value in zip(targets,scores[side])]};dump(out/('targets-'+side+'.json'),manifest)
 tool=root.parent/'sft/core-tools/compare_target_scores.py';argv=[sys.executable,'-B',str(tool),'--contract',str(out/'targets-contract.json'),'--side-a',str(out/'targets-native.json'),'--side-b',str(out/'targets-reference.json'),'--output',str(out/'targets-comparison.json')]
 with (out/'targets-comparison.log').open('xb') as f:code=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT).returncode
 assert code==0
 dump(out/'rl-capture-provenance.json',{'native_actor':actor_result,'native_rollout':rollout_result,'independent_reference':proof,'raw_native_sha256':sha(raw),'raw_reference_sha256':sha(ref/'reference-captures.pt'),'commands':result['commands']+[{'argv':argv,'returncode':code,'core_sha256':sha(tool)}],'thresholds':None,'native_action_scores_captured_not_derived':True,'distribution_scores':'Explicit FP64 full-vocabulary log_softmax derived from original captured logits for core distribution metrics','full_model_training_frozen_inventory':{},'job_completed':json.loads((job/'status.json').read_text())})
 print(json.dumps({'status':'native_and_independent_reference_core_metrics_complete','output':str(out),'comparisons':5,'thresholds':None},indent=2))


if __name__=='__main__':main()
