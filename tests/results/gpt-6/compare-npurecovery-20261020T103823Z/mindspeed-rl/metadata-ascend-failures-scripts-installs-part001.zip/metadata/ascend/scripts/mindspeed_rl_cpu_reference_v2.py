"""Independent CPU Qwen3 fixed-trajectory GRPO/Adam replay; no RL framework import.

Native before values and fixed objective inputs are accepted. Current-policy
logprobs, native losses/gradients/after values are excluded from the reference
input and are not consumed by independent forward/backward/optimizer execution.
"""
import argparse,hashlib,json,sys,re
from pathlib import Path
import torch
from transformers import Qwen3Config,Qwen3ForCausalLM


def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()


def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--native',required=True);ap.add_argument('--model',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
 raw,modeldir,out=Path(a.native),Path(a.model),Path(a.output);out.mkdir(parents=True,exist_ok=False)
 native=torch.load(raw,map_location='cpu',weights_only=False)
 assert native['optimizer_step_count']==1
 assert len(native['native_policy_loss_locals'])==4
 for frame in native['native_policy_loss_locals']:
  assert frame['cliprange']==.2 and frame['entropy_coeff']==0 and frame['kl_coefficient']==.001,frame.keys()
 batch=native['batch_at_update_entry']
 accepted={'before':native['before'],'initial_optimizer':native['optimizer_state_before'],'batch':{k:batch[k] for k in ['input_ids','responses','prompt_length','response_length','old_log_prob','ref_log_prob','advantages'] if k in batch},'config':json.loads((modeldir/'config.json').read_text()),'megatron_config':native['megatron_config'],'objective':{'clip_ratio':0.2,'kl_coefficient':0.001,'kl_penalty':'low_var_kl','entropy_coefficient':0.,'micro_batch_size':1,'mini_batch_size':4,'epochs':1,'temperature':1.}}
 assert set(accepted).isdisjoint({'after','gradients','log_prob','native_policy_loss_locals','native_forward_outputs'})
 torch.save(accepted,out/'reference-input-captures.pt');del native,accepted
 data=torch.load(out/'reference-input-captures.pt',map_location='cpu',weights_only=False)
 assert not any(x=='swift' or x.startswith(('swift.','mindspeed_rl.','megatron.')) for x in sys.modules)
 config=Qwen3Config.from_dict(data['config']);config.use_cache=False;config._attn_implementation='eager'
 model=Qwen3ForCausalLM(config).float().cpu().train();params=dict(model.named_parameters());before=data['before'];batch=data['batch'];mgcfg=data['megatron_config']
 assert config.num_attention_heads==config.num_key_value_heads
 assert mgcfg['tensor_model_parallel_size']==mgcfg['pipeline_model_parallel_size']==1
 assert mgcfg['hidden_dropout']==mgcfg['attention_dropout']==0
 assert float(mgcfg['clip_grad'])==0
 prefix=next(n[:-len('embedding.word_embeddings.weight')] for n in before if n.endswith('embedding.word_embeddings.weight'))
 mapping={prefix+'embedding.word_embeddings.weight':[('model.embed_tokens.weight',None)],prefix+'decoder.final_layernorm.weight':[('model.norm.weight',None)],prefix+'output_layer.weight':[('lm_head.weight',None)]}
 heads,head,hidden,ffn=config.num_attention_heads,config.head_dim,config.hidden_size,config.intermediate_size
 for i in range(config.num_hidden_layers):
  mg,hf=prefix+f'decoder.layers.{i}.',f'model.layers.{i}.'
  for m,h in [('input_layernorm.weight','input_layernorm.weight'),('pre_mlp_layernorm.weight','post_attention_layernorm.weight'),('self_attention.linear_proj.weight','self_attn.o_proj.weight'),('self_attention.q_layernorm.weight','self_attn.q_norm.weight'),('self_attention.k_layernorm.weight','self_attn.k_norm.weight'),('mlp.linear_fc2.weight','mlp.down_proj.weight')]:mapping[mg+m]=[(hf+h,None)]
  mapping[mg+'self_attention.linear_qkv.weight']=[(hf+'self_attn.'+n+'_proj.weight',('qkv',j)) for j,n in enumerate(['q','k','v'])]
  mapping[mg+'mlp.linear_fc1.weight']=[(hf+'mlp.'+n+'_proj.weight',('fc1',j)) for j,n in enumerate(['gate','up'])]
 assert set(mapping)==set(before),(set(mapping)-set(before),set(before)-set(mapping))
 with torch.no_grad():
  for n,parts in mapping.items():
   v=before[n].float()
   for target,spec in parts:
    if spec is None:selected=v
    elif spec[0]=='qkv':selected=v.view(heads,3,head,hidden)[:,spec[1]].reshape(hidden,hidden)
    else:selected=v.view(2,ffn,hidden)[spec[1]]
    assert params[target].shape==selected.shape,(target,params[target].shape,selected.shape)
    params[target].copy_(selected)
 assert {n for parts in mapping.values() for n,_ in parts}==set(params)
 # Compare against the independently stored initial HF checkpoint, including
 # all Q/K normalizers, after accepting the native before values.
 from safetensors.torch import load_file
 original=load_file(str(modeldir/'model.safetensors'))
 assert set(original)==set(params)
 for n,p in params.items():assert torch.equal(p.detach(),original[n].float()),n
 del original
 opt=data['initial_optimizer'];assert not opt['optimizer']['state']
 ordered=[n for n in before if before[n].ndim>1]+[n for n in before if before[n].ndim==1]
 masters=[v for group in opt['fp32_from_fp16_params'] for v in group]
 assert len(masters)==len(ordered)
 for n,v in zip(ordered,masters):assert torch.equal(before[n].float(),v),n
 groups=opt['optimizer']['param_groups']
 assert all(g['lr']==.001 and tuple(g['betas'])==(.9,.95) and g['eps']==1e-8 and g['weight_decay']==0 and not g['amsgrad'] for g in groups)
 optimizer=torch.optim.Adam(model.parameters(),lr=.001,betas=(.9,.95),eps=1e-8,weight_decay=0,foreach=False,fused=False);assert not optimizer.state
 ids=batch['input_ids'].long();responses=batch['responses'].long();bs,width=responses.shape;assert bs==4
 assert ids.shape[0]==bs and int(ids.min())>=0 and int(ids.max())<config.vocab_size
 lengths=batch['response_length'].reshape(-1).long();prompts=batch['prompt_length'].reshape(-1).long();assert torch.all(lengths>0)
 mask=torch.arange(width).unsqueeze(0)<lengths.unsqueeze(1)
 fixed_old=batch.get('old_log_prob');fixed_ref=batch['ref_log_prob'].float();adv=batch['advantages'].float()
 logits_rows=[];full_logits=[];current=[];losses=[];components=[]
 from transformers import AutoTokenizer
 tokenizer=AutoTokenizer.from_pretrained(modeldir,trust_remote_code=False)
 decoded=tokenizer.batch_decode(responses,skip_special_tokens=True)
 pattern=r'(Step \d+:|^\d+\.|\n-|\n\*|First,|Second,|Next,|Finally,)'
 derived_rewards=torch.tensor([min(1.,len(re.findall(pattern,text))/3) for text in decoded],dtype=torch.float32)
 centered=derived_rewards.double().reshape(1,4);derived_scores=(centered-centered.mean(1,keepdim=True))/(centered.std(1,keepdim=True)+1e-6)
 derived_advantages=derived_scores.float().reshape(4,1).repeat(1,width)*mask
 group_audit={'source':'Independent replay of official reasoning_steps_reward regex and compute_group_norm_advantage_return; native rewards were not separately captured','decoded_responses':decoded,'derived_rewards':derived_rewards.tolist(),'derived_group_mean':float(derived_rewards.double().mean()),'derived_group_std_unbiased':float(derived_rewards.double().std()),'group_epsilon':1e-6,'derived_advantage_max_abs_difference_from_accepted_native':float((derived_advantages-adv).abs().max()),'native_advantages_are_accepted_fixed_objective_inputs':True}
 for i in range(bs):
  logits=model(input_ids=ids[i:i+1],position_ids=torch.arange(ids.shape[1]).unsqueeze(0),use_cache=False).logits
  full_logits.append(logits.detach())
  start,count=int(prompts[i])-1,int(lengths[i]);selected=logits[:,start:start+count]
  assert torch.equal(ids[i,int(prompts[i]):int(prompts[i])+count],responses[i,:count])
  lp=selected.log_softmax(-1).gather(-1,responses[i:i+1,:count,None]).squeeze(-1)
  lp=torch.nn.functional.pad(lp,(0,width-count));old=lp.detach().clone() if fixed_old is None else fixed_old[i:i+1].float();ref=fixed_ref[i:i+1];advantages=adv[i:i+1]
  ratio=(lp-old).exp();unclipped=-advantages*ratio;clipped=-advantages*ratio.clamp(.8,1.2)
  delta=(ref-lp).clamp(-20,20);kl=(delta.exp()-delta-1).clamp(-10,10)
  localmask=mask[i:i+1]
  def mean(v):return torch.where(localmask,v,torch.zeros_like(v)).sum()/(localmask.sum()+1e-8)
  pgmean,klmean=mean(torch.maximum(unclipped,clipped)),mean(kl);loss=pgmean+.001*klmean
  # Megatron non-pipeline schedule averages the four microbatch losses.
  (loss/bs).backward();losses.append(loss.detach());current.append(lp.detach());logits_rows.append(selected.detach());components.append({'policy':float(pgmean.detach()),'kl':float(klmean.detach()),'total':float(loss.detach())})
 def backmap(field):
  result={}
  for n,parts in mapping.items():
   values=[(getattr(params[t],field) if field else params[t]).detach().clone() for t,_ in parts]
   if parts[0][1] is None:v=values[0]
   elif parts[0][1][0]=='qkv':v=torch.stack([v.view(heads,head,hidden) for v in values],dim=1).reshape(3*hidden,hidden)
   else:v=torch.cat(values,dim=0)
   result[n]=v
  return result
 gradients=backmap('grad');assert all(torch.isfinite(v).all() for v in gradients.values());assert sum(torch.count_nonzero(v) for v in gradients.values())>0
 optimizer.step();loss=torch.stack(losses).mean()
 result={'before':{n:v.float().clone() for n,v in before.items()},'gradients':gradients,'after':backmap(None),'logits':torch.cat(full_logits),'group_audit':group_audit,'valid_action_logits':torch.cat([v.reshape(-1,config.vocab_size) for v in logits_rows]),'action_logprobs':torch.cat(current),'loss':loss,'microbatch_losses':torch.stack(losses),'components':components,'response_mask':mask,'optimizer_state_after':optimizer.state_dict()}
 torch.save(result,out/'reference-captures.pt')
 proof={'status':'independent_reference_complete','framework':'MindSpeed-RL fixed-trajectory CPU reference','reference_model':'Transformers Qwen3ForCausalLM CPU FP32 eager','reference_input_sha256':sha(out/'reference-input-captures.pt'),'reference_capture_sha256':sha(out/'reference-captures.pt'),'native_capture_sha256':sha(raw),'initial_checkpoint_sha256':sha(modeldir/'model.safetensors'),'reference_input_keys':sorted(data),'native_outcomes_consumed_by_reference':False,'all_parameters_mapped':True,'initial_hf_checkpoint_values_equal_native_before':True,'initial_master_values_equal':True,'fresh_optimizer_state_empty':True,'optimizer_steps':1,'optimizer':'torch.optim.Adam','microbatches':bs,'reduction':'Mean of per-microbatch masked action means, then divide by four; matches selected non-pipeline accumulation','action_rows':int(mask.sum()),'groups':1,'trajectories':bs,'loss':float(loss),'components':components,'fixed_dependencies':['native-generated prompt/response IDs and response lengths','native old-policy/ref logprobs and GRPO advantages accepted as fixed objective inputs'],'group_audit':group_audit,'not_claimed':['separately captured native reward arrays','independent resampling','acceptance against numerical thresholds'],'thresholds':None,'mapping':mapping,'original_dtypes':{'native_before':sorted(set(str(v.dtype) for v in before.values())),'reference':'torch.float32'},'unmodified_cpu_runtime':{'torch':torch.__version__,'forbidden_framework_modules_absent':True}}
 (out/'reference-execution.json').write_text(json.dumps(proof,indent=2));print(json.dumps(proof,indent=2))


if __name__=='__main__':main()
