"""Use a bounded real Ray CPU reservation for the one-prompt native fixture."""
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/host-model/workspace/<user>/projects/yz/precision-gpt6-npu-20261020T090915Z/ascend')
previous=root/'jobs/mindspeed-rl-native-grpo-singleton-registry-20261020T113258Z-d4c26c/status.json'
assert json.loads(previous.read_text())['returncode']!=0
p=root/'sources/MindSpeed-RL-26c21e64/mindspeed_rl/trainer/utils/transfer_dock.py';raw=p.read_bytes();old='@ray.remote(max_concurrency=100, num_cpus=10)';new='@ray.remote(max_concurrency=100, num_cpus=1)';assert raw.decode().count(old)==1
backup=p.with_name(p.name+'.precision-resource-original');assert not backup.exists();backup.write_bytes(raw);p.write_text(raw.decode().replace(old,new))
record={'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'backup':str(backup),'source_commit':'26c21e64f84ae8cd26de9483292349a1850099cf','change':'GRPOTransferDock Ray scheduling reservation 10 -> 1 CPU','reason':'One-prompt/four-response fixture in a task-owned six-CPU Ray cluster. This in-memory transfer/control actor otherwise cannot be scheduled. CPU thread count remains bounded. No model, tensor arithmetic, reward, loss, optimizer or native rollout implementation changes.','not_claimed':'Unmodified upstream large-job resource topology or performance equivalence','primary_source':'https://raw.githubusercontent.com/Ascend/MindSpeed-RL/26c21e64f84ae8cd26de9483292349a1850099cf/mindspeed_rl/trainer/utils/transfer_dock.py'}
(root/'results/rl-native-control-actor-reservation-adapter.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
argv=['/usr/bin/env','PRECISION_RAY_DEVICE_MAPPING_VALIDATED=1','PYTHONWARNINGS=ignore::SyntaxWarning',str(root/'envs/rl-torch2.7.1-npu2.7.1.post8/bin/python'),'-B',str(root/'scripts/run_mindspeed_rl_v8.py')]
subprocess.run([sys.executable,'-B',str(root/'scripts/ascend_jobs_v4.py'),'launch','--native','--label','mindspeed-rl-native-grpo-bounded-dock','--devices','7','--argv-json',json.dumps(argv)],check=True)
