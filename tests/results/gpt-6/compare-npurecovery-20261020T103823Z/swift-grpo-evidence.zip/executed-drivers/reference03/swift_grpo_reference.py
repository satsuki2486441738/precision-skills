"""Independent CPU FP32 forward/backward and first AdamW update on native sampled inputs."""
import os,pathlib,json,hashlib,argparse,inspect,time
import torch
from transformers import AutoModelForCausalLM
from transformers.models.qwen3.modeling_qwen3 import Qwen3RMSNorm
ap=argparse.ArgumentParser();ap.add_argument('--native-output',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
native=pathlib.Path(a.native_output);out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=True)
assert 'swift' not in __import__('sys').modules
norm_source=inspect.getsource(Qwen3RMSNorm.forward);assert 'torch_npu' not in norm_source and 'npu_rms_norm' not in norm_source
torch.set_num_threads(2);torch.manual_seed(20261020)
objective=torch.load(native/'objective_observed.pt',map_location='cpu',weights_only=True)
reward_data=torch.load(native/'reward_observed.pt',map_location='cpu',weights_only=True)
arglist=json.loads((native/'arguments.json').read_text());temperature=float(arglist[arglist.index('--temperature')+1]);group_size=int(arglist[arglist.index('--num_generations')+1])
rewards=torch.tensor([float(i%2)+float(sum(ord(c) for c in str(text))%997)/9970 for i,text in enumerate(reward_data['completions'])],dtype=torch.float32)
groups=rewards.reshape(-1,group_size);adv=((groups-groups.mean(-1,keepdim=True))/(groups.std(-1,unbiased=True,keepdim=True)+1e-4)).reshape(-1)
model=AutoModelForCausalLM.from_pretrained('/SHARED_MODELS/Qwen3-0.6B',dtype=torch.float32,attn_implementation='eager',local_files_only=True,device_map={'':'cpu'})
model.train();model.config.use_cache=False
inputs=dict(objective['model_inputs']);inputs.pop('logits_to_keep',None);batch=objective['grpo_batch'];k=int(batch['logits_to_keep'])
logits=model(**inputs).logits[:, -(k+1):-1,:]/temperature
labels=inputs['input_ids'][:,-k:];logps=logits.log_softmax(-1).gather(-1,labels.unsqueeze(-1)).squeeze(-1)
old=batch['old_per_token_logps'];old=logps.detach() if old is None else old.float()
ratio=torch.exp(logps-old);advantages=adv[:,None].expand_as(logps);mask=batch['completion_mask'].bool()
terms=-torch.minimum(ratio*advantages,ratio.clamp(.8,1.2)*advantages)
loss=((terms*mask).sum(-1)/mask.sum(-1).clamp(min=1)).mean();loss.backward()
preclip_norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
names=dict(model.named_parameters());coordinates=json.loads((native/'optimizer-coordinate-map.json').read_text())
selected={};lr=.001;eps=1e-8
for group in coordinates:
 for coord in group['params']:
  if group['group']!=0 or coord['index']>=12:continue
  p=names[coord['name']];before=p.detach().reshape(-1)[:8192].clone();grad=p.grad.detach().reshape(-1)[:8192].clone()
  update=-lr*grad/(grad.abs()+eps)
  selected[(group['group'],coord['index'])]={'name':coord['name'],'before':before,'gradient':grad,'update':update,'after':before+update}
# Reference computation has finished. Native gradients/updated parameters are first read below, for comparison only.
native_paths=sorted((native/'optimizer').glob('*.pt'));assert len(native_paths)==1
observed=torch.load(native_paths[0],map_location='cpu',weights_only=True)
def comparison(x,y):
 x=x.float().reshape(-1);y=y.float().reshape(-1);den=x.norm().item();other=y.norm().item()
 return {'reference_l2':den,'native_l2':other,'relative_l2':(y-x).norm().item()/max(den,1e-30),'max_abs':(y-x).abs().max().item(),'cosine':float(torch.nn.functional.cosine_similarity(x,y,dim=0).item()) if den>0 and other>0 else None,'all_finite':bool(torch.isfinite(x).all() and torch.isfinite(y).all())}
rows=[]
for i,coord in enumerate(observed['coordinates']):
 key=(coord['group'],coord['index']);ref=selected[key]
 rows.append({'name':ref['name'],'coordinate':coord,'initial_max_abs':(ref['before']-observed['before'][i].float()).abs().max().item(),'gradient':comparison(ref['gradient'],observed['postclip_gradients'][i]),'update':comparison(ref['update'],observed['updates_fp32'][i])})
native_adv=batch['advantages'][:,0].float();native_loss=objective['native_loss_and_metrics'][0].float()
all_gr=torch.cat([v['gradient'] for v in selected.values()]);all_up=torch.cat([v['update'] for v in selected.values()]);native_gr=torch.cat([g.float() for g in observed['postclip_gradients']]);native_up=torch.cat(observed['updates_fp32'])
result={'status':'independent_fp32_reference_complete','native_output':str(native),'reference_device':'cpu','reference_dtype':'torch.float32','model_initialization':'independent reload of original pretrained weights; no native gradients or updated parameters used for execution','model': '/SHARED_MODELS/Qwen3-0.6B','model_norm_class_module':Qwen3RMSNorm.forward.__module__,'swift_imported':False,'native_gradients_read_only_after_reference_computation':True,'loss':{'reference':loss.item(),'native':native_loss.item(),'abs_error':abs(loss.item()-native_loss.item())},'advantage':comparison(adv,native_adv),'gradient_selected':comparison(all_gr,native_gr),'update_selected':comparison(all_up,native_up),'preclip_gradient_norm':float(preclip_norm),'coordinates':rows,'optimizer_reference':'independent zero-state AdamW step1 closed form on selected coordinates, lr=.001 eps=1e-8 weight_decay=0; forward/backward and global norm clipping on full CPU model','temperature':temperature,'reward_quality_claimed':False,'alignment_thresholds_applied':False}
native_logps=torch.load(native/'logps_observed.pt',map_location='cpu',weights_only=True)['native_logps_and_entropies'][0]
result['logprobs']=comparison(logps.detach()[mask],native_logps[mask])
result['coverage']={'sampled_parameter_elements':sum(v['gradient'].numel() for v in selected.values()),'whole_model_parameter_elements':sum(p.numel() for p in model.parameters()),'sampling_rule':'first8192 flattened elements of first12 parameters in native optimizer group0; identical named coordinates in clean CPU model','effective_completion_mask_shape':list(mask.shape),'effective_completion_mask_dtype':str(mask.dtype),'valid_tokens_per_sequence':mask.sum(-1).tolist(),'loss_reduction':'per-sequence masked token mean, then sequence mean','group_size':group_size,'reward_group_count':int(groups.shape[0]),'native_parameter_dtype':observed['coordinates'][0]['dtype'],'native_gradient_dtypes':sorted(set(str(g.dtype) for g in observed['postclip_gradients'])),'native_logprob_dtype':str(native_logps.dtype),'native_loss_dtype':str(native_loss.dtype),'reference_computation_dtype':'torch.float32'}
reference_tensors={'loss':loss.detach(),'rewards':rewards,'advantages':adv,'per_token_logps':logps.detach(),'completion_mask':mask,'selected':list(selected.values())}
if (native/'distribution_rows_observed.pt').exists():
 distribution=torch.load(native/'distribution_rows_observed.pt',map_location='cpu',weights_only=True)
 positions=[p for p in distribution['positions'] if mask[p['batch_index'],p['action_slot']]]
 rows=[logits[p['batch_index'],p['action_slot']].detach().log_softmax(-1) for p in positions]
 reference_tensors['distribution_positions']=positions;reference_tensors['full_normalized_logprobs']=torch.stack(rows)
torch.save(reference_tensors,out/'reference-tensors.pt')
(out/'reference-completion.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
