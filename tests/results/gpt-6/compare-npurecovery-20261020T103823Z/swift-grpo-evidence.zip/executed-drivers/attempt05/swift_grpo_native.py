"""Full official Swift rlhf_main → GRPO Trainer.train, with passive captures."""
import os,json,pathlib,traceback,time,importlib.metadata as md,dataclasses
import torch,torch_npu
OUT=pathlib.Path(os.environ['RLAR_OUTPUT']);OUT.mkdir(parents=True,exist_ok=True)

def cpu(v):
 if torch.is_tensor(v):return v.detach().cpu().clone()
 if dataclasses.is_dataclass(v):return {k:cpu(getattr(v,k)) for k in v.__dataclass_fields__}
 if isinstance(v,dict):return {str(k):cpu(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [cpu(x) for x in v]
 if isinstance(v,(str,float,int,bool,type(None))):return v
 return repr(v)

def save(name,data,**meta):
 torch.save(cpu(data),OUT/(name+'.pt'))
 event={'event':name,'pid':os.getpid(),'time':time.time(),'native_call_stack':traceback.format_stack(limit=18),**meta}
 (OUT/(name+'.json')).write_text(json.dumps(event,indent=2,default=str));print('SWIFT_NATIVE '+json.dumps(event,default=str),flush=True)

from swift.rewards import ORM,orms
class PipelineVariationReward(ORM):
 def __call__(self,completions,**kwargs):
  # Declared synthetic reward: validates group variation; does not measure answer quality.
  values=[float(i%2)+float(sum(ord(c) for c in str(text))%997)/9970 for i,text in enumerate(completions)]
  save('reward_observed',{'completions':completions,'values':values},purpose='synthetic workflow validation only; response character checksum plus alternating sample index')
  return values
orms['precision_pipeline_variation']=PipelineVariationReward
from swift.rlhf_trainers.grpo_trainer import GRPOTrainer

def observe(method,event):
 original=getattr(GRPOTrainer,method)
 def wrapper(self,*args,**kwargs):
  result=original(self,*args,**kwargs)
  data={'result':result,'args':args,'kwargs':kwargs}
  if method=='_compute_loss_and_metrics':data={'native_loss_and_metrics':result,'model_inputs':args[1],'grpo_batch':args[2]}
  if method=='_get_per_token_logps_and_entropies':data={'native_logps_and_entropies':result,'model_inputs':args[1],'grpo_batch':args[2]}
  save(event,data,method=method)
  return result
 setattr(GRPOTrainer,method,wrapper)
observe('_rollout_samples','rollout_observed')
observe('_compute_rewards_per_func','reward_tensor_observed')
observe('_compute_advantages','advantages_observed')
observe('_compute_loss_and_metrics','objective_observed')
observe('_get_per_token_logps_and_entropies','logps_observed')

original_create_optimizer=GRPOTrainer.create_optimizer
def create_optimizer(self,*args,**kwargs):
 result=original_create_optimizer(self,*args,**kwargs)
 names={id(p):name for name,p in self.model.named_parameters()}
 groups=[{'group':gi,'params':[{'index':pi,'name':names.get(id(p)),'shape':list(p.shape),'dtype':str(p.dtype)} for pi,p in enumerate(group['params'])],'settings':{k:v for k,v in group.items() if k!='params'}} for gi,group in enumerate(self.optimizer.param_groups)]
 (OUT/'optimizer-coordinate-map.json').write_text(json.dumps(groups,indent=2,default=str));return result
GRPOTrainer.create_optimizer=create_optimizer

original_local_logps=GRPOTrainer._get_logps_via_local_forward
def local_logps(self,model,model_inputs,logits_to_keep,input_ids,compute_entropy=False):
 if not torch.is_grad_enabled() or (OUT/'distribution_rows_observed.pt').exists():
  return original_local_logps(self,model,model_inputs,logits_to_keep,input_ids,compute_entropy)
 holder={};mask=None
 def hook(module,args,output):
  holder['logits']=output.logits
  holder['raw']=output.logits.detach().cpu().clone()
 handle=model.register_forward_hook(hook)
 try:result=original_local_logps(self,model,model_inputs,logits_to_keep,input_ids,compute_entropy)
 finally:handle.remove()
 # The original native method scales its logits slice in place before returning.
 # Capture those real transformed values, with the pretransform row for provenance.
 scaled=holder['logits'].detach().cpu()[:, -(logits_to_keep+1):-1,:]
 raw=holder['raw'][:, -(logits_to_keep+1):-1,:]
 rows=[];raw_rows=[];scaled_rows=[];native_targets=[]
 # Actual completion mask is recorded separately by the objective wrapper; select
 # first/last scored action slots here, then the exporter validates effective masks.
 for i in range(input_ids.shape[0]):
  for j in sorted(set((0,logits_to_keep-1))):
   pos=input_ids.shape[1]-logits_to_keep+j-1
   rows.append({'sample':str(i),'batch_index':i,'action_slot':j,'position':pos,'history':input_ids[i,:pos+1].detach().cpu().tolist(),'token':int(input_ids[i,pos+1].item())})
   raw_rows.append(raw[i,j]);scaled_rows.append(scaled[i,j]);native_targets.append(result[0][i,j].detach().cpu())
 derived=torch.stack(scaled_rows).float().log_softmax(-1)
 native_targets=torch.stack(native_targets)
 selected=derived.gather(-1,torch.tensor([row['token'] for row in rows])[:,None]).squeeze(-1)
 save('distribution_rows_observed',{'positions':rows,'raw_logits':torch.stack(raw_rows),'native_temperature_scaled_logits':torch.stack(scaled_rows),'full_normalized_logprobs':derived,'native_target_logprobs':native_targets,'derived_target_logprobs':selected},max_target_reconstruction_error=float((selected-native_targets).abs().max().item()),temperature=self.temperature,full_vocab_rows=len(rows),semantics='real native forward raw/scaled logits; full normalization derived in FP32; native target logprobs retained')
 return result
GRPOTrainer._get_logps_via_local_forward=local_logps

from swift.pipelines.train.rlhf import rlhf_main
rows=[{'messages':[{'role':'user','content':p}]} for p in ['Immediately choose one random digit from 0 to 9. Output only the digit.','Choose a random capital letter. Output only that letter.','Name a random color in one word.','Pick one random integer between 1 and 100.']]
data=OUT/'train.jsonl';data.write_text('\n'.join(json.dumps(row) for row in rows)+'\n')
args=['--rlhf_type','grpo','--model','/SHARED_MODELS/Qwen3-0.6B','--model_type','qwen3','--template','qwen3','--tuner_type','full','--dataset',str(data),'--reward_funcs','precision_pipeline_variation','--use_vllm','false','--num_generations','2','--max_completion_length','8','--max_length','128','--per_device_train_batch_size','2','--gradient_accumulation_steps','1','--max_steps','1','--num_train_epochs','1','--learning_rate','0.001','--weight_decay','0','--max_grad_norm','1','--optim','adamw_torch','--lr_scheduler_type','constant','--warmup_steps','0','--beta','0','--torch_dtype','bfloat16','--bf16','true','--fp16','false','--attn_impl','eager','--gradient_checkpointing','false','--padding_free','false','--use_liger_kernel','false','--save_strategy','no','--eval_strategy','no','--report_to','none','--logging_steps','1','--dataset_num_proc','1','--dataloader_num_workers','0','--dataloader_pin_memory','false','--add_version','false','--use_hf','true','--use_logits_to_keep','false','--temperature','0.9','--seed','20261020','--output_dir',str(OUT/'trained')]
args+=['--enable_thinking','false','--top_k','0','--top_p','1']
args[args.index('--temperature')+1]='1.5'
(OUT/'arguments.json').write_text(json.dumps(args,indent=2))
(OUT/'runtime.json').write_text(json.dumps({'versions':{n:md.version(n) for n in ['torch','torch-npu','ms-swift','trl','transformers','accelerate']},'torch_path':torch.__file__,'device_count':torch.npu.device_count(),'visible':os.environ.get('ASCEND_RT_VISIBLE_DEVICES'),'entry':'swift.pipelines.train.rlhf.rlhf_main','native_ops_replaced':False,'reward_quality_claimed':False},indent=2))
result=rlhf_main(args)
save('native_train_returned',{'result':result},entry='swift.pipelines.train.rlhf.rlhf_main',rank=0,world_size=1)
events=[json.loads(p.read_text()) for p in (OUT/'optimizer').glob('*.json')]
for name in ['rollout_observed','reward_observed','reward_tensor_observed','advantages_observed','objective_observed','native_train_returned']:assert (OUT/(name+'.json')).exists(),name
assert events and any(e['finite_updates'] and e['update_l2']>0 for e in events),events
(OUT/'native-completion.json').write_text(json.dumps({'status':'native_rollout_reward_group_advantage_loss_optimizer_complete','entrypoint_returned':True,'rank':0,'world_size':1,'optimizer_steps':len(events),'update_l2':[e['update_l2'] for e in events],'reward_quality_claimed':False},indent=2))
