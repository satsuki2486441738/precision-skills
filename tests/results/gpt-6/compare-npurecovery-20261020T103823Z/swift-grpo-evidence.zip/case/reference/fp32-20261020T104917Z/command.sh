#!/bin/bash
set -Euo pipefail
source /usr/local/Ascend/cann/set_env.sh
unset LOCAL_RANK RANK WORLD_SIZE LOCAL_WORLD_SIZE GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE NODE_RANK MASTER_ADDR MASTER_PORT RLAR_CAPTURE RLAR_OUTPUT RLAR_FRAMEWORK
export PYTHONPATH=/REMOTE_WORKSPACE/swift-rl/addons:"${PYTHONPATH:-}" ASCEND_RT_VISIBLE_DEVICES='' OMP_NUM_THREADS=2 TMPDIR=/tmp/swift-reference-20261020T104917Z
mkdir -p "$TMPDIR"
timeout --signal=TERM --kill-after=30s 600s /REMOTE_WORKSPACE/sft/environments/swift-trl/bin/python /REMOTE_WORKSPACE/swift-rl/drivers/reference03/swift_grpo_reference.py --native-output /REMOTE_WORKSPACE/swift-rl/results/native-grpo-20261020T104243Z --output /REMOTE_WORKSPACE/swift-rl/results/native-grpo-20261020T104243Z/reference/fp32-20261020T104917Z
rc=$?
printf '{"exit_code":%s}\n' "$rc" > /REMOTE_WORKSPACE/swift-rl/results/native-grpo-20261020T104243Z/reference/fp32-20261020T104917Z/process_exit.json
exit "$rc"
