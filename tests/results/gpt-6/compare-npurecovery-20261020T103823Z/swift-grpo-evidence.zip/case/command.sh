#!/bin/bash
set -Euo pipefail
source /usr/local/Ascend/cann/set_env.sh
unset LOCAL_RANK RANK WORLD_SIZE LOCAL_WORLD_SIZE GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE NODE_RANK MASTER_ADDR MASTER_PORT
export PATH=/REMOTE_WORKSPACE/sft/environments/swift-trl/bin:"$PATH" PYTHONPATH=/REMOTE_WORKSPACE/swift-rl/drivers/attempt05:/REMOTE_WORKSPACE/swift-rl/addons:"${PYTHONPATH:-}" PIP_CACHE_DIR=/REMOTE_WORKSPACE/swift-rl/cache/pip
export ASCEND_RT_VISIBLE_DEVICES=2 RLAR_CAPTURE=1 RLAR_OUTPUT=/REMOTE_WORKSPACE/swift-rl/results/native-grpo-20261020T104243Z RLAR_FRAMEWORK=swift-grpo PYTHONUNBUFFERED=1 TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=1
export TMPDIR=/tmp/swift-grpo-20261020T104243Z HF_HOME=/REMOTE_WORKSPACE/swift-rl/cache/huggingface XDG_CACHE_HOME=/REMOTE_WORKSPACE/swift-rl/cache TORCH_EXTENSIONS_DIR=/REMOTE_WORKSPACE/swift-rl/cache/torch_extensions
mkdir -p "$TMPDIR" "$TORCH_EXTENSIONS_DIR"
python -m pip install --no-deps --target /REMOTE_WORKSPACE/swift-rl/addons --index-url https://pypi.tuna.tsinghua.edu.cn/simple --retries 1 --timeout 15 msgspec==0.19.0 > /REMOTE_WORKSPACE/swift-rl/results/native-grpo-20261020T104243Z/private-addon-install.log 2>&1
python -m pip freeze > /REMOTE_WORKSPACE/swift-rl/results/native-grpo-20261020T104243Z/installed_freeze.txt
timeout --signal=TERM --kill-after=40s 900s python /REMOTE_WORKSPACE/swift-rl/drivers/attempt05/swift_grpo_native.py
rc=$?
printf '{"exit_code":%s}\n' "$rc" > /REMOTE_WORKSPACE/swift-rl/results/native-grpo-20261020T104243Z/process_exit.json
exit "$rc"
