"""Private, resumable official slime NPU dependency preparation. No pass claim."""
import tarfile
import concurrent.futures, datetime, hashlib, json, os, pathlib, shutil, signal, subprocess, sys, time, urllib.request, zipfile
ROOT=pathlib.Path('$RLMG_ROOT')
ROOT.mkdir(parents=True,exist_ok=True)
SESSION=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(os.getpid())
for path in ('cache/tmp','cache/pip','cache/uv','cache/pycache','python','sources','logs','state','artifacts'):(ROOT/path).mkdir(parents=True,exist_ok=True)
os.environ.update(TMPDIR=str(ROOT/'cache/tmp'),PIP_CACHE_DIR=str(ROOT/'cache/pip'),UV_CACHE_DIR=str(ROOT/'cache/uv'),UV_PYTHON_INSTALL_DIR=str(ROOT/'python'),UV_LINK_MODE='copy',UV_CONCURRENT_DOWNLOADS='2',UV_CONCURRENT_INSTALLS='2',UV_CONCURRENT_BUILDS='1',PYTHONPYCACHEPREFIX=str(ROOT/'cache/pycache'),TORCH_EXTENSIONS_DIR=str(ROOT/'cache/torch_extensions'),ASCEND_CACHE_PATH=str(ROOT/'cache/ascend'),ASCEND_RT_VISIBLE_DEVICES='12,13,14,15',MAX_JOBS='4',CMAKE_BUILD_PARALLEL_LEVEL='4',TOKENIZERS_PARALLELISM='false',HF_HUB_DISABLE_TELEMETRY='1',WANDB_MODE='disabled')
loaded=subprocess.run(['bash','-lc','source /usr/local/Ascend/cann/set_env.sh >/dev/null 2>&1 && env -0'],capture_output=True,check=True).stdout
for item in loaded.split(b'\0'):
    if b'=' in item:
        key,value=item.split(b'=',1);os.environ[os.fsdecode(key)]=os.fsdecode(value)
for key in ('RANK','WORLD_SIZE','LOCAL_RANK','LOCAL_WORLD_SIZE','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','SLURM_PROCID','SLURM_NTASKS','SLURM_LOCALID','OMPI_COMM_WORLD_RANK','OMPI_COMM_WORLD_SIZE','OMPI_COMM_WORLD_LOCAL_RANK','PMI_RANK','PMI_SIZE'):os.environ.pop(key,None)
PINS={
 'slime':('https://github.com/THUDM/slime.git','2418a7844abe4d490a1676dcf88fc3401adab362'),
 'slime-guide':('https://github.com/THUDM/slime.git','0b0c277d5b4cc66efc3b6db269e2e5184e8f3b1e'),
 'sglang':('https://github.com/sgl-project/sglang.git','dce8b0606c06d3a191a24c7b8cbe8e238ab316c9'),
 'megatron':('https://github.com/NVIDIA/Megatron-LM.git','3714d81d418c9f1bca4594fc35f9e8289f652862'),
 'bridge-npu':('https://github.com/fzyzcjy/Megatron-Bridge.git','35b4ebfc486fb15dcc0273ceea804c3606be948a'),
 'mindspeed':('https://gitcode.com/Ascend/MindSpeed.git','fc63de5c48426dd019c3b3f39e65f5bdf56e4086'),
 'nemo':('https://github.com/NVIDIA-NeMo/RL.git','26f651ea490ef2a343e7f298b9aa54bc7c5da67c'),
 'bridge-upstream':('https://github.com/NVIDIA-NeMo/Megatron-Bridge.git','c0e164ed2aedac4ad1c877780e2564a19d5d54ec'),
 'trtllm':('https://github.com/NVIDIA/TensorRT-LLM.git','7965842954628b0b5456a2f7d59786d3dcd41647')}
def dump(path,value):
    path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(value,indent=2,default=str));os.replace(tmp,path)
PINS['mbridge']=('https://github.com/ISEEKYAN/mbridge.git','89eb10887887bc74853f89a4de258c0702932a1c')
dump(ROOT/'source-pins.json',PINS)
def run(name,command,cwd=None,timeout=900,required=True,cache=False,env=None):
    command=list(map(str,command));signature=hashlib.sha256(json.dumps([command,str(cwd)]).encode()).hexdigest();marker=ROOT/'state'/(name+'.json')
    if cache and marker.exists() and json.loads(marker.read_text()).get('signature')==signature:
        print('NPU_STAGE_REUSE '+name,flush=True);return 0
    log=ROOT/'logs'/(name+'-'+SESSION+'.log');item={'name':name,'command':command,'cwd':str(cwd),'log':str(log),'session':SESSION,'signature':signature}
    print('NPU_STAGE '+name,flush=True);start=time.monotonic()
    with log.open('w') as stream:
        process=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        try:rc=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=20)
            except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
            rc=124
    item.update(returncode=rc,seconds=time.monotonic()-start)
    with (ROOT/'stage-history.jsonl').open('a') as stream:stream.write(json.dumps(item)+'\n')
    if rc==0 and cache:dump(marker,item)
    print('NPU_STAGE_DONE '+json.dumps(item),flush=True)
    if rc and required:raise RuntimeError(name+' failed; '+str(log))
    return rc
def unpack_offline():
    archive=ROOT/'cache/sources-offline.tar.gz'
    assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()=='8e29bd8564ff796092615099fb48c199369c7e2e06978bd4b21b02d679bba052'
    destination=ROOT/'sources-offline-v1'
    marker=destination/'.complete'
    if not marker.exists():
        if destination.exists():destination.rename(ROOT/('incomplete-sources-'+SESSION))
        destination.mkdir()
        with tarfile.open(archive) as tf:tf.extractall(destination,filter='data')
        marker.write_text('verified offline source bundle')
    return destination
def clone(name):
    dest=ROOT/'sources-offline-v1'/name
    if not dest.exists():raise RuntimeError('Offline source not included: '+name)
    actual=subprocess.check_output(['git','-c','safe.directory='+str(dest),'rev-parse','HEAD'],cwd=dest,text=True).strip()
    assert actual==PINS[name][1],(name,actual,PINS[name][1])
    return dest
def patch(name,tree,path):
    git=['git','-c','safe.directory='+str(tree)]
    # Preserve the published bytes and direct-apply diagnostic before repairing diff formatting.
    original=path.read_text(encoding='utf8')
    rawlog=ROOT/'logs'/('official-patch-check-'+name+'-'+SESSION+'.log')
    direct=subprocess.run(git+['apply','--check',str(path)],cwd=tree,capture_output=True,text=True)
    rawlog.write_text(direct.stdout+direct.stderr,encoding='utf8')
    source=original
    adaptations=[]
    if name=='slime-npu':
        source=source.replace(' from slime.observability import train_data_utils, train_metric_utils',' from slime.utils import train_dump_utils').replace('from slime.observability.logging_utils','from slime.utils.logging_utils').replace(' from slime.observability.metric_utils import has_repetition',' from ..utils.metric_utils import has_repetition')
        adaptations.append('Context-only mapping to v0.2.2 existing utils module names')
    if name=='sglang-npu':
        # The published VLM hunk fails at this exact prescribed SGLang commit. It is unused by this text Qwen3 test.
        source='diff --git '+('diff --git '.join(section for section in original.split('diff --git ') if section and not section.startswith('a/python/sglang/srt/models/qwen3_vl.py ')))
        adaptations.append('Exclude unused Qwen3-VL file whose original hunk does not apply; keep text Qwen3/NPU kernels unchanged')
    active=False;lines=[]
    for line in source.splitlines():
        if line.startswith('@@'):active=True
        if line.startswith('diff --git'):active=False
        if active and line=='':line=' '
        lines.append(line)
    normalized=ROOT/'artifacts'/('normalized-'+name+'-'+SESSION+'.patch')
    normalized.write_text('\n'.join(lines)+'\n',encoding='utf8')
    dump(ROOT/'artifacts'/('patch-adaptations-'+name+'-'+SESSION+'.json'),{'official_file':str(path),'official_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'direct_check_returncode':direct.returncode,'adaptations':adaptations,'format_repairs':'blank context prefix + git --recount; inaccurate-eof removed after actual syntax failure','applied_sha256':hashlib.sha256(normalized.read_bytes()).hexdigest()})
    flags=['--recount','--whitespace=nowarn']
    if subprocess.run(git+['apply','--reverse','--check',*flags,str(normalized)],cwd=tree,capture_output=True).returncode==0:return
    run('apply-'+name,git+['apply',*flags,str(normalized)],cwd=tree,timeout=60)
def download_kernel():
    name='sgl-kernel-npu-2026.02.01-torch2.8.0-py311-cann8.5.0-a3-aarch64.zip';dest=ROOT/'cache'/name
    if not dest.exists():
        temporary=dest.with_suffix('.partial')
        with urllib.request.urlopen('https://github.com/sgl-project/sgl-kernel-npu/releases/download/2026.02.01/'+name,timeout=120) as response,temporary.open('wb') as stream:shutil.copyfileobj(response,stream,1024*1024)
        os.replace(temporary,dest)
    assert hashlib.sha256(dest.read_bytes()).hexdigest()=='1fdff482be90fd61a32f7100642afe8836722e21ec87ef223bfd6b0448818e44'
    dump(ROOT/'artifacts/kernel-download.json',{'path':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
    target=ROOT/'cache/kernel-wheels';target.mkdir(exist_ok=True)
    with zipfile.ZipFile(dest) as archive:
        for item in archive.infolist():
            if item.filename.endswith('.whl'):
                output=target/pathlib.Path(item.filename).name
                if not output.exists():output.write_bytes(archive.read(item))
    return target
def main():
    tooling=ROOT/'environments/tooling';tooling.parent.mkdir(exist_ok=True)
    if not (tooling/'bin/python').exists():run('tooling-venv',[sys.executable,'-m','venv','--system-site-packages',tooling])
    if not (tooling/'bin/uv').exists():run('tooling-uv',[tooling/'bin/python','-m','pip','install','--no-compile','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','uv==0.8.22'])
    uv=str(tooling/'bin/uv');os.environ['PATH']=str(tooling/'bin')+os.pathsep+os.environ['PATH']
    archive=ROOT/'cache/cpython311.tar.gz'; assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()=='fc5611d684356e9c560f53c6b1525318a9b0f49a3a1bc8cef11eb3b41c19d786'
    pyroot=ROOT/'python/cpython311-offline'
    if not (pyroot/'python/bin/python3.11').exists():
        pyroot.mkdir(exist_ok=True)
        with tarfile.open(archive) as tf:tf.extractall(pyroot,filter='data')
    managed=str(pyroot/'python/bin/python3.11')
    venv=ROOT/'environments/slime-official-py311'
    if not (venv/'bin/python').exists():run('slime-venv',[uv,'venv','--python',managed,venv])
    python=str(venv/'bin/python')
    constraints=ROOT/'constraints-slime28.txt';constraints.write_text('torch==2.8.0\ntorch-npu==2.8.0\ntorchvision==0.23.0\nnumpy==1.26.4\ntransformers==4.57.1\nsetuptools<80\ntriton-ascend==3.2.0\n')
    pip=[uv,'pip','install','--python',python,'--constraint',str(constraints),'--index-url','https://pypi.tuna.tsinghua.edu.cn/simple']
    run('slime-torch28',pip+['torch==2.8.0','torch-npu==2.8.0','torchvision==0.23.0','numpy==1.26.4','setuptools<80','wheel','packaging','ninja','psutil','pybind11','einops','pyyaml'],timeout=1800,cache=True)
    # Version/ABI check happens before installing the large serving stack.
    check="import torch,torch_npu;print(torch.__version__,torch_npu.__version__,torch.npu.get_device_name(0));x=torch.ones(4,device='npu:0');print((x+x).cpu())"
    run('slime-torch28-native-npu-abi',[python,'-c',check],timeout=180)
    if '--prerequisites-only' in sys.argv:
        dump(ROOT/'prerequisites-ready.json',{'python':python,'stage':'real NPU tensor ABI prerequisite only; no native framework coverage'})
        return
    unpack_offline()
    sources={}
    for name in ('slime','slime-guide','megatron','mindspeed','bridge-npu','sglang','nemo','bridge-upstream','mbridge'):
        try:sources[name]=str(clone(name))
        except Exception as exc:dump(ROOT/'artifacts'/('source-failure-'+name+'-'+SESSION+'.json'),{'error':repr(exc)})
    dump(ROOT/'sources-ready.json',sources)
    required=('slime','slime-guide','megatron','mindspeed','bridge-npu','sglang')
    if any(name not in sources for name in required):raise RuntimeError('Missing one or more official pinned sources')
    sources={key:pathlib.Path(value) for key,value in sources.items()}
    guide=sources['slime-guide']/'docker/npu_patch'
    # Rebuild only our private patched trees deterministically after any interrupted apply.
    # Save all prior worktree deltas before resetting; sources are never shared/base checkouts.
    for name in ('slime','megatron','mindspeed','bridge-npu','sglang'):
        tree=sources[name];git=['git','-c','safe.directory='+str(tree)]
        delta=subprocess.check_output(git+['diff','--binary'],cwd=tree)
        if delta:(ROOT/'artifacts'/('prior-source-delta-'+name+'-'+SESSION+'.patch')).write_bytes(delta)
        run('reset-private-source-'+name,git+['reset','--hard','HEAD'],cwd=tree,timeout=120)
        candidates=[]
        filenames={'slime':'slime.patch','megatron':'megatron.patch','mindspeed':'mindspeed.patch','bridge-npu':'megatron-bridge.patch','sglang':'sglang.patch'}
        patchfiles=[guide/filenames[name]]
        if name in ('megatron','sglang'):patchfiles.append(sources['slime']/'docker/patch/v0.5.7'/(name+'.patch'))
        for patchfile in patchfiles:
            lines=patchfile.read_text(encoding='utf8').splitlines()
            for index,line in enumerate(lines[:-1]):
                if line=='--- /dev/null' and lines[index+1].startswith('+++ b/'):
                    relative=lines[index+1][6:];candidate=(tree/relative).resolve()
                    assert candidate.is_relative_to(tree.resolve())
                    tracked=subprocess.run(git+['ls-files','--error-unmatch',relative],cwd=tree,capture_output=True).returncode==0
                    if candidate.is_file() and not tracked:
                        saved=ROOT/'artifacts'/('prior-added-files-'+SESSION)/name/relative;saved.parent.mkdir(parents=True,exist_ok=True)
                        shutil.copy2(candidate,saved);candidate.unlink();candidates.append(relative)
        dump(ROOT/'artifacts'/('reset-added-files-'+name+'-'+SESSION+'.json'),{'preserved_then_removed':candidates})
    # Follow the published NPU pyproject selection instead of CUDA extras.
    sglang=sources['sglang'];replacement=sglang/'python/pyproject_other.toml';target=sglang/'python/pyproject.toml'
    if replacement.exists():
        backup=target.with_name('pyproject.original.toml')
        if not backup.exists():shutil.copy2(target,backup)
        target.write_bytes(replacement.read_bytes())
    for name in ('megatron','sglang'):patch(name+'-base',sources[name],sources['slime']/'docker/patch/v0.5.7'/(name+'.patch'))
    for name,file in (('slime','slime.patch'),('megatron','megatron.patch'),('sglang','sglang.patch'),('bridge-npu','megatron-bridge.patch'),('mindspeed','mindspeed.patch')):patch(name+'-npu',sources[name],guide/file)
    kernel=download_kernel()
    wheels=sorted(kernel.glob('*.whl'))
    run('slime-npu-kernels',pip+list(map(str,wheels)),timeout=600,cache=True)
    run('slime-sglang-npu',pip+['-e',str(sglang/'python')+'[srt_npu]'],timeout=1800,cache=True)
    for name in ('megatron','mindspeed','bridge-npu'):
        run('slime-install-'+name,pip+['-e',sources[name],'--no-deps','--no-build-isolation'],timeout=900,cache=True)
    run('slime-mbridge',pip+['-e',sources['mbridge'],'--no-deps','--no-build-isolation'],timeout=600,cache=True)
    run('slime-modelopt',pip+['nvidia-modelopt[torch]==0.37.0','--no-build-isolation'],timeout=900,cache=True)
    run('slime-package',pip+['-e',sources['slime'],'triton-ascend==3.2.0','omegaconf','hydra-core','tensorboard','rich','datasets','sentencepiece','accelerate','pytest','transformers==4.57.1'],timeout=1200,cache=True)
    run('slime-freeze',[uv,'pip','freeze','--python',python],timeout=90,required=False)
    dump(ROOT/'official-environment-ready.json',{'python':python,'sources':{key:str(value) for key,value in sources.items()},'published_cann':'8.5.0','actual_cann':'9.1.0','compatibility_status':'native NPU ABI check passed; full framework still unexecuted','guide':str(guide/'README.md')})
if __name__=='__main__':
    try:main()
    except Exception as exc:
        import traceback
        dump(ROOT/'artifacts'/('setup-failure-'+SESSION+'.json'),{'error':repr(exc),'traceback':traceback.format_exc()});raise
