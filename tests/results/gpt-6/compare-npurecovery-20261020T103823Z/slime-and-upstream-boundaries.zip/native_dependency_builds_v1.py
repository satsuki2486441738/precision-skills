"""Actual unmodified native configure/build entrypoints for hardware dependencies."""
import os,sys,tarfile
import repair_upstream_native_v3 as r
root=r.root;out=r.out;uv=root/'environments/tooling/bin/uv'
envroot=root/'environments/native-cuda-dependency-builds';py=envroot/'bin/python'
if not py.exists():r.run('private-build-venv',[uv,'venv','--system-site-packages','--python',sys.executable,envroot])
r.run('private-build-prerequisites',[uv,'pip','install','--python',py,'--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','cmake>=3.27','ninja','pybind11','setuptools<80','wheel','packaging'],timeout=300)
with tarfile.open(root/'cache/trtllm-native-configure.tar.gz') as t:t.extractall(root/'upstream-early',filter='data')
cmake=envroot/'bin/cmake'
r.run('trtllm-official-native-cmake-configure',[cmake,'-S',root/'upstream-early/trtllm-native-build/cpp','-B',root/'build/trtllm-native-configure','-DCMAKE_BUILD_TYPE=Release','-DBUILD_PYT=ON','-DBUILD_PYBIND=ON','-DBUILD_TESTS=OFF','-DBUILD_BENCHMARKS=OFF','-DENABLE_MULTI_DEVICE=ON'],timeout=180)
env=os.environ.copy();env['NVTE_FRAMEWORK']='pytorch'
r.run('bridge-transformer-engine-official-source-build',[uv,'pip','install','--python',py,'--no-deps','--no-build-isolation','transformer-engine[pytorch] @ git+https://github.com/NVIDIA/TransformerEngine.git@15288857644368b8b7bdddd9bead7d6d3d04de80'],env=env,timeout=600)
r.run('dependency-build-freeze',[uv,'pip','freeze','--python',py])
