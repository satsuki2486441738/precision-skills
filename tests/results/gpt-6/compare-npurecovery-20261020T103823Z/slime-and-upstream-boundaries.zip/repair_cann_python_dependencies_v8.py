import subprocess,sys
import prepare_official_npu_v4 as p
root=p.ROOT;py=root/'environments/slime-official-py311/bin/python'
p.run('slime-cann-compiler-python-dependencies',[root/'environments/tooling/bin/uv','pip','install','--python',py,'--constraint',root/'constraints-slime28.txt','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','decorator==5.2.1','attrs','cffi','absl-py','scipy==1.15.3'],timeout=300)
subprocess.run([sys.executable,str(root/'repair_triton_dtfs_cleanup_v7.py')],check=True)
