import datetime,fcntl,json,os,pathlib,subprocess,sys,traceback
ROOT=pathlib.Path('$RLMG_ROOT')
SESSION=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(os.getpid())
for key in ('RANK','WORLD_SIZE','LOCAL_RANK','LOCAL_WORLD_SIZE','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','PMI_RANK','PMI_SIZE'):os.environ.pop(key,None)
def main():
 if '--driver' not in sys.argv:
  log=ROOT/'logs'/('slime-pipeline-'+SESSION+'.log')
  with log.open('w') as out:p=subprocess.Popen([sys.executable,str(ROOT/'slime_pipeline_v4.py'),'--driver'],stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  print(json.dumps({'pid':p.pid,'log':str(log),'scope':'Slime official NPU native pipeline; upstream native cases already run independently'}));return
 lock=(ROOT/'state/slime-pipeline.lock').open('a+')
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:print('Owned Slime pipeline already running',flush=True);return
 sys.path.insert(0,str(ROOT));import prepare_official_npu_v4 as prep
 try:
  prep.main()
  prep.run('slime-native-train',[ROOT/'environments/slime-official-py311/bin/python',ROOT/'slime_npu_native.py'],timeout=1200)
 except BaseException as error:
  (ROOT/'artifacts'/('slime-pipeline-failure-'+SESSION+'.json')).write_text(json.dumps({'error':repr(error),'traceback':traceback.format_exc()},indent=2));raise
if __name__=='__main__':main()
