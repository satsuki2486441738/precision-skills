import datetime,hashlib,json,os,pathlib,time
import prepare_official_npu_v4 as p
root=p.ROOT;py=root/'environments/slime-official-py311/bin/python'
wheel=root/'cache/triton_ascend-3.2.2-cp311-cp311-manylinux_2_27_aarch64.manylinux_2_28_aarch64.whl'
deadline=time.monotonic()+1200
while not wheel.exists():
 if time.monotonic()>deadline:raise TimeoutError('Await verified chunk-transferred official wheel')
 time.sleep(5)
assert hashlib.file_digest(wheel.open('rb'),'sha256').hexdigest()=='f094fcfd7c387b2d25fa746fb784b6e4ef34ca21dedf66271ff57b6f56ca4abf'
p.run('slime-cann91-official-local-triton322-wheel',[root/'environments/tooling/bin/uv','pip','install','--python',py,'--no-deps',wheel],timeout=300)
p.run('slime-native-cann91-triton322-full-grpo',[py,root/'slime_npu_native.py'],timeout=1200)
