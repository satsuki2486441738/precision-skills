import repair_upstream_native_v3 as r
root=r.root;uv=root/'environments/tooling/bin/uv';py=root/'environments/upstream-startups/bin/python'
r.run('trtllm-real-openmpi-runtime-prerequisites',[uv,'pip','install','--python',py,'--no-deps','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','nvtx','mpi4py','openmpi==5.0.11'],timeout=300)
prior=sorted((root/'attempts').glob('upstream-native-startups-20261020T101508Z-*/trt-native-llm.py'))[0]
r.run('trtllm-official-native-llm-bindings-retry',[py,prior],timeout=180)
