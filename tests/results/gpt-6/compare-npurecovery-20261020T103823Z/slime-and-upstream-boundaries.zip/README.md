# Native Slime and upstream dependency evidence

Slime completed one real NPU GRPO rollout and optimizer step on pretrained
Qwen3-0.6B: 8 trajectories, 64 generated action tokens, actual native optimizer
return, positive finite sampled gradients and parameter changes, successful
native checkpoint save and process exit0. STATUS.json records exact observations.
No independent Slime numerical-equivalence comparison was run.

All frozen raw logs, Ray worker logs, attempts, source/patch deltas, environment
freezes/checks and sampled PT artifacts are included without tail truncation.
Checkpoint payloads (weights/optimizer states) remain private; the complete
original per-file SHA inventory is included. The original pretrained model is
not redistributed. A small seeded random Qwen2 model belongs to the failed
TensorRT-LLM startup fixture and must not be confused with Slime pretrained use.

Binary PT tensor files are original bytes. They contain sampled first16 eligible
trainables, not complete model gradients. BF16 parameter values were losslessly
promoted to FP32 by the observer. Original gradient dtype was not recorded;
do not invent it from the saved FP32 derivative. Native losses, response/token
data and sampling coordinate metadata are included. No reference tensors exist.

The historical Slime NPU deployment prescribes CANN8.5/TorchNPU2.8, whereas
this host has CANN9.1. Disclosed private repairs include diff formatting/context,
unused VLM-hunk exclusion, actual NPU backend registration, PyArrow pin,
official gradient-fusion disable flag, Triton Ascend3.2.2 wheel, CANN Python
dependencies, short persistent IPC with real TMPDIR validation, compile-worker
limits, best-effort cache cleanup and same Ascend slice-op namespace migration.
The slice migration also passed an exact real-NPU primitive conformance test.
None of these observations establishes an officially supported full matrix.

NeMo RL entered its unchanged worker constructor and failed at NCCL.
Untouched upstream Megatron Bridge was blocked before provider construction by
Transformer Engine; its exact native source build failed for absent CUDA/NVCC.
TensorRT-LLM official ARM bindings and unchanged CMake configuration exposed
CUDA prerequisites before LLM construction/generation. Vendor/fork NPU ports
are distinct identities and are not substituted for untouched upstream success.

Text is redacted to remove runtime IP/host/account paths. Restore task/model
paths before any native rerun. EXPORT.json records both original and exported
hashes and the private raw archive digest; RAW-MANIFEST.json preserves original
relative-file identities. Binary payload hashes are unchanged. These manifests
provide byte consistency, not independent authenticity. No credentials or SSH
identity files are included. Pickle-bearing PT files require trusted loading.
