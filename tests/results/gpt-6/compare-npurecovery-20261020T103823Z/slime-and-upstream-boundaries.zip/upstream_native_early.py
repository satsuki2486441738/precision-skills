"""Unmodified upstream native API startup attempts on Ascend; failures never pass."""
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

ROOT=Path('$RLMG_ROOT')
RANK_ENV_KEYS=['RANK', 'WORLD_SIZE', 'LOCAL_RANK', 'LOCAL_WORLD_SIZE', 'GROUP_RANK', 'ROLE_RANK', 'ROLE_WORLD_SIZE', 'MASTER_ADDR', 'MASTER_PORT', 'NODE_RANK', 'LOCAL_SIZE', 'SLURM_PROCID', 'SLURM_NTASKS', 'SLURM_LOCALID', 'OMPI_COMM_WORLD_RANK', 'OMPI_COMM_WORLD_SIZE', 'OMPI_COMM_WORLD_LOCAL_RANK', 'PMI_RANK', 'PMI_SIZE']
INHERITED_RANK_ENV={key:os.environ.pop(key) for key in RANK_ENV_KEYS if key in os.environ}
SESSION=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(os.getpid())
OUT=ROOT/'attempts'/('upstream-native-startups-'+SESSION)
OUT.mkdir(parents=True)
(OUT/'discarded-platform-rank-env.json').write_text(json.dumps(INHERITED_RANK_ENV,indent=2),encoding='utf8')
os.environ.update(ASCEND_RT_VISIBLE_DEVICES='12,13,14,15',TMPDIR=str(ROOT/'cache/tmp'),
    PIP_CACHE_DIR=str(ROOT/'cache/pip'),UV_CACHE_DIR=str(ROOT/'cache/uv'),
    PYTHONPYCACHEPREFIX=str(ROOT/'cache/pycache'),TORCH_EXTENSIONS_DIR=str(ROOT/'cache/torch_extensions'),
    HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',
    WANDB_MODE='disabled',MAX_JOBS='4',RANK='0',WORLD_SIZE='1',MASTER_ADDR='<runtime-ip>',MASTER_PORT='29961')

def run(name,argv,env=None,timeout=180):
    log=OUT/(name+'.log'); start=datetime.datetime.now(datetime.timezone.utc)
    with log.open('w') as stream:
        p=subprocess.Popen(list(map(str,argv)),stdout=stream,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        try:rc=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(20)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            rc=124
    result={'name':name,'command':list(map(str,argv)),'returncode':rc,'log':str(log),
            'seconds':(datetime.datetime.now(datetime.timezone.utc)-start).total_seconds(),
            'scope':'native startup attempt; not successful numerical coverage'}
    (OUT/(name+'.json')).write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps(result),flush=True)
    return rc

def main():
    envroot=ROOT/'environments/upstream-startups'
    if not (envroot/'bin/python').exists():run('venv',[sys.executable,'-m','venv','--system-site-packages',envroot])
    py=envroot/'bin/python';uv=ROOT/'environments/tooling/bin/uv'
    # Install only missing pure/runtime prerequisites privately, retaining the actual host Torch/NPU.
    run('prerequisites',[uv,'pip','install','--python',py,'--index-url','https://pypi.tuna.tsinghua.edu.cn/simple',
        'transformers==4.57.1','accelerate','colored==2.2.3','omegaconf','hydra-core','torchdata','nvidia-ml-py','rich','einops','packaging','setuptools<80','wheel','pybind11'],timeout=600)
    if '--prerequisites-only' in sys.argv:return
    # Attempt real distributions before entrypoints. Missing CUDA runtime dependencies remain explicit failures,
    # and are never replaced with simulated bindings or a different framework.
    for name in ('nemo','bridge-upstream'):
        run(name+'-official-editable-install',[uv,'pip','install','--python',py,'--no-deps','--no-build-isolation',
            '--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','-e',ROOT/'upstream-early'/name],timeout=300)
    nemo='''import torch, torch_npu
from transformers import AutoTokenizer
from nemo_reinforcer.models.policy.fsdp1_policy_worker import FSDP1PolicyWorker
cfg={'model_name':'/host-model/Qwen3-0.6B','precision':'float32','activation_checkpointing_enabled':False,'fsdp_offload_enabled':False,'optimizer':{'name':'torch.optim.AdamW','kwargs':{'lr':0.0001}},'train_global_batch_size':1,'train_micro_batch_size':1,'max_grad_norm':1.0}
print('NATIVE_WORKER_CONSTRUCTOR',torch.__version__,torch_npu.__version__,flush=True)
tokenizer=AutoTokenizer.from_pretrained('/host-model/Qwen3-0.6B',local_files_only=True)
worker=FSDP1PolicyWorker.__ray_metadata__.modified_class(cfg,tokenizer,init_reference_model=False)
print('NATIVE_WORKER_CONSTRUCTED',flush=True)
'''
    nemo_file=OUT/'nemo-native-worker.py';nemo_file.write_text(nemo,encoding='utf8')
    env=os.environ.copy();env['PYTHONPATH']=str(ROOT/'upstream-early/nemo')+os.pathsep+env.get('PYTHONPATH','')
    run('nemo-native-worker',[py,nemo_file],env)
    bridge='''from megatron.bridge.models.gpt_provider import GPTModelProvider
provider=GPTModelProvider(num_layers=2,hidden_size=128,ffn_hidden_size=256,num_attention_heads=4,vocab_size=256,seq_length=32)
print('NATIVE_BRIDGE_PROVIDE_DISTRIBUTED_MODEL',flush=True)
provider.provide_distributed_model(wrap_with_ddp=False)
'''
    bridge_file=OUT/'bridge-native-provider.py';bridge_file.write_text(bridge,encoding='utf8')
    env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join([str(ROOT/'upstream-early/bridge-upstream/src'),str(ROOT/'upstream-early/megatron'),env.get('PYTHONPATH','')])
    run('bridge-upstream-native-provider',[py,bridge_file],env)
    trt_install=run('trtllm-official-wheel-install',[uv,'pip','install','--python',py,'--no-deps',
        '--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','--extra-index-url','https://pypi.nvidia.com',
        '--index-strategy','unsafe-best-match','tensorrt-llm==0.20.0'],timeout=600)
    trt='''import pathlib, torch
from tokenizers import Tokenizer
from tokenizers.models import WordLevel
from tokenizers.pre_tokenizers import Whitespace
from transformers import Qwen2Config, Qwen2ForCausalLM, PreTrainedTokenizerFast
fixture=pathlib.Path(__file__).parent/'seeded-random-qwen2'
torch.manual_seed(20261020)
config=Qwen2Config(vocab_size=256,hidden_size=256,intermediate_size=512,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=128,tie_word_embeddings=False,bos_token_id=1,eos_token_id=2,pad_token_id=0)
model=Qwen2ForCausalLM(config)
model.save_pretrained(fixture)
vocab={'<pad>':0,'<s>':1,'</s>':2,'<unk>':3,**{f'tok{i}':i for i in range(4,256)}}
raw=Tokenizer(WordLevel(vocab,unk_token='<unk>'));raw.pre_tokenizer=Whitespace()
PreTrainedTokenizerFast(tokenizer_object=raw,pad_token='<pad>',bos_token='<s>',eos_token='</s>',unk_token='<unk>').save_pretrained(fixture)
from tensorrt_llm import LLM, SamplingParams
print('NATIVE_TRTLLM_LLM_CONSTRUCTOR',flush=True)
llm=LLM(model=str(fixture))
outputs=llm.generate(['tok10 tok11 tok12'],SamplingParams(max_tokens=8,temperature=0.8))
print(outputs)
'''
    trt_file=OUT/'trt-native-llm.py';trt_file.write_text(trt,encoding='utf8')
    env=os.environ.copy()
    if trt_install:
        print('TRT official wheel installation failed; subsequent source-API startup remains dependency-blocked, never a numerical pass.',flush=True)
        env['PYTHONPATH']=str(ROOT/'upstream-early/trtllm')+os.pathsep+env.get('PYTHONPATH','')
    run('trtllm-native-llm',[py,trt_file],env)
    run('environment-freeze',[uv,'pip','freeze','--python',py])
    print('RLMG_UPSTREAM_ATTEMPTS '+str(OUT),flush=True)

if __name__=='__main__':main()
