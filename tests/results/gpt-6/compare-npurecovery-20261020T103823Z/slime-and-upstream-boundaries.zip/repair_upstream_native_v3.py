import datetime,json,os,pathlib,signal,subprocess,sys,tarfile
root=pathlib.Path('$RLMG_ROOT')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(os.getpid())
out=root/'attempts'/('upstream-repair-'+stamp);out.mkdir(parents=True)
for k in ['LOCAL_RANK','RANK','WORLD_SIZE','LOCAL_WORLD_SIZE','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','LOCAL_SIZE']:
 os.environ.pop(k,None)
os.environ.update(ASCEND_RT_VISIBLE_DEVICES='12,13,14,15',TMPDIR=str(root/'cache/tmp'),UV_CACHE_DIR=str(root/'cache/uv'),PYTHONPYCACHEPREFIX=str(root/'cache/pycache'),MAX_JOBS='4',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',RANK='0',WORLD_SIZE='1',MASTER_ADDR='<runtime-ip>',MASTER_PORT='29961')
def run(name,args,env=None,timeout=600,cwd=None):
 log=out/(name+'.log');t=datetime.datetime.now(datetime.timezone.utc)
 with log.open('w') as f:
  p=subprocess.Popen(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True,cwd=cwd)
  try:rc=p.wait(timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=124
 record={'command':list(map(str,args)),'returncode':rc,'seconds':(datetime.datetime.now(datetime.timezone.utc)-t).total_seconds(),'log':str(log),'numerical_pass':False}
 (out/(name+'.json')).write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
 return rc
def main():
 uv=root/'environments/tooling/bin/uv';py=root/'environments/upstream-startups/bin/python'
 with tarfile.open(root/'cache/bridge-mcore-correct.tar.gz') as t:t.extractall(root/'upstream-early',filter='data')
 (out/'bridge-source-compatibility.json').write_text(json.dumps({'bridge':'c0e164ed2aedac4ad1c877780e2564a19d5d54ec','mcore_gitlink':'a0f793dfa4e776d99a8aa63bed74e0fafc91b0db','prior_mcore_was_slime_recipe_pin':True},indent=2))
 constraints=out/'constraints.txt';constraints.write_text('torch==2.9.0\ntorch-npu==2.9.0.post2\nnumpy==1.26.4\n')
 run('bridge-native-prerequisites',[uv,'pip','install','--python',py,'--constraint',constraints,'--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','numpy==1.26.4','transformers==5.12.1','peft==0.18.1','diffusers==0.36.0','mistral-common>=1.10.0','qwen-vl-utils','tensorboard>=2.19.0'],timeout=600)
 script=out/'bridge-native-provider.py';script.write_text("from megatron.bridge.models.gpt_provider import GPTModelProvider\np=GPTModelProvider(num_layers=2,hidden_size=128,ffn_hidden_size=256,num_attention_heads=4,vocab_size=256,seq_length=32)\nprint('NATIVE_BRIDGE_PROVIDE_DISTRIBUTED_MODEL',flush=True)\np.provide_distributed_model(wrap_with_ddp=False)\n")
 env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join([str(root/'upstream-early/bridge-upstream/src'),str(root/'upstream-early/bridge-mcore-correct'),env.get('PYTHONPATH','')])
 run('bridge-upstream-native-provider',[py,script],env,180)
 # Retry official index alone: preserve the prior mirror DNS failure separately.
 wheel='https://pypi.nvidia.com/tensorrt-llm/tensorrt_llm-0.20.0-cp312-cp312-linux_aarch64.whl#sha256=6f3a5c90202ff376bdbe28c71b95117b0518fd354daa3a7cc2c432f6152a589e'
 rc=run('trtllm-official-wheel-retry',[uv,'pip','install','--python',py,'--no-deps',wheel],timeout=900)
 if rc==0:
  run('tensorrt-official-runtime-dependency',[uv,'pip','install','--python',py,'--index-url','https://pypi.nvidia.com','tensorrt==10.10.0.31','cuda-python==12.9.0'],timeout=900)
  prior=next(sorted((root/'attempts').glob('upstream-native-startups-20261020T101508Z-*/trt-native-llm.py')))
  run('trtllm-native-llm',[py,prior],timeout=180)
 run('freeze',[uv,'pip','freeze','--python',py],timeout=180)
if __name__=='__main__':main()
