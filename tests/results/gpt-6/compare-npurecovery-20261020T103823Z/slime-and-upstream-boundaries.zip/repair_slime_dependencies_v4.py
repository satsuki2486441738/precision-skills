import datetime,json,pathlib,subprocess
import prepare_official_npu_v4 as p
root=p.ROOT;py=root/'environments/slime-official-py311/bin/python'
p.run('slime-pyarrow-numpy1-runtime-repair',[root/'environments/tooling/bin/uv','pip','install','--python',py,'--constraint',root/'constraints-slime28.txt','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','pyarrow==21.0.0'],timeout=600)
p.run('slime-pyarrow-real-import',[py,'-c','import numpy,pyarrow; print(numpy.__version__,pyarrow.__version__)'],timeout=120)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');log=root/'logs'/('slime-native-pyarrow-repair-'+stamp+'.log')
with log.open('wb') as f:child=subprocess.Popen([str(py),str(root/'slime_npu_native.py')],stdout=f,stderr=subprocess.STDOUT,cwd=root,start_new_session=True)
print(json.dumps({'pid':child.pid,'log':str(log),'scope':'correct dependency wheel compatible with existing numpy1.26.4; unchanged native training'}))
