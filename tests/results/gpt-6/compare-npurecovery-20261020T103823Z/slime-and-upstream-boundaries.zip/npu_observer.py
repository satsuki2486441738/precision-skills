"""Observation only, called immediately around the unchanged native optimizer step."""
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import torch

_snapshots = {}

def _dump(path, item):
    path.write_text(json.dumps(item, indent=2, default=str), encoding="utf8")

def _parameters(models):
    for chunk, model in enumerate(models):
        for name, parameter in model.named_parameters():
            if parameter.requires_grad and 32 <= parameter.numel() <= 5_000_000:
                yield f"chunk{chunk}.{name}", parameter

def _cpu(value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {key: _cpu(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return type(value)(_cpu(item) for item in value)
    return value

def before(models):
    output = Path(os.environ["RLMG_EVIDENCE"])
    output.mkdir(parents=True, exist_ok=True)
    rank = torch.distributed.get_rank()
    selected = list(_parameters(models))[:16]
    values, gradients, layout = {}, {}, {}
    for name, parameter in selected:
        stride = max(1, parameter.numel() // 16384)
        values[name] = parameter.detach().flatten()[::stride].float().cpu().clone()
        gradient = getattr(parameter, "main_grad", None)
        if gradient is None:
            gradient = parameter.grad
        if gradient is not None:
            gradients[name] = gradient.detach().flatten()[::stride].float().cpu().clone()
        layout[name] = {"shape": list(parameter.shape), "dtype": str(parameter.dtype),
                        "device": str(parameter.device), "sampling_stride": stride}
    frame = inspect.currentframe().f_back
    caller = Path(frame.f_code.co_filename)
    key = (rank, len(list(output.glob(f"rank{rank}-step*-before.pt"))))
    _snapshots[key] = (values, gradients, selected, layout)
    torch.save({"parameters": values, "gradients": gradients}, output / f"rank{rank}-step{key[1]}-before.pt")
    torch.save(_cpu(frame.f_locals.get("losses_reduced")), output / f"rank{rank}-step{key[1]}-native-losses.pt")
    _dump(output / f"rank{rank}-step{key[1]}-caller.json", {
        "file": str(caller), "source_sha256": hashlib.sha256(caller.read_bytes()).hexdigest(),
        "function": frame.f_code.co_name, "line": frame.f_lineno,
        "torch": torch.__version__, "torch_npu": __import__("torch_npu").__version__,
        "distributed_backend": torch.distributed.get_backend(),
        "visible_devices": os.environ.get("ASCEND_RT_VISIBLE_DEVICES"),
        "npu_name": torch.npu.get_device_name(torch.npu.current_device()),
        "parameters": layout, "native_losses_reduced": frame.f_locals.get("losses_reduced"),
    })
    return key

def after(key, optimizer_result):
    values, gradients, selected, layout = _snapshots.pop(key)
    output = Path(os.environ["RLMG_EVIDENCE"])
    after_values = {}
    for name, parameter in selected:
        after_values[name] = parameter.detach().flatten()[::layout[name]["sampling_stride"]].float().cpu().clone()
    torch.save({"parameters": after_values}, output / f"rank{key[0]}-step{key[1]}-after.pt")
    grad2 = sum(float(x.double().square().sum()) for x in gradients.values())
    update2 = sum(float((after_values[name] - before_value).double().square().sum())
                  for name, before_value in values.items())
    finite = all(bool(torch.isfinite(x).all()) for x in [*values.values(), *gradients.values(), *after_values.values()])
    result = {"rank": key[0], "step": key[1], "sampled_gradient_l2": math.sqrt(grad2),
              "sampled_update_l2": math.sqrt(update2), "finite": finite,
              "native_optimizer_result": optimizer_result,
              "positive_finite_gradient_and_update": finite and grad2 > 0 and update2 > 0}
    _dump(output / f"rank{key[0]}-step{key[1]}-update.json", result)
    print("RLMG_NATIVE_UPDATE " + json.dumps(result, default=str), flush=True)

async def reward(args, sample, **kwargs):
    """Deterministic synthetic reward for plumbing validation, not a quality metric."""
    def score(item):
        return int(hashlib.sha256(item.response.encode()).hexdigest()[:8], 16) / (2**32 - 1)
    return [score(item) for item in sample] if isinstance(sample, list) else score(sample)
