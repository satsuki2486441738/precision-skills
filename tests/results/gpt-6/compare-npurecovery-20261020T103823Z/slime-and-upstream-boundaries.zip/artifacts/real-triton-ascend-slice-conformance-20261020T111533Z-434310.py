import json,torch,torch_npu,triton
import triton.language as tl
import triton.language.extra.cann.extension as tlx
@triton.jit
def kernel(X,Y):
 a=tl.load(X+tl.arange(0,32))
 b=tlx.extract_slice(a,(8,),(8,),(1,))
 c=tlx.insert_slice(tl.full((32,),0,tl.float32),b,(8,),(8,),(1,))
 tl.store(Y+tl.arange(0,32),c)
x=torch.arange(32,device='npu:0',dtype=torch.float32);y=torch.empty_like(x)
kernel[(1,)](x,y)
expected=torch.zeros(32);expected[8:16]=torch.arange(8,16,dtype=torch.float32)
actual=y.cpu();assert torch.equal(actual,expected),(actual,expected)
print(json.dumps({'torch':torch.__version__,'torch_npu':torch_npu.__version__,'triton':triton.__version__,'device':str(x.device),'npu':torch.npu.get_device_name(0),'exact_native_extract_insert_slice_equal':True,'maximum_absolute_error':float((actual-expected).abs().max()),'scope':'native operator API migration check only; no framework training pass implied'}))
