"""Real Slime train.py + official Ascend/MindSpeed patches; no CUDA simulation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys

ROOT = Path('$RLMG_ROOT')
SOURCE = ROOT / 'sources-offline-v1/slime'

def main():
    out = ROOT / 'attempts' / ('slime-native-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(os.getpid()))
    out.mkdir(parents=True)
    os.environ.update(RLMG_EVIDENCE=str(out / 'evidence'), ASCEND_RT_VISIBLE_DEVICES='12,13,14,15',
                      RAY_TMPDIR=str(ROOT/'cache/ray-slime'), RAY_DISABLE_DOCKER_CPU_WARNING='1',
                      RAY_DEDUP_LOGS='0', RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES='1',
                      MAX_JOBS='4', CMAKE_BUILD_PARALLEL_LEVEL='4', TOKENIZERS_PARALLELISM='false',
                      TMPDIR=str(ROOT/'cache/tmp'), TORCH_EXTENSIONS_DIR=str(ROOT/'cache/torch_extensions'),
                      WANDB_MODE='disabled', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    sys.path[:0] = [str(ROOT), str(SOURCE)]
    target = SOURCE/'slime/backends/megatron_utils/model.py'
    original = target.read_text(encoding='utf8')
    anchor = '        update_successful, grad_norm, num_zeros_in_grad = optimizer.step()'
    before = '        from npu_observer import before as _rlmg_before, after as _rlmg_after\n        _rlmg_key = _rlmg_before(model)\n'
    after = '\n        _rlmg_after(_rlmg_key, (update_successful, grad_norm, num_zeros_in_grad))'
    if '_rlmg_key = _rlmg_before(model)' not in original:
        assert original.count(anchor) == 1
        (out/'native-model-before-observer.py').write_text(original,encoding='utf8')
        temporary=target.with_name(target.name+'.rlmg-observer.tmp')
        temporary.write_text(original.replace(anchor,before+anchor+after),encoding='utf8')
        os.replace(temporary,target)
    else:
        assert original.count('_rlmg_key = _rlmg_before(model)') == 1
        assert original.count('_rlmg_after(_rlmg_key,') == 1
    prompts = out/'prompts.jsonl'
    prompts.write_text('\n'.join(json.dumps({'prompt': x, 'label': 'synthetic'}) for x in (
        'Give a short name for a blue bird.', 'Write one sentence about a tree.'))+'\n',encoding='utf8')
    model = ['--swiglu','--num-layers','28','--hidden-size','1024','--ffn-hidden-size','3072',
             '--num-attention-heads','16','--group-query-attention','--num-query-groups','8',
             '--use-rotary-position-embeddings','--disable-bias-linear','--normalization','RMSNorm',
             '--norm-epsilon','1e-6','--rotary-base','1000000','--vocab-size','151936',
             '--kv-channels','128','--qk-layernorm']
    args = ['train.py','--actor-num-nodes','1','--actor-num-gpus-per-node','1',
            '--rollout-num-gpus','1','--rollout-num-gpus-per-engine','1', *model,
            '--hf-checkpoint','/host-model/Qwen3-0.6B','--load','/host-model/Qwen3-0.6B',
            '--megatron-to-hf-mode','bridge','--save',str(out/'checkpoint'),'--save-interval','1',
            '--prompt-data',str(prompts),'--input-key','prompt','--label-key','label',
            '--custom-rm-path','npu_observer.reward','--num-rollout','1','--rollout-batch-size','2',
            '--n-samples-per-prompt','4','--num-steps-per-rollout','1','--global-batch-size','8',
            '--micro-batch-size','1','--rollout-max-response-len','8','--rollout-temperature','1',
            '--advantage-estimator','grpo','--kl-coef','0','--entropy-coef','0',
            '--eps-clip','0.2','--optimizer','adam','--lr','0.0001','--lr-decay-style','constant',
            '--weight-decay','0','--seed','20261020','--tensor-model-parallel-size','1','--pipeline-model-parallel-size','1',
            '--context-parallel-size','1','--attention-dropout','0','--hidden-dropout','0',
            '--attention-backend','flash','--bf16','--sglang-context-length','128',
            '--sglang-mem-fraction-static','0.25','--sglang-disable-cuda-graph',
            '--save-debug-rollout-data',str(out/'rollout-{rollout_id}.pt'),
            '--save-debug-train-data',str(out/'train-{rollout_id}-{rank}.pt')]
    (out/'command.json').write_text(json.dumps({'python':sys.executable,'argv':args,'model':'real pretrained /host-model/Qwen3-0.6B',
        'stage':'one native GRPO rollout + optimizer update','reward':'synthetic deterministic response hash',
        'official_slime_source_pin':'2418a7844abe4d490a1676dcf88fc3401adab362',
        'deployment':'official NPU patches with recorded format/context repairs'},indent=2),encoding='utf8')
    print('RLMG_ATTEMPT '+str(out),flush=True)
    import torch_npu  # Register the real Ascend backend before the official is_npu check.
    import ray
    ray.init(address='local',_temp_dir=str(ROOT/'cache/ray-slime'),include_dashboard=False,
             num_cpus=8,resources={'NPU':4},log_to_driver=True)
    try:
        os.chdir(SOURCE)
        sys.argv=args
        runpy.run_path(str(SOURCE/'train.py'),run_name='__main__')
        import torch
        rollout=torch.load(out/'rollout-0.pt',map_location='cpu',weights_only=False)
        samples=rollout['samples']
        updates=[json.loads(p.read_text()) for p in (out/'evidence').glob('rank*-update.json')]
        if not updates:
            updates=[json.loads(p.read_text()) for p in (out/'evidence').glob('rank*-step*-update.json')]
        generated=sum(s['response_length'] for s in samples)
        passed=len(samples)==8 and generated>0 and bool(updates) and all(x['positive_finite_gradient_and_update'] for x in updates)
        result={'native_entrypoint_returned':True,'trajectory_count':len(samples),'generated_action_tokens':generated,
                'rewards':[s['reward'] for s in samples],'native_updates':updates,'validated_one_step':passed}
        (out/'completion.json').write_text(json.dumps(result,indent=2),encoding='utf8')
        if not passed:raise RuntimeError('Native rollout/update validation incomplete')
    finally:
        ray.shutdown()

if __name__=='__main__':main()
