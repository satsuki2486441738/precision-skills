"""Launch isolated, logged continuation after the SSH endpoint returns."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import time

ROOT=Path('$RLMG_ROOT')
SESSION=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(os.getpid())
for name in ('logs','state','artifacts','cache/tmp','cache/pip','cache/uv','cache/pycache','cache/ascend','cache/torch_extensions','environments'):(ROOT/name).mkdir(parents=True,exist_ok=True)
os.environ.update(TMPDIR=str(ROOT/'cache/tmp'),PIP_CACHE_DIR=str(ROOT/'cache/pip'),UV_CACHE_DIR=str(ROOT/'cache/uv'),PYTHONPYCACHEPREFIX=str(ROOT/'cache/pycache'),ASCEND_CACHE_PATH=str(ROOT/'cache/ascend'),TORCH_EXTENSIONS_DIR=str(ROOT/'cache/torch_extensions'),ASCEND_RT_VISIBLE_DEVICES='12,13,14,15',MAX_JOBS='4',CMAKE_BUILD_PARALLEL_LEVEL='4',UV_CONCURRENT_DOWNLOADS='2',UV_CONCURRENT_BUILDS='1')

def phase(name,argv,timeout):
    log=ROOT/'logs'/(name+'-'+SESSION+'.log')
    with log.open('w') as stream:
        process=subprocess.Popen(list(map(str,argv)),stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        start=time.monotonic()
        try:rc=process.wait(timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(20)
            except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
            rc=124
    item={'name':name,'argv':list(map(str,argv)),'returncode':rc,'seconds':time.monotonic()-start,'log':str(log)}
    with (ROOT/'continuation-history.jsonl').open('a') as stream:stream.write(json.dumps(item)+'\n')
    print(json.dumps(item),flush=True)
    return rc

def driver():
    import fcntl
    lock=(ROOT/'state/driver.lock').open('a+')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        print('An owned continuation driver is already running; no duplicate jobs started.',flush=True)
        return
    early=ROOT/'state/early-dependencies.json'
    if early.exists():
        prior=json.loads(early.read_text());pid=prior['pid'];deadline=time.monotonic()+2300
        while time.monotonic()<deadline:
            cmd=Path('/proc')/str(pid)/'cmdline'
            if not cmd.exists():break
            args=cmd.read_bytes().split(b'\0')
            if str(ROOT/'prepare_official_npu_v4.py').encode() not in args or b'--prerequisites-only' not in args:break
            print('Waiting for owned prerequisites installer '+str(pid),flush=True)
            time.sleep(30)
        else:raise RuntimeError('Owned prerequisites installer exceeded bounded wait; inspect its private log')
    # Fresh persistent-root bootstrap must finish before parallel per-framework installers.
    tooling=ROOT/'environments/tooling'
    if not (tooling/'bin/python').exists():
        if phase('tooling-venv',[sys.executable,'-m','venv','--system-site-packages',tooling],120):return
    if not (tooling/'bin/uv').exists():
        if phase('tooling-uv',[tooling/'bin/python','-m','pip','install','--no-compile','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','uv==0.8.22'],300):return
    unpack="import sys;sys.path.insert(0,"+repr(str(ROOT))+");import prepare_official_npu_v4 as prep;prep.unpack_offline()"
    if phase('unpack-exact-offline-sources',[sys.executable,'-c',unpack],300):return
    archive=ROOT/'cache/trt-source-v020.tar'
    assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()=='4dad5ae84fcabd06c23f7c1519339f733e22f486427bc987c479e7f888539d8c'
    destination=ROOT/'sources-trt-v020'
    if not (destination/'.complete').exists():
        if destination.exists():destination.rename(ROOT/('incomplete-trt-source-'+SESSION))
        destination.mkdir()
        with tarfile.open(archive) as tf:tf.extractall(destination,filter='data')
        (destination/'.complete').write_text('official source 7965842954628b0b5456a2f7d59786d3dcd41647')
    pristine=ROOT/'upstream-prereqs'
    if not (pristine/'megatron/megatron/core/__init__.py').exists():
        pristine.mkdir(exist_ok=True)
        with tarfile.open(ROOT/'cache/sources-offline.tar.gz') as tf:
            tf.extractall(pristine,members=[item for item in tf.getmembers() if item.name=='megatron' or item.name.startswith('megatron/')],filter='data')
    childlog=ROOT/'logs'/('upstream-startups-driver-'+SESSION+'.log')
    with childlog.open('w') as stream:
        upstream=subprocess.Popen([sys.executable,str(ROOT/'upstream_native_startups_v4.py')],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    result=phase('official-slime-prepare-v4',[sys.executable,ROOT/'prepare_official_npu_v4.py'],3600)
    if result==0:
        phase('slime-native-train',[ROOT/'environments/slime-official-py311/bin/python',ROOT/'slime_npu_native.py'],1200)
    try:upstream.wait(30)
    except subprocess.TimeoutExpired:pass

def main():
    if '--driver' in sys.argv:return driver()
    log=ROOT/'logs'/('continuation-driver-'+SESSION+'.log')
    with log.open('w') as stream:
        child=subprocess.Popen([sys.executable,str(ROOT/'resume_native_v4.py'),'--driver'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':child.pid,'log':str(log),'script':str(ROOT/'resume_native_v4.py')}))

if __name__=='__main__':main()
