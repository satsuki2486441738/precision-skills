import json,pathlib
root=pathlib.Path("$RLMG_ROOT")
result={}
for pattern in ('logs/continuation-driver-*.log','continuation-history.jsonl','stage-history.jsonl','artifacts/setup-failure-*.json','official-environment-ready.json'):
 for p in sorted(root.glob(pattern))[-2:]:result[str(p.relative_to(root))]=p.read_text(errors='replace')[-9000:]
for p in sorted((root/'logs').glob('*.log'),key=lambda p:p.stat().st_mtime)[-8:]:result[str(p.relative_to(root))]=p.read_text(errors='replace')[-5000:]
for p in (root/'attempts').glob('*/completion.json') if (root/'attempts').exists() else []:result[str(p.relative_to(root))]=p.read_text(errors='replace')
print(json.dumps(result))
