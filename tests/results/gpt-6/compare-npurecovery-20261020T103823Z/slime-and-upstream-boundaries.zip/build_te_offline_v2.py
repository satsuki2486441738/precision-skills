import hashlib,tarfile,os
import repair_upstream_native_v3 as r
root=r.root;archive=root/'cache/transformer-engine-15288857.tar.gz'
assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()=='8557f771be487eca38242589f6f28188b7c77a76b3551e858beaf05f9607c29c'
with tarfile.open(archive) as t:t.extractall(root/'upstream-early',filter='data')
source=root/'upstream-early/TransformerEngine-15288857644368b8b7bdddd9bead7d6d3d04de80'
env=os.environ.copy();env['NVTE_FRAMEWORK']='pytorch'
r.run('bridge-official-transformer-engine-native-local-build',[root/'environments/tooling/bin/uv','pip','install','--python',root/'environments/native-cuda-dependency-builds/bin/python','--no-deps','--no-build-isolation',source],env=env,timeout=300)
