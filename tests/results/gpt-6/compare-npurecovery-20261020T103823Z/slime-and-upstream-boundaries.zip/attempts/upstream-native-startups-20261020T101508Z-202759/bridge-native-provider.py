from megatron.bridge.models.gpt_provider import GPTModelProvider
provider=GPTModelProvider(num_layers=2,hidden_size=128,ffn_hidden_size=256,num_attention_heads=4,vocab_size=256,seq_length=32)
print('NATIVE_BRIDGE_PROVIDE_DISTRIBUTED_MODEL',flush=True)
provider.provide_distributed_model(wrap_with_ddp=False)
