import torch, torch_npu
from transformers import AutoTokenizer
from nemo_reinforcer.models.policy.fsdp1_policy_worker import FSDP1PolicyWorker
cfg={'model_name':'/host-model/Qwen3-0.6B','precision':'float32','activation_checkpointing_enabled':False,'fsdp_offload_enabled':False,'optimizer':{'name':'torch.optim.AdamW','kwargs':{'lr':0.0001}},'train_global_batch_size':1,'train_micro_batch_size':1,'max_grad_norm':1.0}
print('NATIVE_WORKER_CONSTRUCTOR',torch.__version__,torch_npu.__version__,flush=True)
tokenizer=AutoTokenizer.from_pretrained('/host-model/Qwen3-0.6B',local_files_only=True)
worker=FSDP1PolicyWorker.__ray_metadata__.modified_class(cfg,tokenizer,init_reference_model=False)
print('NATIVE_WORKER_CONSTRUCTED',flush=True)
