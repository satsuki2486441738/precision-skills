import pathlib, torch
from tokenizers import Tokenizer
from tokenizers.models import WordLevel
from tokenizers.pre_tokenizers import Whitespace
from transformers import Qwen2Config, Qwen2ForCausalLM, PreTrainedTokenizerFast
fixture=pathlib.Path(__file__).parent/'seeded-random-qwen2'
torch.manual_seed(20261020)
config=Qwen2Config(vocab_size=256,hidden_size=256,intermediate_size=512,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=128,tie_word_embeddings=False,bos_token_id=1,eos_token_id=2,pad_token_id=0)
model=Qwen2ForCausalLM(config)
model.save_pretrained(fixture)
vocab={'<pad>':0,'<s>':1,'</s>':2,'<unk>':3,**{f'tok{i}':i for i in range(4,256)}}
raw=Tokenizer(WordLevel(vocab,unk_token='<unk>'));raw.pre_tokenizer=Whitespace()
PreTrainedTokenizerFast(tokenizer_object=raw,pad_token='<pad>',bos_token='<s>',eos_token='</s>',unk_token='<unk>').save_pretrained(fixture)
from tensorrt_llm import LLM, SamplingParams
print('NATIVE_TRTLLM_LLM_CONSTRUCTOR',flush=True)
llm=LLM(model=str(fixture))
outputs=llm.generate(['tok10 tok11 tok12'],SamplingParams(max_tokens=8,temperature=0.8))
print(outputs)
