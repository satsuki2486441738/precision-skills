import ast,datetime,difflib,hashlib,json,os
import prepare_official_npu_v4 as p
root=p.ROOT;py=root/'environments/slime-official-py311/bin/python'
target=root/'environments/slime-official-py311/lib/python3.11/site-packages/sgl_kernel_npu/norm/split_qkv_rmsnorm_rope.py'
original=target.read_text();changed=original
if 'import triton.language.extra.cann.extension as tl_ascend' not in changed:
 assert original.count('tl.extract_slice')==4 and original.count('tl.insert_slice')==4
 changed=changed.replace('import triton.language as tl','import triton.language as tl\nimport triton.language.extra.cann.extension as tl_ascend').replace('tl.extract_slice','tl_ascend.extract_slice').replace('tl.insert_slice','tl_ascend.insert_slice')
 ast.parse(changed)
 (root/'artifacts'/('sgl-rmsnorm-rope-before-namespace-repair-'+p.SESSION+'.py')).write_text(original)
 temp=target.with_suffix('.rlmg.tmp');temp.write_text(changed);os.replace(temp,target)
 (root/'artifacts'/('sgl-rmsnorm-rope-namespace-repair-'+p.SESSION+'.patch')).write_text(''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile='official-sgl-kernel-npu2026.2.1',tofile='same-operator-triton3.2.2-namespace')))
 (root/'artifacts'/('sgl-rmsnorm-rope-namespace-repair-'+p.SESSION+'.json')).write_text(json.dumps({'before_sha256':hashlib.sha256(original.encode()).hexdigest(),'after_sha256':hashlib.sha256(changed.encode()).hexdigest(),'change':'4 extract_slice and4 insert_slice calls use actual official Ascend extension namespace; arithmetic/shape/dtype unchanged','official_resolution_source':'https://github.com/vllm-project/vllm-ascend/issues/9045'},indent=2))
os.environ.update(PYTHONPATH=str(root/'bootstrap')+os.pathsep+str(root)+os.pathsep+os.environ.get('PYTHONPATH',''),RLMG_TMP_REAL=str(root/'cache/tmp'),RLMG_TMP_SHORT='/tmp/rlmg-tmp-'+str(os.getuid()),TMPDIR=str(root/'cache/tmp'),TRITON_CACHE_DIR=str(root/'cache/triton'),ASCEND_CACHE_PATH=str(root/'cache/ascend'),TORCHINDUCTOR_COMPILE_THREADS='1')
test=root/'artifacts'/('real-triton-ascend-slice-conformance-'+p.SESSION+'.py')
test.write_text('''import json,torch,torch_npu,triton
import triton.language as tl
import triton.language.extra.cann.extension as tlx
@triton.jit
def kernel(X,Y):
 a=tl.load(X+tl.arange(0,32))
 b=tlx.extract_slice(a,(8,),(8,),(1,))
 c=tlx.insert_slice(tl.full((32,),0,tl.float32),b,(8,),(8,),(1,))
 tl.store(Y+tl.arange(0,32),c)
x=torch.arange(32,device='npu:0',dtype=torch.float32);y=torch.empty_like(x)
kernel[(1,)](x,y)
expected=torch.zeros(32);expected[8:16]=torch.arange(8,16,dtype=torch.float32)
actual=y.cpu();assert torch.equal(actual,expected),(actual,expected)
print(json.dumps({'torch':torch.__version__,'torch_npu':torch_npu.__version__,'triton':triton.__version__,'device':str(x.device),'npu':torch.npu.get_device_name(0),'exact_native_extract_insert_slice_equal':True,'maximum_absolute_error':float((actual-expected).abs().max()),'scope':'native operator API migration check only; no framework training pass implied'}))
''')
p.run('real-triton-ascend-slice-native-conformance',[py,test],timeout=180)
p.run('slime-native-full-grpo-triton-namespace-retry',[py,root/'slime_npu_native.py'],timeout=1200)
