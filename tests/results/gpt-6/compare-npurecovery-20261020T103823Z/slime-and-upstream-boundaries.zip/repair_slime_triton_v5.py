import datetime,json,subprocess
import prepare_official_npu_v4 as p
root=p.ROOT;py=root/'environments/slime-official-py311/bin/python'
p.run('slime-cann91-official-triton322-wheel-attempt',[root/'environments/tooling/bin/uv','pip','install','--python',py,'--no-deps','https://github.com/triton-lang/triton-ascend/releases/download/v3.2.2/triton_ascend-3.2.2-cp311-cp311-manylinux_2_27_aarch64.manylinux_2_28_aarch64.whl'],timeout=600)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');log=root/'logs'/('slime-native-triton322-attempt-'+stamp+'.log')
with log.open('wb') as f:child=subprocess.Popen([str(py),str(root/'slime_npu_native.py')],stdout=f,stderr=subprocess.STDOUT,cwd=root,start_new_session=True)
print(json.dumps({'pid':child.pid,'log':str(log),'scope':'Triton3.2.2 from current official CANN9.1 SGLang deployment matrix; rest legacy official Slime2.8 recipe remains compatibility experiment; unchanged native training math'}))
