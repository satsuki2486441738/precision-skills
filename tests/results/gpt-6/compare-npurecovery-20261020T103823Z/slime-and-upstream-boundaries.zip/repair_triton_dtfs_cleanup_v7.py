import ast,datetime,difflib,hashlib,json,os
import prepare_official_npu_v4 as p
root=p.ROOT;py=root/'environments/slime-official-py311/bin/python'
target=root/'environments/slime-official-py311/lib/python3.11/site-packages/triton/backends/ascend/compiler.py'
data=target.read_text();start=data.index('def linalg_to_bin_enable_npu_compile_A2_A3(')
end=data.find('\ndef ',start+5)
if end<0:end=len(data)
block=data[start:end];old='with tempfile.TemporaryDirectory() as tmpdir:';new='with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmpdir:'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
if old in block:
 assert block.count(old)==1
 changed=data[:start]+block.replace(old,new)+data[end:];ast.parse(changed)
 (root/'artifacts'/('triton-compiler-before-dtfs-cleanup-repair-'+stamp+'.py')).write_text(data)
 temp=target.with_suffix('.rlmg.tmp');temp.write_text(changed);os.replace(temp,target)
 diff=''.join(difflib.unified_diff(data.splitlines(True),changed.splitlines(True),fromfile='official-triton3.2.2/compiler.py',tofile='private-cleanup-adapted/compiler.py'))
 (root/'artifacts'/('triton-dtfs-cleanup-repair-'+stamp+'.patch')).write_text(diff)
 (root/'artifacts'/('triton-dtfs-cleanup-repair-'+stamp+'.json')).write_text(json.dumps({'source_before_sha256':hashlib.sha256(data.encode()).hexdigest(),'source_after_sha256':hashlib.sha256(changed.encode()).hexdigest(),'change':'standard TemporaryDirectory(ignore_cleanup_errors=True) for dtfs cleanup only; compiled code and native arithmetic unchanged'},indent=2))
else:assert new in block
os.environ.update(TRITON_CACHE_DIR=str(root/'cache/triton'),XDG_CACHE_HOME=str(root/'cache/xdg'),TORCH_HOME=str(root/'cache/torch'),HF_HOME=str(root/'cache/hf'),ASCEND_CACHE_PATH=str(root/'cache/ascend'))
p.run('slime-native-cann91-triton322-dtfs-cleanup-retry',[py,root/'slime_npu_native.py'],timeout=1200)
