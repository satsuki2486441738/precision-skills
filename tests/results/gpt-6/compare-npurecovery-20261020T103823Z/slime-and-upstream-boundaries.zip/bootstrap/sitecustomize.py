"""Private Slime temp-path setup; no framework or tensor patches."""
import os
import tempfile
real=os.environ.get('RLMG_TMP_REAL')
short=os.environ.get('RLMG_TMP_SHORT')
if real and short:
    if os.path.realpath(short)!=os.path.realpath(real):
        raise RuntimeError('Private short temporary path does not resolve to declared persistent storage')
    os.environ['TMPDIR']=real
    tempfile.tempdir=short
