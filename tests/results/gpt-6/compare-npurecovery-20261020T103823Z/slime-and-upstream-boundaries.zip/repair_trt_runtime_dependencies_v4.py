import os,pathlib
import repair_upstream_native_v3 as r
root=r.root;py=root/'environments/upstream-startups/bin/python';uv=root/'environments/tooling/bin/uv'
rc=r.run('tensorrt-official-runtime-dependency-retry',[uv,'pip','install','--python',py,'--no-build-isolation','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','--extra-index-url','https://pypi.nvidia.com','--index-strategy','unsafe-best-match','tensorrt==10.10.0.31','cuda-python==12.9.0'],timeout=900)
prior=sorted((root/'attempts').glob('upstream-native-startups-20261020T101508Z-*/trt-native-llm.py'))[0]
r.run('trtllm-official-native-llm-runtime-retry',[py,prior],timeout=180)
r.run('freeze',[uv,'pip','freeze','--python',py])
