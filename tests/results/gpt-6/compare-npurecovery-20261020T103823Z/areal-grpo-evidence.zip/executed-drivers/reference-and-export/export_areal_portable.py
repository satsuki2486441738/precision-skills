"""Portable true AReaL native vs independent CPU FP32 score/gradient/update evidence."""
import os,sys,pathlib,json,subprocess,shlex,datetime,hashlib,zipfile
base=pathlib.Path(os.environ['PRECISION_REMOTE_ROOT']);root=base/'rlar'
if os.environ.get('AREAL_PORTABLE_WORKER')!='1':
 env=os.environ.copy();env['AREAL_PORTABLE_WORKER']='1';env.pop('RLAR_CAPTURE',None);worker=root/'drivers/export01/export_areal_portable.py';assert worker.exists()
 cmd='source /usr/local/Ascend/cann/set_env.sh && '+shlex.join([str(root/'environments/areal/bin/python'),str(worker)])
 p=subprocess.run(['bash','-lc',cmd],env=env,capture_output=True,text=True,timeout=180);print(p.stdout);print(p.stderr,file=sys.stderr);raise SystemExit(p.returncode)
import torch,numpy as np,importlib.metadata as md
from safetensors.torch import save_file
native=root/'results/areal-native-dtfs-20261020T102659Z';reference=sorted((native/'reference').glob('*'))[-1]
assert json.loads((native/'process_exit.json').read_text())['exit_code']==0 and json.loads((reference/'process_exit.json').read_text())['exit_code']==0
def load(p):return torch.load(p,map_location='cpu',weights_only=True)
def write(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def thash(t):return hashlib.sha256(t.detach().contiguous().numpy().tobytes()).hexdigest()
capture=load(next((native/'native-tensors').glob('native-grpo-loss*.pt')));data=capture['args'][2];mask=data['loss_mask'].bool();ids=data['input_ids'].long();cu=data['cu_seqlens'].tolist();observed=load(next((native/'optimizer').glob('*.pt')));ref=load(reference/'reference-tensors.pt');ref_result=json.loads((reference/'reference-completion.json').read_text())
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=native/'portable'/('compare-'+stamp);out.mkdir(parents=True)
common={'model':{'id':'Qwen3-0.6B','config_sha256':hashlib.sha256(pathlib.Path('/SHARED_MODELS/Qwen3-0.6B/config.json').read_bytes()).hexdigest()},'inputs':{'packed_ids_sha256':thash(ids),'cu_seqlens':cu,'mask_sha256':thash(mask),'old_policy_sha256':thash(data['logprobs']),'proximal_policy_sha256':thash(data['prox_logp']),'temperature':1.0,'group_size':2,'reward_clip':20,'reward_group_unbiased_std_eps':1e-5,'batch_adv_unbiased_std_eps':1e-5,'ppo_clip':.4,'rejection_ratio_upper':5,'loss_denominator':'32 original valid actions before rejection'},'scope':{'task':'AReaL native GRPO step0','trajectories':4,'complete_groups':2,'valid_actions':32,'parameter_capture':'first min(numel,8192) flattened elements of first12 native optimizer parameters; no full-model update conclusion'},'state':{'weights':'same original pretrained BF16 checkpoint promoted to FP32 master/reference parameters','optimizer_initial':'AdamW zero moments first step,lr.001 eps1e-8 weight_decay0','gradient_clipping':'full-model global norm1','before_values':'exact paired sampled coordinates checked by comparator'}}
side_conditions={'native':{'numerics':{'forward':'native NPU BF16 FSDP2 packed sequence model','parameter_dtype':'float32 master','gradient_dtype':'float32','loss_dtype':'float32','optimizer':'native Torch AdamW FP32'}},'reference':{'numerics':{'forward':'independent CPU FP32 eager Transformers padded causal model, no AReaL/Swift import','parameter_dtype':'float32','gradient_dtype':'float32','loss_dtype':'float32','optimizer':'independent zero-state first AdamW update formula'}}}
spec={'schema_version':2,'common':common,'side_conditions':side_conditions,'thresholds':None,'expected_ranks':{'native':[0],'reference':[0]}}
stores={s:{} for s in ('native','reference')};entries={s:{'postclip-gradients':[],'updates':[],'observations':[]} for s in stores};coverage=[]
for i,coord in enumerate(observed['coordinates']):
 reference_param=ref['selected'][i];assert reference_param['shape']==coord['shape'];n=observed['before'][i].numel();name=reference_param['name']+'/flat[0:'+str(n)+']';key='p'+str(i).zfill(3);coverage.append({'name':name,'shape':[n],'present':True,'full_parameter_shape':coord['shape'],'captured_elements':n})
 for side in stores:
  values={'before':observed['before'][i],'after':observed['after'][i],'gradient':observed['postclip_gradients'][i]} if side=='native' else {'before':reference_param['before'],'after':reference_param['after'],'gradient':reference_param['gradient']}
  for suffix,t in values.items():stores[side][key+'.'+suffix]=t.contiguous()
  entries[side]['postclip-gradients'].append({'name':name,'shape':[n],'present':True,'shards':[{'offset':0,'value':{'path':'values.safetensors','key':key+'.gradient'}}]})
  entries[side]['updates'].append({'name':name,'shape':[n],'present':True,'shards':[{'offset':0,'before':{'path':'values.safetensors','key':key+'.before'},'after':{'path':'values.safetensors','key':key+'.after'}}]})
obs=[('objective',[1],{'boundary':'native decoupled PPO/GRPO loss before backward','invocation':0,'execution_stage':'optimizer_step0'}),('advantages',[32],{'boundary':'native group reward and masked batch advantage normalization','selection':'all32 effective actions row-major packed trajectory order','execution_stage':'optimizer_step0'}),('target_logprobs',[32],{'boundary':'native current actor policy scoring','selection':'all32 valid action prediction positions','execution_stage':'optimizer_step0'})]
for side in stores:
 values={'objective':capture['native_loss'].reshape(1),'advantages':data['advantages'][mask],'target_logprobs':capture['args'][0][mask]} if side=='native' else {'objective':ref['loss'].reshape(1),'advantages':ref['advantages'][mask],'target_logprobs':ref['per_token_logps'][mask]}
 for name,shape,coords in obs:
  stores[side][name]=values[name].contiguous();entries[side]['observations'].append({'name':name,'shape':shape,'present':True,'coordinates':coords,'shards':[{'offset':0,'value':{'path':'values.safetensors','key':name}}]})
for stage in entries['native']:
 tensors=[{k:e[k] for k in ('name','shape','present')} for e in entries['native'][stage]]
 if stage=='observations':
  for tensor,source in zip(tensors,entries['native'][stage]):tensor['coordinates']=source['coordinates']
 write(out/(stage+'.contract.json'),dict(spec,kind='tensors',stage=stage,tensors=tensors))
runtime=json.loads((native/'runtime.json').read_text());versions={name:str(value.get('metadata') or value.get('version') or value.get('import_error')) for name,value in runtime['modules'].items()}
target_coords=[]
for sample,(lo,hi) in enumerate(zip(cu[:-1],cu[1:])):
 for absolute in range(lo,hi-1):
  if mask[absolute]:target_coords.append({'sample':str(sample),'position':absolute-lo+1,'token':int(ids[absolute+1]),'flat_score_index':absolute})
assert len(target_coords)==32
for side in stores:
 folder=out/side;folder.mkdir();save_file(stores[side],str(folder/'values.safetensors'))
 write(folder/'environment.json',{'rank':0,'versions':versions if side=='native' else {'torch':torch.__version__,'transformers':md.version('transformers'),'python':sys.version},'actual':dict(common,**side_conditions[side]),'native_module_records':runtime['modules'] if side=='native' else {'model_norm':'transformers.models.qwen3.modeling_qwen3'}})
 write(folder/'status.json',{'rank':0,'status':'completed','evidence':'native PPOTrainer.train and optimizer completed' if side=='native' else 'independent CPU forward/backward/update completed'})
 for stage in entries[side]:
  manifest={'schema_version':2,'kind':'tensors','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':'environment.json','status':'status.json'}],'stage':stage,'tensors':entries[side][stage]}
  if stage=='updates':manifest['events']={'actor':'applied'}
  write(folder/(stage+'.manifest.json'),manifest)
 vals=capture['args'][0] if side=='native' else ref['per_token_logps'];scores=[dict({k:p[k] for k in ('sample','position','token')},logprob=float(vals[p['flat_score_index']])) for p in target_coords]
 write(folder/'target-scores.manifest.json',{'schema_version':1,'kind':'target-scores','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':'environment.json','status':'status.json'}],'scores':scores})
write(out/'target-scores.contract.json',dict(spec,schema_version=1,kind='target-scores',targets=[{k:p[k] for k in ('sample','position','token')} for p in target_coords]))
np.save(out/'effective-mask.npy',ref['effective_mask'].numpy(),allow_pickle=False)
write(out/'capture-coverage.json',{'reference_result':ref_result,'parameter_slices':coverage,'whole_model_parameter_elements':751632384,'captured_parameter_elements':sum(r['captured_elements'] for r in coverage),'full_vocabulary_distribution_rows':0,'not_covered':'No native full-vocabulary rows captured in this AReaL pass; target32 scores and requested tensors are covered.'})
files=[p for p in out.rglob('*') if p.is_file()];write(out/'file-manifest.json',{'files':[{'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]})
archive=root/'exports'/('areal-native-reference-portable-'+stamp+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in out.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(out).as_posix())
print(json.dumps({'portable_root':str(out),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
