"""Independent FP32 actor/reward/group-normalization/PPO/AdamW step, no AReaL import."""
import os,pathlib,json,argparse,inspect
import torch
from transformers import AutoModelForCausalLM
from transformers.models.qwen3.modeling_qwen3 import Qwen3RMSNorm
ap=argparse.ArgumentParser();ap.add_argument('--native-output',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
native=pathlib.Path(a.native_output);out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=True)
assert 'areal' not in __import__('sys').modules and 'swift' not in __import__('sys').modules
assert 'npu_rms_norm' not in inspect.getsource(Qwen3RMSNorm.forward)
torch.set_num_threads(2);torch.manual_seed(20261020)
capture=torch.load(next((native/'native-tensors').glob('native-grpo-loss*.pt')),map_location='cpu',weights_only=True)
data=capture['args'][2];ids=data['input_ids'].long();cu=data['cu_seqlens'].tolist();mask=data['loss_mask'].bool();lengths=[cu[i+1]-cu[i] for i in range(len(cu)-1)]
raw_rewards=[];matches=[]
rollouts=[]
for p in (native/'native-tensors').glob('rollout_observed*.pt'):
 for row in torch.load(p,map_location='cpu',weights_only=True):
  if 'input_ids' in row:rollouts.append((p.name,row))
for lo,hi in zip(cu[:-1],cu[1:]):
 seq=ids[lo:hi];candidates=[(n,row) for n,row in rollouts if torch.equal(row['input_ids'].long().reshape(-1),seq)]
 assert candidates,'No captured native trajectory matches a packed sequence'
 name,row=candidates[0];tokens=row['input_ids'].reshape(-1)[row['loss_mask'].reshape(-1).bool()]
 reward=float(tokens.double().mean().item()/100);raw_rewards.append(reward);matches.append({'file':name,'raw_reward_recomputed_from_generated_ids':reward,'native_reward':float(row['rewards'].reshape(-1)[0])})
rewards=torch.tensor(raw_rewards,dtype=torch.float32).clamp(-20,20);normalized=torch.empty_like(rewards)
for start in range(0,len(rewards),2):
 group=rewards[start:start+2];mean=group.double().mean().float();std=((group.double()-mean.double()).square().sum()).sqrt().float()
 normalized[start:start+2]=(group-mean)/(std+1e-5)
returns=torch.zeros_like(ids,dtype=torch.float32)
for i,(lo,hi) in enumerate(zip(cu[:-1],cu[1:])):returns[lo:hi-1]=normalized[i]
valid=returns[mask].double();mean=valid.mean();std=((valid-mean).square().sum()/(valid.numel()-1)).sqrt()
advantages=(((returns.double()-mean)*mask)/(std+1e-5)).float()
model=AutoModelForCausalLM.from_pretrained('/SHARED_MODELS/Qwen3-0.6B',dtype=torch.float32,attn_implementation='eager',local_files_only=True,device_map={'':'cpu'});model.train();model.config.use_cache=False
batch=torch.zeros((len(lengths),max(lengths)),dtype=torch.long);attention=torch.zeros_like(batch)
for i,(lo,hi) in enumerate(zip(cu[:-1],cu[1:])):batch[i,:hi-lo]=ids[lo:hi];attention[i,:hi-lo]=1
logits=model(input_ids=batch,attention_mask=attention,use_cache=False).logits
flat=[]
for i,(lo,hi) in enumerate(zip(cu[:-1],cu[1:])):
 targets=torch.roll(ids,-1)[lo:hi]
 flat.append(logits[i,:hi-lo].log_softmax(-1).gather(-1,targets[:,None]).squeeze(-1))
logps=torch.cat(flat);prox=data['prox_logp'].float();old=data['logprobs'].float();behave=(prox-old).exp();effective=mask & (behave<=5)
ratio=(logps-prox).exp();per_token=torch.maximum(-advantages*ratio,-advantages*ratio.clamp(.6,1.4))*behave
loss=(per_token*effective).sum()/mask.count_nonzero();loss.backward();preclip=torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
named=list(model.named_parameters());selected=[]
for i,(name,p) in enumerate(named[:12]):
 before=p.detach().reshape(-1)[:8192].clone();grad=p.grad.detach().reshape(-1)[:8192].clone();update=-.001*grad/(grad.abs()+1e-8)
 selected.append({'name':name,'shape':list(p.shape),'before':before,'gradient':grad,'update':update,'after':before+update})
# All independent computation is complete before any native gradient/update is read.
observed=torch.load(next((native/'optimizer').glob('*.pt')),map_location='cpu',weights_only=True)
def compare(x,y):
 x=x.float().reshape(-1);y=y.float().reshape(-1);n=x.norm().item();m=y.norm().item()
 return {'reference_l2':n,'native_l2':m,'relative_l2':(y-x).norm().item()/max(n,1e-30),'max_abs':(y-x).abs().max().item(),'cosine':float(torch.nn.functional.cosine_similarity(x,y,dim=0)) if n and m else None,'finite':bool(torch.isfinite(x).all() and torch.isfinite(y).all())}
rows=[]
for i,(ref,coord) in enumerate(zip(selected,observed['coordinates'])):
 assert ref['shape']==coord['shape'],(ref['name'],ref['shape'],coord)
 rows.append({'name':ref['name'],'coordinate':coord,'initial_max_abs':float((ref['before']-observed['before'][i].float()).abs().max()),'gradient':compare(ref['gradient'],observed['postclip_gradients'][i]),'update':compare(ref['update'],observed['updates_fp32'][i])})
g=torch.cat([r['gradient'] for r in selected]);u=torch.cat([r['update'] for r in selected]);ng=torch.cat([g.float() for g in observed['postclip_gradients']]);nu=torch.cat(observed['updates_fp32'])
result={'status':'independent_fp32_reference_complete','reference_device':'cpu','native_model_forward':'BF16 NPU FSDP2','native_optimizer_parameter_dtype':observed['coordinates'][0]['dtype'],'native_optimizer_gradient_dtypes':sorted(set(str(g.dtype) for g in observed['postclip_gradients'])),'reference_dtype':'torch.float32','model_norm_module':Qwen3RMSNorm.forward.__module__,'areal_imported':False,'native_gradients_read_only_after_reference_computation':True,'loss':{'reference':loss.item(),'native':float(capture['native_loss']),'abs_error':abs(loss.item()-float(capture['native_loss']))},'advantages':compare(advantages[mask],data['advantages'][mask]),'target_logprobs':compare(logps[mask],capture['args'][0][mask]),'gradient_selected':compare(g,ng),'update_selected':compare(u,nu),'preclip_gradient_norm':float(preclip),'reward_matches':matches,'coverage':{'trajectories':len(lengths),'complete_groups':len(lengths)//2,'valid_actions':int(mask.sum()),'effective_actions_after_rejection':int(effective.sum()),'sampled_parameter_elements':sum(v['before'].numel() for v in selected),'whole_model_parameter_elements':sum(p.numel() for p in model.parameters()),'loss_reduction':'masked sum / original action count before rejection filtering','reward_clip':20,'group_unbiased_std_eps':1e-5,'batch_masked_advantage_unbiased_std_eps':1e-5},'coordinates':rows,'optimizer_reference':'independent zero-state AdamW first-step closed form on sampled coordinates, full-model forward/backward/global gradient clip1','alignment_thresholds_applied':False}
torch.save({'loss':loss.detach(),'rewards':rewards,'normalized_rewards':normalized,'advantages':advantages,'returns':returns,'per_token_logps':logps.detach(),'mask':mask,'effective_mask':effective,'selected':selected,'input_ids':ids,'cu_seqlens':data['cu_seqlens']},out/'reference-tensors.pt')
(out/'reference-completion.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
