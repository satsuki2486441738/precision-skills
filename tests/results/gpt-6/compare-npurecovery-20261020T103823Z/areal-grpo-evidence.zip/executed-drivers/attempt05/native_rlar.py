"""Seeded tiny assets and genuine AReaL/ROLL native RL jobs, with observation only."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys
import time
import uuid


def emit(name, **data):
    output = Path(os.environ["RLAR_OUTPUT"])
    output.mkdir(parents=True, exist_ok=True)
    payload = dict(event=name, framework=os.environ["RLAR_FRAMEWORK"],
                   time_unix=time.time(), pid=os.getpid(), **data)
    (output / (name + ".json")).write_text(json.dumps(payload, indent=2, default=str))
    print("RLAR_STAGE " + json.dumps(payload, default=str), flush=True)


def versions():
    import importlib
    import importlib.metadata as metadata
    import platform
    import torch
    items = {}
    for name in ["torch", "transformers", "datasets", "pyarrow", "accelerate", "peft",
                 "ray", "vllm", "flash_attn", "areal", "roll"]:
        try:
            module = importlib.import_module(name)
            items[name] = {"path": getattr(module, "__file__", None),
                           "version": str(getattr(module, "__version__", None))}
        except Exception as error:
            items[name] = {"import_error": str(error)}
        try:
            items[name]["distribution_version"] = metadata.version(name.replace("_", "-"))
        except metadata.PackageNotFoundError:
            pass
    emit("runtime", python=platform.python_version(), executable=sys.executable,
         modules=items, cuda=torch.version.cuda,
         devices=[torch.npu.get_device_name(i) for i in range(torch.npu.device_count())],
         cxx11_abi=torch._C._GLIBCXX_USE_CXX11_ABI)


def assets():
    import torch
    import yaml
    from tokenizers import Tokenizer, decoders, models, pre_tokenizers
    from transformers import PreTrainedTokenizerFast, Qwen2Config, Qwen2ForCausalLM
    output = Path(os.environ["RLAR_OUTPUT"])
    model_path = Path("/SHARED_MODELS/Qwen3-0.6B")
    rows = [{"messages": [{"role": "user", "content": "Count 1 2 3 then continue."}],
             "tag": "tiny", "ground_truth": "4", "data_source": "seeded-tiny"},
            {"messages": [{"role": "user", "content": "Write a short number list."}],
             "tag": "tiny", "ground_truth": "1", "data_source": "seeded-tiny"}]
    rows += [{"messages": [{"role":"user","content":"List the next two integers after 5."}],"tag":"tiny","ground_truth":"6","data_source":"seeded-tiny"}, {"messages":[{"role":"user","content":"Count backward from 3."}],"tag":"tiny","ground_truth":"2","data_source":"seeded-tiny"}]
    data_path = output / "tiny-data.jsonl"
    data_path.write_text("\n".join(json.dumps(row) for row in rows) + "\n")
    if os.environ["RLAR_FRAMEWORK"] == "areal":
        source = Path(os.environ["RLAR_SOURCE"])
        config = yaml.safe_load((source / "examples/math/gsm8k_grpo.yaml").read_text())
        config.update(experiment_name="native-rlar", trial_name="attempt0", seed=20261020,
                      total_train_epochs=1, allocation_mode="vllm:d1p1t1+d1p1t1",
                      tokenizer_path=str(model_path))
        config["cluster"].update(n_nodes=1, n_gpus_per_node=2, fileroot=str(output / "native"))
        config["cluster"]["name_resolve"] = {"type": "nfs", "nfs_record_root": str(output / "name-resolve")}
        config["gconfig"].update(n_samples=2, min_new_tokens=0, max_new_tokens=8,
                                  greedy=False, temperature=1.0, top_k=-1)
        config["train_dataset"].update(path=str(data_path), batch_size=2, num_workers=0, max_length=128,
                                        shuffle=False, pin_memory=False)
        config["valid_dataset"] = None
        config["actor"].update(path=str(model_path), dtype="bfloat16", group_size=2,
            gradient_checkpointing=False, kl_ctl=0.0, dynamic_sampling=False,
            mask_no_eos_with_zero=False,
            reward_scaling=1.0, reward_bias=0.0, recompute_logprob=True)
        config["actor"]["optimizer"].update(lr=0.001, weight_decay=0.0, warmup_steps_proportion=0.0)
        config["actor"]["mb_spec"]["max_tokens_per_mb"] = 512
        config["rollout"].update(max_concurrent_rollouts=2, max_head_offpolicyness=0)
        config["vllm"] = {"model": str(model_path), "seed": 20261020,
            "dtype": "bfloat16", "enforce_eager": True, "max_model_len": 256,
            "max_num_seqs": 4, "gpu_memory_utilization": 0.15, "swap_space": 0,
            "enable_prefix_caching": False, "disable_sliding_window": True}
        for name in ["saver", "recover", "evaluator", "stats_logger"]:
            config[name].update(experiment_name="native-rlar", trial_name="attempt0",
                                fileroot=str(output / "native"))
        config["saver"].update(freq_epochs=None, freq_steps=None, freq_secs=None)
        config["evaluator"].update(freq_epochs=None, freq_steps=None, freq_secs=None)
        config["recover"].update(mode="disabled", retries=0)
        (output / "areal.yaml").write_text(yaml.safe_dump(config, sort_keys=False))
    else:
        model_args = {"model_name_or_path": str(model_path), "dtype": "bf16",
                      "disable_gradient_checkpointing": True, "attn_implementation": "sdpa"}
        common_data = {"template": "native", "messages": "messages",
                       "preprocessing_num_workers": 1, "rollout_dataloader_num_workers": 0}
        config = {"exp_name": "native-rlar", "seed": 20261020, "num_nodes": 1,
            "num_gpus_per_node": 4, "max_steps": 1, "save_steps": -1, "eval_steps": -1,
            "logging_steps": 1, "track_with": "stdout", "tracker_kwargs": {},
            "output_dir": str(output / "native"), "logging_dir": str(output / "native/logs"),
            "pretrain": str(model_path), "reward_pretrain": str(model_path),
            "checkpoint_config": {"type": "file_system", "output_dir": str(output / "checkpoints")},
            "transfer_backend": {"backend_name": None, "backend_config": {}},
            "rollout_batch_size": 2, "num_return_sequences_in_group": 2,
            "prompt_length": 128, "response_length": 8, "ppo_epochs": 1,
            "adv_estimator": "grpo", "enable_reference": False, "use_kl_loss": False,
            "init_kl_coef": 0.0, "whiten_advantages": False, "difficulty_mask": False,
            "max_len_mask": False, "generate_opt_level": 0, "is_num_return_sequences_expand": True,
            "max_running_requests": 4, "rollout_dump_dir": str(output / "native-rollouts"),
            "rpc_timeout": 300, "system_envs": {"USE_MODELSCOPE": "0",
                "RLAR_CAPTURE": "1", "RLAR_FRAMEWORK": "roll", "RLAR_OUTPUT": str(output),
                "PYTHONPATH": os.environ["PYTHONPATH"], "OMP_NUM_THREADS": "1"},
            "actor_train": {"worker_cls": "native_rlar.ObservedActorWorker",
                "model_args": model_args, "use_sequence_packing": False,
                "training_args": {"learning_rate": 0.001, "weight_decay": 0.0,
                    "per_device_train_batch_size": 2, "gradient_accumulation_steps": 2,
                    "warmup_steps": 0, "num_train_epochs": 1},
                "data_args": dict(common_data, file_name=[str(data_path)],
                                  domain_interleave_probs={"tiny_reward": 1.0}),
                "strategy_args": {"strategy_name": "fsdp2_train", "strategy_config": {
                    "enable_mix_precision": True, "fsdp_size": 1,
                    "reshard_after_forward": True, "offload_policy": False}},
                "device_mapping": [0], "infer_batch_size": 2, "offload_nccl": False},
            "actor_infer": {"model_args": model_args, "data_args": common_data,
                "generating_args": {"max_new_tokens": 8,
                    "top_p": 1.0, "top_k": 0, "temperature": 1.0,
                    "do_sample": True, "num_beams": 1, "num_return_sequences": 2},
                "strategy_args": {"strategy_name": "vllm", "strategy_config": {
                    "gpu_memory_utilization": 0.15, "max_model_len": 256,
                    "block_size": 128, "enforce_eager": True, "max_num_seqs": 4}},
                "device_mapping": [1], "infer_batch_size": 2, "offload_nccl": False},
            "reference": {"model_args": model_args,
                "strategy_args": {"strategy_name": "hf_infer", "strategy_config": {}},
                "device_mapping": [0], "offload_nccl": False},
            "rewards": {"tiny_reward": {"worker_cls": "native_rlar.TokenSumRewardWorker",
                "model_args": model_args, "data_args": common_data,
                "tag_included": ["tiny"], "world_size": 1, "infer_batch_size": 4,
                "offload_nccl": False}}}
        (output / "roll.json").write_text(json.dumps(config, indent=2))
    emit("assets_ready", model_path=str(model_path), data_path=str(data_path),
         seed=20261020, model_class="Qwen3ForCausalLM", weights_origin="preexisting /SHARED_MODELS/Qwen3-0.6B")


# Private subset-device launcher mapping. Native ROLL numbers per-node devices from zero;
# map its placement namespace into this task's assigned physical NPU subset.
if os.environ.get("RLAR_FRAMEWORK") == "roll":
    from roll.platforms import current_platform
    _native_visible_devices = current_platform.update_env_vars_for_visible_devices
    def _assigned_visible_devices(env_vars, gpu_ranks):
        physical = [8,9,10,11]
        mapped = [physical[int(rank)] if 0 <= int(rank) < 4 else int(rank) for rank in gpu_ranks]
        return _native_visible_devices(env_vars, mapped)
    current_platform.update_env_vars_for_visible_devices = _assigned_visible_devices

def save_tensors(prefix, data):
    import torch
    output = Path(os.environ["RLAR_OUTPUT"]) / "native-tensors"
    output.mkdir(parents=True, exist_ok=True)
    tensors = {}
    for key, value in data.items():
        if torch.is_tensor(value):
            if hasattr(value, "to_local"):
                value = value.to_local()
            tensors[key] = value.detach().cpu().clone()
    target = output / f"{prefix}-rank{os.environ.get('RANK', '0')}-pid{os.getpid()}-{uuid.uuid4().hex}.pt"
    torch.save(tensors, target)
    return target


def areal_train(args):
    from datasets import Dataset
    from areal.api.cli_args import GRPOConfig, load_expr_config
    from areal.experimental.trainer.rl import GRPOTrainer
    from areal.utils.hf_utils import load_hf_tokenizer
    from areal.workflow.rlvr import RLVRWorkflow
    config, _ = load_expr_config(args, GRPOConfig)
    versions()
    tokenizer = load_hf_tokenizer(config.tokenizer_path)
    # One native training batch; fixed prompt identities are recorded in assets.
    rows = [json.loads(line) for line in (Path(os.environ["RLAR_OUTPUT"]) / "tiny-data.jsonl").read_text().splitlines()]
    dataset = Dataset.from_list(rows)

    def reward_fn(prompt, completions, prompt_ids, completion_ids, **kwargs):
        return sum(completion_ids) / max(len(completion_ids), 1) / 100.0

    class ObservedRLVRWorkflow(RLVRWorkflow):
        async def arun_episode(self, engine, data):
            result = await super().arun_episode(engine, data)
            path = save_tensors("native-rollout", result)
            emit("rollout_observed", artifact=str(path), engine=type(engine).__name__)
            return result

    with GRPOTrainer(config, train_dataset=dataset, valid_dataset=None, tokenizer=tokenizer) as trainer:
        original_update = trainer.actor.ppo_update

        def observed_update(batch, *args, **kwargs):
            path = save_tensors("native-objective-inputs", batch)
            emit("objective_entered", artifact=str(path), actor=type(trainer.actor).__name__)
            result = original_update(batch, *args, **kwargs)
            emit("objective_returned", result=str(result))
            return result

        trainer.actor.ppo_update = observed_update
        workflow = ObservedRLVRWorkflow(reward_fn=reward_fn, gconfig=config.gconfig,
            tokenizer=tokenizer, dump_dir=str(Path(os.environ["RLAR_OUTPUT"]) / "generated"))
        trainer.train(workflow, workflow)
        emit("native_train_returned", actor=type(trainer.actor).__name__,
             backend="PyTorch FSDP2", rollout_engine=type(trainer.rollout).__name__)
    emit("rank_complete", rank=int(os.environ.get("RANK", 0)), world_size=int(os.environ.get("WORLD_SIZE", 1)))


if os.environ.get("RLAR_FRAMEWORK") == "roll" and os.environ.get("RLAR_WORKER_CLASSES") == "1":
    import torch
    from roll.distributed.executor.worker import Worker
    from roll.distributed.scheduler.decorator import Dispatch, register
    from roll.distributed.scheduler.protocol import DataProto
    from roll.pipeline.rlvr.actor_worker import ActorWorker

    class TokenSumRewardWorker(Worker):
        @register(dispatch_mode=Dispatch.ONE_TO_ALL)
        def initialize(self, pipeline_config):
            super().initialize(pipeline_config)

        @register(dispatch_mode=Dispatch.DP_MP_COMPUTE, clear_cache=False)
        def compute_rewards(self, data):
            response_ids = data.batch["responses"]
            path = save_tensors("native-rollout", data.batch)
            # A declared deterministic toy reward that varies with real generated tokens.
            scores = response_ids.float().mean(dim=-1) / 100.0
            emit("rollout_observed", artifact=str(path), engine="ROLL VllmStrategy",
                 sequences=int(response_ids.shape[0]), response_length=int(response_ids.shape[-1]))
            return DataProto.from_dict(tensors={"scores": scores,
                "response_level_rewards": scores.clone(),
                "token_level_rewards": torch.zeros_like(response_ids, dtype=torch.float32)},
                meta_info={"metrics": {"tiny/token_sum_mean": scores.mean().item()}})

    class ObservedActorWorker(ActorWorker):
        def loss_func(self, data, output_tensor):
            path = save_tensors("native-objective-inputs", data.batch)
            result = super().loss_func(data, output_tensor)
            loss = result[0]
            save_tensors("native-loss-returned", {"loss": loss})
            emit("objective_returned", artifact=str(path), loss=float(loss.detach().item()),
                 native_actor="roll.pipeline.rlvr.actor_worker.ActorWorker", result=str(result[1:]))
            return result


def roll_train():
    import ray
    from dacite import from_dict
    from roll.pipeline.rlvr.rlvr_config import RLVRConfig
    from roll.pipeline.rlvr.rlvr_pipeline import RLVRPipeline
    from roll.utils.constants import RAY_NAMESPACE
    versions()
    output = Path(os.environ["RLAR_OUTPUT"])
    config = from_dict(data_class=RLVRConfig, data=json.loads((output / "roll.json").read_text()))
    # A private local Ray cluster is the documented distributed pipeline runtime.
    ray_temp = Path("/tmp") / ("rlar-ray-" + uuid.uuid4().hex[:8])
    ray.init(address="local", num_cpus=4, num_gpus=0, resources={"NPU":4}, namespace=RAY_NAMESPACE,
        include_dashboard=False, _temp_dir=str(ray_temp),
        runtime_env={"env_vars": {key: value for key, value in os.environ.items()
                     if key.startswith("RLAR_") or key in ["PYTHONPATH", "OMP_NUM_THREADS"]}})
    try:
        pipeline = RLVRPipeline(pipeline_config=config)
        emit("pipeline_initialized", pipeline=type(pipeline).__name__)
        pipeline.run()
        emit("native_train_returned", pipeline=type(pipeline).__name__,
             backend="ROLL FSDP2TrainStrategy", rollout_engine="ROLL VllmStrategy",
             native_state=pipeline.state.to_dict() if hasattr(pipeline.state, "to_dict") else str(pipeline.state))
    finally:
        ray.shutdown()
        import shutil
        if ray_temp.exists():
            for session in ray_temp.glob("session_*"):
                if not session.is_symlink() and (session / "logs").is_dir():
                    shutil.copytree(session / "logs", output / "ray" / session.name / "logs",
                                    dirs_exist_ok=True, symlinks=True)
    emit("rank_complete", rank=0, world_size=1)


def verify():
    output = Path(os.environ["RLAR_OUTPUT"])
    events = [json.loads(path.read_text()) for path in (output / "optimizer").glob("*.json")]
    assert events, "No native optimizer post-step event was observed"
    assert all(event["finite_updates"] for event in events), "Nonfinite native update"
    assert any(event["update_l2"] > 0 for event in events), "Native optimizer produced no stored parameter update"
    assert (output / "rollout_observed.json").exists(), "Native generation was not observed"
    assert (output / "native_train_returned.json").exists(), "Native train/pipeline did not return"
    assert (output / "rank_complete.json").exists(), "Trainer rank did not complete"
    emit("completion", status="native_rollout_and_optimizer_complete", optimizer_events=len(events),
         parameter_elements=sum(event["selected_elements"] for event in events),
         update_l2=[event["update_l2"] for event in events],
         optimizer_artifacts=[event["artifact"] for event in events])


if __name__ == "__main__":
    action = sys.argv[1]
    if action == "assets":
        assets()
    elif action == "--config":
        areal_train(sys.argv[1:])
    elif action == "areal":
        areal_train(sys.argv[2:])
    elif action == "roll":
        roll_train()
    elif action == "verify":
        verify()
    else:
        raise ValueError(action)
