"""Defer passive capture until the official AReaL PPO module loads."""
import sys,importlib.abc,importlib.machinery,functools,os,pathlib,json,time,uuid
TARGET="areal.trainer.ppo.actor"
class Loader:
 def __init__(self,inner):self.inner=inner
 def create_module(self,spec):return self.inner.create_module(spec) if hasattr(self.inner,"create_module") else None
 def exec_module(self,module):
  self.inner.exec_module(module);original=module.grpo_loss_fn
  @functools.wraps(original)
  def observe(*args,**kwargs):
   result=original(*args,**kwargs)
   import torch,traceback
   def cpu(v):
    if torch.is_tensor(v):
     if hasattr(v,"to_local"):v=v.to_local()
     return v.detach().cpu().clone()
    if isinstance(v,dict):return {k:cpu(x) for k,x in v.items() if torch.is_tensor(x) or isinstance(x,(dict,list,tuple))}
    if isinstance(v,(list,tuple)):return [cpu(x) for x in v]
    return repr(v)
   out=pathlib.Path(os.environ["RLAR_OUTPUT"]);folder=out/"native-tensors";folder.mkdir(parents=True,exist_ok=True)
   fn=folder/("native-grpo-loss-pid"+str(os.getpid())+"-"+uuid.uuid4().hex+".pt")
   torch.save({"args":cpu(args),"kwargs":cpu(kwargs),"native_loss":cpu(result)},fn)
   d={"event":"native_loss_observed","pid":os.getpid(),"rank":os.environ.get("RANK","0"),"time":time.time(),"loss":result.detach().item(),"loss_dtype":str(result.dtype),"loss_device":str(result.device),"artifact":str(fn),"native_call_stack":traceback.format_stack(limit=20)}
   (out/("native_loss_observed-pid"+str(os.getpid())+".json")).write_text(json.dumps(d,indent=2));print("RLAR_NATIVE_LOSS "+json.dumps(d),flush=True)
   return result
  module.grpo_loss_fn=observe
class Finder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname!=TARGET:return None
  spec=importlib.machinery.PathFinder.find_spec(fullname,path)
  if spec and spec.loader:spec.loader=Loader(spec.loader)
  return spec
sys.meta_path.insert(0,Finder())
