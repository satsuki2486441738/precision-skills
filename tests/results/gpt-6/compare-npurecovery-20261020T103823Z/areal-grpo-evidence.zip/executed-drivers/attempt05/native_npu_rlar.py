"""Private native AReaL NPU driver; no replacement of training/rollout operations."""
import os,json,time,uuid,sys,importlib,importlib.metadata as md
from pathlib import Path
def emit(name,**kw):
 out=Path(os.environ["RLAR_OUTPUT"]);out.mkdir(parents=True,exist_ok=True)
 d={"event":name,"time":time.time(),"pid":os.getpid(),"framework":os.environ["RLAR_FRAMEWORK"],**kw}
 (out/(name+".json")).write_text(json.dumps(d,indent=2,default=str));print("RLAR_STAGE "+json.dumps(d,default=str),flush=True)
def save_tensors(name,batch):
 import torch
 out=Path(os.environ["RLAR_OUTPUT"])/"native-tensors";out.mkdir(exist_ok=True)
 seq=batch if isinstance(batch,list) else [batch]
 captures=[]
 for data in seq:
  caps={}
  for k,v in data.items():
   if torch.is_tensor(v):
    if hasattr(v,"to_local"):v=v.to_local()
    caps[k]=v.detach().cpu().clone()
  captures.append(caps)
 fn=out/(name+"-pid"+str(os.getpid())+"-"+uuid.uuid4().hex+".pt");torch.save(captures,fn)
 emit(name,artifact=str(fn),tensor_metadata=[{k:{"dtype":str(v.dtype),"shape":list(v.shape)} for k,v in cap.items()} for cap in captures])
 return fn
def versions():
 import torch,torch_npu,platform
 modules={}
 for name in ("torch","torch_npu","transformers","peft","datasets","ray","vllm","vllm_ascend","areal"):
  try:
   m=importlib.import_module(name);modules[name]={"version":getattr(m,"__version__",None),"path":getattr(m,"__file__",None)}
  except Exception as e:modules[name]={"import_error":repr(e)}
  try:modules[name]["metadata"]=md.version(name.replace("_","-"))
  except md.PackageNotFoundError:pass
 emit("runtime",python=sys.version,executable=sys.executable,modules=modules,visible=os.environ.get("ASCEND_RT_VISIBLE_DEVICES"),devices=[torch.npu.get_device_name(i) for i in range(torch.npu.device_count())])
def assets():
 import yaml
 out=Path(os.environ["RLAR_OUTPUT"]);source=Path(os.environ["RLAR_SOURCE"]);model="/SHARED_MODELS/Qwen3-0.6B"
 rows=[{"messages":[{"role":"user","content":"Count 1 2 3 then continue briefly."}],"ground_truth":"4","tag":"tiny","data_source":"seeded-native"},
 {"messages":[{"role":"user","content":"Write three small numbers."}],"ground_truth":"1","tag":"tiny","data_source":"seeded-native"}]
 (out/"data.jsonl").write_text("\n".join(json.dumps(x) for x in rows)+"\n")
 cfg=yaml.safe_load((source/"examples/math/gsm8k_grpo_npu.yaml").read_text())
 cfg.update(experiment_name="npurl",trial_name=out.name,seed=20261020,total_train_epochs=1,total_train_steps=1,tokenizer_path=model)
 cfg["scheduler"]["type"]="local"
 cfg["cluster"].update(n_nodes=1,n_gpus_per_node=4,fileroot=str(out/"native"))
 cfg["cluster"]["name_resolve"]={"type":"nfs","nfs_record_root":str(out/"name-resolve")}
 cfg["rollout"].update(backend="vllm:d1p1t1",max_concurrent_rollouts=2,max_head_offpolicyness=0)
 cfg["gconfig"].update(n_samples=2,max_new_tokens=8,max_tokens=128,min_new_tokens=0,temperature=1.0,greedy=False)
 cfg["actor"].update(backend="fsdp:d1p1t1",path=model,gradient_checkpointing=False,mask_no_eos_with_zero=False,reward_scaling=1.0,reward_bias=0.0,kl_ctl=0.0)
 cfg["actor"]["mb_spec"]["max_tokens_per_mb"]=512
 cfg["actor"]["optimizer"].update(lr=0.001,weight_decay=0.0,warmup_steps_proportion=0.0)
 # Preserve true native HCCL actor-to-rollout weight update.
 cfg["vllm"].update(model=model,max_model_len=256,max_num_seqs=4,gpu_memory_utilization=0.2,enforce_eager=True)
 cfg["train_dataset"].update(path=str(out/"data.jsonl"),batch_size=2,shuffle=False,pin_memory=False,num_workers=0,max_length=128)
 cfg["valid_dataset"]=None
 for name in ("saver","evaluator","recover"):
  cfg[name].update(freq_epochs=None,freq_steps=None,freq_secs=None)
 cfg["recover"].update(mode="disabled",retries=0)
 (out/"areal.yaml").write_text(yaml.safe_dump(cfg,sort_keys=False))
 emit("assets_ready",model=model,dataset=str(out/"data.jsonl"),source_commit="65d0bcd8afb3e10b0083003a1d1694135fab093c",seed=20261020)
def areal_train(args):
 from datasets import Dataset
 from areal import PPOTrainer
 from areal.api.cli_args import GRPOConfig,load_expr_config
 from areal.utils.hf_utils import load_hf_tokenizer
 from areal.workflow.rlvr import RLVRWorkflow
 cfg,_=load_expr_config(args,GRPOConfig);versions()
 tok=load_hf_tokenizer(cfg.tokenizer_path)
 rows=[json.loads(x) for x in (Path(os.environ["RLAR_OUTPUT"])/"data.jsonl").read_text().splitlines()]
 workflow='rlar_areal_workflow.ObservedWorkflow'
 workflow_kwargs={'gconfig':cfg.gconfig,'tokenizer':cfg.tokenizer_path}
 with PPOTrainer(cfg,train_dataset=Dataset.from_list(rows),valid_dataset=None) as trainer:
  original_adv=trainer.actor.compute_advantages
  def observed_adv(batch,*args,**kwargs):
   result=original_adv(batch,*args,**kwargs);save_tensors("advantages_observed",result);return result
  trainer.actor.compute_advantages=observed_adv
  original_ppo=trainer.actor.ppo_update
  def observed_ppo(batch,*args,**kwargs):
   save_tensors("objective_inputs_observed",batch);result=original_ppo(batch,*args,**kwargs);emit("objective_returned",result=repr(result));return result
  trainer.actor.ppo_update=observed_ppo
  trainer.train(workflow=workflow,workflow_kwargs=workflow_kwargs)
  emit("native_train_returned",actor=type(trainer.actor).__name__,rollout=type(trainer.rollout).__name__)
 emit("rank_complete",rank=0,world_size=1,role="driver")
def verify():
 out=Path(os.environ["RLAR_OUTPUT"])
 events=[json.loads(p.read_text()) for p in (out/"optimizer").glob("*.json")]
 assert events,"No observed native optimizer step"
 assert all(x["finite_updates"] for x in events)
 assert any(x["update_l2"]>0 for x in events),"No positive stored parameter update"
 for n in ("rollout_observed","advantages_observed","objective_inputs_observed","objective_returned","native_train_returned","rank_complete"):assert (out/(n+".json")).is_file(),n
 emit("completion",status="native_rollout_reward_advantage_loss_optimizer_complete",optimizer_steps=len(events),update_l2=[x["update_l2"] for x in events])
if __name__=="__main__":
 action=sys.argv[1]
 if action=="assets":assets()
 elif action=="train":areal_train(sys.argv[2:])
 elif action=="verify":verify()
 else:raise ValueError(action)
