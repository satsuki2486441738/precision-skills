"""Lazy, passive capture: do not preload Torch/NPU into Ray infrastructure."""
import os,sys,importlib.abc,importlib.machinery

def patch_optimizer(module):
 cls=module.Optimizer
 if getattr(cls,'_rlar_observed',False):return
 cls._rlar_observed=True;original=cls.__init__
 def observed(self,*args,**kwargs):
  original(self,*args,**kwargs);self._rlar_step=0
  def cpu(p):
   if hasattr(p,'to_local'):p=p.to_local()
   return p.detach().reshape(-1)[:8192].cpu().clone()
  def pre(opt,args,kwargs):
   import traceback
   allp=[(gi,pi,p) for gi,g in enumerate(opt.param_groups) for pi,p in enumerate(g['params'])]
   selected=[(gi,pi,p) for gi,pi,p in allp if p.numel()>0][:12]
   opt._rlar_selected=selected;opt._rlar_before=[cpu(p) for _,_,p in selected]
   opt._rlar_grads=[None if p.grad is None else cpu(p.grad) for _,_,p in selected]
   opt._rlar_stack=traceback.format_stack(limit=24)
  def post(opt,args,kwargs):
   import torch,pathlib,time,json
   selected=opt._rlar_selected;before=opt._rlar_before;after=[cpu(p) for _,_,p in selected]
   updates=[a.float()-b.float() for a,b in zip(after,before)]
   out=pathlib.Path(os.environ['RLAR_OUTPUT'])/'optimizer';out.mkdir(parents=True,exist_ok=True)
   name=f"pid{os.getpid()}-rank{os.environ.get('RANK','0')}-step{opt._rlar_step}"
   coords=[{'group':gi,'index':pi,'shape':list(p.shape),'sample':'flattened first 8192 elements','sample_elements':min(p.numel(),8192),'dtype':str(p.dtype),'device':str(p.device)} for gi,pi,p in selected]
   torch.save({'before':before,'after':after,'postclip_gradients':opt._rlar_grads,'updates_fp32':updates,'coordinates':coords},out/(name+'.pt'))
   e={'event':'native_optimizer_step_returned','framework':os.environ['RLAR_FRAMEWORK'],'pid':os.getpid(),'rank':os.environ.get('RANK','0'),'step':opt._rlar_step,'optimizer':type(opt).__module__+'.'+type(opt).__name__,'time':time.time(),'torch':torch.__version__,'visible':os.environ.get('ASCEND_RT_VISIBLE_DEVICES'),'selected_parameter_count':len(selected),'selected_elements':sum(p.numel() for _,_,p in selected),'all_parameter_elements':sum(p.numel() for g in opt.param_groups for p in g['params']),'coordinates':coords,'update_l2':sum(u.double().square().sum().item() for u in updates)**.5,'finite_updates':all(torch.isfinite(u).all().item() for u in updates),'present_gradients':sum(g is not None for g in opt._rlar_grads),'artifact':name+'.pt','native_call_stack':opt._rlar_stack}
   (out/(name+'.json')).write_text(json.dumps(e,indent=2));print('RLAR_NATIVE_OPTIMIZER '+json.dumps(e),flush=True);opt._rlar_step+=1
  self.register_step_pre_hook(pre);self.register_step_post_hook(post)
 cls.__init__=observed

class CaptureFinder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname!='torch.optim.optimizer':return None
  spec=importlib.machinery.PathFinder.find_spec(fullname,path)
  if spec and spec.loader:
   original=spec.loader.exec_module
   def execute(module):original(module);patch_optimizer(module)
   spec.loader.exec_module=execute
  return spec

if os.environ.get('RLAR_CAPTURE')=='1':
 sys.meta_path.insert(0,CaptureFinder())
 if os.environ.get('RLAR_FRAMEWORK')=='areal':import rlar_areal_observe
 elif os.environ.get('RLAR_FRAMEWORK')=='openrlhf-community':import rlar_open_observe
