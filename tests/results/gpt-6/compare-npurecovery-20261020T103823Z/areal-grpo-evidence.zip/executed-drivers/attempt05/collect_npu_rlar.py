"""Fresh case collector. Distribution metadata is never native execution proof."""
import argparse,pathlib,subprocess,json,datetime,hashlib,zipfile,sys
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--root",default="/home/<operator>/material/precision-gpt6-npu-20261020/rlar");a=ap.parse_args();r=pathlib.Path(a.root)
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
 dst=r/("evidence-"+stamp);dst.mkdir(exist_ok=False)
 summary={"collected_utc":stamp,"root":str(r),"collector_sha256":hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),"frameworks":{}}
 for identity,prefix,env in (("AReaL-ascend-v1.0.4","areal","areal"),("ROLL-v0.4.0","roll","roll"),("OpenRLHF-community-zhuo97","openrlhf-community","openrlhf-community")):
  python=r/"environments"/env/"bin/python";versions={}
  if python.exists():
   program="import importlib.metadata as m,json,sys; names=['torch','torch-npu','transformers','peft','datasets','ray','vllm','vllm-ascend','deepspeed','areal','roll']; out={}; exec(\"for n in names:\\n try:out[n]=m.version(n)\\n except m.PackageNotFoundError:out[n]=None\"); print(json.dumps({'executable':sys.executable,'metadata_only':True,'versions':out}))"
   p=subprocess.run([str(python),"-c",program],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=60)
   versions={"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
  attempts=[];files=[]
  for folder in sorted((r/"results").glob(prefix+"-*")) if (r/"results").exists() else []:
   events={}
   for f in folder.glob("*.json"):
    try:events[f.stem]=json.loads(f.read_text())
    except Exception as e:events[f.stem]={"read_error":str(e)}
   optimizer=[]
   for f in (folder/"optimizer").glob("*.json"):
    try:optimizer.append(json.loads(f.read_text()))
    except Exception as e:optimizer.append({"read_error":str(e)})
   native_complete=bool(events.get("completion",{}).get("status","").endswith("_complete"))
   attempts.append({"output":str(folder),"completion_marker":native_complete,"process_exit":events.get("process_exit"),"events":events,"optimizer_events":optimizer,"stdout_tail":(folder/"stdout.log").read_text(errors="replace")[-16000:] if (folder/"stdout.log").exists() else None})
   for f in folder.rglob("*"):
    if f.is_file() and not f.is_symlink() and f.suffix not in (".safetensors",".bin") and "checkpoint" not in f.parts:files.append(f)
  for f in (r/"logs").glob(prefix+"*"):
   if f.is_file():files.append(f)
  for f in (r/"drivers").rglob("*.py") if (r/"drivers").exists() else []:files.append(f)
  report={"identity":identity,"upstream_native_pass_allowed":prefix!="openrlhf-community","installed_distribution_metadata":versions,"attempts":attempts}
  result=dst/(prefix+".json");result.write_text(json.dumps(report,indent=2,default=str));files.append(result)
  archive=dst/(prefix+".zip")
  with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
   for f in sorted(set(files)):
    z.write(f,arcname=str(f.relative_to(r)))
  summary["frameworks"][identity]={"attempts":len(attempts),"native_completion_observed":any(x["completion_marker"] for x in attempts),"report":str(result),"archive":str(archive),"bytes":archive.stat().st_size,"sha256":hashlib.sha256(archive.read_bytes()).hexdigest()}
 (dst/"summary.json").write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=="__main__":main()
