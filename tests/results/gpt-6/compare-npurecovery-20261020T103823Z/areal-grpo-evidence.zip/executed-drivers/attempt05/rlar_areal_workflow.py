"""Importable custom reward workflow delegating rollout and rewards to native RLVR."""
from areal.workflow.rlvr import RLVRWorkflow
from native_npu_rlar import save_tensors,emit

def token_mean_reward(prompt,completions,prompt_ids,completion_ids,**kwargs):
 reward=sum(completion_ids)/max(len(completion_ids),1)/100.0
 emit('reward_observed',reward=reward,generated_token_count=len(completion_ids),reward_fn='actual generated token-ID mean divided by100; synthetic validation only')
 return reward

class ObservedWorkflow(RLVRWorkflow):
 def __init__(self,gconfig,tokenizer):
  super().__init__(reward_fn=token_mean_reward,gconfig=gconfig,tokenizer=tokenizer,enable_thinking=False)
 async def arun_episode(self,engine,data):
  result=await super().arun_episode(engine,data);save_tensors('rollout_observed',result);return result
