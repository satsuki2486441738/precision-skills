#!/bin/bash
set -Euo pipefail
source /usr/local/Ascend/cann/set_env.sh
unset LOCAL_RANK RANK WORLD_SIZE LOCAL_WORLD_SIZE GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE NODE_RANK MASTER_ADDR MASTER_PORT RLAR_CAPTURE RLAR_OUTPUT RLAR_FRAMEWORK
export ASCEND_RT_VISIBLE_DEVICES='' OMP_NUM_THREADS=2 TMPDIR=/tmp/areal-reference-20261020T105208Z
mkdir -p "$TMPDIR"
timeout --signal=TERM --kill-after=30s 600s /REMOTE_WORKSPACE/rlar/environments/areal/bin/python /REMOTE_WORKSPACE/rlar/drivers/reference01/areal_cpu_reference.py --native-output /REMOTE_WORKSPACE/rlar/results/areal-native-dtfs-20261020T102659Z --output /REMOTE_WORKSPACE/rlar/results/areal-native-dtfs-20261020T102659Z/reference/fp32-20261020T105208Z
rc=$?
printf '{"exit_code":%s}\n' "$rc" > /REMOTE_WORKSPACE/rlar/results/areal-native-dtfs-20261020T102659Z/reference/fp32-20261020T105208Z/process_exit.json
exit "$rc"
