#!/bin/bash
set -Euo pipefail
source /usr/local/Ascend/cann/set_env.sh
unset LOCAL_RANK RANK WORLD_SIZE LOCAL_WORLD_SIZE GROUP_RANK ROLE_RANK ROLE_WORLD_SIZE NODE_RANK MASTER_ADDR MASTER_PORT RLAR_CAPTURE RLAR_OUTPUT RLAR_FRAMEWORK
export ASCEND_RT_VISIBLE_DEVICES='' OMP_NUM_THREADS=2 TMPDIR=/tmp/rlar-reference-20261020T112820Z
mkdir -p "$TMPDIR"
timeout --signal=TERM --kill-after=30s 900s /REMOTE_WORKSPACE/rlar/environments/roll/bin/python /REMOTE_WORKSPACE/rlar/drivers/cpu-reference01/rl_cpu_reference.py --framework roll --native-output /REMOTE_WORKSPACE/rlar/results/roll-native-dtfs-20261020T112103Z --output /REMOTE_WORKSPACE/rlar/results/roll-native-dtfs-20261020T112103Z/reference/fp32-20261020T112820Z
rc=$?
printf '{"exit_code":%s}\n' "$rc" > /REMOTE_WORKSPACE/rlar/results/roll-native-dtfs-20261020T112103Z/reference/fp32-20261020T112820Z/process_exit.json
exit "$rc"
