# Third-party attribution companion

This companion and the linked native evaluation evidence archives form one
public distribution. The `licenses/` files reproduce upstream license and
notice bytes without modification. `ATTRIBUTION.json` records fixed source
identities, retrieval provenance, SHA256 values, and public source selectors.

Selectors use `archive-or-index::logical/path` notation. For indexed volumes,
paths refer to logical paths after verified reassembly. Wildcards identify
source prefixes in bundles assembled during the same evaluation. Framework
context entries also cover source excerpts in logs, patches and provenance;
they do not relabel task-owned collectors as upstream code. Captured numeric
arrays are not relicensed by this companion.

Original copyright/license headers remain in redistributed source snapshots.
Compatibility changes, redactions, source forks, and native/reference scope
remain documented in the corresponding evidence and guide. A fixed source
identity supplies attribution, not a claim of unmodified runtime source.
