"""Launch one clean CPU reference with immutable source and logs."""
import argparse
import os
from setup_trt import command,ENV,HERE

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--native-attempt',required=True);ap.add_argument('--attempt',required=True);a=ap.parse_args()
    os.environ['CUDA_VISIBLE_DEVICES']=''
    os.environ['TOKENIZERS_PARALLELISM']='false'
    source=HERE/'trt_cpu_reference.py'
    frozen=HERE/('trt-reference-'+a.case+'-'+a.attempt+'.collector.py');assert not frozen.exists();frozen.write_bytes(source.read_bytes())
    command('trt-reference-'+a.case+'-'+a.attempt,[str(ENV/'bin/python'),str(frozen),'--case',a.case,'--native-history',str(HERE/('trt-native-'+a.case+'-'+a.native_attempt)/'result.json'),'--output',str(HERE/('trt-reference-'+a.case+'-'+a.attempt))])

if __name__=='__main__':main()
