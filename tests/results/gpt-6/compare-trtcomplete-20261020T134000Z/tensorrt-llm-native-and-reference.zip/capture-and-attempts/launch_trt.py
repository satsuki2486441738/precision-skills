"""Run task-owned GPU jobs with private CUDA/MPI paths and immutable logs."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import time

ROOT=Path('/LOCAL_LINUX_HOME/precision-framework-tests/remaining-20261020T122851Z')
HERE=Path(__file__).resolve().parent
ENV=ROOT/'environments/trtllm-1.2.0-py312-attempt02'

def native_environment():
    cuda=ROOT/'toolkits/cuda13.1/nvidia/cu13';mpi=ROOT/'runtimes/openmpi-attempt02'
    site=ENV/'lib/python3.12/site-packages'
    libs=[ROOT/'runtimes/python312/usr/lib/x86_64-linux-gnu',mpi/'usr/lib/x86_64-linux-gnu',mpi/'usr/lib/x86_64-linux-gnu/pmix2/lib',cuda/'lib',site/'torch/lib',site/'nvidia/cu13/lib',Path('/usr/lib/wsl/lib')]
    libs.extend(p for p in site.glob('nvidia/*/lib') if p not in libs)
    libs.extend(p for p in site.glob('tensorrt*_libs') if p.is_dir())
    headers=ROOT/'runtimes/python312/usr/include/python3.12'
    return dict(os.environ,CUDA_HOME=str(cuda),CUDA_PATH=str(cuda),CPATH=str(headers)+':'+str(headers.parent)+':'+str(cuda/'include'),PATH=str(cuda/'bin')+':'+str(mpi/'usr/bin')+':'+os.environ['PATH'],LD_LIBRARY_PATH=':'.join(map(str,libs)),OPAL_PREFIX=str(mpi/'usr'),OMPI_MCA_mca_base_component_path=str(mpi/'usr/lib/x86_64-linux-gnu/openmpi/lib/openmpi3'),OMP_NUM_THREADS='4',MAX_JOBS='2',TORCHINDUCTOR_COMPILE_THREADS='1',CUDA_VISIBLE_DEVICES='0',TOKENIZERS_PARALLELISM='false',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONUNBUFFERED='1',TLLM_LOG_LEVEL='INFO')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--attempt',required=True);ap.add_argument('--attention',default='TRTLLM');a=ap.parse_args()
    name='trt-native-'+a.case+'-'+a.attempt
    log=HERE/(name+'.log');result=HERE/(name+'.json');assert not log.exists() and not result.exists()
    env=native_environment()
    collector=HERE/(name+'.collector.py');assert not collector.exists();collector.write_bytes((HERE/'trt_native.py').read_bytes())
    cmd=[str(ENV/'bin/python'),str(collector),'--case',a.case,'--output',str(HERE/name),'--attention',a.attention]
    print(json.dumps(dict(stage=name,status='starting')),flush=True);start=time.monotonic()
    with log.open('xb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
    receipt=dict(command=cmd,returncode=p.returncode,elapsed_seconds=time.monotonic()-start,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),environment_overrides={k:env[k] for k in ['CUDA_HOME','LD_LIBRARY_PATH','OPAL_PREFIX','OMPI_MCA_mca_base_component_path','CUDA_VISIBLE_DEVICES','MAX_JOBS','TORCHINDUCTOR_COMPILE_THREADS']})
    result.write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt),flush=True)
    raise SystemExit(p.returncode)

if __name__=='__main__':main()
