"""Hash actual installed compiled libraries when pip has not retained wheels."""
from pathlib import Path
import hashlib
import json
from launch_trt import ENV,HERE

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    site=ENV/'lib/python3.12/site-packages'
    records=[]
    for folder in [site/'tensorrt_llm',site/'tensorrt_libs']:
        for p in sorted(folder.rglob('*')):
            if p.is_file() and ('.so' in p.name or p.name=='RECORD'):
                records.append(dict(path=p.relative_to(site).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
    p=site/'tensorrt_llm-1.2.0.dist-info/RECORD'
    records.append(dict(path=p.relative_to(site).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
    out=HERE/'trt-runtime-provenance/installed-native-libraries.json';assert not out.exists()
    out.write_text(json.dumps(dict(wheel_cache_retained=False,whole_wheel_sha256_locally_computed=False,claim='Actual installed library and wheel RECORD byte identities; not an invented complete wheel digest.',files=records),indent=2),encoding='utf-8')
    print(json.dumps(dict(files=len(records),bytes=sum(x['bytes'] for x in records))))

if __name__=='__main__':main()
