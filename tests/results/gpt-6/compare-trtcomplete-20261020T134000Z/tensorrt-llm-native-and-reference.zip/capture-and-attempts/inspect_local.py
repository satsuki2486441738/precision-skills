import json,sys,importlib.metadata as m,subprocess
from pathlib import Path
result={'python':sys.executable,'packages':{}}
for k in ['torch','transformers','tensorrt-llm','tensorrt','nvidia-cuda-runtime-cu12','nvidia-cuda-runtime-cu13']:
 try:result['packages'][k]=m.version(k)
 except m.PackageNotFoundError:pass
print(json.dumps(result))
