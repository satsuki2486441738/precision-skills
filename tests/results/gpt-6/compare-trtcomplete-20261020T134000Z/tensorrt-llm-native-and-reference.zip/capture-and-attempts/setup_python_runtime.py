"""Unpack the matching Ubuntu Python shared runtime without system installation."""
from pathlib import Path
import setup_private_mpi_v2 as install

if __name__=='__main__':
    install.ROOT=Path('/LOCAL_LINUX_HOME/precision-framework-tests/remaining-20261020T122851Z/runtimes/python312')
    install.PACKAGES=['libpython3.12t64','libpython3.12-dev']
    install.HERE=Path(__file__).resolve().parent/'python312-install'
    install.HERE.mkdir(exist_ok=False)
    install.main()
