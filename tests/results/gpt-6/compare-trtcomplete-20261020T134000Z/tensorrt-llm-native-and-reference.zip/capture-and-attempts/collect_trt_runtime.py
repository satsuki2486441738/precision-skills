"""Collect actual package/compiler/library identities and resource release proof."""
import ctypes
import hashlib
import importlib.metadata as md
import json
from pathlib import Path
import subprocess
import zipfile
from launch_trt import HERE,ENV,native_environment

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    output=HERE/'trt-runtime-provenance';output.mkdir(exist_ok=False)
    result={}
    commands={'pip-freeze':[str(ENV/'bin/python'),'-m','pip','freeze'],'pip-check':[str(ENV/'bin/python'),'-m','pip','check'],'nvcc':[native_environment()['CUDA_HOME']+'/bin/nvcc','--version'],'gpu-release':['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.used','--format=csv'],'compute-processes':['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv']}
    for name,args in commands.items():
        p=subprocess.run(args,env=native_environment(),capture_output=True,text=True,timeout=60)
        (output/(name+'.log')).write_text(p.stdout+p.stderr,encoding='utf-8')
        result[name]=dict(command=args,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
    candidates=[]
    for p in Path('/LOCAL_LINUX_HOME/.cache/pip/http-v2').rglob('*.body'):
        if p.stat().st_size not in [2514193777,3437501033]:continue
        with zipfile.ZipFile(p) as z:
            metadata=[n for n in z.namelist() if n.endswith('.dist-info/METADATA')]
            assert len(metadata)==1
            selected=z.read(metadata[0]).decode('utf-8').splitlines()[:10]
        candidates.append(dict(cache_file=str(p),bytes=p.stat().st_size,sha256=sha(p),metadata_header=selected))
    result['actual_cached_wheels']=candidates
    site=ENV/'lib/python3.12/site-packages'
    license_file=site/'tensorrt_llm-1.2.0.dist-info/licenses/LICENSE'
    b=license_file.read_bytes();(output/'TensorRT-LLM-1.2.0-LICENSE').write_bytes(b)
    result['source_license']=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),source=str(license_file))
    packages={}
    for d in md.distributions(path=[str(site)]):packages[d.metadata['Name']]=d.version
    result['installed_distributions']=packages
    def get(name,function):
        library=ctypes.CDLL(name);value=ctypes.c_int();status=getattr(library,function)(ctypes.byref(value));return dict(status=status,version=value.value)
    result['cuda_driver_api']=get('libcuda.so.1','cuDriverGetVersion')
    result['cuda_runtime_api']=get('libcudart.so.13','cudaRuntimeGetVersion')
    result['loaded_cuda_libraries']=[line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if any(n in line for n in ['libcuda.so','libcudart.so'])]
    (output/'runtime.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(dict(pip_check=result['pip-check']['returncode'],wheel_hashes=[dict(bytes=x['bytes'],sha256=x['sha256']) for x in candidates],license_sha256=result['source_license']['sha256'],driver=result['cuda_driver_api'],runtime=result['cuda_runtime_api'])),flush=True)

if __name__=='__main__':main()
