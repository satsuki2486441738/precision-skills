"""Fresh CPU fixed-history reference; accepts generated token IDs, not native scores."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import time
import torch
import numpy as np
from safetensors.torch import save_file
from transformers import AutoModelForCausalLM

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--native-history',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    root=Path(__file__).resolve().parent
    case=next(x for x in json.loads((root/'trt-models-and-inputs.json').read_text())['cases'] if x['name']==a.case)
    history=json.loads(Path(a.native_history).read_text());prompt=history['prompt_ids'];targets=history['generated_ids'];assert prompt==case['prompt_ids'] and len(targets)==4
    torch.set_num_threads(4);torch.manual_seed(20261020)
    started=time.monotonic()
    model=AutoModelForCausalLM.from_pretrained(case['model'],local_files_only=True,torch_dtype=torch.float16,attn_implementation='eager').float().eval()
    dtypes=Counter(str(p.dtype) for p in model.parameters());assert set(dtypes)=={'torch.float32'}
    rows=[];cache=None
    with torch.no_grad():
        for i in range(len(targets)):
            ids=prompt if i==0 else [targets[i-1]]
            positions=list(range(len(prompt))) if i==0 else [len(prompt)+i-1]
            result=model(input_ids=torch.tensor([ids]),position_ids=torch.tensor([positions]),attention_mask=torch.ones((1,len(prompt)+i),dtype=torch.long),past_key_values=cache,use_cache=True)
            cache=result.past_key_values
            rows.append(result.logits[0,-1].detach().cpu().clone())
    logits=torch.stack(rows).contiguous();assert torch.isfinite(logits).all()
    save_file({'generation_logits':logits},str(out/'reference.safetensors'))
    np.save(out/'generation-f32.npy',logits.numpy(),allow_pickle=False)
    record=dict(status='independent_cpu_reference_complete',case=case['name'],input_history_only=dict(prompt_ids=prompt,generated_ids=targets),parameter_dtypes=dict(dtypes),logit_dtype=str(logits.dtype),cache_dtype='torch.float32',shape=list(logits.shape),torch=torch.__version__,transformers=__import__('transformers').__version__,tensorrt_llm_imported='tensorrt_llm' in sys.modules,native_scores_read=False,elapsed_seconds=time.monotonic()-started,initial_representation='Same source checkpoint loaded as float16, then promoted to float32 before forward; native converted parameter values were not directly measured.')
    (out/'result.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record),flush=True)

if __name__=='__main__':main()
