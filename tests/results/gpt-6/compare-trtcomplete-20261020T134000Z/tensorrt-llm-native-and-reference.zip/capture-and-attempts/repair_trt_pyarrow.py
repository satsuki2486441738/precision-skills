from setup_trt import command,ENV,HERE
command("trt-pyarrow-repair-01",[str(ENV/"bin/python"),"-m","pip","install","pyarrow==21.0.0","-c",str(HERE/"trt-install-constraints.txt")])
