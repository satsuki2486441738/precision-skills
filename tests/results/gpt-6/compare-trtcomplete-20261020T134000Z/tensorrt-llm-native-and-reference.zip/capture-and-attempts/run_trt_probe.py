"""Use the shipped skill probe in the exact private GPU interpreter."""
from pathlib import Path
import json
import subprocess
import sys
from launch_trt import native_environment,ENV,HERE

def main():
    suffix=sys.argv[1]
    spec=HERE/('trt-probe-'+suffix+'.spec.json');assert not spec.exists()
    spec.write_text(json.dumps(dict(imports=['torch','tensorrt_llm'],symbols=['tensorrt_llm:LLM','tensorrt_llm:SamplingParams'],checks=['trt_probe_checks:initialize'],distributions=['torch','tensorrt-llm','transformers','flashinfer-python'],python_paths=[str(HERE)]),indent=2),encoding='utf-8')
    core=HERE.parents[1]/'skills/precision-skill/scripts/runtime_probe.py'
    p=subprocess.run([str(ENV/'bin/python'),str(core),'--spec',str(spec),'--output',str(HERE/('trt-probe-'+suffix+'.json')),'--timeout','180'],env=native_environment())
    raise SystemExit(p.returncode)

if __name__=='__main__':main()
