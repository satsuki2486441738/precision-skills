"""Validate native copy-only history/scores and execute all six core CLIs."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
TOOLS=REPO/'skills/precision-skill/scripts'
sys.path.insert(0,str(TOOLS))
from inference_capture import validate_history

def save(p,o):
    with p.open('x',encoding='utf-8') as f:json.dump(o,f,indent=2,allow_nan=False)

def tensor(p,key):
    b=p.read_bytes();size=int.from_bytes(b[:8],'little');header=json.loads(b[8:8+size]);s=header[key];assert s['dtype']=='F32'
    lo,hi=s['data_offsets'];return np.frombuffer(b,dtype='<f4',offset=8+size+lo,count=(hi-lo)//4).reshape(s['shape'])

def main():
    root=HERE/'trt-core-metrics-04';root.mkdir(exist_ok=False)
    resource=json.loads((HERE/'trt-models-and-inputs.json').read_text())
    receipts=[]
    for name,attempt in [('seeded-llama','02'),('qwen25-05b','01')]:
        native=HERE/('trt-native-'+name+'-'+attempt);reference=HERE/('trt-reference-'+name+'-01')
        result=json.loads((native/'result.json').read_text());assert result['status']=='native_generation_complete'
        ref=json.loads((reference/'result.json').read_text());assert ref['status']=='independent_cpu_reference_complete' and not ref['native_scores_read'] and not ref['tensorrt_llm_imported']
        prompt=result['prompt_ids'];continuation=result['generated_ids'];out=root/name;out.mkdir()
        observed=[]
        for meta in (native/'callback-events').glob('*.json'):
            info=json.loads(meta.read_text());assert info['original_device']=='cuda:0' and info['copy_only'] and not info['modified_input']
            assert len(info['token_ids'])==1
            observed.append((info['token_ids'][0],tensor(meta.with_suffix('.safetensors'),'logits').reshape(-1)))
        assert len(observed)==4
        api=tensor(native/'native-api.safetensors','generation_logits')
        context=tensor(native/'native-api.safetensors','context_logits')
        assert np.array_equal(api,np.load(native/'generation-f32.npy',allow_pickle=False))
        assert np.array_equal(context[-1],api[0])
        events=[]
        for i in range(4):
            history=prompt+continuation[:i];matches=[row for ids,row in observed if ids==history];assert len(matches)==1
            assert np.array_equal(matches[0],context[0] if i==0 else api[i])
            assert int(api[i].argmax())==continuation[i]
            events.append(dict(stage='prefill' if i==0 else 'decode',input_ids=history if i==0 else [history[-1]],positions=list(range(len(prompt))) if i==0 else [len(history)-1],prefix_length=0 if i==0 else len(history)-1))
        checked=validate_history(prompt,continuation,events)
        save(out/'capture-validation.json',dict(status='native_api_score_selection_and_callback_histories_validated',history=checked,native_callback_histories=[x[0] for x in observed],events=events,positions='Logical positions derived from the actual callback histories; native physical input position tensors not instrumented.',native_callback_rows=4,warmup_rows_included=0,prefill_selection='Returned generation_logits[0] equals returned context_logits[-1]; callback exposed context_logits[0], so its first row is not used as the final-prefill distribution.',decode_selection='All three callback rows are bit-identical to returned generation_logits[1:4].',native_greedy_argmax_equals_generated_ids=True,failed_initial_export='Attempt01 wrongly assumed every callback row was the generation distribution; it was rejected before producing any comparison report. All original arrays remain unchanged.'))
        common=dict(model=dict(name=name,source_files=resource['resource_files'][name],quantization='none: unquantized'),inputs=dict(prompt=prompt,continuation=continuation),numerics=dict(raw_score_dtype='float32',derived_logprob_dtype='offline float64 log_softmax',requested_model_loading='float16',cache_and_arithmetic='Declared separately for native CUDA and CPU reference'),scope='Four full-vocabulary rows: one prefill and three cached decode; TP1; fixed native continuation; diagnostic metrics only.',capture=dict(coordinates='Four full-vocabulary native API rows paired to the CPU fixed native history, anchored by context last row and three decode callbacks.',native_converted_parameter_values_directly_measured=False),weight_loading='Same unquantized source checkpoint; native requests float16, CPU loads float16 then promotes stored values to float32 before forward.')
        sides=dict(reference=dict(engine='Transformers CPU eager',attention_backend='eager',parameter_dtype='float32 after float16 loading',cache_dtype='float32',logit_storage='float32',hardware='x86_64 CPU',parameter_values_verified_by_tensor=False),native=dict(engine='TensorRT-LLM 1.2.0 PyTorch backend',attention_backend='TRTLLM',parameter_dtype='requested float16',cache_dtype='auto resolves from float16 model by upstream allocator; actual cache tensors not copied',logit_storage='float32',hardware='NVIDIA RTX5060 sm120',parameter_values_verified_by_tensor=False))
        shape=list(api.shape)
        for side,folder in [('native',native),('reference',reference)]:
            a=np.load(folder/'generation-f32.npy',allow_pickle=False);assert a.dtype==np.float32 and list(a.shape)==shape and np.isfinite(a).all()
            if side=='reference':assert np.array_equal(a,tensor(folder/'reference.safetensors','generation_logits'))
            np.save(out/(side+'-logits.npy'),a,allow_pickle=False)
            x=a.astype(np.float64);x-=x.max(axis=-1,keepdims=True);lp=x-np.log(np.exp(x).sum(axis=-1,keepdims=True))
            np.save(out/(side+'-logprobs.npy'),lp,allow_pickle=False)
            save(out/(side+'-environment.json'),dict(rank=0,versions=ref if side=='reference' else json.loads((native/'environment.json').read_text()),actual={**common,**sides[side]},logprob_export='Explicit offline FP64 log_softmax from the preserved raw float32 logits; not native probability dtype.'))
            save(out/(side+'-status.json'),dict(rank=0,status='completed',execution='independent CPU fixed-history forward' if side=='reference' else 'native LLM.generate and shutdown completed',source_result_sha256=hashlib.sha256((folder/'result.json').read_bytes()).hexdigest()))
        positions=[dict(sample=name,position=len(prompt)-1+i,history=prompt+continuation[:i]) for i in range(4)]
        coords=dict(sample=name,prediction_positions=[p['position'] for p in positions],execution_stages=['prefill','first_decode','later_decode','later_decode'],token_ids='full vocabulary order')
        specs={'tensors':dict(schema_version=2,kind='tensors',stage='observations',tensors=[dict(name='logits',shape=shape,present=True,coordinates=coords)]),'distributions':dict(schema_version=2,kind='distributions',positions=positions,vocab_size=shape[1],normalization_tolerance=1e-5,renormalization='full_vocabulary_fp64'),'target-scores':dict(schema_version=1,kind='target-scores',targets=[dict(sample=name,position=len(prompt)+i,token=t) for i,t in enumerate(continuation)])}
        for kind,spec in specs.items():
            contract={**spec,'common':common,'side_conditions':sides,'thresholds':None,'expected_ranks':{'reference':[0],'native':[0]}};cp=out/(kind+'-contract.json');save(cp,contract)
            manifests=[]
            for side in ['reference','native']:
                m=dict(schema_version=spec['schema_version'],kind=kind,common=common,side=side,expected_ranks=[0],ranks=[dict(rank=0,environment=side+'-environment.json',status=side+'-status.json')])
                if kind=='tensors':m.update(stage='observations',tensors=[dict(name='logits',shape=shape,present=True,coordinates=coords,shards=[dict(offset=0,value=dict(path=side+'-logits.npy'))])])
                elif kind=='distributions':m['positions']=[{**p,'scores':dict(path=side+'-logprobs.npy',row=i)} for i,p in enumerate(positions)]
                else:
                    lp=np.load(out/(side+'-logprobs.npy'),allow_pickle=False);m['scores']=[{**p,'logprob':float(lp[i,p['token']])} for i,p in enumerate(spec['targets'])]
                mp=out/(side+'-'+kind+'.json');save(mp,m);manifests.append(mp)
            tool={'tensors':'compare_tensors.py','distributions':'compare_distributions.py','target-scores':'compare_target_scores.py'}[kind];rp=out/(kind+'-report.json')
            cmd=[sys.executable,str(TOOLS/tool),'--contract',str(cp),'--side-a',str(manifests[0]),'--side-b',str(manifests[1]),'--output',str(rp)]
            run=subprocess.run(cmd,capture_output=True,text=True);report=json.loads(rp.read_text()) if rp.exists() else {}
            receipts.append(dict(case=name,operation=kind,command=cmd,returncode=run.returncode,stdout=run.stdout,stderr=run.stderr,report=report));assert run.returncode==0 and report['status']=='no_thresholds',receipts[-1]
    save(root/'receipts.json',receipts)
    print(json.dumps([dict(case=r['case'],operation=r['operation'],metrics=r['report'].get('global',r['report'].get('aggregate',r['report'].get('metrics')))) for r in receipts],indent=2))

if __name__=='__main__':main()
