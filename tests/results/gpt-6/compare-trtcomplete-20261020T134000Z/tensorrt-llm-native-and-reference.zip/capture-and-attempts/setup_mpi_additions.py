"""Complete the private MPI runtime with real distro data and NUMA library."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import urllib.request
from setup_private_mpi_v2 import ROOT,HERE

def main():
    assert ROOT.resolve().is_relative_to(Path('/LOCAL_LINUX_HOME/precision-framework-tests/remaining-20261020T122851Z/runtimes'))
    records=[]
    for package in ['openmpi-common','libnuma1']:
        r=subprocess.run(['apt-get','--print-uris','download',package],capture_output=True,text=True,check=True)
        for line in r.stdout.splitlines():
            if not line.startswith("'"):continue
            url,name,size,digest=shlex.split(line);algorithm,wanted=digest.split(':',1)
            assert algorithm in ['SHA256','SHA512']
            url=url.replace('http://','https://',1);data=urllib.request.urlopen(url,timeout=60).read()
            assert len(data)==int(size) and hashlib.new(algorithm.lower(),data).hexdigest()==wanted
            p=ROOT/'downloads'/name;assert not p.exists();p.write_bytes(data)
            subprocess.run(['dpkg-deb','-x',str(p),str(ROOT)],check=True)
            records.append(dict(package=package,url=url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    p=HERE/'openmpi-additions-receipt.json';assert not p.exists();p.write_text(json.dumps(records,indent=2),encoding='utf-8');print(json.dumps(records))

if __name__=='__main__':main()
