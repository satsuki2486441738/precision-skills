import subprocess
from launch_trt import ENV,HERE,native_environment
p=subprocess.run([str(ENV/"bin/python"),str(HERE/"collect_trt_runtime.py")],env=native_environment());raise SystemExit(p.returncode)
