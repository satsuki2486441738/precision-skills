"""Install the official TensorRT-LLM cohort in a new task-owned WSL environment."""
from pathlib import Path
import json
import os
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
TASK=Path('/LOCAL_LINUX_HOME/precision-framework-tests/remaining-20261020T122851Z')
ENV=TASK/'environments/trtllm-1.2.0-py312-attempt02'

def command(stage,args,timeout=2400):
    target=HERE/(stage+'.log')
    assert not target.exists(),target
    started=time.monotonic()
    print(json.dumps({'stage':stage,'status':'starting','log':str(target)}),flush=True)
    with target.open('xb') as log:
        p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,env=dict(os.environ,PIP_PROGRESS_BAR='off',PIP_DISABLE_PIP_VERSION_CHECK='1',PYTHONUNBUFFERED='1'))
    result={'stage':stage,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-started,'command':args}
    (HERE/(stage+'.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)
    if p.returncode:raise SystemExit(p.returncode)

def main():
    TASK.mkdir(parents=True,exist_ok=True)
    command('trt-venv-02',['/LOCAL_LINUX_HOME/.local/bin/uv','venv','--python','/usr/bin/python3','--seed',str(ENV)])
    python=str(ENV/'bin/python')
    command('trt-torch-install-01',[python,'-m','pip','install','torch==2.9.1+cu130','torchvision==0.24.1+cu130','--index-url','https://download.pytorch.org/whl/cu130'])
    constraints=HERE/'trt-install-constraints.txt'
    command('trt-package-install-01',[python,'-m','pip','install','tensorrt-llm==1.2.0','--extra-index-url','https://pypi.nvidia.com','-c',str(constraints)])

if __name__=='__main__':main()
