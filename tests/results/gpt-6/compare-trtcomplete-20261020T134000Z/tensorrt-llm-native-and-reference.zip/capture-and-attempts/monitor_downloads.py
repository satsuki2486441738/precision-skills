import json
from pathlib import Path
f=[(p.name,p.stat().st_size) for p in Path("/tmp").glob("pip-unpack-*/*") if p.is_file() and p.stat().st_size>100_000_000]
print(json.dumps(f))
