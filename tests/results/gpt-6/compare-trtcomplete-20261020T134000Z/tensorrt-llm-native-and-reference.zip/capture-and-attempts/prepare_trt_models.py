"""Create a seeded unquantized fixture and hash the existing pretrained resource."""
import ctypes.util
import hashlib
import json
from pathlib import Path
import torch
from transformers import AutoTokenizer,LlamaConfig,LlamaForCausalLM

ROOT=Path('/LOCAL_LINUX_HOME/precision-framework-tests/remaining-20261020T122851Z')
HERE=Path(__file__).resolve().parent

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    torch.set_num_threads(4);torch.manual_seed(20261020)
    tiny=ROOT/'models/seeded-llama-fp16'
    tiny.mkdir(parents=True,exist_ok=False)
    config=LlamaConfig(vocab_size=256,hidden_size=128,intermediate_size=256,num_hidden_layers=2,num_attention_heads=2,num_key_value_heads=2,max_position_embeddings=128,bos_token_id=1,eos_token_id=2,pad_token_id=0,tie_word_embeddings=False,attention_dropout=0.0)
    model=LlamaForCausalLM(config).half().eval();model.save_pretrained(tiny,safe_serialization=True)
    native=Path('/LOCAL_LINUX_HOME/precision-framework-tests/inference/Qwen2.5-0.5B-Instruct-7ae557604adf67be50417f59c2c2f167def9a775')
    tokenizer=AutoTokenizer.from_pretrained(native,local_files_only=True)
    cases=[dict(name='seeded-llama',model=str(tiny),prompt_ids=[1,4,5,6],end_id=2,pad_id=0,seeded=True),dict(name='qwen25-05b',model=str(native),prompt_ids=tokenizer.encode('Name one color.',add_special_tokens=False),end_id=tokenizer.eos_token_id,pad_id=tokenizer.pad_token_id,seeded=False)]
    resources={}
    for case in cases:
        folder=Path(case['model']);resources[case['name']]=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(folder.iterdir()) if p.is_file() and p.suffix in ['.json','.safetensors','.txt']]
    record=dict(cases=cases,resource_files=resources,mpi_library=ctypes.util.find_library('mpi'),weight_promotion='Native loading requested float16; clean CPU reference will load float16 then promote stored values to float32.',numerical_thresholds=None)
    out=HERE/'trt-models-and-inputs.json';assert not out.exists();out.write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))

if __name__=='__main__':main()
