"""Real TensorRT-LLM LLM.generate with bounded cache and returned score tensors."""
import argparse
from collections import Counter
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import time

class CopyOnlyLogitsObserver:
    """Official logits callback; copy the input and leave it unchanged."""
    def __init__(self,destination):self.destination=str(destination)
    def __call__(self,req_id,logits,token_ids,stream_ptr,client_id):
        import os
        import uuid
        import torch
        from safetensors.torch import save_file
        root=Path(self.destination);root.mkdir(parents=True,exist_ok=True)
        key='event-'+uuid.uuid4().hex
        if logits.is_cuda and stream_ptr:
            with torch.cuda.stream(torch.cuda.ExternalStream(stream_ptr,device=logits.device)):
                copied=logits.detach().to('cpu').contiguous()
        else:copied=logits.detach().to('cpu').contiguous()
        save_file({'logits':copied},str(root/(key+'.safetensors')))
        record=dict(request_id=int(req_id),token_ids=token_ids,shape=list(copied.shape),dtype=str(copied.dtype),original_device=str(logits.device),copy_only=True,modified_input=False,stream_provided=bool(stream_ptr),pid=os.getpid())
        (root/(key+'.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--output',required=True);ap.add_argument('--attention',default='TRTLLM');a=ap.parse_args()
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    source=Path(__file__).resolve().parent
    case=next(x for x in json.loads((source/'trt-models-and-inputs.json').read_text())['cases'] if x['name']==a.case)
    import torch
    import numpy as np
    from safetensors.torch import save_file
    from tensorrt_llm import LLM,SamplingParams
    from tensorrt_llm.llmapi import KvCacheConfig
    versions={}
    for name in ['torch','torchvision','tensorrt-llm','tensorrt','transformers','flashinfer-python','cuda-python','mpi4py']:
        try:versions[name]=metadata.version(name)
        except metadata.PackageNotFoundError:pass
    settings=dict(model=case['model'],backend='pytorch',skip_tokenizer_init=True,dtype='float16',tensor_parallel_size=1,pipeline_parallel_size=1,max_batch_size=1,max_num_tokens=64,max_seq_len=128,disable_overlap_scheduler=True,enable_chunked_prefill=False,cuda_graph_config=None,attn_backend=a.attention,gather_generation_logits=True)
    environment=dict(versions=versions,torch_cuda=torch.version.cuda,device_name=torch.cuda.get_device_name(),capability=torch.cuda.get_device_capability(),architecture_list=torch.cuda.get_arch_list(),settings=settings,cache=dict(dtype='auto',max_tokens=256,free_gpu_memory_fraction=0.1,tokens_per_block=32),requested_parameter_dtype='float16',converted_parameter_values_measured=False)
    (out/'environment.json').write_text(json.dumps(environment,indent=2),encoding='utf-8')
    started=time.monotonic()
    print('TENSORRT_LLM_NATIVE_START',flush=True)
    with LLM(**settings,kv_cache_config=KvCacheConfig(dtype='auto',max_tokens=256,free_gpu_memory_fraction=0.1,tokens_per_block=32)) as llm:
        params=SamplingParams(temperature=0.0,max_tokens=4,end_id=case['end_id'],pad_id=case['pad_id'],ignore_eos=True,return_context_logits=True,return_generation_logits=True,logits_processor=CopyOnlyLogitsObserver(out/'callback-events'))
        result=llm.generate([case['prompt_ids']],params)[0]
        completion=result.outputs[0]
        ids=list(completion.token_ids);assert len(ids)==4,ids
        raw=completion.generation_logits
        if raw is None:raise RuntimeError('Native generation completed but requested generation logits were unavailable')
        generation=raw.detach().cpu().contiguous()
        if generation.ndim==3:
            assert generation.shape[0]==1,generation.shape
            generation=generation[0]
        assert generation.ndim==2 and generation.shape[0]==len(ids),generation.shape
        assert torch.isfinite(generation).all()
        tensors={'generation_logits':generation}
        context=getattr(result,'context_logits',None)
        if context is not None:
            context=context.detach().cpu().contiguous()
            if context.ndim==3:
                assert context.shape[0]==1
                context=context[0]
            tensors['context_logits']=context
        save_file(tensors,str(out/'native-api.safetensors'))
        np.save(out/'generation-f32.npy',generation.float().numpy(),allow_pickle=False)
        rows=[]
        for i,token in enumerate(ids):
            rows.append(dict(index=i,stage='prefill' if i==0 else 'decode',input_ids=case['prompt_ids'] if i==0 else [ids[i-1]],history_ids=case['prompt_ids']+ids[:i],input_positions=list(range(len(case['prompt_ids']))) if i==0 else [len(case['prompt_ids'])+i-1],prediction_position=len(case['prompt_ids'])+i-1,target_position=len(case['prompt_ids'])+i,target_token_id=token,kv_cache_retained=True))
        record=dict(status='native_generation_complete',case=case['name'],prompt_ids=case['prompt_ids'],generated_ids=ids,rows=rows,raw_generation_dtype=str(generation.dtype),raw_context_dtype=str(context.dtype) if context is not None else None,raw_generation_shape=list(generation.shape),raw_context_shape=list(context.shape) if context is not None else None,last_context_equals_first_generation=bool(torch.equal(context[-1],generation[0])) if context is not None else None,finish_reason=str(completion.finish_reason),elapsed_seconds=time.monotonic()-started,boundary='TensorRT-LLM public RequestOutput/CompletionOutput context_logits and generation_logits; source-semantic review required before final comparison export.',native_model_operator_changes=False)
        (out/'result.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
        print('TENSORRT_LLM_NATIVE_GENERATION_COMPLETE '+json.dumps(record),flush=True)
    print('TENSORRT_LLM_NATIVE_SHUTDOWN_COMPLETE',flush=True)

if __name__=='__main__':main()
