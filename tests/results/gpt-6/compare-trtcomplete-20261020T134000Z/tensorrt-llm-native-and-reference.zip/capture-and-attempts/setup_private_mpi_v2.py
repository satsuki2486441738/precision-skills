"""Download hash-verified Ubuntu MPI runtime packages and unpack privately."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import urllib.request

HERE=Path(__file__).resolve().parent
ROOT=Path('/LOCAL_LINUX_HOME/precision-framework-tests/remaining-20261020T122851Z/runtimes/openmpi-attempt02')
PACKAGES=['libopenmpi3t64','openmpi-bin','libpmix2t64','libhwloc15','libevent-pthreads-2.1-7t64','libucx0','libfabric1','libibverbs1','librdmacm1t64','libmunge2','libltdl7','libnl-route-3-200','libnl-3-200']

def main():
    ROOT.mkdir(parents=True,exist_ok=False)
    downloads=ROOT/'downloads';downloads.mkdir()
    records=[]
    for package in PACKAGES:
        r=subprocess.run(['apt-get','--print-uris','download',package],capture_output=True,text=True,check=True)
        for line in r.stdout.splitlines():
            if not line.startswith("'"):continue
            url,name,size,digest=shlex.split(line)
            algorithm,wanted=digest.split(':',1);assert algorithm in ['SHA256','SHA512'],algorithm
            url=url.replace('http://','https://',1)
            data=urllib.request.urlopen(url,timeout=60).read()
            assert len(data)==int(size) and hashlib.new(algorithm.lower(),data).hexdigest()==wanted
            p=downloads/name;p.write_bytes(data)
            subprocess.run(['dpkg-deb','-x',str(p),str(ROOT)],check=True)
            records.append(dict(package=package,url=url,filename=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
            print(json.dumps(records[-1]),flush=True)
    (HERE/'openmpi-package-receipt.json').write_text(json.dumps(records,indent=2),encoding='utf-8')

if __name__=='__main__':main()
