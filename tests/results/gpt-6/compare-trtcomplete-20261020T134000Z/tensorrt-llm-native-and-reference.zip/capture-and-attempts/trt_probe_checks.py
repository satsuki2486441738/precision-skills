"""Task-selected real CUDA/MPI initialization check for runtime_probe."""
def initialize():
    import os
    import subprocess
    import torch
    from mpi4py import MPI
    x=torch.arange(16,dtype=torch.float32,device='cuda')
    value=float(x.square().sum().cpu());assert value==1240.0
    return dict(cuda_name=torch.cuda.get_device_name(),cuda_capability=list(torch.cuda.get_device_capability()),cuda_build=torch.version.cuda,checked_sum=value,mpi_world_size=MPI.COMM_WORLD.Get_size(),mpi_library=MPI.Get_library_version(),nccl_available=torch.distributed.is_nccl_available(),nvcc=subprocess.check_output([os.environ['CUDA_HOME']+'/bin/nvcc','--version'],text=True))
