"""Install official CUDA compiler components under a private target directory."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from setup_trt import command,TASK

if __name__=='__main__':
    command('cuda-toolkit-install-01',[sys.executable,'-m','pip','install','--target',str(TASK/'toolkits/cuda13.1'),'cuda-toolkit[nvcc,cccl,cudart,crt,nvvm]==13.1.1'])
