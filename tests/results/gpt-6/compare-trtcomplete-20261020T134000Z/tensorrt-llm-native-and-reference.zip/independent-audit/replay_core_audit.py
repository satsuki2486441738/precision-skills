from pathlib import Path
import json,shutil,numpy as np,subprocess,sys,hashlib
root=Path.cwd();out=root/'runs/compare-trtsemanticaudit-20261020T131909Z';base=root/'runs/compare-remaining-20261020T122851Z';src=base/'trt-core-metrics-04';copy=out/'fresh-core-inputs';shutil.copytree(src,copy);reports=out/'fresh-core-replay';reports.mkdir();records=[]
for case in ['seeded-llama','qwen25-05b']:
 p=copy/case;native=base/('trt-native-'+case+('-02' if case=='seeded-llama' else '-01'));reference=base/('trt-reference-'+case+'-01')
 for side,folder in [('native',native),('reference',reference)]:
  logits=np.load(p/(side+'-logits.npy'),allow_pickle=False);assert np.array_equal(logits,np.load(folder/'generation-f32.npy',allow_pickle=False));lp=np.load(p/(side+'-logprobs.npy'),allow_pickle=False);x=logits.astype(np.float64);x-=x.max(axis=-1,keepdims=True);expected=x-np.log(np.exp(x).sum(axis=-1,keepdims=True));assert np.array_equal(lp,expected)
 for kind,tool,fields in [('tensors','compare_tensors.py',['global','per_tensor']),('distributions','compare_distributions.py',['aggregate','positions','coverage']),('target-scores','compare_target_scores.py',['metrics','coverage'])]:
  rp=reports/(case+'-'+kind+'.json');cmd=[sys.executable,'-B',str(root/'skills/precision-skill/scripts'/tool),'--contract',str(p/(kind+'-contract.json')),'--side-a',str(p/('reference-'+kind+'.json')),'--side-b',str(p/('native-'+kind+'.json')),'--output',str(rp)];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,(case,kind,r.stderr);a=json.loads((p/(kind+'-report.json')).read_text());b=json.loads(rp.read_text());assert b['status']==a['status']=='no_thresholds'
  for field in fields:assert a.get(field)==b.get(field),(case,kind,field)
  records.append({'case':case,'kind':kind,'returncode':r.returncode,'command':cmd,'metrics_frozen_exact':True})
(reports/'REPLAY.json').write_text(json.dumps({'status':'completed','actual_comparisons':6,'unchanged_logits_and_exact_fp64_log_softmax_verified':True,'records':records},indent=2)+'\n');print('FRESH_6_CLI_COMPLETE')
