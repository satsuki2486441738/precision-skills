from pathlib import Path
import json,hashlib,io,numpy as np
root=Path.cwd();run=root/'runs/compare-trtsemanticaudit-20261020T131909Z';base=root/'runs/compare-remaining-20261020T122851Z';src=Path(r'\\wsl.localhost\Ubuntu-24.04\home\precision\precision-framework-tests\remaining-20261020T122851Z\environments\trtllm-1.2.0-py312-attempt02\lib\python3.12\site-packages\tensorrt_llm')
def safe(p):
 b=p.read_bytes();l=int.from_bytes(b[:8],'little');h=json.loads(b[8:8+l]);out={}
 for n,e in h.items():
  if n=='__metadata__':continue
  assert e['dtype']=='F32';a,z=e['data_offsets'];out[n]=np.frombuffer(b[8+l+a:8+l+z],dtype='<f4').reshape(e['shape'])
 return out
report={'cases':{},'source':{}}
for name,refname in [('trt-native-seeded-llama-02','trt-reference-seeded-llama-01'),('trt-native-qwen25-05b-01','trt-reference-qwen25-05b-01')]:
 d=base/name;result=json.loads((d/'result.json').read_text());arrays=safe(d/'native-api.safetensors');g=arrays['generation_logits'];c=arrays['context_logits'];assert g.shape[0]==c.shape[0]==4 and np.array_equal(g[0],c[-1]);assert np.array_equal(g,np.load(d/'generation-f32.npy',allow_pickle=False))
 events=[]
 for p in (d/'callback-events').glob('*.json'):
  e=json.loads(p.read_text());history=e['token_ids'][0];i=len(history)-len(result['prompt_ids']);assert history==result['prompt_ids']+result['generated_ids'][:i];row=safe(p.with_suffix('.safetensors'))['logits'].reshape(-1);assert e['modified_input']==False and e['copy_only']==True
  events.append({'index':i,'history':history,'callback_shape':e['shape'],'equal_generation_row':bool(np.array_equal(row,g[i])),'equal_context_rows':[j for j in range(len(c)) if np.array_equal(row,c[j])],'argmax':int(row.argmax()),'generated_token':result['generated_ids'][i]})
 events.sort(key=lambda e:e['index']);assert [e['index'] for e in events]==[0,1,2,3];assert events[0]['equal_context_rows']==[0] and not events[0]['equal_generation_row'];assert all(e['equal_generation_row'] for e in events[1:]);assert g.argmax(axis=-1).tolist()==result['generated_ids'];ref=safe(base/refname/'reference.safetensors')['generation_logits'];assert ref.shape==g.shape
 report['cases'][name]={'native_generation_shape':list(g.shape),'native_context_shape':list(c.shape),'last_context_equals_first_generation':True,'all_actual_generated_ids_equal_api_argmax':True,'events':events,'first_context_argmax':int(c[0].argmax()),'last_context_argmax':int(c[-1].argmax()),'reference_argmax':ref.argmax(axis=-1).tolist(),'reference_status':json.loads((base/refname/'result.json').read_text()),'native_environment':json.loads((d/'environment.json').read_text())}
for rel in ['_torch/pyexecutor/model_engine.py','_torch/pyexecutor/handle_logits.py','_torch/pyexecutor/sampler.py','_torch/modules/logits_processor.py','executor/base_worker.py']:
 b=(src/rel).read_bytes();lines=b.decode('utf-8').splitlines();report['source'][rel]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 if rel.endswith('model_engine.py'):
  for i,l in enumerate(lines):
   if '_execute_logit_post_processors(' in l:print('CALLSITE',i+1,'\n'.join(f'{j+1}: {lines[j]}' for j in range(max(0,i-7),min(len(lines),i+8))))
report['interpretation']='Installed1.2.0 PyTorch backend callback uses logits_tensor[idx] per request although return_context_logits retains one row per prompt token; with one request idx0 selects first prompt row. API HandleLogits and sampler correctly select end-offset-1 for first generated token. Collector callback is copy-only. This is an upstream installed-backend row-indexing defect under return_context_logits=True, not an exported array mutation or collector ordering error.'
(run/'raw-array-source-semantics.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'cases':{k:{a:v for a,v in x.items() if a not in ['native_environment','reference_status']} for k,x in report['cases'].items()},'interpretation':report['interpretation']},indent=2))
