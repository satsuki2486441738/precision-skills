"""Bounded native trainer adapter. Capture hooks observe; loss/backward/update stay native."""
import argparse, gc, hashlib, importlib, importlib.metadata as md, json, os, pathlib, sys, time, traceback
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[1]
sys.path.insert(0,str(REPO/'skills/precision-skill/scripts'))
from runtime_probe import inspect_runtime
from compare_tensors import compare as compare_tensors
from compare_target_scores import compare as compare_scores
from validate_artifacts import validate

def write(path,value):
    pathlib.Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def env_probe(framework):
    imports=['torch','numpy','transformers','datasets','accelerate','peft',framework]
    symbol={'trl':'trl:SFTTrainer','llamafactory':'llamafactory.train.sft.trainer:CustomSeq2SeqTrainer','swift':'swift.trainers:Seq2SeqTrainer'}[framework]
    return inspect_runtime({'imports':imports,'symbols':[symbol],'distributions':['torch','numpy','transformers','datasets','accelerate','peft','ms-swift' if framework=='swift' else framework]})

def main(framework,architecture):
    import numpy as np, torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, Qwen2Config, Qwen2ForCausalLM, PreTrainedTokenizerFast, TrainerCallback, Seq2SeqTrainingArguments
    from datasets import Dataset
    from tokenizers import Tokenizer
    from tokenizers.models import WordLevel
    from tokenizers.pre_tokenizers import Whitespace
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(20261019)
    pair=ROOT/f'{framework}-{architecture}';pair.mkdir(exist_ok=False)
    runtime=env_probe(framework);write(pair/'runtime.json',runtime)
    if runtime['status']!='completed':raise RuntimeError(runtime)
    model_path='<PRETRAINED_SMOLLM2_DIR>'
    if architecture=='smollm2':
        tok=AutoTokenizer.from_pretrained(model_path,local_files_only=True)
        model=AutoModelForCausalLM.from_pretrained(model_path,local_files_only=True,torch_dtype=torch.float32,attn_implementation='eager')
        identity={'architecture':model.config.model_type,'weights':'pretrained','path':model_path,'snapshot':'12fd25f77366fa6b3b4b768ec3050bf629380bac'}
    else:
        backend=Tokenizer(WordLevel({**{'[PAD]':0,'[UNK]':1,'[BOS]':2,'[EOS]':3},**{f't{i}':i for i in range(4,64)}},unk_token='[UNK]'))
        backend.pre_tokenizer=Whitespace()
        tok=PreTrainedTokenizerFast(tokenizer_object=backend,pad_token='[PAD]',unk_token='[UNK]',bos_token='[BOS]',eos_token='[EOS]')
        tok.save_pretrained(pair/'local-tokenizer')
        cfg=Qwen2Config(vocab_size=64,hidden_size=32,intermediate_size=64,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=64,attention_dropout=0.0,tie_word_embeddings=True,pad_token_id=0,bos_token_id=2,eos_token_id=3)
        cfg._attn_implementation='eager';model=Qwen2ForCausalLM(cfg)
        identity={'architecture':'qwen2','weights':'random-init','seed':20261019,'config':cfg.to_dict()}
    model.config.use_cache=False
    if tok.pad_token_id is None:tok.pad_token=tok.eos_token
    tok.padding_side='right'
    bos=tok.bos_token_id if tok.bos_token_id is not None else 2;eos=tok.eos_token_id
    ids=[[bos,10,11,12,13,14,15,16,17,18,19,eos],[bos,20,21,22,23,24,25,26,eos]]
    masks=[[0]*4+[1]*8,[0]*3+[1]*6]
    features=[{'input_ids':x,'labels':[t if active else -100 for t,active in zip(x,m)],'attention_mask':[1]*len(x),'completion_mask':m} for x,m in zip(ids,masks)]
    dataset=Dataset.from_list(features)
    if framework=='trl':
        from trl import SFTTrainer,SFTConfig
        from trl.trainer.sft_trainer import DataCollatorForLanguageModeling
        collator=DataCollatorForLanguageModeling(pad_token_id=tok.pad_token_id,completion_only_loss=True,pad_to_multiple_of=8)
    elif framework=='llamafactory':
        from llamafactory.train.sft.trainer import CustomSeq2SeqTrainer
        from llamafactory.data import SFTDataCollatorWith4DAttentionMask,get_template_and_fix_tokenizer
        from llamafactory.hparams import DataArguments,FinetuningArguments
        template=get_template_and_fix_tokenizer(tok,DataArguments(template='default'))
        collator=SFTDataCollatorWith4DAttentionMask(tokenizer=tok,model=model,template=template,pad_to_multiple_of=8,label_pad_token_id=-100,block_diag_attn=False,attn_implementation='eager',compute_dtype=torch.float32)
        dataset=Dataset.from_list([{k:v for k,v in f.items() if k!='completion_mask'} for f in features])
    else:
        from swift.llm import get_template
        from swift.llm.model.register import get_model_info_meta
        from swift.trainers import Seq2SeqTrainer as SwiftSeq2SeqTrainer,Seq2SeqTrainingArguments as SwiftSeq2SeqTrainingArguments
        from functools import partial
        if architecture=='tiny-qwen2':
            local=pair/'local-tokenizer';model.config.save_pretrained(local);meta_path=str(local);model_type='qwen2'
        else:meta_path=model_path;model_type='llama'
        model_info,model_meta=get_model_info_meta(meta_path,torch_dtype=torch.float32,use_hf=True,download_model=False,model_type=model_type)
        model.model_info=model_info;model.model_meta=model_meta
        tok.model_info=model_info;tok.model_meta=model_meta
        template=get_template('default',tok,max_length=16);template.set_mode('train')
        collator=partial(template.data_collator,padding_to=16)
        dataset=Dataset.from_list([{k:v for k,v in f.items() if k!='completion_mask'} for f in features])
    # The native TRL SeedableRandomSampler at data_seed=20261019 puts sample-1
    # before sample-0 in this sole microbatch. Preserve native execution and
    # align the reference to that observed ordering; assert actual inputs below.
    row_order=[1,0] if framework=='trl' else [0,1]
    batch=collator([dict(dataset[i]) for i in row_order])
    write(pair/'batch.json',{k:v.tolist() for k,v in batch.items() if torch.is_tensor(v)})
    initial={n:p.detach().cpu().clone() for n,p in model.named_parameters()}
    state_hash=hashlib.sha256()
    for n,t in initial.items():state_hash.update(n.encode());state_hash.update(t.numpy().tobytes())
    state_hash=state_hash.hexdigest()
    params=list(model.named_parameters())
    aliases={};canonical_by_id={id(p):n for n,p in params}
    for n,p in model.named_parameters(remove_duplicate=False):aliases[n]=canonical_by_id[id(p)]
    write(pair/'inventory.json',{'unique_parameters':[{'name':n,'shape':list(p.shape),'dtype':str(p.dtype),'trainable':p.requires_grad} for n,p in params],'aliases':aliases,'initial_sha256':state_hash,'identity':identity})
    common={'model':{'architecture':identity['architecture'],'weights':identity['weights'],'initial_sha256':state_hash},'inputs':{k:v.tolist() for k,v in batch.items() if torch.is_tensor(v)},'numerics':{'parameters':'float32','gradients':'float32','attention':'eager','device':'cuda','tf32':False,'deterministic_algorithms':True},'scope':{'task':'full-parameter-SFT','optimizer':'SGD','learning_rate':0.001,'momentum':0,'weight_decay':0,'accumulation':1,'max_grad_norm':0,'steps':1,'loss':'native shifted CE; global valid-token mean','seed':20261019},'state':state_hash}
    versions={k:v for k,v in runtime['distributions'].items()}
    entries=[]
    for i,(n,p) in enumerate(params):
        np.save(pair/f'before-{i:04}.npy',initial[n].numpy(),allow_pickle=False)
        entries.append({'name':n,'shape':list(p.shape),'present':True})
    del params
    scores_by_side={};observations={}
    def hook(side):
        def capture(module,args,kwargs,out):
            labels=kwargs.get('labels')
            if labels is None:return
            actual_inputs={k:v.detach().cpu() for k,v in kwargs.items() if torch.is_tensor(v) and k in batch}
            for key,value in batch.items():
                if torch.is_tensor(value):assert torch.equal(actual_inputs[key],value.cpu()),(side,key,'native fixed input mismatch')
            folder=pair/side;folder.mkdir(exist_ok=True)
            write(folder/'native-forward-inputs.json',{k:v.tolist() for k,v in actual_inputs.items()})
            logp=out.logits.detach().float().log_softmax(-1)
            scores=[];active=[]
            for row in range(labels.shape[0]):
                for pos in range(1,labels.shape[1]):
                    token=int(labels[row,pos])
                    if token==-100:continue
                    sample=f'sample-{row_order[row]}'
                    scores.append({'sample':sample,'position':pos,'token':token,'logprob':float(logp[row,pos-1,token].cpu())})
                    active.append({'sample':sample,'prediction_position':pos-1,'target_position':pos,'label':token,'is_eos':token==eos})
            scores_by_side[side]=scores
            observations[side]={'native_loss':float(out.loss.detach().cpu()),'active_targets':active,'valid_tokens':len(scores),'loss_kwargs':{k:(int(v) if torch.is_tensor(v) and v.numel()==1 else str(v)) for k,v in kwargs.items() if k in ('num_items_in_batch','logits_to_keep')},'native_input_keys':list(kwargs),'forward_calls':observations.get(side,{}).get('forward_calls',0)+1,'fixed_forward_inputs_equal':True,'sample_row_order':row_order}
        return capture
    def gradients(side,model):
        folder=pair/side;folder.mkdir(exist_ok=True)
        inventory=[]
        for i,(n,p) in enumerate(model.named_parameters()):
            present=p.grad is not None
            inventory.append({'name':n,'present':present,'numel':p.numel(),'zeros':int((p.grad==0).sum().cpu()) if present else None})
            if present:np.save(folder/f'gradient-{i:04}.npy',p.grad.detach().cpu().numpy(),allow_pickle=False)
        write(folder/'gradient-presence.json',inventory)
    def finish(side,model):
        folder=pair/side
        for i,(n,p) in enumerate(model.named_parameters()):np.save(folder/f'after-{i:04}.npy',p.detach().cpu().numpy(),allow_pickle=False)
        write(folder/'environment.json',{'rank':0,'versions':versions,'actual':common,'framework':side,'runtime':runtime})
        write(folder/'status.json',{'rank':0,'status':'completed','optimizer_event':'applied'})
        write(folder/'objective.json',observations[side])
        write(folder/'scores.json',{'schema_version':1,'kind':'target-scores','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':'environment.json','status':'status.json'}],'scores':scores_by_side[side]})
        for stage in ['gradients','updates']:
            tensors=[]
            for i,e in enumerate(entries):
                shard={'offset':0}
                if stage=='gradients':shard['value']={'path':f'gradient-{i:04}.npy'}
                else:shard.update(before={'path':f'../before-{i:04}.npy'},after={'path':f'after-{i:04}.npy'})
                tensors.append({**e,'shards':[shard]})
            manifest={'schema_version':2,'kind':'tensors','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':'environment.json','status':'status.json'}],'stage':stage,'tensors':tensors}
            if stage=='updates':manifest['events']={'model':'applied'}
            write(folder/f'{stage}.json',manifest)
    model=model.cuda().train();native_handle=model.register_forward_hook(hook('pytorch'),with_kwargs=True)
    optimizer=torch.optim.SGD(model.parameters(),lr=0.001)
    output=model(**{k:v.cuda() if torch.is_tensor(v) else v for k,v in batch.items()});output.loss.backward()
    gradients('pytorch',model);optimizer.step();finish('pytorch',model)
    native_handle.remove();model.zero_grad(set_to_none=True);del output,optimizer
    for n,p in model.named_parameters():p.data.copy_(initial[n].to(p.device))
    for n,p in model.named_parameters():assert torch.equal(p.detach().cpu(),initial[n]),n
    native_handle=model.register_forward_hook(hook(framework),with_kwargs=True)
    class CaptureCallback(TrainerCallback):
        def on_pre_optimizer_step(self,args,state,control,model=None,**kwargs):gradients(framework,model)
    kwargs=dict(output_dir=str(pair/'trainer-output'),max_steps=1,per_device_train_batch_size=2,gradient_accumulation_steps=1,learning_rate=0.001,optim='sgd',lr_scheduler_type='constant',weight_decay=0.0,max_grad_norm=0.0,fp16=False,bf16=False,report_to=[],save_strategy='no',logging_strategy='steps',logging_steps=1,disable_tqdm=True,seed=20261019,data_seed=20261019,dataloader_num_workers=0,dataloader_pin_memory=False,remove_unused_columns=False)
    if framework=='trl':
        args=SFTConfig(**kwargs,max_length=16,packing=False,padding_free=False,completion_only_loss=True,assistant_only_loss=False,dataset_kwargs={'skip_prepare_dataset':True})
        trainer=SFTTrainer(model=model,args=args,train_dataset=dataset,data_collator=collator,processing_class=tok,callbacks=[CaptureCallback()])
    elif framework=='llamafactory':
        args=Seq2SeqTrainingArguments(**kwargs);args.fp8=False
        trainer=CustomSeq2SeqTrainer(finetuning_args=FinetuningArguments(finetuning_type='full',disable_shuffling=True),processor=None,model=model,args=args,train_dataset=dataset,data_collator=collator,tokenizer=tok,callbacks=[CaptureCallback()])
    else:
        args=SwiftSeq2SeqTrainingArguments(**kwargs,gradient_checkpointing=False,check_model=False,use_logits_to_keep=False,train_dataloader_shuffle=False)
        trainer=SwiftSeq2SeqTrainer(model=model,args=args,train_dataset=dataset,data_collator=collator,template=template,callbacks=[CaptureCallback()])
    write(pair/'trainer-resolved.json',{'class':type(trainer).__module__+'.'+type(trainer).__qualname__,'source':importlib.import_module(type(trainer).__module__).__file__,'args':trainer.args.to_dict(),'optimizer':'native Trainer create_optimizer: torch.optim.SGD','integration_scope':'native trainer + native collator on fixed pretokenized samples; framework CLI/raw text preprocessing is not exercised'})
    train_result=trainer.train();finish(framework,model);native_handle.remove()
    reports={}
    for stage in ['gradients','updates']:
        contract={'schema_version':2,'kind':'tensors','common':common,'thresholds':None,'expected_ranks':{'pytorch':[0],framework:[0]},'stage':stage,'tensors':entries}
        write(pair/f'{stage}-contract.json',contract)
        validations={}
        for side in ['pytorch',framework]:
            validations[side]=validate(pair/f'{stage}-contract.json',pair/side/f'{stage}.json');write(pair/side/f'{stage}-validation.json',validations[side])
        reports[stage]=compare_tensors(pair/f'{stage}-contract.json',pair/'pytorch'/f'{stage}.json',pair/framework/f'{stage}.json')
        write(pair/f'{stage}-comparison.json',reports[stage])
    targets=[{k:s[k] for k in ['sample','position','token']} for s in scores_by_side['pytorch']]
    write(pair/'scores-contract.json',{'schema_version':1,'kind':'target-scores','common':common,'thresholds':None,'expected_ranks':{'pytorch':[0],framework:[0]},'targets':targets})
    scores_report=compare_scores(pair/'scores-contract.json',pair/'pytorch/scores.json',pair/framework/'scores.json');write(pair/'scores-comparison.json',scores_report)
    summary={'framework':framework,'architecture':architecture,'status':'native_training_completed','precision_status':'no_thresholds','native_steps':trainer.state.global_step,'initial_equal':True,'unique_parameters':len(entries),'elements':sum(x.numel() for x in initial.values()),'native_loss':observations[framework]['native_loss'],'reference_loss':observations['pytorch']['native_loss'],'loss_abs_difference':abs(observations[framework]['native_loss']-observations['pytorch']['native_loss']),'valid_targets':len(targets),'scores':scores_report,'gradients':reports['gradients'],'updates':reports['updates'],'train_result':train_result.metrics,'limitations':['Single cold SGD step; stateful optimizer/restored state, distributed, LoRA, packing and mixed precision untested.','Fixed-token adapter constructs native trainer/collator directly; CLI and raw-text preprocessing untested.'],'path':str(pair)}
    write(pair/'summary.json',summary);print(json.dumps({k:v for k,v in summary.items() if k not in ['scores','gradients','updates']},indent=2),flush=True)
    del trainer,model,initial;gc.collect();torch.cuda.empty_cache()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--framework',choices=['trl','llamafactory','swift'],required=True);p.add_argument('--architecture',choices=['smollm2','tiny-qwen2'],required=True);a=p.parse_args()
    try:main(a.framework,a.architecture)
    except Exception as e:
        write(ROOT/f'failure-{a.framework}-{a.architecture}-{int(time.time())}.json',{'stage':'native_training_or_capture','error':repr(e),'traceback':traceback.format_exc()});raise
