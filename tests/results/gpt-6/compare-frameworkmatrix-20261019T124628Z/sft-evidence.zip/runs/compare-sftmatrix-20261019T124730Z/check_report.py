import hashlib,json,pathlib,re,datetime
ROOT=pathlib.Path(__file__).resolve().parent;FOLLOW=ROOT.parent/'compare-sftmatrix-20261019T130222Z'
results=json.loads((ROOT/'results.json').read_text())
assert len(results['cases'])==6
for c in results['cases']:
    assert c['comparison_status']=='no_thresholds' and c['precision_acceptance'] is None
    assert c['valid_targets']==14 and c['active_eos_count']==2
    assert c['initial_equal'] and c['native_optimizer_steps']==1
    assert c['native_loss_absolute_difference']==0
    for m in [c['gradient_metrics'],c['stored_update_metrics']]:
        assert m['count']==c['elements'] and m['error_norm']['value']==0
    assert all(x=='validated' for stages in c['validation'].values() for x in stages.values())
assert all(p['training_passed'] is False for p in results['non_training_probes'])
assert all(p['status']=='completed' for p in results['fresh_runtime_probes'])
p=ROOT/'report.md';text=p.read_text()
for a,b in [('TRL0','TRL 0'),('LLaMAFactory0','LLaMAFactory 0'),('ms-swift3','ms-swift 3'),('contain14','contain 14'),('including2','including 2'),('has272','has 272'),('has26','has 26'),(' /134',' / 134'),(' /20',' / 20'),('seed2026','seed 2026'),('Axolotl0','Axolotl 0'),('latest0','latest 0'),('Bridge0','Bridge 0'),('Python3','Python 3'),('requires3','requires 3'),('Python>=','Python >= '),('Torch>=','Torch >= ')]:text=text.replace(a,b)
p.write_text(text)
validation={'status':'validated','selected_cases':6,'single_side_tensor_manifests_validated':24,'target_comparisons':6,'gradient_comparisons':6,'stored_update_comparisons':6,'precision_status':'no_thresholds','acceptance_thresholds':None,'all_selected_global_error_norms_zero':True,'fresh_runtime_probes_completed':3,'unrun_frameworks_misclassified_as_training_passed':0,'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_array_hash_note':'Every raw array SHA256 was computed by finalize.py. This post-check verifies sizes and refreshes hashes of small metadata/log files after the finalizer log closed.'}
(ROOT/'verification.json').write_text(json.dumps(validation,indent=2)+'\n')
for run in [ROOT,FOLLOW]:
    manifest=run/'artifacts.sha256.json';old=json.loads(manifest.read_text());known={x['path']:x for x in old['files']};files=[]
    for p in sorted(run.rglob('*')):
        if not p.is_file() or p==manifest:continue
        rel=str(p.relative_to(run));size=p.stat().st_size
        if p.suffix=='.npy':
            row=known[rel];assert row['bytes']==size
        else:row={'path':rel,'bytes':size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        files.append(row)
    manifest.write_text(json.dumps({'algorithm':'SHA256','files':files,'total_bytes':sum(x['bytes'] for x in files)},indent=2)+'\n')
print(json.dumps(validation,indent=2))
