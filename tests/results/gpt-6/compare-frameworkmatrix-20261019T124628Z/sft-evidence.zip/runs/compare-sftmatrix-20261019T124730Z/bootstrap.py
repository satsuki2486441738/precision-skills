import importlib.metadata as md, json, pathlib, subprocess, sys, urllib.request
ROOT=pathlib.Path(__file__).resolve().parent
def run(cmd, timeout=90):
    print('$ '+' '.join(cmd),flush=True)
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
    print(p.stdout,flush=True); return p
for dist in ['trl','llamafactory','ms-swift','axolotl']:
    d=md.distribution(dist)
    print(dist,d.version,d.requires,flush=True)
run(['<USER_HOME>/.local/bin/uv','pip','install','--python',sys.executable,'--no-deps','datasets==4.3.0','accelerate==1.10.1','peft==0.17.1','tyro==0.9.35','omegaconf==2.3.0','packaging==25.0','dill==0.4.0','multiprocess==0.70.16','pyarrow==21.0.0','xxhash==3.6.0','rouge-chinese==1.0.3','jieba==0.42.1','sse-starlette==3.0.2','fire==0.7.1','eval-type-backport==0.2.2','docstring-parser==0.17.0','shtab==1.7.2','typeguard==4.4.4'],180)
sources={
 'trl':('huggingface/trl','v0.24.0',['trl/trainer/sft_trainer.py','pyproject.toml']),
 'llamafactory':('hiyouga/LlamaFactory','v0.9.3',['src/llamafactory/train/sft/trainer.py','src/llamafactory/train/sft/workflow.py','src/llamafactory/extras/env.py','requirements.txt']),
 'ms-swift':('modelscope/ms-swift','v3.10.3',['swift/llm/train/sft.py','requirements/framework.txt']),
 'axolotl':('axolotl-ai-cloud/axolotl','v0.10.0',['src/axolotl/train.py','pyproject.toml']),
 'megatron-bridge':('NVIDIA-NeMo/Megatron-Bridge','main',['pyproject.toml','README.md']),
 'mindspeed-llm':('Ascend/MindSpeed-LLM','master',['setup.py','requirements.txt','docs/en/pytorch/training/install_guide.md','pretrain_gpt.py']),
}
evidence={}
for name,(repo,ref,files) in sources.items():
    dest=ROOT/'official-source'/name;dest.mkdir(parents=True,exist_ok=True)
    try:
        req=urllib.request.Request(f'https://api.github.com/repos/{repo}/commits/{ref}',headers={'User-Agent':'precision-sft-check'})
        commit=json.load(urllib.request.urlopen(req,timeout=25))['sha']
        rec={'repository':repo,'requested_ref':ref,'sha':commit,'files':[]}
        for f in files:
            url=f'https://raw.githubusercontent.com/{repo}/{commit}/{f}'
            try:
                data=urllib.request.urlopen(url,timeout=20).read();(dest/f.replace('/','__')).write_bytes(data)
                rec['files'].append({'path':f,'url':f'https://github.com/{repo}/blob/{commit}/{f}'})
            except Exception as e:rec['files'].append({'path':f,'error':str(e)})
        evidence[name]=rec
    except Exception as e:evidence[name]={'repository':repo,'requested_ref':ref,'error':repr(e)}
    (ROOT/'sources.json').write_text(json.dumps(evidence,indent=2))
    print(name,evidence[name],flush=True)
