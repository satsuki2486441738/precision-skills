import importlib.metadata as md, json, pathlib, subprocess, sys, urllib.request
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'skills/precision-skill/scripts'))
from runtime_probe import probe_runtime
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def request(url):return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'precision-sft-check'}),timeout=20)
evidence=json.loads((ROOT/'sources-final.json').read_text())
for name,repo,ref,files in [('axolotl-0.12.2','axolotl-ai-cloud/axolotl','v0.12.2',['pyproject.toml','src/axolotl/train.py']),('axolotl-latest','axolotl-ai-cloud/axolotl','main',['pyproject.toml'])]:
    try:
        sha=json.load(request(f'https://api.github.com/repos/{repo}/commits/{ref}'))['sha'];dest=ROOT/'official-source'/name;dest.mkdir(parents=True,exist_ok=True)
        entry={'repository':repo,'requested_ref':ref,'sha':sha,'files':[]}
        for f in files:
            data=request(f'https://raw.githubusercontent.com/{repo}/{sha}/{f}').read();(dest/f.replace('/','__')).write_bytes(data);entry['files'].append({'path':f,'url':f'https://github.com/{repo}/blob/{sha}/{f}'})
        evidence[name]=entry
    except Exception as e:evidence[name]={'error':repr(e)}
write(ROOT/'sources-complete.json',evidence)
spec={'imports':['torch','transformers','axolotl'],'symbols':['axolotl.train:train'],'distributions':['axolotl','torch','transformers']}
write(ROOT/'probe-axolotl-0.12.2.json',probe_runtime(spec,executable=sys.executable,timeout=45))
write(ROOT/'axolotl-installed-requirements.json',{'version':md.version('axolotl'),'requires':md.requires('axolotl')})
try:
    info=json.load(request('https://pypi.org/pypi/megatron-bridge/json'))['info'];write(ROOT/'megatron-bridge-pypi.json',info)
    command=['<USER_HOME>/.local/bin/uv','pip','install','--python',sys.executable,'--no-deps','megatron-bridge=='+info['version']]
    p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
    write(ROOT/'install-probe-megatron-bridge.json',{'command':command,'returncode':p.returncode,'output':p.stdout})
except Exception as e:write(ROOT/'install-probe-megatron-bridge.json',{'error':repr(e)})
write(ROOT/'native-import-probe-megatron-bridge.json',probe_runtime({'imports':['torch','megatron.bridge.training.pretrain'],'symbols':[],'distributions':['torch']},executable=sys.executable,timeout=45))
rec=evidence['mindspeed-llm'];sha=rec['sha'];fragment=ROOT/'official-source/mindspeed-native-fragment';(fragment/'mindspeed_llm').mkdir(parents=True,exist_ok=True)
fragment_evidence=[]
for f in ['mindspeed_llm/__init__.py','mindspeed_llm/megatron_adaptor.py']:
    try:
        data=request(f'https://raw.githubusercontent.com/Ascend/MindSpeed-LLM/{sha}/{f}').read();(fragment/f).write_bytes(data);fragment_evidence.append({'path':f,'url':f'https://github.com/Ascend/MindSpeed-LLM/blob/{sha}/{f}'})
    except Exception as e:fragment_evidence.append({'path':f,'error':repr(e)})
report=probe_runtime({'imports':['torch','mindspeed_llm.megatron_adaptor'],'symbols':[],'distributions':['torch'],'python_paths':[str(fragment)]},executable=sys.executable,timeout=45)
report['scope']='Pinned native source fragment import; complete repository archive download timed out.';report['official_files']=fragment_evidence
write(ROOT/'native-import-probe-mindspeed-llm.json',report)
p=subprocess.run([sys.executable,str(ROOT/'official-source/mindspeed-llm/pretrain_gpt.py'),'--help'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45,env={**__import__('os').environ,'PYTHONPATH':str(fragment)})
write(ROOT/'entrypoint-probe-mindspeed-llm.json',{'command':[sys.executable,str(ROOT/'official-source/mindspeed-llm/pretrain_gpt.py'),'--help'],'returncode':p.returncode,'output':p.stdout,'source_fragment_pythonpath':str(fragment)})
