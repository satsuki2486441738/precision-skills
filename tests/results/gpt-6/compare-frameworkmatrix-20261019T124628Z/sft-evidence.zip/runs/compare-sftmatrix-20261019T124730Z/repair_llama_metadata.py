"""Preserve raw captures and re-export metadata for strict non-null condition identities."""
import copy, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'skills/precision-skill/scripts'))
from compare_tensors import compare
from compare_target_scores import compare as compare_scores
from validate_artifacts import validate
def read(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
for framework in ['llamafactory']:
    pair=ROOT/f'{framework}-tiny-qwen2';out=pair/'comparison-v2';out.mkdir(exist_ok=False)
    old=read(pair/'gradients-contract.json');common=copy.deepcopy(old['common'])
    common['model']={'architecture':common['model']['architecture'],'weights':common['model']['weights'],'initial_sha256':common['state']}
    for side in ['pytorch',framework]:
        dest=out/side;dest.mkdir()
        env=read(pair/side/'environment.json');env['actual']=common;write(dest/'environment.json',env)
        write(dest/'status.json',read(pair/side/'status.json'))
        for stage in ['gradients','updates','scores']:
            data=read(pair/side/f'{stage}.json');data['common']=common
            if stage!='scores':
                for t in data['tensors']:
                    for shard in t['shards']:
                        for key in ['before','after','value']:
                            if key in shard:shard[key]['path']=str((pair/side/shard[key]['path']).resolve())
            write(dest/f'{stage}.json',data)
    for stage in ['gradients','updates','scores']:
        contract=read(pair/f'{stage}-contract.json');contract['common']=common;write(out/f'{stage}-contract.json',contract)
        if stage!='scores':
            for side in ['pytorch',framework]:write(out/side/f'{stage}-validation.json',validate(out/f'{stage}-contract.json',out/side/f'{stage}.json'))
            report=compare(out/f'{stage}-contract.json',out/'pytorch'/f'{stage}.json',out/framework/f'{stage}.json')
        else:report=compare_scores(out/f'{stage}-contract.json',out/'pytorch/scores.json',out/framework/'scores.json')
        write(out/f'{stage}-comparison.json',report)
        assert report['status']=='no_thresholds',report
    write(out/'reexport.json',{'reason':'Full Qwen2 config in raw common.model contains known null/default fields; strict condition checker rejects nested nulls. Re-export uses exact initial-state hash for comparison identity; full actual config retained in original inventory.','raw_capture_unchanged':True,'arrays_reused':True,'training_repeated':False})
