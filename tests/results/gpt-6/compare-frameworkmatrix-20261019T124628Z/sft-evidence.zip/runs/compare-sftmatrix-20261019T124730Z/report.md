Native SFT framework/model precision checks completed for TRL 0.24.0, LLaMAFactory 0.9.5 and ms-swift 3.10.3 on two architectures. Each selected case executes the native trainer .train() for one cold FP32 SGD step against its own identical-initial-state fixed-token PyTorch reference. No different model weights are compared.

All six selected cases contain 14 valid completion labels including 2 active EOS targets, full trainable gradient presence, and stored before/after updates. SmolLM2 has 272 unique trainable parameters / 134,515,008 elements; tiny Qwen2 has 26 / 20,768. Tiny Qwen2 is deterministic random initialization (seed 20261019), not pretrained.

- trl / tiny-qwen2: native loss 4.15116214752, loss abs difference 0; target-logprob MAE/P99/max=0/0/0; gradient L2/RMSE/max=0/0/0; stored-update L2/RMSE/max=0/0/0. Status=no_thresholds; no acceptance threshold was specified.
- trl / smollm2: native loss 11.2073755264, loss abs difference 0; target-logprob MAE/P99/max=0/0/0; gradient L2/RMSE/max=0/0/0; stored-update L2/RMSE/max=0/0/0. Status=no_thresholds; no acceptance threshold was specified.
- llamafactory / tiny-qwen2: native loss 4.15116214752, loss abs difference 0; target-logprob MAE/P99/max=0/0/0; gradient L2/RMSE/max=0/0/0; stored-update L2/RMSE/max=0/0/0. Status=no_thresholds; no acceptance threshold was specified.
- llamafactory / smollm2: native loss 11.2073755264, loss abs difference 0; target-logprob MAE/P99/max=0/0/0; gradient L2/RMSE/max=0/0/0; stored-update L2/RMSE/max=0/0/0. Status=no_thresholds; no acceptance threshold was specified.
- swift / tiny-qwen2: native loss 4.15116214752, loss abs difference 0; target-logprob MAE/P99/max=0/0/0; gradient L2/RMSE/max=0/0/0; stored-update L2/RMSE/max=0/0/0. Status=no_thresholds; no acceptance threshold was specified.
- swift / smollm2: native loss 11.2073755264, loss abs difference 0; target-logprob MAE/P99/max=0/0/0; gradient L2/RMSE/max=0/0/0; stored-update L2/RMSE/max=0/0/0. Status=no_thresholds; no acceptance threshold was specified.

All selected score/tensor comparisons return no_thresholds and gradient/update manifests validate. Native and reference losses agree exactly in the selected captures. Tiny and Smol weight identities and tied aliases are retained. Native sampler row order and denominator kwargs remain recorded.

Axolotl 0.12.2 native import stops at missing bitsandbytes and its pinned Torch/Transformers stack conflicts with this runtime; latest 0.21.0 needs Python >= 3.12/Torch >= 2.13. Megatron Bridge 0.6.2 installation is rejected by Python 3.11 (requires 3.12). MindSpeed-LLM native source adaptor and training entrypoint stop at missing torch_npu; official prerequisites require Ascend/CANN/TorchNPU. None of these three is marked training passed.

Initial TRL row-coordinate mapping and Qwen config null-condition errors are preserved as superseded attempts. TRL was re-collected in compare-sftmatrix-20261019T130222Z with equal native forward inputs asserted; LLaMAFactory tiny metadata was re-exported without repeating training. These are adapter friction findings, not confirmed skill comparator bugs.

Scope: native trainer/collator fixed-token integration only. One cold SGD step, FP32 eager attention, no clipping/accumulation/stateful optimizer/distributed/LoRA/packing. See results.json, commands.json, source evidence, native runtime paths and artifact hash manifests.
