import hashlib, importlib.metadata as md, json, pathlib, subprocess, sys, tarfile, urllib.request, traceback
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'skills/precision-skill/scripts'))
from runtime_probe import probe_runtime
def write(path,x):path.write_text(json.dumps(x,indent=2)+'\n')
def fetch_json(url):return json.load(urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'precision-sft-check'}),timeout=25))
def cmd(args,timeout=90):
    print('$ '+' '.join(args),flush=True)
    try:
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
        print(p.stdout,flush=True);return {'command':args,'returncode':p.returncode,'output':p.stdout}
    except subprocess.TimeoutExpired as e:return {'command':args,'status':'timeout','output':str(e.output)}
versions={}
for version in ['0.11.0','0.12.2','0.13.0','']:
    try:
        d=fetch_json('https://pypi.org/pypi/axolotl/'+(version+'/' if version else '')+'json')['info']
        versions[version or 'latest']={'version':d['version'],'python':d['requires_python'],'requires':d['requires_dist']}
    except Exception as e:versions[version or 'latest']={'error':repr(e)}
write(ROOT/'axolotl-version-selection.json',versions)
evidence=json.loads((ROOT/'sources.json').read_text())
sources={'llamafactory-0.9.5':('hiyouga/LlamaFactory','v0.9.5',['src/llamafactory/train/sft/trainer.py','src/llamafactory/train/sft/workflow.py','pyproject.toml']), 'axolotl':('axolotl-ai-cloud/axolotl','v0.10.0',['src/axolotl/train.py','pyproject.toml'])}
for name,(repo,ref,files) in sources.items():
    try:
        sha=fetch_json(f'https://api.github.com/repos/{repo}/commits/{ref}')['sha'];dest=ROOT/'official-source'/name;dest.mkdir(parents=True,exist_ok=True)
        rec={'repository':repo,'requested_ref':ref,'sha':sha,'files':[]}
        for f in files:
            url=f'https://raw.githubusercontent.com/{repo}/{sha}/{f}'
            try:
                data=urllib.request.urlopen(url,timeout=25).read();(dest/f.replace('/','__')).write_bytes(data);rec['files'].append({'path':f,'url':f'https://github.com/{repo}/blob/{sha}/{f}'})
            except Exception as e:rec['files'].append({'path':f,'error':repr(e)})
        evidence[name]=rec
    except Exception as e:evidence[name]={'error':repr(e)}
write(ROOT/'sources-final.json',evidence)
probe_specs={
 'ms-swift':{'imports':['torch','transformers','swift'],'symbols':['swift.llm.train.sft:SwiftSft','swift.trainers:Seq2SeqTrainer'],'distributions':['ms-swift','torch','transformers','peft','trl','datasets']},
 'axolotl':{'imports':['torch','transformers','axolotl'],'symbols':['axolotl.train:train'],'distributions':['axolotl','torch','transformers']},
}
for name,spec in probe_specs.items():
    report=probe_runtime(spec,executable=sys.executable,timeout=45);write(ROOT/f'probe-{name}.json',report);print(name,report,flush=True)
resources=pathlib.Path('<USER_HOME>/precision-framework-tests/sft')
for name in ['megatron-bridge','mindspeed-llm']:
    rec=evidence[name];repo=rec['repository'];sha=rec['sha'];archive=resources/(name+'-'+sha+'.tar.gz');source=resources/(name+'-'+sha)
    acquisition={'url':f'https://codeload.github.com/{repo}/tar.gz/{sha}','sha':sha}
    try:
        if not archive.exists():
            with urllib.request.urlopen(acquisition['url'],timeout=60) as r,archive.open('wb') as out:
                while b:=r.read(1024*1024):
                    out.write(b)
                    if out.tell()>200*1024*1024:raise RuntimeError('source archive exceeded 200 MiB bounded download')
        acquisition.update(bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
        source.mkdir(exist_ok=True)
        with tarfile.open(archive) as tf:tf.extractall(source,filter='data')
        top=next(p for p in source.iterdir() if p.is_dir())
        if name=='megatron-bridge':spec={'imports':['torch','transformers','megatron.bridge.training.pretrain'],'symbols':['megatron.bridge.training.pretrain:pretrain'],'distributions':['torch','transformers'],'python_paths':[str(top/'src')]}
        else:spec={'imports':['torch','mindspeed_llm.megatron_adaptor'],'symbols':[],'distributions':['torch'],'python_paths':[str(top)]}
        report=probe_runtime(spec,executable=sys.executable,timeout=45);report['source_acquisition']=acquisition;report['source_root']=str(top)
        write(ROOT/f'probe-{name}.json',report);print(name,report,flush=True)
        if name=='mindspeed-llm':write(ROOT/'entrypoint-mindspeed-llm.json',cmd([sys.executable,str(top/'pretrain_gpt.py'),'--help'],45))
    except Exception as e:write(ROOT/f'probe-{name}.json',{'status':'source_acquisition_failed','error':repr(e),'traceback':traceback.format_exc(),'source_acquisition':acquisition})
write(ROOT/'installed-distributions.json',sorted([{'name':d.metadata['Name'],'version':d.version,'location':str(d.locate_file(''))} for d in md.distributions()],key=lambda d:d['name'].lower()))
