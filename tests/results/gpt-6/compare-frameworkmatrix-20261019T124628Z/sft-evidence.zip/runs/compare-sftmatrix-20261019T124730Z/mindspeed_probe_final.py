import json,pathlib,subprocess,sys,urllib.request,os,traceback
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'skills/precision-skill/scripts'))
from runtime_probe import probe_runtime
sha='5a8ea03b12066067f39b1771782d12db236267ef';f='mindspeed_llm/tasks/megatron_adaptor_v2.py';fragment=ROOT/'official-source/mindspeed-native-fragment';(fragment/pathlib.Path(f).parent).mkdir(parents=True,exist_ok=True)
url=f'https://raw.githubusercontent.com/Ascend/MindSpeed-LLM/{sha}/{f}';attempts=[]
for attempt in range(3):
    try:
        (fragment/f).write_bytes(urllib.request.urlopen(url,timeout=10).read());attempts.append({'attempt':attempt,'status':'downloaded'});break
    except Exception as e:attempts.append({'attempt':attempt,'error':repr(e)})
report=probe_runtime({'imports':['torch','mindspeed_llm'],'symbols':['mindspeed_llm:megatron_adaptor'],'distributions':['torch'],'python_paths':[str(fragment)]},executable=sys.executable,timeout=45)
report['scope']='Pinned native source fragments; native package __init__ routes to tasks.megatron_adaptor_v2. Complete repository archive timed out; no training executed.';report['source_url']=f'https://github.com/Ascend/MindSpeed-LLM/blob/{sha}/{f}';report['acquisition_attempts']=attempts
(ROOT/'native-import-probe-mindspeed-final.json').write_text(json.dumps(report,indent=2)+'\n')
command=[sys.executable,str(ROOT/'official-source/mindspeed-llm/pretrain_gpt.py'),'--help'];p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45,env={**os.environ,'PYTHONPATH':str(fragment)})
(ROOT/'entrypoint-probe-mindspeed-final.json').write_text(json.dumps({'command':command,'returncode':p.returncode,'output':p.stdout,'source_fragment_pythonpath':str(fragment)},indent=2)+'\n')
