import hashlib, importlib.metadata as md,json,pathlib,subprocess,sys,urllib.request,os
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'skills/precision-skill/scripts'))
from runtime_probe import probe_runtime
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def fetch(url):return urllib.request.urlopen(url,timeout=20).read()
evidence=json.loads((ROOT/'sources-complete.json').read_text())
name='axolotl-0.12.2';sha='3cf22ae23bbc6ded4cfe713fad847fe93ec99b1f';repo='axolotl-ai-cloud/axolotl';dest=ROOT/'official-source'/name;dest.mkdir(exist_ok=True)
rec={'repository':repo,'requested_ref':'v0.12.2','sha':sha,'sha_resolution_command':['git','ls-remote','https://github.com/axolotl-ai-cloud/axolotl.git','refs/tags/v0.12.2','refs/tags/0.12.2'],'files':[]}
for f in ['pyproject.toml','src/axolotl/train.py']:
    try:
        data=fetch(f'https://raw.githubusercontent.com/{repo}/{sha}/{f}');(dest/f.replace('/','__')).write_bytes(data);rec['files'].append({'path':f,'url':f'https://github.com/{repo}/blob/{sha}/{f}','sha256':hashlib.sha256(data).hexdigest()})
    except Exception as e:rec['files'].append({'path':f,'error':repr(e)})
evidence[name]=rec;write(ROOT/'sources-verified.json',evidence)
fragment=ROOT/'official-source/mindspeed-native-fragment';sha=evidence['mindspeed-llm']['sha'];f='mindspeed_llm/megatron_adaptor/__init__.py';(fragment/pathlib.Path(f).parent).mkdir(parents=True,exist_ok=True)
try:
    data=fetch(f'https://raw.githubusercontent.com/Ascend/MindSpeed-LLM/{sha}/{f}');(fragment/f).write_bytes(data)
    spec={'imports':['torch','mindspeed_llm.megatron_adaptor'],'symbols':[],'distributions':['torch'],'python_paths':[str(fragment)]}
    report=probe_runtime(spec,executable=sys.executable,timeout=45);report['scope']='Pinned native adaptor package source fragment; not an installed/full repository. Training not executed.';report['source_url']=f'https://github.com/Ascend/MindSpeed-LLM/blob/{sha}/{f}'
    write(ROOT/'native-import-probe-mindspeed-package.json',report)
    command=[sys.executable,str(ROOT/'official-source/mindspeed-llm/setup.py'),'--name'];p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45)
    write(ROOT/'setup-probe-mindspeed-llm.json',{'command':command,'returncode':p.returncode,'output':p.stdout})
    command=[sys.executable,str(ROOT/'official-source/mindspeed-llm/pretrain_gpt.py'),'--help'];p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45,env={**os.environ,'PYTHONPATH':str(fragment)})
    write(ROOT/'entrypoint-probe-mindspeed-package.json',{'command':command,'returncode':p.returncode,'output':p.stdout,'source_fragment_pythonpath':str(fragment)})
except Exception as e:write(ROOT/'native-import-probe-mindspeed-package.json',{'error':repr(e)})
packages=[]
for name in ['torch','numpy','transformers','trl','llamafactory','ms-swift','axolotl','peft','accelerate','datasets','tokenizers']:
    d=md.distribution(name);packages.append({'distribution':name,'version':d.version,'location':str(d.locate_file('')),'requires':d.requires})
write(ROOT/'pinned-packages-final.json',packages)
write(ROOT/'installed-distributions-final.json',sorted([{'name':d.metadata['Name'],'version':d.version,'location':str(d.locate_file(''))} for d in md.distributions()],key=lambda d:d['name'].lower()))
