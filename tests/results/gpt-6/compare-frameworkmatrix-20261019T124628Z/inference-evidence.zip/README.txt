Portable captured inference evidence

Run: python replay.py --output /absolute/path/to/a-new-output-directory
Requires Python and NumPy only. This replays 9 target/distribution comparisons, validates 9 side manifests, and reproduces the exact default-temperature mismatch diagnostic. Full captured FP32 logprob rows are included. Model weights, GGUF files, native executables, most optional raw-logit arrays, and external environments are excluded. Native capture source is archival and has redacted environment/model paths; native framework reruns are not promised. Processed/default PyTorch capture is under diagnostics/default-temperature/, separate from neutral final captures. See EXPORT.json for raw/exported hashes and transformations.
