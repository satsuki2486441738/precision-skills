import pathlib,json,shutil,hashlib,subprocess,importlib.metadata as m,sys
RUN=pathlib.Path(__file__).resolve().parent;DEST=RUN/'installed-source';DEST.mkdir(exist_ok=True)
env=pathlib.Path('<ENV_ROOT>/precision-inference-20261019/lib/python3.11/site-packages')
src=pathlib.Path((RUN/'source-path.txt').read_text())
items=[]
for rel in ['lmdeploy/serve/core/async_engine.py','lmdeploy/messages.py','lmdeploy/pytorch/engine/model_agent/agent.py','lmdeploy/pytorch/engine/logits_process.py','lmdeploy/pytorch/kernels/cuda/pagedattention.py','lmdeploy/turbomind/turbomind.py']:
 p=env/rel
 if p.exists():
  dest=DEST/rel.replace('/','__');shutil.copyfile(p,dest);items.append({'path':str(p),'copy':str(dest.relative_to(RUN)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for rel in ['include/llama.h','convert_hf_to_gguf.py','requirements/requirements-convert_hf_to_gguf.txt','ggml/src/ggml-cpu/CMakeLists.txt']:
 p=src/rel;dest=DEST/('llama.cpp__'+rel.replace('/','__'));shutil.copyfile(p,dest);items.append({'path':str(p),'copy':str(dest.relative_to(RUN)),'source_revision':(RUN/'llama-source-revision.txt').read_text().strip(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for n in ['lmdeploy','triton','torch','transformers']:
 d=m.distribution(n);p=DEST/(n+'--METADATA.txt');p.write_text(d.read_text('METADATA'));items.append({'package':n,'version':d.version,'copy':str(p.relative_to(RUN)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(RUN/'installed-source-index.json').write_text(json.dumps(items,indent=2))
with (RUN/'llama-ldd.log').open('w') as f:subprocess.run(['ldd',str(RUN/'native_llama_capture')],stdout=f,stderr=subprocess.STDOUT,timeout=20)
with (RUN/'runtime-freeze.log').open('w') as f:
 for d in sorted(m.distributions(),key=lambda d:(d.metadata['Name'] or '').lower()):f.write(f"{d.metadata['Name']}=={d.version} @ {d.locate_file('')}\n")
