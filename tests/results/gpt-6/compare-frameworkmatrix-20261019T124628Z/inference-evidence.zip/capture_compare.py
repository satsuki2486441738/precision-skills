import sys,os,json,pathlib,hashlib,time,subprocess,traceback,importlib.metadata
import numpy as np
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer
RUN=pathlib.Path(__file__).resolve().parent
SKILL=RUN.parent.parent/'skills/precision-skill/scripts'
sys.path.insert(0,str(SKILL))
from inference_capture import FixedHistory,validate_history,export_records
from runtime_probe import probe_runtime
MODEL=pathlib.Path('<RESOURCE_ROOT>/models/SmolLM2-135M-Instruct/12fd25f77366fa6b3b4b768ec3050bf629380bac')
SOURCE=pathlib.Path((RUN/'source-path.txt').read_text())
def save(name,data):
 (RUN/name).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def inputs():
 tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
 ids=tok.encode('The capital of France is Paris. The capital of Germany is Berlin.',add_special_tokens=False)
 d={'sample':'geography','text':'The capital of France is Paris. The capital of Germany is Berlin.','prompt':ids[:6],'continuation':ids[6:9],'all_token_ids':ids,'bos_added':False,'template':None,'attention_mask':'all ones','positions':'absolute contiguous from zero'}
 save('inputs.json',d)
 (RUN/'tokens.txt').write_text(f"{len(d['prompt'])} {len(d['continuation'])}\n"+' '.join(map(str,d['prompt']+d['continuation'])))
 return d
def export(side,rows,d,extra):
 records=[];events=[];hist=FixedHistory(d['sample'],d['prompt'],d['continuation'])
 for step,row in enumerate(rows):
  tensor=row.detach().cpu().clone() if torch.is_tensor(row) else torch.from_numpy(np.array(row,copy=True))
  np.save(RUN/f'{side}-raw-logits-{step}.npy',tensor.float().numpy(),allow_pickle=False)
  record=hist.capture_and_force(tensor,RUN/f'{side}-logprobs-{step}')
  records.append(record)
  events.append({'stage':'prefill' if step==0 else 'decode','input_ids':d['prompt'] if step==0 else [d['continuation'][step-1]],'positions':list(range(len(d['prompt']))) if step==0 else [len(d['prompt'])+step-1],**({'prefix_length':0} if step==0 else {})})
 save(side+'-records.json',records)
 if extra.get('native_cache_replay') is False:
  events=[{'stage':'prefill','input_ids':d['prompt']+d['continuation'][:i],'positions':list(range(len(d['prompt'])+i)),'prefix_length':0} for i in range(len(rows))]
  validation={'native_execution':'repeated-prefill','distributions':len(rows),'fixed_histories_match':all(e['input_ids']==r['history'] for e,r in zip(events,records)),'cached_decode_coverage':0}
 else:validation=validate_history(d['prompt'],d['continuation'],events)
 save(side+'-history.json',{'events':events,'validation':validation,'native_evidence':extra})
 return records
def reference(d):
 torch.set_num_threads(4);torch.manual_seed(0)
 m=AutoModelForCausalLM.from_pretrained(MODEL,dtype=torch.float32,attn_implementation='eager',local_files_only=True).eval()
 rows=[];past=None
 with torch.inference_mode():
  for step in range(len(d['continuation'])):
   ids=d['prompt'] if step==0 else [d['continuation'][step-1]]
   pos=list(range(len(d['prompt']))) if step==0 else [len(d['prompt'])+step-1]
   o=m(input_ids=torch.tensor([ids]),position_ids=torch.tensor([pos]),attention_mask=torch.ones((1,len(d['prompt'])+step),dtype=torch.long),past_key_values=past,use_cache=True)
   rows.append(o.logits[0,-1].clone());past=o.past_key_values
 return export('transformers-cpu-f32',rows,d,{'native_entrypoint':'LlamaForCausalLM.forward','cache_class':type(past).__name__,'cache_dtype':str(past.layers[0].keys.dtype),'eval':not m.training,'grad_enabled':False,'attention':'eager','position_ids_explicit':True})
def run(cmd,name,timeout=180):
 t=time.monotonic()
 with (RUN/(name+'.log')).open('w') as f:
  p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 save(name+'-status.json',{'command':list(map(str,cmd)),'returncode':p.returncode,'elapsed_seconds':time.monotonic()-t})
 p.check_returncode()
def llama(d):
 lib=SOURCE/'build/bin'
 run(['g++','-std=c++17','-O2',str(RUN/'native_llama_capture.cpp'),'-I'+str(SOURCE/'include'),'-I'+str(SOURCE/'ggml/include'),'-L'+str(lib),'-Wl,-rpath,'+str(lib),'-lllama','-o',str(RUN/'native_llama_capture')],'llama-adapter-build')
 run([str(RUN/'native_llama_capture'),'<RESOURCE_ROOT>/inference/SmolLM2-135M-Instruct-f32.gguf',str(RUN/'tokens.txt'),str(RUN/'llama-raw.bin'),str(RUN/'llama-native-settings.json')],'llama-native-capture')
 native=json.loads((RUN/'llama-native-settings.json').read_text())
 rows=np.fromfile(RUN/'llama-raw.bin',dtype=np.float32).reshape(native['rows'],native['vocab_size'])
 return export('llama-cpu-f32',rows,d,native)
if __name__=='__main__':
 d=inputs()
 save('model-identity.json',{'model':'HuggingFaceTB/SmolLM2-135M-Instruct','revision':MODEL.name,'initialization':'pretrained','files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in MODEL.iterdir() if p.is_file()},'gguf':{'path':'<RESOURCE_ROOT>/inference/SmolLM2-135M-Instruct-f32.gguf','sha256':sha(pathlib.Path('<RESOURCE_ROOT>/inference/SmolLM2-135M-Instruct-f32.gguf'))},'llama_revision':(RUN/'llama-source-revision.txt').read_text().strip()})
 save('runtime-reference.json',probe_runtime({'imports':['torch','transformers','numpy'],'symbols':['transformers:AutoModelForCausalLM'],'distributions':['torch','transformers','numpy']},timeout=60))
 t=time.monotonic();reference(d);llama(d);save('capture-stage-status.json',{'status':'completed','elapsed_seconds':time.monotonic()-t})
