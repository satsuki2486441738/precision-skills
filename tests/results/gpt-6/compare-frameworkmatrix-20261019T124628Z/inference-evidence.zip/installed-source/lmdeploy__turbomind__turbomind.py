# Copyright (c) OpenMMLab. All rights reserved.

import asyncio
import copy
import math
import os
import os.path as osp
from collections.abc import Sequence
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from multiprocessing.reduction import ForkingPickler
from typing import Any

import pybase64
import torch

from lmdeploy._guided_decoding import compile_response_format
from lmdeploy.messages import EngineOutput, GenerationConfig, ResponseType, ScheduleMetrics, TurbomindEngineConfig
from lmdeploy.serve.openai.protocol import UpdateParamsRequest
from lmdeploy.tokenizer import Tokenizer
from lmdeploy.utils import get_logger, get_max_batch_size, get_model

from . import _tm
from .parallel_config import derive_parallel_config
from .supported_models import is_supported
from .tokenizer_info import TokenizerInfo

logger = get_logger('lmdeploy')

MAX_LOGPROBS = 1024
_FP32_MAMBA_SSM_DTYPE = os.getenv('LMDEPLOY_FP32_MAMBA_SSM_DTYPE', '0') == '1'


def _construct_stop_or_bad_words(words: list[int] = None):
    if words is None or len(words) == 0:
        return None
    offsets = list(range(1, len(words) + 1))
    combined = [words, offsets]
    return combined


def _np_dict_to_tm_dict(np_dict: dict):
    """Map numpy.ndarray to turbomind's tensor."""
    ret = _tm.TensorMap()
    for k, v in np_dict.items():
        ret[k] = _tm.from_dlpack(v)

    return ret


def _tm_dict_to_torch_dict(tm_dict: _tm.TensorMap):
    """Map turbomind's tensor to torch's tensor."""
    ret = dict()
    for k, v in tm_dict.items():
        if v.type == _tm.DataType.TYPE_UINT32:
            v = v.view(_tm.DataType.TYPE_INT32)
        ret[k] = torch.from_dlpack(v)

    return ret


def complete_parallel_config(cfg: TurbomindEngineConfig):
    if any((cfg.attn_dp_size, cfg.attn_tp_size, cfg.attn_cp_size, cfg.mlp_dp_size, cfg.mlp_tp_size,
            cfg.outer_dp_size)):
        cfg.attn_dp_size = cfg.attn_dp_size or 1
        cfg.attn_tp_size = cfg.attn_tp_size or 1
        cfg.attn_cp_size = cfg.attn_cp_size or 1
        cfg.mlp_dp_size = cfg.mlp_dp_size or 1
        cfg.mlp_tp_size = cfg.mlp_tp_size or 1
        cfg.outer_dp_size = cfg.outer_dp_size or 1
        gcd = math.gcd(cfg.mlp_dp_size, cfg.attn_dp_size)
        cfg.outer_dp_size *= gcd
        cfg.mlp_dp_size //= gcd
        cfg.attn_dp_size //= gcd
        return True
    return False


def update_parallel_config(cfg: TurbomindEngineConfig):
    cfg.device_num = len(cfg.devices) * cfg.nnodes if cfg.devices else cfg.device_num
    if not complete_parallel_config(cfg):
        available = torch.cuda.device_count() * cfg.nnodes
        parallel = derive_parallel_config(cfg.dp, cfg.tp, cfg.ep, cfg.cp, cfg.device_num, available)
        cfg.device_num = parallel.device_num
        cfg.outer_dp_size = parallel.outer_dp_size
        cfg.attn_dp_size = parallel.attn_dp_size
        cfg.attn_tp_size = parallel.attn_tp_size
        cfg.attn_cp_size = parallel.attn_cp_size
        cfg.mlp_dp_size = parallel.mlp_dp_size
        cfg.mlp_tp_size = parallel.mlp_tp_size
    if cfg.ep > 1:
        if cfg.moe_a2a_backend == 'auto':
            cfg.moe_a2a_backend = 'deepep' if cfg.nnodes > 1 else 'default'
        if cfg.moe_a2a_backend == 'deepep':
            assert cfg.communicator == 'nccl', 'deepep backend only supports nccl communicator'
            # Reduce the number of QPs used in multithreaded scenarios.
            os.environ.setdefault('NCCL_CROSS_NIC', '0')
        if cfg.communicator in ['cuda-ipc', 'native']:
            assert cfg.nnodes == 1, f'{cfg.communicator} communicator only supports single-node'
    assert cfg.attn_dp_size * cfg.attn_tp_size * cfg.attn_cp_size * cfg.outer_dp_size == cfg.device_num
    # update devices
    cfg.devices = cfg.devices or list(range(cfg.device_num // cfg.nnodes))
    cfg.devices = cfg.devices[:cfg.device_num // cfg.nnodes]
    assert len(cfg.devices) == cfg.device_num // cfg.nnodes


class TurboMind:
    """LMDeploy's inference engine.

    Args:
        model_path (str): the path of turbomind's model
        mode_name (str): the name of the served model
        chat_template_name (str): the name of the chat template, which is
            supposed to be a builtin chat template defined in
            `lmdeploy/model.py`
        engine_config (TurbomindEngineConfig): the config of the inference
            engine
        model_source (int): the source of the model, which is either
            turbomind model, or a transformers model
    """

    def __init__(self,
                 model_path: str,
                 model_name: str = None,
                 chat_template_name: str = None,
                 engine_config: TurbomindEngineConfig = None,
                 trust_remote_code: bool = False,
                 **kwargs):
        self.model_name = model_name
        self.chat_template_name = chat_template_name

        _engine_config = copy.deepcopy(engine_config)
        if _engine_config is None:
            _engine_config = TurbomindEngineConfig()
        if _engine_config.max_batch_size is None:
            _engine_config.max_batch_size = get_max_batch_size('cuda')
        assert _engine_config.max_batch_size > 0, 'max_batch_size should be' \
            f' greater than 0, but got {_engine_config.max_batch_size}'

        update_parallel_config(_engine_config)
        if _engine_config.nnodes > 1:
            logger.info(f'dist_init_addr={_engine_config.dist_init_addr}')
            assert _engine_config.dist_init_addr is not None
            hostname, port = _engine_config.dist_init_addr.split(':')
            os.environ['LMDEPLOY_DIST_INIT_ADDR'] = hostname
            os.environ['LMDEPLOY_DIST_INIT_PORT'] = port
            # this will block the process and ignore signals until all ranks done
            from torch.distributed import TCPStore
            self.store = TCPStore(host_name=hostname,
                                  port=int(port),
                                  world_size=_engine_config.nnodes,
                                  is_master=_engine_config.node_rank == 0)

        self.gpu_count = len(_engine_config.devices)
        self.devices = _engine_config.devices
        self._engine_created = False

        if not osp.exists(model_path):
            model_path = get_model(model_path, _engine_config.download_dir, _engine_config.revision)
        self.model_comm, model_loader = self._from_hf(model_path=model_path, engine_config=_engine_config,
                                                      trust_remote_code=trust_remote_code)
        self.source_model = model_loader.model
        self.is_dummy = self.model_comm.is_dummy_node()
        self.tokenizer = Tokenizer(model_path, trust_remote_code=trust_remote_code)
        self._grammar_compiler = None
        if not _engine_config.empty_init:
            with torch.cuda.device(self.devices[0]):
                model_loader.export()
            self._process_weights()
            self._create_engine()

        self.session_len = _engine_config.session_len
        self.health_executor = ThreadPoolExecutor(max_workers=1)

    @property
    def grammar_compiler(self):
        """Lazy-initialized GrammarCompiler shared across all requests."""
        if self._grammar_compiler is None:
            tokenizer_info = TokenizerInfo.from_huggingface(
                self.tokenizer.model.model, vocab_size=self._vocab_size)
            self._grammar_compiler = _tm.GrammarCompiler(tokenizer_info)
        return self._grammar_compiler

    def _process_weights(self):
        """Process weight."""
        with ThreadPoolExecutor(max_workers=self.gpu_count) as e:
            for _ in e.map(self.model_comm.process_weight, range(self.gpu_count)):
                pass

    def _create_engine(self):
        """Create engine."""
        with ThreadPoolExecutor(max_workers=self.gpu_count) as e:
            for _ in e.map(self.model_comm.create_engine, range(self.gpu_count)):
                pass
        self._engine_created = True

    def _create_weight(self, model_comm):
        """Create per-GPU Context + empty ModelRoot sentinel.

        Runs both C++ init steps sequentially per device, inside a
        ThreadPoolExecutor so all ranks enter ``create_context``
        concurrently and hit its ``h_global->Sync()`` barriers together.
        ``create_root`` itself has no collectives, so it can follow
        synchronously on each thread.
        """

        def _create_weight_func(device_id):
            model_comm.create_context(device_id)
            model_comm.create_root(device_id)

        with ThreadPoolExecutor(max_workers=self.gpu_count) as executor:
            futures = []
            for device_id in range(self.gpu_count):
                futures.append(executor.submit(_create_weight_func, device_id))
            for future in futures:
                future.result()

    def _from_hf(self, model_path: str, engine_config: TurbomindEngineConfig,
                 trust_remote_code: bool = False):
        """Load model which is in hf format."""
        assert is_supported(model_path, trust_remote_code=trust_remote_code), (
            f'turbomind does not support {model_path}. '
            'Plz try pytorch engine instead.')

        from .converter import get_tm_config
        from .model_loader import ModelLoader

        model, model_path, data_type = get_tm_config(model_path, engine_config,
                                                     trust_remote_code=trust_remote_code)

        self._vocab_size = model._vocab_size
        self.engine_config = engine_config

        dtype_map = {
            'bfloat16': _tm.DataType.TYPE_BF16,
            'float16': _tm.DataType.TYPE_FP16,
            'float32': _tm.DataType.TYPE_FP32,
        }
        state_dtype = 'float32' if _FP32_MAMBA_SSM_DTYPE else engine_config.dtype
        ec = _tm.EngineConfig()
        ec.data_type = dtype_map[engine_config.dtype]
        ec.state_dtype = dtype_map[state_dtype]
        ec.cache_block_seq_len = engine_config.cache_block_seq_len
        ec.quant_policy = engine_config.quant_policy
        ec.max_batch_size = engine_config.max_batch_size
        ec.max_prefill_token_num = engine_config.max_prefill_token_num
        ec.session_len = engine_config.session_len
        ec.cache_max_block_count = engine_config.cache_max_entry_count
        ec.cache_chunk_size = engine_config.cache_chunk_size
        ec.enable_prefix_caching = engine_config.enable_prefix_caching
        ec.cache_checkpoint_interval = engine_config.cache_checkpoint_interval
        ec.cache_prompt = engine_config.cache_prompt
        ec.cache_prompt_boundary_skip = engine_config.cache_prompt_boundary_skip
        ec.cache_generation = engine_config.cache_generation
        ec.enable_metrics = engine_config.enable_metrics
        ec.num_tokens_per_iter = engine_config.num_tokens_per_iter
        ec.max_prefill_iters = engine_config.max_prefill_iters
        ec.async_ = engine_config.async_
        ec.outer_dp_size = engine_config.outer_dp_size
        ec.attn_dp_size = engine_config.attn_dp_size
        ec.attn_tp_size = engine_config.attn_tp_size
        ec.attn_cp_size = engine_config.attn_cp_size
        ec.mlp_tp_size = engine_config.mlp_tp_size
        ec.ep_size = engine_config.ep
        ec.devices = engine_config.devices
        ec.nnodes = engine_config.nnodes
        ec.node_rank = engine_config.node_rank
        ec.communicator = engine_config.communicator
        ec.moe_a2a_backend = engine_config.moe_a2a_backend

        logger.info(f'turbomind engine config:\n\n'
                    f'dtype={engine_config.dtype}, state_dtype={state_dtype}, '
                    f'session_len={engine_config.session_len}, '
                    f'max_batch_size={engine_config.max_batch_size}, '
                    f'devices={engine_config.devices}, '
                    f'tp={engine_config.attn_tp_size}, '
                    f'dp={engine_config.attn_dp_size}, '
                    f'cp={engine_config.attn_cp_size}, '
                    f'ep={engine_config.ep}, '
                    f'moe_a2a_backend={engine_config.moe_a2a_backend}')

        model_comm = _tm.TurboMind.create(model_dir='', engine_config=ec)
        self._create_weight(model_comm)

        model_loader = ModelLoader(
            model=model,
            model_comm=model_comm,
            gpu_count=self.gpu_count,
            model_path=model_path,
            data_type=data_type,
            engine_config=engine_config,
        )

        return model_comm, model_loader

    def mm_input_converter(self, multimodal: list[dict[str, Any]] | None):
        """Convert frontend multimodal data into model-specific TurboMind
        input."""
        if not multimodal:
            return None
        if self.engine_config.language_model_only:
            logger.warning('Running in language-model-only mode; multimodal inputs will be ignored.')
            return None

        parser = getattr(self.source_model, 'to_turbomind_multimodal', None)
        if parser is None:
            raise ValueError(f'{type(self.source_model).__name__} does not support TurboMind multimodal inputs.')
        return parser(multimodal)

    async def sleep(self, level: int = 1):
        """Sleep the model."""
        with ThreadPoolExecutor(max_workers=self.gpu_count) as e:
            for _ in e.map(self.model_comm.sleep, range(self.gpu_count), [level] * self.gpu_count):
                pass

    def wakeup(self, tags: list[str] | None = None):
        """Wakeup the model."""
        if tags is None:
            tags = ['weights', 'kv_cache']
        with ThreadPoolExecutor(max_workers=self.gpu_count) as e:
            for _ in e.map(self.model_comm.wakeup, range(self.gpu_count), [tags] * self.gpu_count):
                pass

    def update_params(self, request: UpdateParamsRequest):
        """Update params.

        When using the this function, you need to set empty_init=True when creating the engine.

        For each request, the serialized_named_tensors should be the full weights of a decoder layer or the misc weights
        (embedding, norm, lm_haed). You should set finished=True when you call this function for the last time.
        """

        def _construct(item):
            """ Deserialize torch.Tensor
            Args:
                item (tuple[Callable, tuple]): the return of reduce_tensor
            """
            func, args = item
            args = list(args)
            args[6] = torch.cuda.current_device()  # device id.
            return func(*args).clone()

        with torch.cuda.device(self.devices[0]):
            if isinstance(request.serialized_named_tensors, str):
                weights = ForkingPickler.loads(pybase64.b64decode(request.serialized_named_tensors))
                weights = {k: _construct(v) for k, v in weights}
            else:
                weights = request.serialized_named_tensors
            self._update_params_que.put(weights)
            next(self._export_iter)

        if request.finished:
            self._process_weights()
            if self._engine_created is False:
                self._create_engine()

    @classmethod
    def from_pretrained(cls,
                        pretrained_model_name_or_path: str,
                        model_name: str = None,
                        chat_template_name: str = None,
                        engine_config: TurbomindEngineConfig = None,
                        trust_remote_code: bool = False,
                        **kwargs):
        """LMDeploy's turbomind inference engine.

        Args:
            pretrained_model_name_or_path (str):
                It could be one of the following options:
                    - i) A local directory path of a turbomind model which is
                      converted by `lmdeploy convert` command or download from
                      ii) and iii)
                    - ii) The model_id of a lmdeploy-quantized model hosted
                      inside a model repo on huggingface.co, such as
                      "lmdeploy/llama2-chat-70b-4bit", etc.
                    - iii) The model_id of a model hosted inside a model repo
                      on huggingface.co, such as "internlm/internlm2-chat-7b",
                      "Qwen/Qwen2.5-7B-Instruct"
                      and so on.
            kwargs (remaining dictionary of keyword arguments, *optional*):
                Can be used to update configuration when initialize the engine.
        """
        return cls(model_path=pretrained_model_name_or_path,
                   model_name=model_name,
                   chat_template_name=chat_template_name,
                   engine_config=engine_config,
                   trust_remote_code=trust_remote_code,
                   **kwargs)

    def close(self):
        if hasattr(self, '_export_iter'):
            del self._export_iter
        if self.model_comm is not None:
            self.model_comm = None
        self._engine_created = False
        if hasattr(self, 'store'):
            del self.store

    def create_instance(self, cuda_stream_id=0):
        """Create a turbomind instance.

        Args:
            cuda_stream_id(int): identity of a cuda stream
        Returns:
            TurboMindInstance: an instance of turbomind
        """
        return TurboMindInstance(self, cuda_stream_id)

    def get_schedule_metrics(self):
        # TODO: support dp
        tm_metrics = self.model_comm.get_schedule_metrics(0)
        return ScheduleMetrics(active_seqs=tm_metrics.active_seqs,
                               waiting_seqs=tm_metrics.waiting_seqs,
                               cache_usage=tm_metrics.cache_usage,
                               prefix_cache_hit_rate=tm_metrics.prefix_cache_hit_rate,
                               scheduler_tick=tm_metrics.scheduler_tick)

    def _get_health_status(self) -> dict:
        """Get lightweight health status."""
        if self.model_comm is None:
            return dict(alive=False,
                        message='TurboMind model communicator is not available.',
                        schedule_metrics=None)

        if not self._engine_created:
            if self.engine_config.empty_init:
                return dict(alive=True,
                            message='TurboMind engine is waiting for weights in empty-init mode.',
                            schedule_metrics=None)
            return dict(alive=False,
                        message='TurboMind engine has not been created.',
                        schedule_metrics=None)

        return dict(alive=True,
                    message='TurboMind engine is healthy.',
                    schedule_metrics=self.get_schedule_metrics())

    async def get_health_status(self) -> dict:
        """Get backend health status without blocking the event loop."""
        # MultimodalProcessor may submit a large number of tasks to the default thread pool, causing
        # the _get_health_status task to be selected after the DEFAULT_PROBE_TIMEOUT has already elapsed.
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self.health_executor, self._get_health_status)


def _get_logits(outputs, offset: int):
    logits = outputs['logits']

    def _func(out: EngineOutput, step: int, **kwargs):
        out.logits = logits[:step - offset - 1, :]

    return _func


def _get_ce_loss(outputs):
    ce_loss = outputs['ce_loss']

    def _func(out: EngineOutput, step: int, **kwargs):
        if out.status == ResponseType.FINISH:
            out.ce_loss = ce_loss[0].item()

    return _func


def _get_last_hidden_state(outputs, offset: int):
    last_hidden_state = outputs['last_hidden_state']

    def _func(out: EngineOutput, step: int, **kwargs):
        out.last_hidden_state = last_hidden_state[:step - offset - 1, :]

    return _func


def _get_logprobs_impl(logprob_vals: torch.Tensor, logprob_idxs: torch.Tensor, logprob_nums: torch.Tensor,
                       output_ids: list[int], logprobs: int, offset: int):
    """Get logprob of each generated token.

    Args:
        logprob_vals (torch.Tensor): shape (max_new_tokens, 1024),
            1024 is the max_logprobs that turbomind engine can output
        logprob_idxs (torch.Tensor): shape (max_new_tokens, 1024)
        logprob_nums (torch.Tensor): shape (max_new_tokens,)
        output_ids (list[int]): new generated token ids
        logprobs (int): top n logprobs to return
        offset (int): offset to index logprob_vals, logprob_idxs and logprob_nums.
            It indicates where to start getting logprobs for the current generated tokens `output_ids`
    """
    out_logprobs = []
    # the total generated token number until now
    length = len(output_ids) + offset
    for (pos, idx, val, n) in zip(range(len(output_ids)), logprob_idxs[offset:length], logprob_vals[offset:length],
                                  logprob_nums[offset:length]):
        topn = min(n.item(), logprobs)
        tok_res = {idx[i].item(): val[i].item() for i in range(topn)}
        token_id = output_ids[pos]
        if token_id not in tok_res:
            valid_n = n.item()
            tok_res[token_id] = \
                val[:valid_n][idx[:valid_n] == token_id].item()
        ids = list(tok_res.keys())
        for k in ids:
            if tok_res[k] == float('-inf'):
                tok_res.pop(k)
        out_logprobs.append(tok_res)
    return out_logprobs


def _get_logprobs(outputs, output_logprobs: int):
    logprob_vals = outputs['logprob_vals']  # shape {max_new_tokens, 1024}
    logprob_idxs = outputs['logprob_indexes']  # shape {max_new_tokens, 1024}
    logprob_nums = outputs['logprob_nums']  # shape {max_new_tokens,}
    offset = 0  # offset to index logprob_vals, logprob_idxs and logprob_nums

    def _func(out: EngineOutput, step: int, **kwargs):
        nonlocal offset
        out.logprobs = _get_logprobs_impl(logprob_vals, logprob_idxs, logprob_nums, out.token_ids, output_logprobs,
                                          offset)
        offset += len(out.token_ids)

    return _func


def _get_metrics(metrics):
    import time

    from lmdeploy.messages import EngineEvent, EventType, RequestMetrics

    is_first = True

    def _func(out: EngineOutput, step: int, **kwargs):
        nonlocal is_first
        cached_tokens = metrics.cached_tokens
        if not is_first:
            out.req_metrics = RequestMetrics(token_timestamp=time.time(), cached_tokens=cached_tokens)
        else:
            events = [EngineEvent(EventType.QUEUED, metrics.enqueue_time / 1000000)]
            if metrics.scheduled_time:
                events.append(EngineEvent(EventType.SCHEDULED, metrics.scheduled_time / 1000000))
            out.req_metrics = RequestMetrics(token_timestamp=time.time(),
                                             engine_events=events,
                                             cached_tokens=cached_tokens)
            is_first = False

    return _func


class StreamingSemaphore:

    def __init__(self):
        self.loop = asyncio.get_running_loop()
        self.fut = None
        self.val = 0

    async def acquire(self):
        if self.val:
            self.val = 0
            return
        self.fut = self.loop.create_future()
        await self.fut
        self.fut = None
        self.val = 0

    def release(self):
        if not self.val:
            self.val = 1
            if self.fut and not self.fut.done():
                self.fut.set_result(None)


class TurboMindInstance:
    """Instance of TurboMind.

    Args:
        tm_model (str): turbomind's model path
        cuda_stream_id(int): identity of a cuda stream
    """

    def __init__(self, tm_model: 'TurboMind', cuda_stream_id: int = 0):
        self.tm_model = tm_model
        self.cuda_stream_id = cuda_stream_id

        # create model instances
        lazy_init = self.tm_model.engine_config.empty_init
        self._model_inst = None if lazy_init else self._create_model_instance()

        self.lock = None
        # error code map from csrc (refer to `struct Request` in src/turbomind/engine/request.h)
        # to lmdeploy.messages.ResponseType
        self.errcode_map = {
            0: ResponseType.SUCCESS,
            1: ResponseType.SESSION_NOT_EXIST,
            2: ResponseType.SESSION_REPEAT,
            5: ResponseType.INTERNAL_ENGINE_ERROR,
            6: ResponseType.INPUT_LENGTH_ERROR,
            7: ResponseType.FINISH,
            8: ResponseType.CANCEL,
            9: ResponseType.PREFIX_CACHE_CONFLICT,
            10: ResponseType.NO_QUEUE,
            11: ResponseType.OUT_OF_MEMORY,
            -1: ResponseType.INTERNAL_ENGINE_ERROR,
        }

    @property
    def model_inst(self):
        if self._model_inst is None:
            self._model_inst = self._create_model_instance()
        return self._model_inst

    def _create_model_instance(self):
        model_inst = self.tm_model.model_comm.create_request()
        return model_inst

    def _get_extra_output_processors(self, outputs: dict[str, torch.Tensor], gen_config: GenerationConfig,
                                     input_len: int, metrics: '_tm.RequestMetrics'):

        def _get_offset(type):
            return input_len - 1 if type == 'generation' else 0

        fs = []
        if gen_config.output_logits:
            offset = _get_offset(gen_config.output_logits)
            fs.append(_get_logits(outputs, offset))
        if gen_config.return_ppl:
            fs.append(_get_ce_loss(outputs))
        if gen_config.output_last_hidden_state:
            offset = _get_offset(gen_config.output_last_hidden_state)
            fs.append(_get_last_hidden_state(outputs, offset))
        if gen_config.logprobs:
            fs.append(_get_logprobs(outputs, gen_config.logprobs))
        if self.tm_model.engine_config.enable_metrics:
            fs.append(_get_metrics(metrics))
        return fs

    def prepare_embeddings(self, input_embeddings=None, input_embedding_ranges=None):
        """Convert embeddings."""
        if not input_embeddings:
            return None, None

        assert isinstance(input_embeddings, list)
        assert isinstance(input_embedding_ranges, list)
        assert len(input_embeddings) == len(input_embedding_ranges)

        length = sum([x.shape[0] for x in input_embeddings])

        _MAP = dict(bfloat16=torch.bfloat16, float16=torch.float16)
        dtype = _MAP[self.tm_model.engine_config.dtype]

        values = torch.empty((length, input_embeddings[0].shape[-1]), dtype=dtype, device='cpu')
        ranges = torch.tensor(input_embedding_ranges, dtype=torch.int32, device='cpu')

        offset = 0
        for embeds in input_embeddings:
            values[offset:offset + embeds.shape[0]].copy_(embeds)
            offset += embeds.shape[0]

        return values, ranges

    def prepare_inputs(self,
                       input_ids,
                       gen_config: GenerationConfig,
                       input_embeddings=None,
                       input_embedding_ranges=None):
        """Convert inputs format."""
        assert isinstance(input_ids, Sequence)

        input_ids = torch.IntTensor(input_ids)
        input_len = len(input_ids)

        inputs = dict(input_ids=input_ids, )

        input_embeddings, input_embedding_ranges = self.prepare_embeddings(input_embeddings, input_embedding_ranges)
        if input_embeddings is not None:
            inputs['input_embeddings'] = input_embeddings.cpu()
            inputs['input_embedding_ranges'] = input_embedding_ranges

        return inputs, input_len

    async def async_cancel(self, session_id: int = None):
        self.model_inst.cancel()

    async def async_end(self, session_id):
        """TurboMind is stateless; there is no engine-side session to end."""
        return

    def async_signal_cb(self, s: StreamingSemaphore):
        """Executing on engine's signaling thread."""
        s.loop.call_soon_threadsafe(s.release)

    async def async_stream_infer(self,
                                 session_id,
                                 input_ids,
                                 input_embeddings=None,
                                 input_embedding_ranges=None,
                                 multimodal: list[dict[str, Any]] = None,
                                 gen_config: GenerationConfig = None,
                                 stream_output=False,
                                 **kwargs):
        """Perform model inference.

        Args:
            session_id (int): the id of a session
            input_ids (numpy.ndarray): the token ids of a prompt
            input_embeddings (list[numpy.ndarray]): embeddings features
            input_embedding_ranges (list[tuple[int,int]]): the begin/end
              offsets of input_embeddings to input_ids
            gen_config (GenerationConfig): generation config
            stream_output (bool): indicator for stream output
            kwargs (dict): kwargs for backward compatibility
        """
        logger.info(f'[async_stream_infer] session {session_id} start')
        gen_cfg = self._get_generation_config(gen_config)

        inputs, input_len = self.prepare_inputs(input_ids=input_ids,
                                                input_embeddings=input_embeddings,
                                                input_embedding_ranges=input_embedding_ranges,
                                                gen_config=gen_config)

        if gen_config.response_format is not None:
            try:
                compiler = self.tm_model.grammar_compiler
                grammar = compile_response_format(compiler, gen_config.response_format)
                self.model_inst.set_grammar(grammar)
            except (ValueError, KeyError) as e:
                logger.warning(f'Failed to initialize guided decoding, '
                               f'disable guided decoding: {e}')
                gen_config.response_format = None

        session = _tm.SessionParam(id=session_id, step=0)

        inputs = _np_dict_to_tm_dict(inputs)
        mm_inputs = self.tm_model.mm_input_converter(multimodal)

        sem = StreamingSemaphore()
        signal_cb = partial(self.async_signal_cb, sem)

        outputs, shared_state, metrics = self.model_inst.forward(inputs, mm_inputs, session, gen_cfg, stream_output,
                                                                 self.tm_model.engine_config.enable_metrics, signal_cb)

        outputs = _tm_dict_to_torch_dict(outputs)

        extra_fs = self._get_extra_output_processors(outputs, gen_config, input_len, metrics)

        output_ids_buf = outputs['output_ids']

        finish = False
        state = None

        output_ids = []
        prev_len = input_len
        try:
            while True:
                await sem.acquire()
                state = shared_state.consume()

                status, seq_len = state.status, state.seq_len
                ret_status = ResponseType.SUCCESS

                if status in [7, 8]:  # finish / canceled
                    finish = True
                    ret_status = ResponseType.FINISH if status == 7 else ResponseType.CANCEL
                elif status:
                    logger.error(f'internal error. status_code {status}')
                    yield self._get_error_output(status)
                    break

                if seq_len == prev_len and not finish:
                    continue

                output_ids = output_ids_buf[prev_len:seq_len].tolist()
                output = EngineOutput(ret_status, output_ids)

                for f in extra_fs:
                    f(output, seq_len)

                prev_len = seq_len

                yield output

                if finish:
                    break

        except (GeneratorExit, asyncio.CancelledError) as e:
            logger.info(f'[async_stream_infer] {type(e).__name__}')
            self.model_inst.cancel()
        except Exception as e:
            logger.error(f'[async_stream_infer] {type(e).__name__} {e}')
            self.model_inst.cancel()
            yield self._get_error_output(-1)
        finally:
            # Contract: `cb` won't be called again if status is non-zero
            # wait for status to be set as `finish` or `error`
            while not state or state.status == 0:
                await sem.acquire()
                state = shared_state.consume()
            logger.info(f'[async_stream_infer] session {session_id} done')

    def _get_error_output(self, status):
        return EngineOutput(status=self.errcode_map[status], token_ids=[])

    def _get_generation_config(self, cfg: GenerationConfig):
        c = _tm.GenerationConfig()
        c.max_new_tokens = cfg.max_new_tokens
        c.top_k = cfg.top_k
        c.top_p = cfg.top_p
        c.min_p = cfg.min_p
        c.temperature = cfg.temperature
        if cfg.stop_token_ids:
            c.eos_ids = cfg.stop_token_ids
        if cfg.bad_token_ids:
            c.bad_ids = _construct_stop_or_bad_words(cfg.bad_token_ids)
        if not cfg.ignore_eos and cfg.stop_token_ids:
            c.stop_ids = _construct_stop_or_bad_words(cfg.stop_token_ids)
        c.repetition_penalty = cfg.repetition_penalty
        if cfg.min_new_tokens:
            c.min_new_tokens = cfg.min_new_tokens
        output_type = dict(all=1, generation=2)
        if cfg.output_last_hidden_state:
            c.output_last_hidden_state = output_type[cfg.output_last_hidden_state]
        if cfg.output_logits:
            c.output_logits = output_type[cfg.output_logits]
        c.return_ppl = cfg.return_ppl
        if cfg.logprobs:
            if cfg.logprobs > MAX_LOGPROBS:
                cfg.logprobs = MAX_LOGPROBS
                logger.warning(f'logprobs should be in range [1, {MAX_LOGPROBS}]'
                               f'update logprobs={cfg.logprobs}')
            c.output_logprobs = cfg.logprobs
        if cfg.random_seed is not None:
            c.random_seed = cfg.random_seed
        # print (c)
        return c
