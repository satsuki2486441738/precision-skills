#include "llama.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <cstdlib>
int main(int argc, char **argv) {
 if(argc!=5) return 2;
 std::ifstream in(argv[2]); int n_prompt,n_cont; in>>n_prompt>>n_cont;
 std::vector<llama_token> ids(n_prompt+n_cont); for(auto &x:ids)in>>x;
 llama_backend_init();
 auto mp=llama_model_default_params(); mp.n_gpu_layers=0; mp.check_tensors=true;
 auto *model=llama_model_load_from_file(argv[1],mp); if(!model)return 3;
 auto cp=llama_context_default_params(); cp.n_ctx=128;cp.n_batch=64;cp.n_ubatch=64;cp.n_seq_max=1;cp.n_threads=4;cp.n_threads_batch=4;cp.type_k=GGML_TYPE_F32;cp.type_v=GGML_TYPE_F32;cp.flash_attn_type=LLAMA_FLASH_ATTN_TYPE_DISABLED;cp.offload_kqv=false;cp.op_offload=false;
 auto *ctx=llama_init_from_model(model,cp);if(!ctx)return 4;
 int vocab=llama_vocab_n_tokens(llama_model_get_vocab(model));
 std::ofstream out(argv[3],std::ios::binary);
 auto batch=llama_batch_init(64,0,1);
 for(int step=0;step<n_cont;step++){
  int start=step==0?0:n_prompt+step-1;int count=step==0?n_prompt:1;batch.n_tokens=count;
  for(int i=0;i<count;i++){batch.token[i]=ids[start+i];batch.pos[i]=start+i;batch.n_seq_id[i]=1;batch.seq_id[i][0]=0;batch.logits[i]=(i==count-1);}
  int rc=llama_decode(ctx,batch);if(rc!=0)return 5;
  const float *logits=llama_get_logits_ith(ctx,-1);if(!logits)return 6;
  out.write(reinterpret_cast<const char*>(logits),sizeof(float)*vocab);
 }
 std::ofstream meta(argv[4]);meta<<"{\"vocab_size\":"<<vocab<<",\"rows\":"<<n_cont<<",\"native_entrypoint\":\"llama_decode -> llama_get_logits_ith(ctx,-1)\",\"weight_dtype\":\"F32 GGUF conversion, no quantization\",\"kv_dtype\":\"F32\",\"threads\":4,\"gpu_layers\":0,\"flash_attention\":false,\"explicit_positions\":true,\"context\":128}";
 llama_batch_free(batch);llama_free(ctx);llama_model_free(model);llama_backend_free();return 0;
}
