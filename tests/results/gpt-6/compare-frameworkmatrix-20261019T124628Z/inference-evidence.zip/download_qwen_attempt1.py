import pathlib,json,urllib.request,time
from huggingface_hub import snapshot_download
RUN=pathlib.Path(__file__).resolve().parent
repo='Qwen/Qwen2.5-0.5B-Instruct'
meta=json.load(urllib.request.urlopen('https://huggingface.co/api/models/'+repo,timeout=30))
revision=meta['sha']
(RUN/'qwen-model-metadata.json').write_text(json.dumps(meta,indent=2))
start=time.monotonic()
path=snapshot_download(repo,revision=revision,local_dir='<RESOURCE_ROOT>/inference/Qwen2.5-0.5B-Instruct-'+revision,allow_patterns=['*.json','*.safetensors','*.txt','*.model','merges.txt','vocab.json'],max_workers=4)
(RUN/'qwen-resource.json').write_text(json.dumps({'repo':repo,'revision':revision,'path':path,'elapsed_seconds':time.monotonic()-start,'files':{str(p.relative_to(path)):p.stat().st_size for p in pathlib.Path(path).rglob('*') if p.is_file() and '.cache' not in p.parts}},indent=2))
print(path)
