import json, urllib.request, tarfile, pathlib, subprocess
RUN=pathlib.Path(__file__).resolve().parent
RES=pathlib.Path('<RESOURCE_ROOT>/inference')
env='<ENV_ROOT>/precision-inference-20261019/bin'
release=json.load(urllib.request.urlopen('https://api.github.com/repos/ggml-org/llama.cpp/releases/latest',timeout=30))
(RUN/'llama-release.json').write_text(json.dumps(release,indent=2))
ref=json.load(urllib.request.urlopen('https://api.github.com/repos/ggml-org/llama.cpp/git/ref/tags/'+release['tag_name'],timeout=30))
sha=ref['object']['sha']
(RUN/'llama-source-ref.json').write_text(json.dumps(ref,indent=2))
(RUN/'llama-source-revision.txt').write_text(sha+'\n')
archive=RES/('llama.cpp-'+sha+'.tar.gz')
urllib.request.urlretrieve('https://codeload.github.com/ggml-org/llama.cpp/tar.gz/'+sha,archive)
with tarfile.open(archive) as t:t.extractall(RES,filter='data')
src=RES/('llama.cpp-'+sha)
(RUN/'source-path.txt').write_text(str(src))
for name,cmd in [('llama-configure',[env+'/cmake','-S',str(src),'-B',str(src/'build'),'-DGGML_CUDA=OFF','-DLLAMA_CURL=OFF','-DLLAMA_BUILD_TESTS=OFF','-DLLAMA_BUILD_TOOLS=OFF','-DLLAMA_BUILD_EXAMPLES=OFF','-DCMAKE_BUILD_TYPE=Release']),('llama-build',[env+'/cmake','--build',str(src/'build'),'-j','8'])]:
 with (RUN/(name+'.log')).open('w') as f:
  r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=480)
  (RUN/(name+'-status.json')).write_text(json.dumps({'command':cmd,'returncode':r.returncode}))
  r.check_returncode()
print(src)
