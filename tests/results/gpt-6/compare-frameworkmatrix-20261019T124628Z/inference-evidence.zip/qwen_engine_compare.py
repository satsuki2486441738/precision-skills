import sys,pathlib,json
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import capture_compare as cap
from compare_distributions import compare as dc
from compare_target_scores import compare as tc
RUN=ROOT/'qwen2.5-0.5b';cap.RUN=RUN
save=cap.save
original=json.loads((RUN/'distribution-contract.json').read_text())
common={k:v for k,v in original['common'].items() if k!='numerics'}
sides=['transformers-cpu-f32','llama-cpu-f32']+[s for s in ['lmdeploy-turbomind-neutral','lmdeploy-pytorch-neutral'] if (RUN/(s+'-completion.json')).exists()]
numerics={s:{'numerics':{'weights':'FP32, same pretrained values' if s in sides[:2] else 'FP16, same pretrained checkpoint','logits':'FP32' if s in sides[:2] else 'FP16 promoted to FP32 for logsoftmax','logsoftmax':'FP32','cache':'FP32' if s in sides[:2] else 'FP16'},'execution':{'framework':s,'native_cache_replay':s in sides[:2],'tp':1,'native_entrypoint':'forward' if s.startswith('transformers') else 'llama_decode' if s.startswith('llama') else 'Session.request_handle / AsyncEngine.safe_run','score_processors':'neutral temperature=1 repetition=1 top_p=1 top_k=1' if s.startswith('lmdeploy') else 'none'}} for s in sides}
for s in sides[2:]:numerics[s]['execution']['backend_settings']={k:v for k,v in json.loads((RUN/(s+'-requested-settings.json')).read_text()).items() if v is not None}
contract={**original,'common':common,'side_conditions':numerics,'expected_ranks':{s:[0] for s in sides}}
targetorig=json.loads((RUN/'target-contract.json').read_text());target={**targetorig,'common':common,'side_conditions':numerics,'expected_ranks':{s:[0] for s in sides}}
save('native-distribution-contract.json',contract);save('native-target-contract.json',target)
for s in sides:
 rec=json.loads((RUN/(s+'-records.json')).read_text());ex=cap.export_records(rec,RUN)
 if s in sides[:2]:versions=json.loads((RUN/(s+'-environment.json')).read_text())['versions']
 else:versions=json.loads((RUN/(s+'-runtime.json')).read_text())
 save(s+'-native-environment.json',{'rank':0,'versions':versions,'actual':{**common,**numerics[s]},'evidence':json.loads((RUN/(s+'-history.json')).read_text())})
 save(s+'-native-status.json',{'rank':0,'status':'completed'})
 base={'schema_version':1,'common':common,'side':s,'expected_ranks':[0],'ranks':[{'rank':0,'environment':s+'-native-environment.json','status':s+'-native-status.json'}]}
 save(s+'-native-distribution.json',{**base,'kind':'distributions','positions':ex['positions']});save(s+'-native-targets.json',{**base,'kind':'target-scores','scores':ex['scores']})
metrics={}
for s in sides[1:]:
 dr=dc(RUN/'native-distribution-contract.json',RUN/'transformers-cpu-f32-native-distribution.json',RUN/(s+'-native-distribution.json'));tr=tc(RUN/'native-target-contract.json',RUN/'transformers-cpu-f32-native-targets.json',RUN/(s+'-native-targets.json'))
 save(s+'-native-distribution-comparison.json',dr);save(s+'-native-target-comparison.json',tr);metrics[s]={'distribution':dr,'target':tr}
save('native-metrics-summary.json',metrics)
print(json.dumps({s:{'distribution_status':v['distribution']['status'],'target_status':v['target']['status'],'target_metrics':v['target'].get('metrics'),'JSD':v['distribution'].get('aggregate',{}).get('tail_merged_js')} for s,v in metrics.items()},indent=2))
