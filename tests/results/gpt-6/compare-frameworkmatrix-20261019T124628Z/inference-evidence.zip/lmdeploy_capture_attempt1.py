import os,sys,json,time,pathlib,traceback,inspect
RUN=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(RUN))
from capture_compare import export,save
from runtime_probe import inspect_runtime
import torch
import lmdeploy
from lmdeploy import pipeline,PytorchEngineConfig,TurbomindEngineConfig
side=sys.argv[1]
d=json.loads((RUN/'inputs.json').read_text())
save(side+'-runtime.json',inspect_runtime({'imports':['torch','lmdeploy'],'symbols':['lmdeploy:pipeline','lmdeploy:PytorchEngineConfig','lmdeploy:TurbomindEngineConfig'],'distributions':['torch','lmdeploy','triton','transformers']}))
model='<RESOURCE_ROOT>/models/SmolLM2-135M-Instruct/12fd25f77366fa6b3b4b768ec3050bf629380bac'
cfg=PytorchEngineConfig(dtype='float16',tp=1,session_len=128,max_batch_size=1,cache_max_entry_count=0.1,eager_mode=True,enable_prefix_caching=False,block_size=16) if side=='lmdeploy-pytorch' else TurbomindEngineConfig(dtype='float16',tp=1,session_len=128,max_batch_size=1,cache_max_entry_count=0.1,enable_prefix_caching=False)
save(side+'-requested-settings.json',vars(cfg))
started=time.monotonic()
try:
 pipe=pipeline(model,backend_config=cfg)
 save(side+'-initialized.json',{'elapsed_seconds':time.monotonic()-started,'type':str(type(pipe)),'async_engine_type':str(type(pipe.async_engine)),'async_get_logits_source':inspect.getsourcefile(pipe.async_engine.async_get_logits)})
 # Replay fixed prefixes through the engine's native full-forward score API.
 # Each request starts a fresh native session; this is repeated-prefill coverage.
 prefixes=[d['prompt']+d['continuation'][:i] for i in range(len(d['continuation']))]
 rows=[]
 for prefix in prefixes:
  result=pipe._run(coro=pipe.async_engine.async_get_logits(input_ids=[prefix])).result(timeout=60)
  native=result[0]
  save(side+f'-native-shape-{len(rows)}.json',{'shape':list(native.shape),'dtype':str(native.dtype),'device':str(native.device),'history':prefix})
  rows.append(native[-1,:49152].detach().cpu().clone())
 export(side,rows,d,{'native_entrypoint':'Pipeline._run(AsyncEngine.async_get_logits(input_ids=[fixed_prefix]))','mode':'separate full-prefix prefill requests, native cache only within each prefill','native_cache_replay':False,'raw_scores':'GenerationConfig(output_logits=all), before sampling','config':vars(cfg)})
 pipe.close()
 save(side+'-completion.json',{'status':'completed','elapsed_seconds':time.monotonic()-started,'captured_distributions':len(rows),'execution':'repeated-prefill'})
except Exception as e:
 save(side+'-failure.json',{'status':'execution_failed','type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'elapsed_seconds':time.monotonic()-started})
 raise
