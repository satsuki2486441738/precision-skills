#!/usr/bin/env bash
set -eu
RUN='<EVIDENCE_ROOT>'
RES=<RESOURCE_ROOT>/inference
ENV=<ENV_ROOT>/precision-inference-20261019
mkdir -p "$RES"
<HOME>/.local/bin/uv venv --python <ENV_ROOT>/precision-vllm011/bin/python "$ENV"
printf '%s\n' <ENV_ROOT>/precision-vllm011/lib/python3.11/site-packages > "$ENV/lib/python3.11/site-packages/precision-base.pth"
timeout 150 <HOME>/.local/bin/uv pip install --python "$ENV/bin/python" cmake ninja sentencepiece protobuf --no-deps > "$RUN/install-tools.log" 2>&1
timeout 180 git clone --depth 1 --branch b7000 https://github.com/ggml-org/llama.cpp.git "$RES/llama.cpp-b7000" > "$RUN/llama-clone.log" 2>&1
git -C "$RES/llama.cpp-b7000" rev-parse HEAD > "$RUN/llama-source-revision.txt"
"$ENV/bin/python" - <<'PY' > "$RUN/pypi-versions.json"
import json,urllib.request
d={}
for p in ['lmdeploy','tensorrt-llm','mindie-llm']:
 try:
  j=json.load(urllib.request.urlopen('https://pypi.org/pypi/'+p+'/json',timeout=20));d[p]={'version':j['info']['version'],'requires_dist':j['info']['requires_dist'],'files':[{k:f.get(k) for k in ['filename','size','url','digests']} for f in j['urls']]}
 except Exception as e:d[p]={'error':repr(e)}
print(json.dumps(d,indent=2))
PY
timeout 240 "$ENV/bin/cmake" -S "$RES/llama.cpp-b7000" -B "$RES/llama.cpp-b7000/build" -DGGML_CUDA=OFF -DLLAMA_CURL=OFF -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_TOOLS=OFF -DLLAMA_BUILD_EXAMPLES=OFF -DCMAKE_BUILD_TYPE=Release > "$RUN/llama-configure.log" 2>&1
timeout 480 "$ENV/bin/cmake" --build "$RES/llama.cpp-b7000/build" -j 8 > "$RUN/llama-build.log" 2>&1
echo native-library-build-complete
