import sys,json,pathlib,subprocess,platform
RUN=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(RUN))
from capture_compare import save,export_records,sha
SKILL=RUN.parent.parent/'skills/precision-skill/scripts'
from compare_target_scores import compare as compare_targets
from compare_distributions import compare as compare_distributions
from runtime_probe import inspect_runtime
import torch,transformers,numpy
d=json.loads((RUN/'inputs.json').read_text());ident=json.loads((RUN/'model-identity.json').read_text())
sides=['transformers-cpu-f32','llama-cpu-f32']
for s in ['lmdeploy-pytorch-neutral','lmdeploy-turbomind']:
 if (RUN/(s+'-records.json')).exists():sides.append(s)
if (RUN/'transformers-cuda-f16-records.json').exists():sides.append('transformers-cuda-f16')
common={'model':{'name':ident['model'],'revision':ident['revision'],'checkpoint_sha256':ident['files']['model.safetensors']['sha256'],'vocab_mapping':'original checkpoint tokenizer integer IDs 0..49151'},'inputs':{'prompt':d['prompt'],'continuation':d['continuation'],'bos_added':False,'attention_mask':'causal, all tokens valid','position_ids':'absolute contiguous from 0'},'scope':{'task':'fixed-history next-token scoring','sample':d['sample'],'targets':3,'vocab_size':49152,'before_processors':True}}
configs={
 'transformers-cpu-f32':{'numerics':{'weights':'FP32 from pretrained BF16 values','logits':'FP32','logsoftmax':'FP32','cache':'FP32'},'execution':{'framework':'transformers 4.57.1','hardware':'WSL x86_64 CPU','attention':'eager','tp':1,'cache_replay':True,'threads':4}},
 'llama-cpu-f32':{'numerics':{'weights':'FP32 GGUF, no quantization, converted from same checkpoint','logits':'FP32','logsoftmax':'FP32','cache':'FP32'},'execution':{'framework':'llama.cpp '+ident['llama_revision'],'hardware':'WSL x86_64 CPU','attention':'native CPU, flash disabled','tp':1,'cache_replay':True,'threads':4}}
}
configs['transformers-cuda-f16']={'numerics':{'weights':'FP16 from same pretrained BF16 checkpoint','logits':'FP16 converted to FP32 for logsoftmax','logsoftmax':'FP32','cache':'disabled'},'execution':{'framework':'transformers 4.57.1','hardware':'NVIDIA GeForce RTX 5060 8GB','attention':'eager','tf32':False,'tp':1,'cache_replay':False,'execution_mode':'three full prefixes with cache disabled'}}
for side in [s for s in sides if s.startswith('lmdeploy-')]:
 cfg=json.loads((RUN/(side+'-requested-settings.json')).read_text())
 configs[side]={'numerics':{'weights':'FP16 from same pretrained BF16 checkpoint','logits':'native FP16 converted to FP32 for logsoftmax','logsoftmax':'FP32','cache':'FP16'},'execution':{'framework':'LMDeploy 0.18.0 '+('pytorch' if 'pytorch' in side else 'turbomind'),'hardware':'NVIDIA GeForce RTX 5060 8GB','tp':1,'cache_replay':False,'execution_mode':'three fresh full-prefix requests','score_processors':'temperature=1 repetition=1 top_p=1 top_k=1' if side.endswith('neutral') else 'native TurboMind output_logits, unaffected by default sampling temperature','backend_settings':{k:v for k,v in cfg.items() if v is not None}}}
positions=[];targets=[]
for i,tok in enumerate(d['continuation']):
 positions.append({'sample':d['sample'],'position':len(d['prompt'])-1+i,'history':d['prompt']+d['continuation'][:i]})
 targets.append({'sample':d['sample'],'position':len(d['prompt'])+i,'token':tok})
contract={'schema_version':1,'kind':'distributions','thresholds':None,'common':common,'side_conditions':{s:configs[s] for s in sides},'expected_ranks':{s:[0] for s in sides},'positions':positions,'vocab_size':49152,'normalization_tolerance':1e-4,'renormalization':'full_vocabulary_fp64'}
tc={**contract,'kind':'target-scores','targets':targets};tc.pop('positions');tc.pop('vocab_size');tc.pop('normalization_tolerance');tc.pop('renormalization')
save('distribution-contract.json',contract);save('target-contract.json',tc)
for side in sides:
 records=json.loads((RUN/(side+'-records.json')).read_text());out=export_records(records,RUN)
 runtime=json.loads((RUN/('runtime-reference.json' if side=='transformers-cpu-f32' else side+'-runtime.json')).read_text()) if side!='llama-cpu-f32' else {'modules':{'llama.cpp':{'source':str((RUN/'source-path.txt').read_text()),'revision':ident['llama_revision'],'library':str(pathlib.Path((RUN/'source-path.txt').read_text())/'build/bin/libllama.so')}}}
 save(side+'-environment.json',{'rank':0,'versions':runtime,'actual':{**common,**configs[side]},'collected_evidence':json.loads((RUN/(side+'-history.json')).read_text())})
 save(side+'-rank-status.json',{'rank':0,'status':'completed','full_vocabulary_rows':len(records),'pretrained_checkpoint':True})
 base={'schema_version':1,'common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':side+'-environment.json','status':side+'-rank-status.json'}]}
 save(side+'-distribution.json',{**base,'kind':'distributions','positions':out['positions']})
 save(side+'-targets.json',{**base,'kind':'target-scores','scores':out['scores']})
summaries={}
for side in sides[1:]:
 a=RUN/'transformers-cpu-f32-distribution.json';b=RUN/(side+'-distribution.json')
 report=compare_distributions(RUN/'distribution-contract.json',a,b);save(side+'-distribution-comparison.json',report)
 tr=compare_targets(RUN/'target-contract.json',RUN/'transformers-cpu-f32-targets.json',RUN/(side+'-targets.json'));save(side+'-target-comparison.json',tr)
 summaries[side]={'distributions':report,'targets':tr}
if 'transformers-cuda-f16' in sides:
 for side in [s for s in sides if s.startswith('lmdeploy-')]:
  report=compare_distributions(RUN/'distribution-contract.json',RUN/'transformers-cuda-f16-distribution.json',RUN/(side+'-distribution.json'));save(side+'-vs-cuda-f16-distribution-comparison.json',report)
  tr=compare_targets(RUN/'target-contract.json',RUN/'transformers-cuda-f16-targets.json',RUN/(side+'-targets.json'));save(side+'-vs-cuda-f16-target-comparison.json',tr)
  summaries[side+'-vs-cuda-f16']={'distributions':report,'targets':tr}
save('metrics-summary.json',summaries)
breakdowns={}
for i in range(3):
 dc={**contract,'positions':[positions[i]]};sc={**tc,'targets':[targets[i]]}
 save(f'step{i}-distribution-contract.json',dc);save(f'step{i}-target-contract.json',sc)
 for side in sides:
  dm=json.loads((RUN/(side+'-distribution.json')).read_text());tm=json.loads((RUN/(side+'-targets.json')).read_text())
  save(f'{side}-step{i}-distribution.json',{**dm,'positions':[dm['positions'][i]]});save(f'{side}-step{i}-targets.json',{**tm,'scores':[tm['scores'][i]]})
 for ref in ['transformers-cpu-f32','transformers-cuda-f16']:
  if ref not in sides:continue
  for side in [s for s in sides if not s.startswith('transformers')]:
   key=side+'-vs-'+ref
   dr=compare_distributions(RUN/f'step{i}-distribution-contract.json',RUN/f'{ref}-step{i}-distribution.json',RUN/f'{side}-step{i}-distribution.json')
   sr=compare_targets(RUN/f'step{i}-target-contract.json',RUN/f'{ref}-step{i}-targets.json',RUN/f'{side}-step{i}-targets.json')
   breakdowns.setdefault(key,[]).append({'fixed_history_step':i,'history_length':len(d['prompt'])+i,'reference_native_stage':('prefill' if i==0 else 'decode') if ref=='transformers-cpu-f32' else 'full-forward-cache-disabled','side_native_stage':('prefill' if i==0 else 'decode') if side=='llama-cpu-f32' else 'prefill','distribution':dr,'target':sr})
save('stage-context-breakdowns.json',breakdowns)
print(json.dumps({s:{'distribution_status':v['distributions']['status'],'target_status':v['targets']['status'],'target_metrics':v['targets'].get('metrics')} for s,v in summaries.items()},indent=2))
