import sys,json,pathlib,subprocess,platform
RUN=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(RUN))
from capture_compare import save,export_records,sha
SKILL=RUN.parent.parent/'skills/precision-skill/scripts'
from compare_target_scores import compare as compare_targets
from compare_distributions import compare as compare_distributions
from runtime_probe import inspect_runtime
import torch,transformers,numpy
d=json.loads((RUN/'inputs.json').read_text());ident=json.loads((RUN/'model-identity.json').read_text())
sides=['transformers-cpu-f32','llama-cpu-f32']
for s in ['lmdeploy-pytorch','lmdeploy-turbomind']:
 if (RUN/(s+'-records.json')).exists():sides.append(s)
common={'model':{'name':ident['model'],'revision':ident['revision'],'checkpoint_sha256':ident['files']['model.safetensors']['sha256'],'vocab_mapping':'original checkpoint tokenizer integer IDs 0..49151'},'inputs':{'prompt':d['prompt'],'continuation':d['continuation'],'bos_added':False,'attention_mask':'causal, all tokens valid','position_ids':'absolute contiguous from 0'},'scope':{'task':'fixed-history next-token scoring','sample':d['sample'],'targets':3,'vocab_size':49152,'before_processors':True}}
configs={
 'transformers-cpu-f32':{'numerics':{'weights':'FP32 from pretrained BF16 values','logits':'FP32','logsoftmax':'FP32','cache':'FP32'},'execution':{'framework':'transformers 4.57.1','hardware':'WSL x86_64 CPU','attention':'eager','tp':1,'cache_replay':True,'threads':4}},
 'llama-cpu-f32':{'numerics':{'weights':'FP32 GGUF, no quantization, converted from same checkpoint','logits':'FP32','logsoftmax':'FP32','cache':'FP32'},'execution':{'framework':'llama.cpp '+ident['llama_revision'],'hardware':'WSL x86_64 CPU','attention':'native CPU, flash disabled','tp':1,'cache_replay':True,'threads':4}}
}
for side in sides[2:]:
 cfg=json.loads((RUN/(side+'-requested-settings.json')).read_text())
 configs[side]={'numerics':{'weights':'FP16 from same pretrained BF16 checkpoint','logits':'native FP16 converted to FP32 for logsoftmax','logsoftmax':'FP32','cache':'FP16'},'execution':{'framework':'LMDeploy 0.18.0 '+side.split('-')[-1],'hardware':'NVIDIA GeForce RTX 5060 8GB','tp':1,'cache_replay':False,'execution_mode':'three fresh full-prefix requests','backend_settings':{k:v for k,v in cfg.items() if v is not None}}}
positions=[];targets=[]
for i,tok in enumerate(d['continuation']):
 positions.append({'sample':d['sample'],'position':len(d['prompt'])-1+i,'history':d['prompt']+d['continuation'][:i]})
 targets.append({'sample':d['sample'],'position':len(d['prompt'])+i,'token':tok})
contract={'schema_version':1,'kind':'distributions','thresholds':None,'common':common,'side_conditions':{s:configs[s] for s in sides},'expected_ranks':{s:[0] for s in sides},'positions':positions,'vocab_size':49152,'normalization_tolerance':1e-5,'renormalization':'full_vocabulary_fp64'}
tc={**contract,'kind':'target-scores','targets':targets};tc.pop('positions');tc.pop('vocab_size');tc.pop('normalization_tolerance');tc.pop('renormalization')
save('distribution-contract.json',contract);save('target-contract.json',tc)
for side in sides:
 records=json.loads((RUN/(side+'-records.json')).read_text());out=export_records(records,RUN)
 runtime=json.loads((RUN/('runtime-reference.json' if side=='transformers-cpu-f32' else side+'-runtime.json')).read_text()) if side!='llama-cpu-f32' else {'modules':{'llama.cpp':{'source':str((RUN/'source-path.txt').read_text()),'revision':ident['llama_revision'],'library':str(pathlib.Path((RUN/'source-path.txt').read_text())/'build/bin/libllama.so')}}}
 save(side+'-environment.json',{'rank':0,'versions':runtime,'actual':{**common,**configs[side]},'collected_evidence':json.loads((RUN/(side+'-history.json')).read_text())})
 save(side+'-rank-status.json',{'rank':0,'status':'completed','full_vocabulary_rows':len(records),'pretrained_checkpoint':True})
 base={'schema_version':1,'common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':side+'-environment.json','status':side+'-rank-status.json'}]}
 save(side+'-distribution.json',{**base,'kind':'distributions','positions':out['positions']})
 save(side+'-targets.json',{**base,'kind':'target-scores','scores':out['scores']})
summaries={}
for side in sides[1:]:
 a=RUN/'transformers-cpu-f32-distribution.json';b=RUN/(side+'-distribution.json')
 report=compare_distributions(RUN/'distribution-contract.json',a,b);save(side+'-distribution-comparison.json',report)
 tr=compare_targets(RUN/'target-contract.json',RUN/'transformers-cpu-f32-targets.json',RUN/(side+'-targets.json'));save(side+'-target-comparison.json',tr)
 summaries[side]={'distributions':report,'targets':tr}
save('metrics-summary.json',summaries)
print(json.dumps({s:{'distribution_status':v['distributions']['status'],'target_status':v['targets']['status'],'target_metrics':v['targets'].get('metrics')} for s,v in summaries.items()},indent=2))
