import json,pathlib,sys,argparse,math
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from compare_distributions import compare as distribution_compare
from compare_target_scores import compare as target_compare
from validate_artifacts import validate
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args()
 out=pathlib.Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
 spec=json.loads((ROOT/'REPLAY.json').read_text());reports={};seen=set();validations={}
 for c in spec['cases']:
  dr=distribution_compare(ROOT/c['distribution_contract'],ROOT/c['side_a_distribution'],ROOT/c['side_b_distribution'])
  tr=target_compare(ROOT/c['target_contract'],ROOT/c['side_a_targets'],ROOT/c['side_b_targets'])
  if dr['status']!='no_thresholds' or tr['status']!='no_thresholds':raise RuntimeError((c['name'],dr,tr))
  reports[c['name']]={'distribution':dr,'target':tr}
  for key in ['side_a_distribution','side_b_distribution']:
   pair=(c['distribution_contract'],c[key])
   if pair in seen:continue
   seen.add(pair);v=validate(ROOT/pair[0],ROOT/pair[1])
   if v['status']!='validated':raise RuntimeError(v)
   validations[c[key]]=v
 diag=spec['diagnostic'];checks=[]
 for q,pth in zip(diag['processed_raw_rows'],diag['neutral_raw_rows']):
  processed=np.load(ROOT/q);neutral=np.load(ROOT/pth)
  predicted=(neutral.astype(np.float16)/np.float16(diag['temperature'])).astype(np.float16).astype(np.float32)
  checks.append(bool(np.array_equal(processed,predicted)))
 if not all(checks):raise RuntimeError('Default-temperature diagnostic no longer reproduces')
 result={'status':'completed','thresholds':None,'comparisons':reports,'validated_sides':validations,'temperature_diagnostic_exact_rows':checks,'scope':'Captured-array offline replay; no native framework/model execution.'}
 (out/'replay-results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'status':'completed','comparison_count':len(reports),'validated_sides':len(validations),'temperature_diagnostic_exact_rows':checks,'output':str(out)},indent=2))
if __name__=='__main__':main()
