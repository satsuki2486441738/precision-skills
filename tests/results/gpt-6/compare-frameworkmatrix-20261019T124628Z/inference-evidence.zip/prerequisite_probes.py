import pathlib,sys,json,subprocess,shutil,os,urllib.request,hashlib
RUN=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(RUN.parent.parent/'skills/precision-skill/scripts'))
from runtime_probe import probe_runtime
for name,imports,syms in [('lmdeploy',['torch','lmdeploy'],['lmdeploy:pipeline','lmdeploy:PytorchEngineConfig','lmdeploy:TurbomindEngineConfig']),('tensorrt-llm',['torch','tensorrt_llm'],['tensorrt_llm:LLM']),('mindie-llm',['torch','torch_npu','mindie_llm'],[])]:
 report=probe_runtime({'imports':imports,'symbols':syms,'distributions':[]},timeout=45)
 (RUN/(name+'-prerequisite-probe.json')).write_text(json.dumps(report,indent=2))
hardware={}
for cmd in [['nvidia-smi','--query-gpu=name,compute_cap,memory.total,driver_version','--format=csv,noheader'],['npu-smi','info'],['docker','version'],['nvcc','--version']]:
 try:
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=20);hardware[' '.join(cmd)]={'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
 except Exception as e:hardware[' '.join(cmd)]={'error':repr(e)}
hardware['ascend_devices']=[str(p) for p in pathlib.Path('/dev').glob('davinci*')]
hardware['ascend_install_paths']={p:os.path.exists(p) for p in ['/usr/local/Ascend','/usr/local/Ascend/ascend-toolkit','/usr/local/Ascend/mindie']}
(RUN/'hardware-prerequisites.json').write_text(json.dumps(hardware,indent=2))
docs=[('llama.cpp','ggml-org/llama.cpp',['include/llama.h','docs/build.md']),('lmdeploy','InternLM/lmdeploy',['lmdeploy/serve/core/async_engine.py','lmdeploy/messages.py','lmdeploy/pytorch/check_env/triton.py']),('tensorrt-llm','NVIDIA/TensorRT-LLM',['docs/source/supported-hardware.md','docs/source/installation/linux.md','docs/source/features/additional-outputs.md']),('mindie-llm','Ascend/MindIE-LLM',['docs/zh/user_guide/install/source/preparing_software_and_dependencies.md','docs/zh/user_guide/quick_start/quick_start.md'])]
out=[];dest=RUN/'official-source';dest.mkdir(exist_ok=True)
for name,repo,paths in docs:
 try:
  branch='master' if name in ['llama.cpp','mindie-llm'] else 'main'
  meta=json.load(urllib.request.urlopen(f'https://api.github.com/repos/{repo}/commits/{branch}',timeout=20));rev=meta['sha']
  for p in paths:
   u=f'https://raw.githubusercontent.com/{repo}/{rev}/{p}'
   try:
    data=urllib.request.urlopen(u,timeout=20).read();f=dest/(name+'--'+p.replace('/','__'));f.write_bytes(data);out.append({'framework':name,'repo':repo,'revision':rev,'path':p,'url':f'https://github.com/{repo}/blob/{rev}/{p}','local':str(f.relative_to(RUN)),'sha256':hashlib.sha256(data).hexdigest()})
   except Exception as e:out.append({'framework':name,'url':u,'error':repr(e)})
 except Exception as e:out.append({'framework':name,'repo':repo,'error':repr(e)})
(RUN/'official-source-index.json').write_text(json.dumps(out,indent=2))
meta={}
for package in ['lmdeploy','tensorrt-llm','mindie-llm']:
 try:
  j=json.load(urllib.request.urlopen('https://pypi.org/pypi/'+package+'/json',timeout=20));meta[package]={'version':j['info']['version'],'requires_dist':j['info']['requires_dist'],'files':[{'filename':f['filename'],'size':f['size'],'sha256':f['digests']['sha256']} for f in j['urls']]}
 except Exception as e:meta[package]={'error':repr(e)}
(RUN/'pypi-versions.json').write_text(json.dumps(meta,indent=2))
