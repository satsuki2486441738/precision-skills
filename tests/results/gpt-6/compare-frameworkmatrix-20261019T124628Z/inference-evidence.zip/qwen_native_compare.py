import sys,pathlib,json,subprocess,time,numpy as np
RUN=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(RUN))
import capture_compare as cap
from compare_distributions import compare as distcompare
from compare_target_scores import compare as targetcompare
resource=json.loads((RUN/'qwen-resource.json').read_text());MODEL=pathlib.Path(resource['path']);OUT=RUN/'qwen2.5-0.5b';OUT.mkdir(exist_ok=True)
cap.RUN=OUT;cap.MODEL=MODEL
def save(name,data):cap.save(name,data)
d=cap.inputs();cap.reference(d)
gguf=pathlib.Path('<RESOURCE_ROOT>/inference/Qwen2.5-0.5B-Instruct-f32.gguf')
cap.run([sys.executable,str(cap.SOURCE/'convert_hf_to_gguf.py'),str(MODEL),'--outfile',str(gguf),'--outtype','f32'],'gguf-convert',180)
cap.run([str(RUN/'native_llama_capture'),str(gguf),str(OUT/'tokens.txt'),str(OUT/'llama-raw.bin'),str(OUT/'llama-native-settings.json')],'llama-native-capture',180)
native=json.loads((OUT/'llama-native-settings.json').read_text());rows=np.fromfile(OUT/'llama-raw.bin',dtype=np.float32).reshape(native['rows'],native['vocab_size'])
cap.export('llama-cpu-f32',rows,d,native)
identity={'model':resource['repo'],'revision':resource['revision'],'initialization':'pretrained','files':{p.name:{'bytes':p.stat().st_size,'sha256':cap.sha(p)} for p in MODEL.iterdir() if p.is_file()},'gguf':{'path':str(gguf),'sha256':cap.sha(gguf)}};save('model-identity.json',identity)
sides=['transformers-cpu-f32','llama-cpu-f32']
common={'model':{'name':resource['repo'],'revision':resource['revision'],'checkpoint_sha256':identity['files']['model.safetensors']['sha256'],'vocab_mapping':'original checkpoint IDs'},'inputs':{'prompt':d['prompt'],'continuation':d['continuation'],'attention':'causal, all valid','positions':'absolute contiguous from zero'},'numerics':{'weights':'FP32 from same pretrained BF16 checkpoint, GGUF F32 unquantized on llama side','logits':'FP32','logsoftmax':'FP32','kv_cache':'FP32'},'scope':{'task':'cached fixed-history scoring','sample':d['sample'],'target_count':3}}
positions=[{'sample':d['sample'],'position':len(d['prompt'])-1+i,'history':d['prompt']+d['continuation'][:i]} for i in range(3)]
targets=[{'sample':d['sample'],'position':len(d['prompt'])+i,'token':t} for i,t in enumerate(d['continuation'])]
dc={'schema_version':1,'kind':'distributions','thresholds':None,'common':common,'expected_ranks':{s:[0] for s in sides},'positions':positions,'vocab_size':native['vocab_size'],'normalization_tolerance':1e-4,'renormalization':'full_vocabulary_fp64'}
tc={k:v for k,v in dc.items() if k not in ['positions','vocab_size','normalization_tolerance','renormalization']};tc.update(kind='target-scores',targets=targets)
save('distribution-contract.json',dc);save('target-contract.json',tc)
for side in sides:
 rec=json.loads((OUT/(side+'-records.json')).read_text());ex=cap.export_records(rec,OUT)
 evidence=json.loads((OUT/(side+'-history.json')).read_text())
 runtime=json.loads((RUN/'runtime-reference.json').read_text()) if side.startswith('transformers') else {'llama.cpp':{'revision':(RUN/'llama-source-revision.txt').read_text().strip(),'native_settings':native}}
 save(side+'-environment.json',{'rank':0,'versions':runtime,'actual':common,'native_evidence':evidence})
 save(side+'-status.json',{'rank':0,'status':'completed'})
 base={'schema_version':1,'common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':side+'-environment.json','status':side+'-status.json'}]}
 save(side+'-distribution.json',{**base,'kind':'distributions','positions':ex['positions']});save(side+'-targets.json',{**base,'kind':'target-scores','scores':ex['scores']})
dr=distcompare(OUT/'distribution-contract.json',OUT/'transformers-cpu-f32-distribution.json',OUT/'llama-cpu-f32-distribution.json');tr=targetcompare(OUT/'target-contract.json',OUT/'transformers-cpu-f32-targets.json',OUT/'llama-cpu-f32-targets.json')
save('distribution-comparison.json',dr);save('target-comparison.json',tr)
save('results.json',{'model':resource,'capture_status':'completed','distribution':dr,'targets':tr})
print(json.dumps({'distribution_status':dr['status'],'target_status':tr['status'],'targets':tr.get('metrics'),'distribution':dr.get('aggregate')},indent=2))
