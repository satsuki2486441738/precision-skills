import sys,pathlib,json,time
RUN=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(RUN))
from capture_compare import export,save,MODEL
from runtime_probe import inspect_runtime
import torch
from transformers import AutoModelForCausalLM
d=json.loads((RUN/'inputs.json').read_text())
torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
model=AutoModelForCausalLM.from_pretrained(MODEL,dtype=torch.float16,attn_implementation='eager',local_files_only=True).to('cuda').eval()
rows=[]
with torch.inference_mode():
 for i in range(len(d['continuation'])):
  ids=d['prompt']+d['continuation'][:i]
  out=model(input_ids=torch.tensor([ids],device='cuda'),position_ids=torch.arange(len(ids),device='cuda').unsqueeze(0),attention_mask=torch.ones((1,len(ids)),dtype=torch.long,device='cuda'),use_cache=False)
  rows.append(out.logits[0,-1].cpu().clone())
export('transformers-cuda-f16',rows,d,{'native_entrypoint':'LlamaForCausalLM.forward','native_cache_replay':False,'mode':'separate complete prefixes, use_cache=False','attention':'eager','tf32':False,'dtype':'float16','autocast':False,'eval':not model.training})
save('transformers-cuda-f16-runtime.json',inspect_runtime({'imports':['torch','transformers','numpy'],'distributions':['torch','transformers','numpy']}))
save('transformers-cuda-f16-completion.json',{'status':'completed','device':torch.cuda.get_device_name(),'maximum_cuda_memory_allocated':torch.cuda.max_memory_allocated(),'rows':len(rows)})
