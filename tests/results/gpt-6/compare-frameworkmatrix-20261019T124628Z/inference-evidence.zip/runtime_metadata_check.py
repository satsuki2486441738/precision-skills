import pathlib,importlib.metadata as m,json,sys
from packaging.requirements import Requirement
RUN=pathlib.Path(__file__).resolve().parent
out={'sys_path':sys.path,'packages':{},'note':'Unlike uv pip check, importlib metadata traverses the inherited .pth site-packages used by this interpreter.'}
for name in ['torch','transformers','lmdeploy','triton','numpy','tensorrt-llm','mindie-llm','torch-npu']:
 try:
  d=m.distribution(name);a={'version':d.version,'metadata_location':str(d.locate_file('')),'requires':[]}
  for text in d.requires or []:
   r=Requirement(text)
   if r.marker and not r.marker.evaluate():continue
   try:v=m.version(r.name);status='satisfied' if v in r.specifier else 'version_mismatch'
   except m.PackageNotFoundError:v=None;status='missing'
   a['requires'].append({'requirement':text,'installed':v,'status':status})
  out['packages'][name]=a
 except m.PackageNotFoundError:out['packages'][name]={'status':'missing'}
(RUN/'runtime-metadata-dependencies.json').write_text(json.dumps(out,indent=2))
print(json.dumps({n:[r for r in d.get('requires',[]) if r['status']!='satisfied'] for n,d in out['packages'].items()},indent=2))
