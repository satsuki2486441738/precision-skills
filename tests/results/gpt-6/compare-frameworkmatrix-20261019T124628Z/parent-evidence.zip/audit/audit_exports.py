"""Independent read-only public bundle audit; outputs only beside this script."""
import datetime,hashlib,json,os,pathlib,re,stat,subprocess,sys,time,traceback,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[1]
PUBLIC=REPO/'tests/results/gpt-6/compare-frameworkmatrix-20261019T124628Z'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def unwrap(x):
    if isinstance(x,dict):
        if 'value' in x and 'status' in x:return x['value']
        return {k:unwrap(v) for k,v in x.items()}
    if isinstance(x,list):return [unwrap(v) for v in x]
    return x
audit={'schema_version':1,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent public ZIP/metadata audit and captured-array inference replay only; no network or native model execution.','inputs_directory':str(PUBLIC),'output_directory':str(ROOT),'python':sys.executable,'archives':{},'coherence':{},'findings':[]}
input_hashes={p.name:sha(p.read_bytes()) for p in PUBLIC.iterdir() if p.name.endswith(('-evidence.zip','-results.json','-report.md'))}
bundles={};results={};reports={}
try:
    for family in ['inference','sft','rl']:
        path=PUBLIC/f'{family}-evidence.zip';raw=path.read_bytes();record={'outer_sha256':sha(raw),'outer_bytes':len(raw)}
        audit['archives'][family]=record
        results[family]=read(PUBLIC/f'{family}-results.json');reports[family]=(PUBLIC/f'{family}-report.md').read_text()
        with zipfile.ZipFile(path) as z:
            infos=z.infolist();names=[i.filename for i in infos]
            assert len(names)==len(set(names))==len(set(n.casefold() for n in names)),('duplicate member',family)
            for info in infos:
                n=info.filename;p=pathlib.PurePosixPath(n)
                assert n and not p.is_absolute() and not pathlib.PureWindowsPath(n).drive and '\\' not in n and '\x00' not in n and ':' not in n and '..' not in p.parts,('unsafe member',family,n)
                assert not stat.S_ISLNK(info.external_attr>>16),('symlink member',family,n)
                assert p.as_posix()==n.rstrip('/'),('noncanonical member',family,n)
            assert sum(i.file_size for i in infos)<512*1024*1024,('unexpected expansion',family)
            assert z.testzip() is None,('CRC error',family)
            files={i.filename:z.read(i) for i in infos if not i.is_dir()};bundles[family]=files
        export=json.loads(files['EXPORT.json'])
        rows=export.get('records') or export.get('files');indexed=[]
        for row in rows:
            member=row.get('archive_member') or row.get('export_relative_path') or row.get('archive_path')
            assert member in files,('missing indexed entry',family,member)
            assert len(files[member])==row['exported_bytes'],('byte length mismatch',family,member)
            assert sha(files[member])==row['exported_sha256'],('index digest mismatch',family,member)
            raw_digest=row.get('raw_sha256') or row.get('source_sha256')
            if raw_digest is None:
                assert row.get('source_relative_path') is None and any('generated' in s.lower() for s in row.get('transforms',[])),('missing non-generated original digest',family,member)
            else:assert isinstance(raw_digest,str) and re.fullmatch('[0-9a-f]{64}',raw_digest),('bad original digest record',family,member)
            indexed.append(member)
        assert len(indexed)==len(set(indexed)),('duplicate export index',family)
        generated=[]
        for row in export.get('generated_members',[]):
            member=row['archive_member'];assert sha(files[member])==row['sha256'] and len(files[member])==row['bytes'];generated.append(member)
        generated+=export.get('generated_files',[])
        assert all(m in files for m in generated),('missing generated member',family)
        unexplained=set(files)-set(indexed)-set(generated)-{'EXPORT.json'}
        assert not unexplained,('unexplained unindexed files',family,sorted(unexplained))
        external=[]
        for row in export.get('external_exports',[]):
            p=PUBLIC/row['path'];data=p.read_bytes();assert sha(data)==row['exported_sha256'] and len(data)==row['exported_bytes'];external.append(row['path'])
        claims=[]
        public_export=results[family].get('portable_export') or results[family].get('export') or {}
        expected=public_export.get('archive_sha256') or public_export.get('sha256')
        if expected:assert expected==record['outer_sha256'];claims.append('public results JSON')
        for value in re.findall(r'SHA256\s*[:` ]+([0-9a-f]{64})',reports[family],flags=re.I):
            assert value==record['outer_sha256'],('report archive digest differs',family,value);claims.append('public report')
        record.update(member_paths='safe canonical relative paths; no symlinks/case collisions',crc='all passed',members=len(files),expanded_bytes=sum(map(len,files.values())),export_schema_keys=list(export),indexed_exported_hashes_verified=len(indexed),generated_members=generated,generated_member_digest_coverage='SFT AUDIT.json has its own index hash; inference generated files are declared and covered by the published outer ZIP hash.',external_public_exports_verified=external,unindexed_members=['EXPORT.json'],outer_hash_claims_verified=claims,outer_hash_note='Measured and recorded independently; no separate published outer hash in RL bundle.' if not claims else 'Matches all published outer-hash claims.',raw_original_hashes='Recorded/format-checked; original private files are outside this public-only audit.')
    # SFT: selected reports rather than provisional superseded summary flags.
    sft=results['sft'];data=bundles['sft'];selection=json.loads(data['AUDIT.json'])['selected_case_mapping'];checks=[]
    assert len(sft['cases'])==len(selection)==6
    for c,m in zip(sft['cases'],selection):
        assert c['framework']==m['framework'] and c['architecture']==m['architecture']
        assert c['precision_acceptance'] is None and c['comparison_status']=='no_thresholds'
        assert c['valid_targets']==14 and c['active_eos_count']==2 and c['native_optimizer_steps']==1
        for member in m['comparison_reports']:assert json.loads(data[member])['status']=='no_thresholds'
        for member in m['validation_reports']:assert json.loads(data[member])['status']=='validated'
        base=m['comparison_member_prefix']
        sr=json.loads(data[base+'/scores-comparison.json']);gr=json.loads(data[base+'/gradients-comparison.json']);ur=json.loads(data[base+'/updates-comparison.json'])
        assert sr['metrics']==c['score_metrics'] and gr['global']==c['gradient_metrics'] and ur['global']==c['stored_update_metrics']
        assert gr['global']['count']==ur['global']['count']==c['elements']
        checks.append({'framework':c['framework'],'architecture':c['architecture'],'comparisons':len(m['comparison_reports']),'validations':len(m['validation_reports']),'elements':c['elements'],'status':'coherent'})
    assert 'CustomSeq2SeqTrainer' in reports['sft'] and 'not exercised' in reports['sft'] and 'archive alone does not reproduce native training' in reports['sft']
    audit['coherence']['sft']={'status':'coherent','selected_cases':checks,'comparison_reports':18,'validation_reports':24,'tensor_manifests':24,'scope':'Native fixed-token trainer components; full LLaMAFactory workflow not claimed; independent reference execution shares model/loss implementation; omitted arrays prevent full replay.'}
    # RL: check selected scalar/tensor metrics, coordinate inventory and stage claims.
    rl=results['rl'];data=bundles['rl'];checks=[]
    def rlmember(value):return 'evidence/'+value.removeprefix('$RL_RUN/')
    for c in rl['cases']:
        score_member=rlmember(c.get('score_report') or c['reports']['scores']);grad_member=rlmember(c['gradient_report'])
        sr=json.loads(data[score_member]);gr=json.loads(data[grad_member])
        assert sr['status']==gr['status']=='no_thresholds' and sr['metrics']==c['action_scores']
        assert unwrap(gr['global'])==c['gradients']
        assert sr['coverage']=={'expected':7,'paired':7} and gr['global']['count']==c['coverage']['parameter_elements']
        assert c['stages']['backward'] and not c['stages']['rollout'] and not c['stages'].get('native_trainer_step',False) and not c['stages'].get('native_training_step',False)
        prefix=score_member.rsplit('/',1)[0];trajectory=json.loads(data[prefix+'/trajectory.json']);expected={(f'trajectory-{b}',8+j,int(trajectory['input_ids'][b][8+j])) for b,row in enumerate(trajectory['action_mask']) for j,active in enumerate(row) if active}
        assert len(expected)==7 and sum(token==trajectory['eos_token_id'] for _,_,token in expected)==2
        sides=['ms-swift-native','torch-reference'] if c.get('framework')=='ms-swift' else ['openrlhf-native','torch-reference']
        for side in sides:
            rows=json.loads(data[prefix+'/'+side+'/scores.json'])['scores'];assert {(r['sample'],r['position'],r['token']) for r in rows}==expected
        updates=bool(c.get('updates'))
        if updates:
            ur=json.loads(data[rlmember(c['update_report'])]);assert ur['status']=='no_thresholds' and unwrap(ur['global'])==c['updates'] and c['stages']['explicit_torch_sgd_step']
        checks.append({'case':c['case'],'paired_actions':7,'gradient_elements':gr['global']['count'],'explicit_torch_sgd':updates,'status':'coherent'})
    assert len(checks)==3 and sum(c['explicit_torch_sgd'] for c in checks)==1
    assert 'No framework rollout or full training loop is claimed' in reports['rl'] and 'No train(), training_step(), rollout or optimizer' in reports['rl']
    audit['coherence']['rl']={'status':'coherent','cases':checks,'scope':'Native scoring/objective/backward components; only tiny OpenRLHF explicit Torch SGD; no framework training step, rollout or native optimizer claim.'}
    # Inference replay script was read before running; it imports only NumPy and bundled artifact tools.
    files=bundles['inference'];extract=ROOT/'inference-extracted';extract.mkdir(exist_ok=False)
    for member,raw in files.items():
        target=extract/member;assert target.resolve().is_relative_to(extract.resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    replay_output=ROOT/'inference-offline-replay'
    wrapper="import runpy,socket,sys; deny=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('network disabled for offline evidence audit')); socket.socket=deny; socket.create_connection=deny; socket.getaddrinfo=deny; sys.argv=[sys.argv[1], '--output', sys.argv[2]]; runpy.run_path(sys.argv[0],run_name='__main__')"
    command=[sys.executable,'-I','-c',wrapper,str(extract/'replay.py'),str(replay_output)]
    started=time.monotonic();p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180,cwd=extract,env={**os.environ,'CUDA_VISIBLE_DEVICES':'','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','PYTHONDONTWRITEBYTECODE':'1'})
    (ROOT/'inference-offline-replay.log').write_text(p.stdout)
    audit['inference_replay']={'command':command,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-started,'log':'inference-offline-replay.log','network':'socket operations denied; offline environment variables set','native_device_execution':'CUDA_VISIBLE_DEVICES empty; only bundled NumPy/artifact replay code executed'}
    assert p.returncode==0,p.stdout
    replay=read(replay_output/'replay-results.json');inf=results['inference'];assert len(replay['comparisons'])==len(inf['pairs'])==9
    exact=[]
    for pair in inf['pairs']:
        name=('qwen-' if pair['model'].startswith('Qwen') else 'smol-')+pair['pair'];observed=replay['comparisons'][name]
        assert observed['target']['metrics']==pair['target_metrics'],('target metrics differ',name)
        assert observed['target']['coverage']==pair['coverage'],('target coverage differs',name)
        assert observed['distribution']['aggregate']==pair['distribution_metrics'],('distribution metrics differ',name)
        exact.append(name)
    assert len(replay['validated_sides'])==inf['validation']['side_manifests']==9
    assert all(v['status']=='validated' for v in replay['validated_sides'].values())
    assert replay['temperature_diagnostic_exact_rows']==[True,True,True]
    for name,framework in inf['frameworks'].items():
        if name.startswith('LMDeploy'):assert framework['cached_decode_coverage']==0
    assert 'Their cached-decode coverage is 0' in reports['inference'] and 'only captured-array offline replay is promised' in reports['inference']
    audit['inference_replay'].update(status='completed',comparison_pairs=len(exact),comparison_metric_groups=18,validated_side_manifests=9,temperature_diagnostic_exact_rows=replay['temperature_diagnostic_exact_rows'],metrics_exactly_equal_public_results=True,case_names=exact,output='inference-offline-replay/replay-results.json',output_sha256=sha((replay_output/'replay-results.json').read_bytes()))
    audit['coherence']['inference']={'status':'coherent','pairs':9,'primary_native_captures':6,'primary_targets':18,'scope':'Two pretrained models; llama native cached boundaries; LMDeploy repeated prefill only; exploratory dependencies stated; unavailable engines have zero native coverage; replay does not rerun models.'}
    assert input_hashes=={name:sha((PUBLIC/name).read_bytes()) for name in input_hashes},'Public inputs changed during audit'
    audit['public_inputs_unchanged']=True;audit['status']='validated';audit['findings']=[]
except Exception as exc:
    audit['status']='failed';audit['findings'].append({'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
finally:
    audit['public_input_sha256']=input_hashes;audit['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(ROOT/'audit.json',audit)
    lines=[f"Independent evidence export audit: {audit['status']}.",'']
    for family,row in audit['archives'].items():lines.append(f"- {family}: SHA256 {row['outer_sha256']}; {row['outer_bytes']:,} ZIP bytes; {row.get('members','?')} members; {row.get('indexed_exported_hashes_verified','?')} indexed file hashes verified. Paths and CRCs: {row.get('crc','not completed')}.")
    lines+=['','Inference bundled offline replay ran in a fresh extraction/output directory with network socket operations denied and CUDA hidden. Native model/framework execution was not run.']
    if audit.get('inference_replay',{}).get('status')=='completed':lines.append('All 9 comparison pairs (18 target/distribution metric groups), 9 side validations and 3 temperature-diagnostic rows reproduce; metrics and coverage exactly match the public results JSON.')
    lines+=['','SFT and RL selected metadata/report scope was checked for stage counts, full-parameter coverage and stable target coordinates. Their omitted training arrays prevent full tensor replay; SFT component scope and RL no-rollout/no-native-trainer-step limits are explicit. Raw-original hashes are provenance records; this public-only audit validates exported bytes, not inaccessible private originals.','',f"Findings: {json.dumps(audit['findings'],ensure_ascii=False)}",'', 'Public files were not modified. See audit.json and inference-offline-replay/replay-results.json.']
    (ROOT/'report.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'status':audit['status'],'audit':str(ROOT/'audit.json'),'report':str(ROOT/'report.md'),'findings':audit['findings']},indent=2))
    if audit['status']!='validated':sys.exit(1)
