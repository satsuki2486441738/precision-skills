Independent evidence export audit: validated.

- inference: SHA256 96b9cf9f1be4584ce0ba41279aa8ffeca2434b6697db6907b0383d4af2e7e166; 7,594,354 ZIP bytes; 424 members; 419 indexed file hashes verified. Paths and CRCs: all passed.
- sft: SHA256 3fea576e14d1c76863767512dee4f7918e44c75941c3a666fa34cf64c4eabde5; 1,030,474 ZIP bytes; 384 members; 382 indexed file hashes verified. Paths and CRCs: all passed.
- rl: SHA256 356620f059c9c97e2c0329e08011de87d972c290b080be4b2714bccffabda6be; 523,341 ZIP bytes; 419 members; 418 indexed file hashes verified. Paths and CRCs: all passed.

Inference bundled offline replay ran in a fresh extraction/output directory with network socket operations denied and CUDA hidden. Native model/framework execution was not run.
All 9 comparison pairs (18 target/distribution metric groups), 9 side validations and 3 temperature-diagnostic rows reproduce; metrics and coverage exactly match the public results JSON.

SFT and RL selected metadata/report scope was checked for stage counts, full-parameter coverage and stable target coordinates. Their omitted training arrays prevent full tensor replay; SFT component scope and RL no-rollout/no-native-trainer-step limits are explicit. Raw-original hashes are provenance records; this public-only audit validates exported bytes, not inaccessible private originals.

Findings: []

Public files were not modified. See audit.json and inference-offline-replay/replay-results.json.
