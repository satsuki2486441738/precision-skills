Parent consolidation evidence. Audit/validation source is archival and has placeholder paths and identity-check strings.
The status regression is synthetic launcher-only coverage, not native training.
Remote observations are manually transcribed from visible console output; raw remote JSON remains on AFS.
Screenshots, host/account identifiers, weights and raw training arrays are excluded.
