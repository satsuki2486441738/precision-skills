"""Synthetic launcher-status regression only; never runs Torch or a GPU worker."""
import argparse, contextlib, importlib.util, io, json, pathlib, tempfile, types
from unittest.mock import patch

def check(source):
    spec = importlib.util.spec_from_file_location('probe_under_test', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    results = []
    scenarios = [('complete', 0, 0), ('nccl_only', 0, 1),
                 ('failed_rank_nested_completed', 1, 1), ('missing_rank', 1, 1)]
    for scenario, worker_code, expected_exit in scenarios:
        with tempfile.TemporaryDirectory() as directory:
            class Process:
                def __init__(self, command, **kwargs):
                    run = pathlib.Path(kwargs['cwd'])
                    for rank in range(4):
                        if scenario == 'missing_rank' and rank == 3:
                            continue
                        state = dict(rank=rank, status='completed', nccl=dict(status='completed'),
                                     sft=dict(status='completed', gradient=dict(sha256='same'),
                                              after_parameters_sha256='same'))
                        if scenario == 'nccl_only':
                            state.update(status='completed_nccl_only', sft=dict(status='unavailable'))
                        elif scenario == 'failed_rank_nested_completed' and rank == 3:
                            state.update(status='failed', error='post-training assertion failed')
                        module.dump(run / f'rank-{rank}.json', state)
                def wait(self, timeout=None):
                    return worker_code
            with patch.object(module.subprocess, 'Popen', Process), contextlib.redirect_stdout(io.StringIO()):
                code = module.launch(types.SimpleNamespace(output_dir=directory))
            summary = json.loads(next(pathlib.Path(directory).glob('*/summary.json')).read_text())
            expected_sft = scenario == 'complete'
            results.append(dict(scenario=scenario, exit_code=code, expected_exit=expected_exit,
                                native_sft=summary['native_sft_trainer_completed'],
                                expected_native_sft=expected_sft,
                                passed=code == expected_exit and summary['native_sft_trainer_completed'] == expected_sft))
    return results

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=pathlib.Path)
    args = parser.parse_args()
    results = check(args.source)
    print(json.dumps(dict(scope=__doc__, results=results), indent=2))
    raise SystemExit(0 if all(case['passed'] for case in results) else 1)
