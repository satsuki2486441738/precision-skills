"""Check local documentation links and the new published result inventories."""
import argparse, ast, datetime, hashlib, json, pathlib, re, urllib.parse, zipfile

root = pathlib.Path(__file__).resolve().parents[2]
main = root / 'tests/results/gpt-6/compare-frameworkmatrix-20261019T124628Z'
luna = root / 'tests/results/gpt-6-luna/compare-luna-native-20261019T140106Z'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--defer-parent-archive', action='store_true')
parser.add_argument('--output', type=pathlib.Path, required=True)
args = parser.parse_args()
errors = []; deferred = []; links = 0
docs = [root / 'README.md', root / 'README.zh-CN.md', *sorted((root/'skills/precision-skill').rglob('*.md')),
        *sorted((root/'tests/results').rglob('*.md'))]

def anchors(path):
    text = path.read_text(encoding='utf-8-sig')
    headings = re.findall(r'^#{1,6}\s+(.+?)\s*#*$', text, re.M)
    result = set(re.findall(r'<a\s+(?:name|id)=[\'\"]([^\'\"]+)', text))
    counts = {}
    for heading in headings:
        slug = re.sub(r'[^\w\-\s]', '', heading.lower()).replace(' ', '-')
        count = counts.get(slug, 0); counts[slug] = count + 1
        result.add(slug + ('-' + str(count) if count else ''))
    return result

for doc in docs:
    text = re.sub(r'```.*?```', '', doc.read_text(encoding='utf-8-sig'), flags=re.S)
    for target in re.findall(r'\[[^\]]*\]\(([^)\s]+)(?:\s+"[^"]*")?\)', text):
        target = target.strip('<>'); parsed = urllib.parse.urlsplit(target)
        if parsed.scheme or parsed.netloc: continue
        links += 1
        dest = (doc.parent / urllib.parse.unquote(parsed.path)).resolve() if parsed.path else doc
        if not dest.exists():
            if args.defer_parent_archive and dest == main/'parent-evidence.zip':
                deferred.append(target); continue
            errors.append(dict(source=str(doc.relative_to(root)), target=target, issue='missing file')); continue
        if parsed.fragment and dest.suffix.lower() == '.md' and urllib.parse.unquote(parsed.fragment) not in anchors(dest):
            errors.append(dict(source=str(doc.relative_to(root)), target=target, issue='missing anchor'))

d = json.loads((main/'results.json').read_text(encoding='utf8'))
assert len(d['lanes']) == 17
assert len(set(item['library'] for item in d['lanes'])) == 16
assert sum(item['status'] != 'prerequisite_blocked' for item in d['lanes']) == 7
assert sum(item['primary_cases'] for item in d['lanes']) == len(d['primary_local_native_cases']) == 15
for file in [*main.glob('*.json'), *luna.glob('*.json')]:
    json.loads(file.read_text(encoding='utf-8-sig'))
ast.parse((main/'remote_four_gpu_probe.py').read_text(encoding='utf8'))
expected = {
    main/'sft-evidence.zip': '3fea576e14d1c76863767512dee4f7918e44c75941c3a666fa34cf64c4eabde5',
    main/'inference-evidence.zip': '96b9cf9f1be4584ce0ba41279aa8ffeca2434b6697db6907b0383d4af2e7e166',
    main/'rl-evidence.zip': '356620f059c9c97e2c0329e08011de87d972c290b080be4b2714bccffabda6be',
    luna/'evidence.zip': '49d433192e2a94ec09b5d1e6301d41aca384499c72a03ca2e418dfbcd7b6367c',
}
archives = {}
for file, digest in expected.items():
    assert hashlib.sha256(file.read_bytes()).hexdigest() == digest
    with zipfile.ZipFile(file) as archive:
        assert archive.testzip() is None
        names = archive.namelist(); assert len(names) == len(set(names))
        for name in names:
            path = pathlib.PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
    archives[file.relative_to(root).as_posix()] = dict(sha256=digest, bytes=file.stat().st_size, members=len(names))
for folder in [main, luna]:
    for file in folder.iterdir():
        if file.suffix not in ['.md', '.json', '.py']: continue
        text = file.read_text(encoding='utf-8-sig')
        assert '<USER_ID>' not in text and '<SUBSCRIPTION_PREFIX>' not in text and '<INSTANCE_PREFIX>' not in text, file
result = dict(schema_version=1, recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              status='passed' if not errors else 'failed', local_markdown_files=len(docs),
              local_links_checked=links, errors=errors, deferred_parent_archive_links=deferred,
              coverage_counts='17 lanes,16 libraries,7 native lanes,15 primary local cases',
              skill_metadata='quick_validate.py passed in WSL', new_probe_syntax='passed',
              archives=archives, public_direct_file_privacy='passed')
args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
raise SystemExit(bool(errors))
