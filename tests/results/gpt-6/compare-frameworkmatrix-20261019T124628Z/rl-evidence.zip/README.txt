RL evidence export

The native measurements, per-tensor comparison reports, coverage, source pins, logs, and redacted collectors/verifier are included. NPY arrays, model weights, caches, and large shards are omitted. Consequently this archive is not a full gradient replay archive. Redacted collector source requires path rebinding and the original runtime/checkpoints/arrays for execution. Run python verify_export.py rl-evidence.zip to validate exported member hashes. Source hashes document provenance; original source bytes remain in the private run.
