"""Execute fresh-interpreter framework probes and bounded private dependency installs."""
import json, os, pathlib, subprocess, sys
from prepare import RUN, ROOT, ENV, SOURCES, command

PY = str(ENV / 'bin/python')
UV = '$WSL_HOME/.local/bin/uv'
SELECTED = {
    'openrlhf': ('openrlhf_v090', ['torch', 'transformers', 'openrlhf.models'], ['openrlhf.models:Actor', 'openrlhf.models:PolicyLoss'], 'openrlhf.cli.train_ppo_ray'),
    'slime': ('slime_retry', ['torch', 'slime.backends.megatron_utils.loss'], [], 'train.py'),
    'nemo_rl': ('nemo_rl', ['torch', 'nemo_rl.algorithms.grpo'], [], 'examples/run_grpo.py'),
    'ms_swift': ('ms_swift', ['torch', 'swift.rlhf_trainers.grpo_trainer'], ['swift.rlhf_trainers.grpo_trainer:GRPOTrainer'], 'swift.cli.rlhf'),
    'areal': ('areal', ['torch', 'areal'], ['areal:PPOTrainer'], 'examples/r3/gsm8k_rlvr.py'),
    'roll': ('roll', ['torch', 'roll.pipeline.rlvr.rlvr_pipeline'], [], 'examples/start_rlvr_pipeline.py'),
    'mindspeed_rl': ('mindspeed_rl', ['torch', 'mindspeed_rl.trainer.grpo_trainer_hybrid'], [], 'cli/train_grpo.py'),
}

def probes(label, entrypoints=False):
    results = []
    for name, (directory, imports, symbols, entry) in SELECTED.items():
        source = SOURCES / directory
        spec = dict(imports=imports, symbols=symbols, distributions=['torch', 'transformers', name.replace('_', '-')], python_paths=[str(source)])
        specpath = RUN / f'{label}_{name}.spec.json'
        specpath.write_text(json.dumps(spec, indent=2))
        rec, out = command(f'{label}_{name}_runtime', [PY, str(ROOT / 'skills/precision-skill/scripts/runtime_probe.py'), '--spec', str(specpath), '--output', str(RUN / f'{label}_{name}_runtime.json'), '--python', PY, '--timeout', '50'], timeout=65)
        result = dict(framework=name, runtime=rec)
        if entrypoints:
            env = dict(os.environ, PYTHONPATH=str(source), CUDA_VISIBLE_DEVICES='', TOKENIZERS_PARALLELISM='false')
            args = [PY, '-m', entry, '--help'] if not entry.endswith('.py') else [PY, str(source / entry), '--help']
            result['entrypoint'], _ = command(f'{label}_{name}_entrypoint', args, cwd=source, timeout=50, env=env)
        results.append(result)
    (RUN / f'{label}_probe_commands.json').write_text(json.dumps(results, indent=2))

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'initial':
        pins = json.loads((RUN / 'source_pins.json').read_text())
        for name, (directory, *_rest) in SELECTED.items():
            source = SOURCES / directory
            sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
            pins.append(dict(name=name + '_selected', source=str(source), sha=sha,
                             official_repository=subprocess.check_output(['git','config','--get','remote.origin.url'],cwd=source,text=True).strip()))
        (RUN / 'selected_source_pins.json').write_text(json.dumps(pins, indent=2))
        probes('initial', entrypoints=True)
    elif action == 'install':
        env = dict(os.environ, DS_BUILD_OPS='0', MAX_JOBS='2')
        packages = ['transformers==4.57.0', 'accelerate==1.10.1', 'peft==0.17.1', 'deepspeed==0.18.1',
                    'hjson==3.1.0', 'nvidia-ml-py==13.580.82', 'optree==0.17.0', 'py-cpuinfo==9.0.0',
                    'datasets==4.4.1', 'pandas==2.3.3', 'pyarrow==22.0.0', 'multiprocess==0.70.18',
                    'hydra-core==1.3.2', 'omegaconf==2.3.0', 'antlr4-python3-runtime==4.9.3',
                    'dacite==1.9.2', 'jsonlines==4.0.0', 'orjson==3.11.4', 'loralib==0.1.2', 'torchdata==0.11.0',
                    'wandb==0.23.0', 'tensorboard==2.20.0', 'modelscope==1.31.0', 'trl==0.25.1']
        rec, out = command('install_native_prerequisites', [UV, 'pip', 'install', '--python', PY, '--no-deps', '--no-build-isolation'] + packages, timeout=300, env=env)
        print(json.dumps(rec)); print(out[-3000:])
        wheel = 'https://github.com/Dao-AILab/flash-attention/releases/download/v2.8.3/flash_attn-2.8.3%2Bcu12torch2.8cxx11abiTRUE-cp311-cp311-linux_x86_64.whl'
        rec, out = command('install_official_flashattention', [UV, 'pip', 'install', '--python', PY, '--no-deps', wheel], timeout=240, env=env)
        print(json.dumps(rec)); print(out[-3000:])
    elif action == 'after':
        probes('after_install', entrypoints=True)
    elif action == 'repair_install':
        # CPU is a real supported DeepSpeed accelerator; no native operators are replaced.
        env = dict(os.environ, DS_BUILD_OPS='0', DS_ACCELERATOR='cpu', MAX_JOBS='2')
        packages = ['transformers==4.57.0', 'accelerate==1.10.1', 'peft==0.17.1', 'deepspeed==0.18.1',
                    'hjson==3.1.0', 'nvidia-ml-py==13.580.82', 'optree==0.17.0', 'py-cpuinfo==9.0.0',
                    'datasets==4.4.1', 'pandas==2.3.3', 'pyarrow==22.0.0', 'multiprocess==0.70.18',
                    'hydra-core==1.3.2', 'omegaconf==2.3.0', 'antlr4-python3-runtime==4.9.3',
                    'dacite==1.9.2', 'jsonlines==4.0.0', 'orjson==3.11.4', 'loralib==0.1.2', 'torchdata==0.11.0',
                    'wandb==0.23.0', 'tensorboard==2.20.0', 'modelscope==1.31.0', 'trl==0.25.1']
        rec, out = command('repair_install_cpu_deepspeed', [UV, 'pip', 'install', '--python', PY, '--no-deps', '--no-build-isolation'] + packages, timeout=300, env=env)
        print(json.dumps(rec)); print(out[-3500:])
