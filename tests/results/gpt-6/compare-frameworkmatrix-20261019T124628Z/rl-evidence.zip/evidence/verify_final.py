"""Verify final evidence coverage without running or reading repository tests."""
import json,pathlib
RUN=pathlib.Path(__file__).resolve().parent
def read(path):return json.loads(path.read_text())
result=read(RUN/'results.json')
assert len(result['frameworks'])==7
assert {x['framework'] for x in result['frameworks']}=={'openrlhf','slime','nemo_rl','ms_swift','areal','roll','mindspeed_rl'}
assert read(RUN/'post_native_runtime.json')['status']=='completed'
checks=[]
for case in result['cases']:
    assert case['score_status']=='no_thresholds'
    assert case['gradient_status']=='no_thresholds'
    assert case['action_scores']['target_count']==7
    assert case['gradients']['count']==case['coverage']['parameter_elements']
    assert case['stages']['backward']
    assert not case['stages'].get('rollout')
    scorepath=pathlib.Path(case.get('score_report') or case['reports']['scores'])
    gradpath=pathlib.Path(case['gradient_report'])
    assert read(scorepath)['thresholds'] is None and read(gradpath)['thresholds'] is None
    if case.get('updates'):assert case['updates']['count']==22816 and case['update_status']=='no_thresholds'
    checks.append(dict(case=case['case'],paired_actions=7,gradient_elements=case['gradients']['count'],status='validated'))
trajectory=read(RUN/'ms_swift_smollm2_complete_group/trajectory.json')
assert trajectory['input_ids'][0][:8]==trajectory['input_ids'][1][:8]
assert trajectory['group_ids']==['group-0','group-0']
assert trajectory['input_ids'][0][8:]!=trajectory['input_ids'][1][8:]
assert sum(sum(x) for x in trajectory['action_mask'])==7
validation=dict(status='validated',case_checks=checks,complete_grpo_group=True,
    full_framework_trainer_step_claimed=False,repository_tests_read=False)
(RUN/'final_validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps(validation,indent=2))
