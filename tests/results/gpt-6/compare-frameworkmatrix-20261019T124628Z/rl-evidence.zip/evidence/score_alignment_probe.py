"""Localize native Swift score differences by matching retained LM-head rows."""
import json,pathlib,sys,torch
RUN=pathlib.Path(__file__).resolve().parent
ROOT=RUN.parent.parent
sys.path[:0]=['$FRAMEWORK_SOURCES/ms_swift']
from transformers import AutoModelForCausalLM
from swift.model import get_model_processor
from native_openrlhf import PRETRAINED,fixed_inputs,write,state_hash

torch.set_num_threads(4)
folder=RUN/'ms_swift_smollm2_trl026'
native_rows=json.loads((folder/'ms-swift-native/scores.json').read_text())['scores']
tokens,attention,mask,*_=fixed_inputs('cpu')
positions=attention.long().cumsum(-1)-1;positions.masked_fill_(attention==0,1)
model=AutoModelForCausalLM.from_pretrained(str(PRETRAINED),torch_dtype=torch.float32,attn_implementation='eager',local_files_only=True).eval()
result=dict(device='cpu',dtype='float32',initial_parameters_sha256=state_hash(model),
            interpretation='Reference-only localization; no new native trainer execution or gradient capture.')
with torch.no_grad():
    for keep in [0,5]:
        logits=model(tokens,attention_mask=attention,position_ids=positions,logits_to_keep=keep,use_cache=False).logits
        logits=logits[:,-5:-1]
        scores=logits.log_softmax(-1).gather(-1,tokens[:,-4:,None]).squeeze(-1)
        errors=[abs(float(scores[int(r['sample'].split('-')[-1]),r['position']-8])-r['logprob']) for r in native_rows]
        result[str(keep)]=dict(logits_to_keep=keep,mae=sum(errors)/len(errors),maximum=max(errors),paired=len(errors))
write(RUN/'swift_score_alignment_probe.json',result)
print(json.dumps(result,indent=2))
