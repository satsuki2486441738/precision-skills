"""Fresh-interpreter interface checks after isolated dependency alignment."""
import dataclasses, json, pathlib

def check_swift_config():
    from swift.rlhf_trainers import GRPOConfig, GRPOTrainer
    args=GRPOConfig(output_dir=str(pathlib.Path(__file__).parent/'swift_config_probe'),
                    per_device_train_batch_size=2,num_generations=2,use_cpu=True,
                    bf16=False,fp16=False,beta=0.,report_to=[],check_model=False,
                    temperature=1.,loss_type='grpo',use_vllm=False)
    return dict(class_name=GRPOTrainer.__module__+'.'+GRPOTrainer.__name__,
                config_constructed=True,device=str(args.device),loss_type=args.loss_type,
                temperature=args.temperature,use_vllm=args.use_vllm)

def check_openrlhf_interfaces():
    from openrlhf.models import Actor,PolicyLoss
    return dict(actor=Actor.__module__+'.'+Actor.__name__,loss=PolicyLoss.__module__+'.'+PolicyLoss.__name__)
