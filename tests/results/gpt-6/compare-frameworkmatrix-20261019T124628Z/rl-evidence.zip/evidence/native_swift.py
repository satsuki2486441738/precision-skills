"""Instantiate the real ms-swift GRPOTrainer and replay its prepared fixed-batch loss.

Executes native model loader, trainer constructor, action scoring, compute_loss,
and backward. It does not call train(), training_step(), rollout, or an optimizer.
"""
import gc, importlib, json, pathlib, sys, time
import numpy as np
import torch
RUN=pathlib.Path(__file__).resolve().parent
ROOT=RUN.parent.parent
SOURCE=pathlib.Path('$FRAMEWORK_SOURCES/ms_swift')
sys.path[:0]=[str(SOURCE),str(ROOT/'skills/precision-skill/scripts')]
from swift.model import get_model_processor
from swift.template import get_template
from swift.rlhf_trainers import GRPOConfig, GRPOTrainer
from swift.rl_core.data import GRPOBatch
from datasets import Dataset
from transformers import AutoModelForCausalLM
from native_openrlhf import PRETRAINED, fixed_inputs, state_hash, digest, write
from compare_target_scores import compare as compare_scores
from compare_tensors import compare as compare_tensors
from validate_artifacts import validate

def reward(completions,**kwargs):return [float(i%2) for i in range(len(completions))]

if __name__=='__main__':
    torch.set_num_threads(4);torch.manual_seed(20261019)
    folder=RUN/(sys.argv[1] if len(sys.argv)>1 else 'ms_swift_smollm2_pretrained');folder.mkdir(exist_ok=False)
    started=time.time()
    model,processor=get_model_processor(str(PRETRAINED),model_type='llama',torch_dtype=torch.float32,
        device_map='cpu',attn_impl='eager',use_hf=True,download_model=False)
    template=get_template(processor,template_type='chatml',max_length=64,truncation_strategy='right',padding_free=False)
    args=GRPOConfig(output_dir=str(folder/'trainer_output'),max_steps=1,
        per_device_train_batch_size=2,per_device_eval_batch_size=2,gradient_accumulation_steps=1,
        num_generations=2,num_iterations=1,steps_per_generation=1,learning_rate=.001,
        temperature=1.,beta=0.,epsilon=.2,epsilon_high=.2,loss_type='grpo',importance_sampling_level='token',
        use_cpu=True,bf16=False,fp16=False,gradient_checkpointing=False,report_to=[],save_strategy='no',
        eval_strategy='no',check_model=False,disable_dropout=True,max_completion_length=4,
        use_vllm=False,log_entropy=False,overlong_filter=False,seed=20261019,remove_unused_columns=False)
    dataset=Dataset.from_list([{'messages':[{'role':'user','content':'Compute one plus one.'}]}]*2)
    trainer=GRPOTrainer(model=model,args=args,template=template,train_dataset=dataset,reward_funcs=[reward])
    print('REAL_GRPO_TRAINER_INITIALIZED',flush=True)
    model=trainer.model;model.train()
    initial=state_hash(model)
    tokens,attention,mask,_,desired_ratios=fixed_inputs('cpu')
    # A complete GRPO group has the same prompt and two distinct completions.
    tokens[1,:8]=tokens[0,:8]
    advantages=torch.tensor([[1.,1.,1.,1.],[-1.,-1.,-1.,0.]])
    positions=attention.long().cumsum(-1)-1;positions.masked_fill_(attention==0,1)
    inputs=dict(input_ids=tokens,attention_mask=attention,position_ids=positions)
    batch=GRPOBatch(completion_mask=mask,truncated_mask=torch.tensor([False,False]),
        seq_lengths=attention.sum(-1),advantages=advantages,logits_to_keep=4)
    with torch.no_grad():anchors,_=trainer._get_per_token_logps_and_entropies(model,dict(inputs),batch)
    old=(anchors-desired_ratios.log()).detach();batch.old_per_token_logps=old
    write(folder/'trajectory.json',dict(input_ids=tokens.tolist(),attention_mask=attention.tolist(),
        action_mask=mask.tolist(),action_target_positions=[8,9,10,11],group_ids=['group-0','group-0'],
        group_size=2,advantages=advantages.tolist(),advantages_origin='injected fixed per-token expansion of per-sequence +1/-1; native reward/group normalization not executed',
        old_logprobs=old.tolist(),old_scores_origin='injected initial native scores minus prescribed log-ratio',
        rewards=None,reference_logprobs=None,values=None,returns=None,policy_version=0,
        eos_token_id=2,valid_eos_actions=2,truncated_mask=[False,False]))
    common=dict(model=dict(name='SmolLM2-135M-Instruct',checkpoint=str(PRETRAINED),
                model_sha256=digest(PRETRAINED/'model.safetensors'),config_sha256=digest(PRETRAINED/'config.json')),
        inputs=dict(trajectory_sha256=digest(folder/'trajectory.json')),
        numerics=dict(device='cpu',dtype='float32',attention='eager',temperature=1.,dropout=False,torch_threads=4),
        scope='native initialized ms-swift GRPOTrainer fixed-batch compute_loss and full-parameter backward',
        state=dict(initial_parameters_sha256=initial,optimizer='not executed',clipping='disabled',gradient_accumulation=1,optimizer_step=0))
    targets=[dict(sample=f'trajectory-{b}',position=8+j,token=int(tokens[b,8+j])) for b in range(2) for j in range(4) if mask[b,j]]
    sides=['ms-swift-native','torch-reference']
    inventory=[dict(name=n,shape=list(p.shape),present=True) for n,p in model.named_parameters() if p.requires_grad]
    gcpath=write(folder/'gradient_contract.json',dict(schema_version=2,kind='tensors',common=common,thresholds=None,
        expected_ranks={s:[0] for s in sides},stage='gradients',tensors=inventory))
    scpath=write(folder/'score_contract.json',dict(schema_version=1,kind='target-scores',common={k:v for k,v in common.items() if k!='state'},thresholds=None,
        expected_ranks={s:[0] for s in sides},targets=targets))
    scorepaths=[];gradpaths=[];losses={}
    versions={}
    for name in ['torch','transformers','trl','accelerate','swift.rlhf_trainers.grpo_trainer','swift.rl_core.data']:
        mod=importlib.import_module(name);versions[name]=dict(path=getattr(mod,'__file__',None),version=getattr(mod,'__version__',None))
    for side in sides:
        dest=folder/side;dest.mkdir()
        if side=='torch-reference':
            model=AutoModelForCausalLM.from_pretrained(str(PRETRAINED),torch_dtype=torch.float32,attn_implementation='eager',local_files_only=True)
            model.config.use_cache=False;model.train()
            if state_hash(model)!=initial:raise ValueError('reference initial weights differ')
        model.zero_grad(set_to_none=True)
        if side=='ms-swift-native':
            # Retain the exact tensor returned by the real native scorer during
            # compute_loss; do not substitute or recompute the objective scores.
            score_capture={}
            native_scorer=trainer._get_per_token_logps_and_entropies
            def capture_scores(*call_args,**call_kwargs):
                output=native_scorer(*call_args,**call_kwargs)
                score_capture['scores']=output[0].detach().clone()
                return output
            trainer._get_per_token_logps_and_entropies=capture_scores
            native_inputs=dict(inputs)
            loss=trainer.compute_loss(model,dict(model_inputs=native_inputs,grpo_batch=batch))
            scores=score_capture['scores']
            effective_inputs=native_inputs
        else:
            logits=model(**inputs).logits[:,-5:-1].float()
            scores=logits.log_softmax(-1).gather(-1,tokens[:,-4:,None]).squeeze(-1)
            ratio=(scores-old).exp();per_token=-torch.minimum(ratio*advantages,ratio.clamp(.8,1.2)*advantages)
            loss=((per_token*mask).sum(-1)/mask.sum(-1).clamp(min=1.)).mean()
            effective_inputs=inputs
        loss.backward()
        write(dest/'execution_settings.json',dict(model_class=model.__class__.__module__+'.'+model.__class__.__name__,
            model_config=model.config.to_dict(),parameter_dtypes=sorted(set(str(p.dtype) for p in model.parameters())),
            training=model.training,effective_forward_inputs={key:dict(shape=list(value.shape),dtype=str(value.dtype)) if torch.is_tensor(value) else value for key,value in effective_inputs.items()},
            score_capture='exact output tensor from native scorer during public compute_loss; pass-through wrapper' if side==sides[0] else 'same autograd score tensor used by independent loss'))
        entries=[]
        for i,(name,p) in enumerate(model.named_parameters()):
            if not p.requires_grad:continue
            if p.grad is None:raise ValueError('absent gradient '+name)
            np.save(dest/f'gradient_{i:04d}.npy',p.grad.detach().cpu().numpy(),allow_pickle=False)
            entries.append(dict(name=name,shape=list(p.shape),present=True,shards=[dict(offset=0,value=dict(path=f'gradient_{i:04d}.npy'))]))
        write(dest/'environment.json',dict(rank=0,versions=versions,actual=common,
            framework='native ms-swift GRPOTrainer' if side==sides[0] else 'independent Torch reference',
            training_backend='Transformers Trainer initialized by ms-swift; ordinary Torch autograd',rollout_engine=None))
        write(dest/'status.json',dict(rank=0,status='completed'))
        base=dict(common=common,side=side,expected_ranks=[0],ranks=[dict(rank=0,environment='environment.json',status='status.json')])
        gpath=write(dest/'gradients.json',dict(schema_version=2,kind='tensors',stage='gradients',tensors=entries,**base))
        write(dest/'gradient_validation.json',validate(gcpath,gpath));gradpaths.append(gpath)
        rows=[dict(t,logprob=float(scores[int(t['sample'].split('-')[-1]),t['position']-8].detach())) for t in targets]
        sbase=dict(base);sbase['common']={k:v for k,v in common.items() if k!='state'}
        scorepaths.append(write(dest/'scores.json',dict(schema_version=1,kind='target-scores',scores=rows,**sbase)))
        losses[side]=float(loss.detach());print(json.dumps(dict(side=side,loss=losses[side],parameter_tensors=len(entries),parameter_elements=sum(p.numel() for p in model.parameters()))),flush=True)
        del loss,scores
        if side==sides[0]:del trainer
        del model;gc.collect()
    sr=compare_scores(scpath,*scorepaths);gr=compare_tensors(gcpath,*gradpaths)
    write(folder/'score_comparison.json',sr);write(folder/'gradient_comparison.json',gr)
    result=dict(framework='ms-swift',case='SmolLM2-135M-Instruct pretrained',
        stages=dict(native_model_loader=True,trainer_constructed=True,native_action_scoring=True,native_compute_loss=True,backward=True,
                    rollout=False,native_training_step=False,native_optimizer_step=False,trainer_train_loop=False),
        losses=losses,loss_absolute_difference=abs(losses[sides[0]]-losses[sides[1]]),score_report=str(folder/'score_comparison.json'),gradient_report=str(folder/'gradient_comparison.json'),
        score_status=sr['status'],gradient_status=gr['status'],elapsed_seconds=time.time()-started)
    write(folder/'result.json',result);print(json.dumps(result),flush=True)
