"""Native OpenRLHF Actor + PolicyLoss replay against an independent Torch reference.

This adapter executes model scoring, native PPO objective, and full-model backward.
It is not a rollout or an OpenRLHF Ray/DeepSpeed trainer step. Tiny Qwen2 also
performs a matched explicit SGD step, whose state is captured by stored values.
"""
import argparse, gc, hashlib, importlib, importlib.metadata, json, math, os, pathlib, sys, time
import numpy as np
import torch

RUN = pathlib.Path(__file__).resolve().parent
ROOT = RUN.parent.parent
SOURCE = pathlib.Path('$FRAMEWORK_SOURCES/openrlhf_v090')
RESOURCE = pathlib.Path('$RL_RESOURCES')
PRETRAINED = pathlib.Path('$MODEL_ROOT/SmolLM2-135M-Instruct/12fd25f77366fa6b3b4b768ec3050bf629380bac')
sys.path[:0] = [str(SOURCE), str(ROOT / 'skills/precision-skill/scripts')]
from openrlhf.models import Actor, PolicyLoss
from transformers import AutoModelForCausalLM, Qwen2Config, Qwen2ForCausalLM
from compare_target_scores import compare as compare_scores
from compare_tensors import compare as compare_tensors
from validate_artifacts import validate

def write(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    return path

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(8*1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def state_hash(model):
    h = hashlib.sha256()
    for name, value in model.named_parameters():
        h.update(name.encode()); h.update(str(tuple(value.shape)).encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

def native_model(checkpoint, device):
    actor = Actor(str(checkpoint), attn_implementation='eager', bf16=False, packing_samples=False)
    actor.to(device=device, dtype=torch.float32).eval()
    return actor

def reference_model(checkpoint, device):
    model = AutoModelForCausalLM.from_pretrained(str(checkpoint), torch_dtype=torch.float32,
                                                attn_implementation='eager', local_files_only=True)
    model.config.use_cache = False
    return model.to(device).eval()

def fixed_inputs(device):
    tokens = torch.tensor([[1,10,11,12,13,14,15,16,40,41,42,2],
                           [1,20,21,22,23,24,25,26,50,51,2,0]], device=device)
    attention = torch.ones_like(tokens); attention[1,-1] = 0
    mask = torch.tensor([[1,1,1,1],[1,1,1,0]], dtype=torch.bool, device=device)
    advantages = torch.tensor([[1.,1.,-1.,-.5],[-1.,.5,1.,0.]],device=device)
    ratios = torch.tensor([[1.,1.5,.5,1.1],[1.5,.5,1.05,1.]],device=device)
    return tokens, attention, mask, advantages, ratios

def independent_scores(model, tokens, attention, mask):
    positions = attention.long().cumsum(-1) - 1
    positions.masked_fill_(attention == 0, 1)
    logits = model(tokens, attention_mask=attention, position_ids=positions).logits.float()
    selected = logits[:, :-1].log_softmax(-1).gather(-1,tokens[:,1:,None]).squeeze(-1)
    return selected[:,-mask.shape[1]:] * mask.float()

def run_case(name, checkpoint, device, updates):
    folder = RUN / name; folder.mkdir(exist_ok=False)
    started = time.time()
    tokens, attention, mask, advantages, desired_ratios = fixed_inputs(device)
    identities = {p.name: digest(p) for p in checkpoint.iterdir() if p.name in ['config.json','model.safetensors','tokenizer.json','tokenizer_config.json']}
    native = native_model(checkpoint, device)
    initial = state_hash(native.model)
    aliases = {}
    for pname,p in native.model.named_parameters(remove_duplicate=False): aliases.setdefault(p.data_ptr(), []).append(pname)
    tied = [v for v in aliases.values() if len(v)>1]
    with torch.no_grad():
        anchors = native(tokens, action_mask=mask, attention_mask=attention).detach()
    old = (anchors - desired_ratios.log()).detach()
    write(folder/'trajectory.json', dict(
        input_ids=tokens.cpu().tolist(), attention_mask=attention.cpu().tolist(),
        action_mask=mask.cpu().tolist(), action_target_positions=[8,9,10,11],
        prompt_positions=list(range(8)), eos_token_id=2, valid_eos_actions=2,
        old_logprobs=old.cpu().tolist(), old_scores_origin='injected: initial native action logprob minus prescribed log ratio; identical on both sides',
        advantages=advantages.cpu().tolist(), advantages_origin='injected fixed tensor; no reward model or normalization',
        reference_logprobs=None, rewards=None, returns=None, values=None,
        policy_version=0, rollout_policy_version=None, truncation=[False,False],
        chosen_initial_ratios=desired_ratios.cpu().tolist()))
    common = dict(model=dict(name=name, checkpoint=str(checkpoint), files_sha256=identities),
                  inputs=dict(trajectory_sha256=digest(folder/'trajectory.json')),
                  numerics=dict(device=device,dtype='float32',attention='eager',temperature=1.0,
                                tf32=False,dropout=False,seed=20261019),
                  scope='fixed-trajectory PPO action scoring and full-parameter backward',
                  state=dict(initial_parameters_sha256=initial, optimizer='SGD(lr=0.001,momentum=0)' if updates else None,
                             optimizer_step=0, gradient_accumulation=1, clipping=None))
    targets = [dict(sample=f'trajectory-{b}',position=8+j,token=int(tokens[b,8+j]))
               for b in range(2) for j in range(4) if mask[b,j]]
    contract_base = dict(schema_version=2,kind='tensors',common=common,thresholds=None,
                         expected_ranks={'openrlhf-native':[0],'torch-reference':[0]})
    inventory = [dict(name=n,shape=list(p.shape),present=True) for n,p in native.model.named_parameters() if p.requires_grad]
    grad_contract = write(folder/'gradient_contract.json',dict(contract_base,stage='gradients',tensors=inventory))
    update_contract = write(folder/'update_contract.json',dict(contract_base,stage='updates',tensors=inventory)) if updates else None
    score_contract = write(folder/'score_contract.json',dict(schema_version=1,kind='target-scores',common={k:v for k,v in common.items() if k!='state'},thresholds=None,
                           expected_ranks=contract_base['expected_ranks'],targets=targets))
    manifests={}; metrics={}
    versions={}
    for module in ['torch','transformers','numpy','deepspeed','peft','flash_attn','openrlhf.models.actor','openrlhf.models.loss']:
        mod=importlib.import_module(module)
        versions[module]={'path':getattr(mod,'__file__',None),'version':getattr(mod,'__version__',None)}
    for side in ['openrlhf-native','torch-reference']:
        sub=folder/side; sub.mkdir()
        if side=='openrlhf-native': model=native; params=native.model
        else:
            model=reference_model(checkpoint,device);params=model
            observed=state_hash(params)
            if observed!=initial: raise ValueError('initial checkpoint mismatch: '+observed+' versus '+initial)
        model.zero_grad(set_to_none=True)
        before={n:p.detach().cpu().clone() for n,p in params.named_parameters()} if updates else None
        scores = model(tokens,action_mask=mask,attention_mask=attention) if side=='openrlhf-native' else independent_scores(model,tokens,attention,mask)
        if side=='openrlhf-native':
            loss,clip_ratio,ppo_kl,vllm_kl=PolicyLoss(clip_eps_low=.2,clip_eps_high=.2,token_level_loss=True)(scores,old,advantages,mask)
        else:
            ratio=(scores-old).exp()
            s1=ratio*advantages; s2=ratio.clamp(.8,1.2)*advantages
            loss=-(torch.minimum(s1,s2)*mask).sum()/mask.sum()
            clip_ratio=((s2<s1).float()*mask).sum()/mask.sum()
            ppo_kl=(-(scores-old).detach()*mask).sum()/mask.sum();vllm_kl=None
        loss.backward()
        torch.cuda.synchronize() if device=='cuda' else None
        grad_tensors=[];update_tensors=[]
        for i,(pname,p) in enumerate(params.named_parameters()):
            if not p.requires_grad:continue
            present=p.grad is not None
            shards=[]
            if present:
                np.save(sub/f'gradient_{i:04d}.npy',p.grad.detach().cpu().numpy(),allow_pickle=False)
                shards=[dict(offset=0,value=dict(path=f'gradient_{i:04d}.npy'))]
            grad_tensors.append(dict(name=pname,shape=list(p.shape),present=present,shards=shards))
        if updates:
            optimizer=torch.optim.SGD(params.parameters(),lr=.001,momentum=0)
            optimizer.step()
            for i,(pname,p) in enumerate(params.named_parameters()):
                if not p.requires_grad:continue
                np.save(sub/f'before_{i:04d}.npy',before[pname].numpy(),allow_pickle=False)
                np.save(sub/f'after_{i:04d}.npy',p.detach().cpu().numpy(),allow_pickle=False)
                update_tensors.append(dict(name=pname,shape=list(p.shape),present=True,
                    shards=[dict(offset=0,before=dict(path=f'before_{i:04d}.npy'),after=dict(path=f'after_{i:04d}.npy'))]))
        write(sub/'environment.json',dict(rank=0,versions=versions,actual=common,
              framework='OpenRLHF native Actor/PolicyLoss' if side=='openrlhf-native' else 'Transformers model + independent Torch log_softmax/PPO',
              training_backend='ordinary Torch autograd; explicit Torch SGD for tiny Qwen2 only',rollout_engine=None,
              torch_threads=torch.get_num_threads(),DS_ACCELERATOR=os.getenv('DS_ACCELERATOR')))
        write(sub/'status.json',dict(rank=0,status='completed'))
        base=dict(schema_version=2,kind='tensors',common=common,side=side,expected_ranks=[0],
                  ranks=[dict(rank=0,environment='environment.json',status='status.json')])
        grad_manifest=write(sub/'gradients.json',dict(base,stage='gradients',tensors=grad_tensors))
        write(sub/'gradient_validation.json',validate(grad_contract,grad_manifest))
        if updates:
            update_manifest=write(sub/'updates.json',dict(base,stage='updates',tensors=update_tensors,events={'policy':'applied'}))
            write(sub/'update_validation.json',validate(update_contract,update_manifest))
        score_rows=[dict(target,logprob=float(scores[int(target['sample'].split('-')[-1]),target['position']-8].detach())) for target in targets]
        score_manifest=write(sub/'scores.json',dict(schema_version=1,kind='target-scores',common={k:v for k,v in common.items() if k!='state'},side=side,
            expected_ranks=[0],ranks=base['ranks'],scores=score_rows))
        ratio=(scores-old).detach().exp()
        native_metrics=dict(loss=float(loss.detach()),clip_ratio=float(clip_ratio.detach()),ppo_kl=float(ppo_kl.detach()),
            vllm_kl=None if vllm_kl is None else float(vllm_kl.detach()),valid_actions=int(mask.sum()),
            parameter_tensors=len(grad_tensors),parameter_elements=sum(p.numel() for p in params.parameters() if p.requires_grad),
            absent_gradients=[x['name'] for x in grad_tensors if not x['present']],
            ratios=ratio.cpu().tolist(),clipped_branch=((ratio*advantages)>(ratio.clamp(.8,1.2)*advantages)).cpu().tolist(),
            explicit_sgd_step_applied=updates,native_trainer_step=False)
        write(sub/'native_metrics.json',native_metrics);metrics[side]=native_metrics
        manifests[side]=dict(gradients=str(grad_manifest),scores=str(score_manifest),updates=str(update_manifest) if updates else None)
        print(json.dumps(dict(case=name,side=side,**native_metrics)),flush=True)
        del scores,loss,params,model
        if side=='openrlhf-native':del native
        gc.collect()
        if device=='cuda':torch.cuda.empty_cache()
    score_report=compare_scores(score_contract,manifests['openrlhf-native']['scores'],manifests['torch-reference']['scores'])
    grad_report=compare_tensors(grad_contract,manifests['openrlhf-native']['gradients'],manifests['torch-reference']['gradients'])
    write(folder/'score_comparison.json',score_report);write(folder/'gradient_comparison.json',grad_report)
    update_report=None
    if updates:
        update_report=compare_tensors(update_contract,manifests['openrlhf-native']['updates'],manifests['torch-reference']['updates'])
        write(folder/'update_comparison.json',update_report)
    result=dict(case=name,checkpoint=str(checkpoint),model_origin='pretrained HuggingFace SmolLM2-135M-Instruct' if checkpoint==PRETRAINED else 'tiny random-initialized Qwen2, seed 20261019; not pretrained',
        tied_parameter_mappings=tied,stages=dict(model_scoring=True,native_policy_loss=True,backward=True,explicit_torch_sgd_step=updates,rollout=False,native_trainer_step=False),
        metrics=metrics,loss_absolute_difference=abs(metrics['openrlhf-native']['loss']-metrics['torch-reference']['loss']),
        reports=dict(scores=str(folder/'score_comparison.json'),gradients=str(folder/'gradient_comparison.json'),updates=str(folder/'update_comparison.json') if updates else None),
        score_status=score_report['status'],gradient_status=grad_report['status'],update_status=update_report['status'] if updates else None,elapsed_seconds=time.time()-started)
    write(folder/'result.json',result)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--device',choices=['cpu','cuda'],default='cuda');parser.add_argument('--smoke',action='store_true');args=parser.parse_args()
    torch.set_num_threads(4);torch.manual_seed(20261019)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    RESOURCE.mkdir(parents=True,exist_ok=True)
    tiny=RESOURCE/'tiny-qwen2-random-seed20261019'
    if not tiny.exists():
        config=Qwen2Config(vocab_size=128,hidden_size=32,intermediate_size=64,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=64,attention_dropout=0.,bos_token_id=1,eos_token_id=2,pad_token_id=0,tie_word_embeddings=True)
        model=Qwen2ForCausalLM(config);model.save_pretrained(tiny);del model
    if args.smoke:
        model=native_model(tiny,args.device);tokens,attention,mask,*_=fixed_inputs(args.device)
        print(model(tokens,action_mask=mask,attention_mask=attention));raise SystemExit(0)
    results=[]
    for name,path,updates in [('tiny_qwen2_random',tiny,True),('smollm2_135m_pretrained',PRETRAINED,False)]:
        results.append(run_case(name,path,args.device,updates))
    write(RUN/'native_results.json',results)
