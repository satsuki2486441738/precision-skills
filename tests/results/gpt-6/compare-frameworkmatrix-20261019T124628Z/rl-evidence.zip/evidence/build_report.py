"""Build the English bounded-run report from this run's preserved evidence only."""
import datetime, importlib.metadata, json, pathlib, platform, subprocess
from prepare import RUN, ROOT, ENV, SOURCES

def read(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def metric_values(report):
    return {key:(value.get('value') if isinstance(value,dict) and 'value' in value else value)
            for key,value in report.get('global',{}).items()}

matrix=read(RUN/'framework_matrix_deeper.json')
earlier=read(RUN/'framework_matrix.json')
for row in matrix:
    row['backends']=next(x for x in earlier if x['framework']==row['framework'])['backends']
pins=read(RUN/'selected_source_pins.json')
additional=SOURCES/'openrlhf_v0810'
pins.append(dict(name='openrlhf_v0810_inspection_only',source=str(additional),
    official_repository='https://github.com/OpenRLHF/OpenRLHF.git',sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=additional,text=True).strip()))
commands=[read(path) for path in sorted(RUN.glob('*.command.json'))]
frameworks=[]
blockers={
    'slime':['Native Megatron loss import fails: megatron is not installed.',
             'Native train.py --help reaches the SGLang dependency and fails: sglang is not installed.',
             'No Megatron or SGLang backend was fabricated or provisioned.'],
    'nemo_rl':['Pinned main requires Python >=3.13.14,<3.14 and Torch >=2.11,<2.14; actual Python is3.11.17 and Torch is2.8.0+cu128.',
               'Native GRPO entrypoint raises a Pydantic TypedDict-on-Python<3.12 error.',
               'Actual backend probes fail for nemo_automodel, megatron.core and transformer_engine.'],
    'areal':['Pinned main requires Torch >=2.9.1,<2.11 and Transformers >=5.0,<=5.3; actual2.8.0+cu128/4.57.0 do not satisfy these.',
             'The native PPOTrainer/entrypoint dependency frontier is missing flask after bounded repairs.',
             'Actual SGLang and torch_memory_saver backend imports fail.'],
    'roll':['Native RLVR pipeline/entrypoint import fails for transfer_queue.',
            'Actual selected backend prerequisites megatron.core and quack are absent.',
            'Its source has a Torch2.8/vLLM0.11 dependency file, but the distributed pipeline was not provisioned.'],
    'mindspeed_rl':['Native trainer/GRPO entrypoint fails for torch_npu after bounded repairs.',
                    'Actual torch_npu, mindspeed and megatron.core imports fail.',
                    'Available hardware is an NVIDIA RTX5060 under WSL; no Ascend NPU or Ascend runtime is supplied.'],
}
for row in matrix:
    name=row['framework'];runtime=row['runtime']['data']
    item=dict(framework=name,official_source_sha=row['sha'],source=row['source'],
        source_inspected=True,prerequisite_runtime_probe_executed=True,
        native_entrypoint_probe_executed=True,native_entrypoint_returncode=row['native_entrypoint']['returncode'],
        native_entrypoint_log=row['native_entrypoint']['log'],runtime_report=row['runtime']['report'],
        runtime_status=runtime['status'],runtime_error=runtime.get('error',{}).get('message'),
        backend_reports={k:v['report'] for k,v in row['backends'].items()},
        version_prerequisite_checks=row['version_prerequisite_checks'],python_requirement=row.get('python_requirement'),
        source_prerequisite_evidence=row['source_prerequisite_evidence'],
        executed_stages=dict(native_model=False,native_loss=False,backward=False,rollout=False,native_training_step=False,native_optimizer_step=False),
        blockers=blockers.get(name,[]))
    if name=='openrlhf':
        item['executed_stages'].update(native_model=True,native_loss=True,backward=True)
        item['boundary']='Native Actor + PolicyLoss model execution; tiny Qwen2 explicit Torch SGD. No Ray/DeepSpeed training orchestration.'
    if name=='ms_swift':
        item['executed_stages'].update(native_model=True,native_loss=True,backward=True)
        item['boundary']='Real native get_model_processor and GRPOTrainer constructor, public compute_loss, native scorer and backward. No train(), training_step(), rollout or optimizer.'
        item['runtime_report']=str(RUN/'post_native_runtime.json')
        item['trl_requirement']='GRPOConfig checks trl>=0.26 at swift/rlhf_trainers/arguments.py:102; executed withTRL0.26.2.'
    frameworks.append(item)

cases=[]
for name in ['tiny_qwen2_random','smollm2_135m_pretrained']:
    result=read(RUN/name/'result.json')
    result['action_scores']=read(RUN/name/'score_comparison.json')['metrics']
    gpath=RUN/name/'explicit_disabled_views/gradients_comparison.json'
    greport=read(gpath);result['gradients']=metric_values(greport)
    result['raw_capture_attempt_statuses']=dict(gradient_status=result.get('gradient_status'),update_status=result.get('update_status'))
    result['gradient_status']=greport['status']
    result['gradient_comparator_status']=greport['status'];result['gradient_report']=str(gpath)
    result['coverage']=dict(trajectories=2,valid_actions=7,valid_eos_actions=2,
        parameter_tensors=result['metrics']['openrlhf-native']['parameter_tensors'],parameter_elements=result['metrics']['openrlhf-native']['parameter_elements'],ranks=1)
    result['objective_configuration']=dict(objective='PPO',policy_loss_type='ppo',clip_eps_low=.2,clip_eps_high=.2,
        token_level_loss=True,temperature=1.,dual_clip='disabled',vllm_importance_correction='disabled',kl_term='disabled')
    if name=='tiny_qwen2_random':
        upath=RUN/name/'explicit_disabled_views/updates_comparison.json';ureport=read(upath)
        result['updates']=metric_values(ureport);result['update_report']=str(upath);result['update_comparator_status']=ureport['status']
        result['update_status']=ureport['status']
    result['reports']['gradients']=str(gpath)
    if name=='tiny_qwen2_random':result['reports']['updates']=result['update_report']
    cases.append(result)

swiftfolder=RUN/'ms_swift_smollm2_complete_group'
swift=read(swiftfolder/'result.json') if (swiftfolder/'result.json').exists() else None
if swift:
    swift['action_scores']=read(swiftfolder/'score_comparison.json')['metrics']
    swift['gradients']=metric_values(read(swiftfolder/'gradient_comparison.json'))
    swift['coverage']=dict(trajectories=2,complete_groups=1,group_size=2,valid_actions=7,valid_eos_actions=2,parameter_tensors=272,parameter_elements=134515008,ranks=1)
    swift['objective_configuration']=dict(objective='GRPO',loss_type='grpo',importance_sampling_level='token',epsilon_low=.2,
        epsilon_high=.2,beta=0.,temperature=1.,reduction='mean of masked per-sequence means',
        advantage_normalization='not executed: injected fixed +1/-1 per-sequence advantages expanded to tokens',gradient_accumulation_steps=1)
    settings={s:read(swiftfolder/s/'execution_settings.json') for s in ['ms-swift-native','torch-reference']}
    config_a=settings['ms-swift-native']['model_config'];config_b=settings['torch-reference']['model_config']
    swift['observed_model_config_differences']={k:dict(native=config_a.get(k),reference=config_b.get(k)) for k in set(config_a)|set(config_b) if config_a.get(k)!=config_b.get(k)}
    swift['effective_execution_settings']={s:str(swiftfolder/s/'execution_settings.json') for s in settings}
    cases.append(swift)

metadata=[dict(name=d.metadata.get('Name'),version=d.version,location=str(d.locate_file(''))) for d in importlib.metadata.distributions()]
write(RUN/'post_native_distribution_metadata.json',metadata)
manual_attempts=[
    dict(attempt='Initial .pth target guessed Python3.12',outcome='Failed path: base interpreter is Python3.11.17. prepare.py discovered python*/site-packages and wrote only the private env .pth.'),
    dict(attempt='Windows python ast-docstring extraction',outcome='Windows python alias unavailable. Extracted selected tool docstrings using the WSL base interpreter instead.'),
    dict(attempt='Initial slime clone',outcome='TLS GnuTLS transport failure; clone_slime.log preserved. One shallow retry succeeded at pinned a4202e0595467d9374d9a68d45a34f45c3f8d230.'),
    dict(attempt='OpenRLHF main dependency inspection',outcome='Main pins Transformers5.15.0. v0.8.10 inspection pins4.55.2; selected officialv0.9.0 pins4.57.0 with matching Torch-generation FlashAttention wheel.'),
    dict(attempt='git ls-remote inside Windows-managed worktree from WSL',outcome='Git read the Windows gitdir pointer as a relative Linux path and failed; reran source-ref lookup outside that worktree in $WSL_HOME.'),
]
write(RUN/'manual_setup_attempts.json',manual_attempts)
friction=[
    dict(kind='native prerequisite',description='DeepSpeed source build selected CUDA compatibility probes even with DS_BUILD_OPS=0; CUDA_HOME is absent. Supported DS_ACCELERATOR=cpu plus DS_BUILD_OPS=0 built the real package. No fake backend imports were used.',evidence='install_native_prerequisites.log and repair_install_cpu_deepspeed.log'),
    dict(kind='native runtime',description='Installed real FlashAttention exposes OpenRLHF Triton cross_entropy; CPU Actor scoring fails with CPU tensor pointer error. Unmodified native scoring/backward succeeded on CUDA under shared flock.',evidence='native_cpu_smoke.log and native_gpu_replay.log'),
    dict(kind='artifact adapter',description='Nested null for known-disabled clipping/optimizer was treated as an unknown state by conditions.known. Original reports/captures were preserved; fresh explicit_disabled_views use disabled/not-executed strings and validate.',evidence='compare_captured.py and tensor_comparison_summary.json'),
    dict(kind='runtime probe selection',description='Requesting installed distribution metadata for an uninstalled source checkout made the first successful OpenRLHF symbol import report fail at metadata lookup. Editable no-deps installation provided genuine metadata; final ordered probe completed.',evidence='after_install_openrlhf_runtime.json and post_native_runtime.json'),
    dict(kind='native prerequisite',description='ms-swift top-level requirements allowTRL>=0.15,<1 but GRPOConfig requiresTRL>=0.26. Initial actual constructor attempt failed withTRL0.25.1; retry with0.26.2 constructed the real trainer and executed its loss/backward.',evidence='native_ms_swift_replay.log and native_ms_swift_exact_capture.log'),
    dict(kind='capture quality',description='First Swift attempt captured a no-grad rescoring call separately from the loss forward. A new exact-capture attempt uses a pass-through native-scorer wrapper during public compute_loss; prior attempts remain preserved.',evidence='native_swift.py and ms_swift_smollm2_exact_capture/'),
    dict(kind='trajectory adapter',description='The final Swift replay gives both trajectories the identical eight-token prompt, making one complete two-completion GRPO group. Earlier fixed-batch attempts with distinct prompts are preserved as component probes and are not the final group comparison.',evidence='ms_swift_smollm2_complete_group/trajectory.json'),
    dict(kind='version warning',description='The official OpenRLHFv0.9.0 Transformers4.57.0 pin is yanked onPyPI for setup issues; its installed wheel executed. Ray2.59 differs from the framework full-trainer pin2.48 and no Ray trainer was run. These are subset native-component checks, not a fully provisioned trainer environment.',evidence='repair_install_cpu_deepspeed.log and final/deeper native entrypoint logs'),
]
result=dict(schema_version=1,run_id=RUN.name,started_utc='2026-10-19T12:48:18Z',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    skill='skills/precision-skill/SKILL.md',clean_context=dict(read_git_history=False,read_repository_tests=False,read_parent_findings=False,read_other_worktrees=False),
    environment=dict(os='WSL Ubuntu-24.04',python=platform.python_version(),interpreter=str(ENV/'bin/python'),
        isolated_env=str(ENV),base_environment='$BASE_ENV',base_read_only_pth=True,
        gpu='NVIDIA GeForce RTX5060 8151MiB',driver='595.95',torch='2.8.0+cu128',transformers='4.57.0',
        deepspeed='0.18.1',flash_attention='2.8.3',flash_attention_wheel_flavor='cu12torch2.8cxx11abiTRUE-cp311-linux_x86_64',
        trl='0.26.2',accelerate='1.10.1',peft='0.17.1',openrlhf='0.9.0',ms_swift_source_version='4.7.0.dev0',
        runtime_report=str(RUN/'post_native_runtime.json'),distribution_metadata=str(RUN/'post_native_distribution_metadata.json')),
    budgets=dict(wall_clock_limit_minutes=35,download_limit_bytes=2_000_000_000,
        largest_download='Official FlashAttention wheel, logged244.2MiB',
        download_accounting='No Torch/model download. Shallow official source packs plus small dependency installs; estimated aggregate below0.75GiB. Network aggregate was not independently byte-metered.',
        gpu_lock='/tmp/precision-skills-gpu.lock',gpu_replay_wall_seconds=read(RUN/'native_gpu_replay.command.json')['elapsed_seconds']),
    source_pins=pins,frameworks=frameworks,cases=cases,commands=commands,friction=friction,
    allowed_implementation_differences=[
        'OpenRLHF uses the native Actor score transform/Triton cross_entropy and PolicyLoss; reference uses Transformers logits, torch.log_softmax, and an independent clipped PPO formula.',
        'Swift uses its native model loader, real GRPOTrainer and TRL selective_log_softmax; reference uses direct Transformers loading/log_softmax and independent sequence-mean GRPO reduction.',
        'Native Swift forwards logits_to_keep=5/use_cache=False as supported by the model; full-sequence reference forwards the same input IDs/positions/masks. The separate row-retention probe did not reduce the initial rescoring discrepancy; no cause is asserted.',
        'OpenRLHF cases use token-mean PPO; Swift uses its actual sequence-mean GRPO reduction. These cases are independently matched to their references, not cross-framework loss comparisons.'
    ],
    common_conditions=['Identical checkpoint files and exact FP32 initial parameter hash per matched pair.',
        'Fixed2 trajectories,7 active action targets including2EOS targets; native mask retained.',
        'Identical injected detached old scores and advantages per pair; no reward model or rollout recomputation.',
        'Full parameter inventory including tied-weight mappings; no gradient clipping or accumulation beyond one batch.',
        'TinyQwen2 has a stateless matched explicit SGD(lr0.001,momentum0) step with stored before/after tensors.',
        'All comparison contracts thresholds=null; no pass/fail precision threshold is invented.'],
    coverage_limits=['No rollout in any framework.', 'No framework train() loop, training_step() or distributed optimizer step.',
        'No critic/value/reward-model/GAE/KL-reward execution.', 'Injected advantages do not validate reward normalization or native group-statistic construction.',
        'No fused-Liger, ring/sequence/tensor/pipeline parallel, DeepSpeed engine, Ray worker or Megatron training execution.',
        'One pretrained Llama architecture and one explicitly random tinyQwen2 architecture; Swift executed the pretrained architecture only.'],
    reusable_candidates=['A prepared-trajectory adapter that maps native action positions/masks/EOS into target-score artifacts.',
        'A generic native-call pass-through capture wrapper for exact objective scores without replacing native operators.',
        'A prerequisite matrix separating source constraints, import probes, CLI initialization, native model/loss execution and full training.',
        'An artifact metadata convention for explicitly disabled optimizer/clipping states rather than unknown null fields.'],
    artifact_directory=str(RUN),report=str(RUN/'report.md'))
write(RUN/'results.json',result)

lines=['# Native RL framework checks','',
    'Two native execution paths completed: OpenRLHF Actor/PolicyLoss on CUDA, and a genuinely constructed ms-swift GRPOTrainer with public compute_loss/backward on CPU. Five other frameworks received bounded official-source, native-entrypoint and backend prerequisite probes. No framework rollout or full training loop is claimed.','',
    f'Run: `{RUN.name}`. Start: 2026-10-19 12:48:18 UTC. Finish: {result["finished_utc"]}.',
    f'Environment: Python {platform.python_version()}, Torch 2.8.0+cu128, Transformers 4.57.0, RTX 5060 8151 MiB; private environment `{ENV}` references the base read-only site-packages and owns its dependency overrides.','',
    '## Executed comparisons','']
for case in cases:
    name=case.get('case');scores=case['action_scores'];grad=case['gradients']
    lines += [f'### {name}', '',f'- Loss absolute difference: {case["loss_absolute_difference"]:.10g}.',
        f'- Action scores: 7/7 paired, MAE {scores["mae_nat"]:.10g}, P99 {scores["p99_nat"]:.10g}, maximum {scores["max_abs_nat"]:.10g} nats at `{scores["max_coordinate"]}`.',
        f'- Gradients: {grad["count"]:,} paired elements, L2 error {grad["error_norm"]:.10g}, RMSE {grad["rmse"]:.10g}, cosine {grad["cosine"]:.15g}, maximum {grad["max_abs"]:.10g} at `{grad["max_coordinate"]}`.']
    if case.get('updates'):
        upd=case['updates'];lines += [f'- Stored explicit-SGD updates: {upd["count"]:,} paired elements, L2 error {upd["error_norm"]:.10g}, RMSE {upd["rmse"]:.10g}, cosine {upd["cosine"]:.15g}, maximum {upd["max_abs"]:.10g}.']
    lines += [f'- Captured stages: `{case["stages"]}`.',f'- Gradient report: `{case.get("gradient_report")}`.','']
lines += ['The tinyQwen2 checkpoint is random-initialized with seed20261019; it is not a pretrained model. The SmolLM2 cases use the existing pretrained checkpoint. All matched pairs verify exact initial FP32 parameter hashes. Old policy scores and advantages are injected fixed tensors and explicitly recorded in trajectory.json. Swift complete group membership is recorded, but native reward/group normalization is not executed.','',
    '## Framework stage coverage and blockers','']
for item in frameworks:
    lines += [f'- **{item["framework"]}**, source SHA `{item["official_source_sha"]}`: native CLI return code {item["native_entrypoint_returncode"]}; runtime probe `{item["runtime_status"]}`.']
    if item.get('boundary'):lines += ['  '+item['boundary']]
    for blocker in item['blockers']:lines += ['  '+blocker]
lines += ['', '## Precision scope','',*['- '+text for text in result['common_conditions']], '',
          *['- '+text for text in result['allowed_implementation_differences']], '',
          '## Friction and preserved attempts','']
for item in friction:lines += ['- '+item['description']+' Evidence:`'+item['evidence']+'`.']
lines += ['', '## Evidence and reusable adapters','',
    '- `results.json` contains the exact sourcepins, package/runtime paths, command arguments, comparison metrics, stage distinctions and evidence paths.',
    '- `post_native_runtime.json` completed ordered imports, selected symbol checks and real SwiftGRPOConfig construction withTRL0.26.2.',
    '- `framework_matrix.json` and `framework_matrix_deeper.json` preserve native CLI/backend attempts and source prerequisite evidence. All logs and earlier failed captures remain in place.',
    '- `native_openrlhf.py` and `native_swift.py` retain unmodified native loss operators and map their observations to the skill artifact interfaces.',
    '- Full gradient arrays are in per-case native/reference directories; fresh metadata views refer to the original arrays without changing their bytes.',
    '- Downloads stayed well below the2GB allocation by reusing Torch/model resources; largest explicit download was the244.2MiB official FlashAttention wheel. Exact aggregate network bytes were not independently metered.',
    '', 'Useful reusable candidates: exact native-scorer pass-through capture, fixed-trajectory action-coordinate export, prerequisite/stage coverage matrix, and explicit-disabled metadata state conventions.','']
report='\n'.join(lines)
for old,new in [('tinyQwen2','tiny Qwen2'),('TinyQwen2','Tiny Qwen2'),('seed20261019','seed 20261019'),
                ('Fixed2','Fixed 2'),('trajectories,7','trajectories, 7'),('including2EOS','including 2 EOS'),
                ('SGD(lr0.001,momentum0)','SGD(lr=0.001, momentum=0)'),('is3.11','is 3.11'),('is2.8','is 2.8'),
                ('actual2.8','actual 2.8'),('Torch2.8','Torch 2.8'),('vLLM0.11','vLLM 0.11'),('RTX5060','RTX 5060'),
                ('allowTRL','allow TRL'),('requiresTRL','requires TRL'),('withTRL','with TRL'),('with0.26','with 0.26'),
                ('OpenRLHFv0.9','OpenRLHF v0.9'),('Transformers4.57','Transformers 4.57'),('onPyPI','on PyPI'),
                ('Ray2.59','Ray 2.59'),('pin2.48','pin 2.48'),('sourcepins','source pins'),('SwiftGRPOConfig','Swift GRPOConfig'),
                ('the2GB','the 2 GB'),('the244.2MiB','the 244.2 MiB'),('Evidence:`','Evidence: `')]:
    report=report.replace(old,new)
(RUN/'report.md').write_text(report,encoding='utf-8')
print(json.dumps(dict(results=str(RUN/'results.json'),report=str(RUN/'report.md'),cases=len(cases),frameworks=len(frameworks)),indent=2))
