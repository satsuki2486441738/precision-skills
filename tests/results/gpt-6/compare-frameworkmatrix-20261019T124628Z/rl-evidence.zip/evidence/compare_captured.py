"""Normalize known-disabled capture metadata into fresh views; preserve raw captures."""
import copy, json, pathlib, sys
from prepare import RUN, ROOT
sys.path.insert(0,str(ROOT/'skills/precision-skill/scripts'))
from compare_tensors import compare
from validate_artifacts import validate

def read(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');return path

reports=[]
for case in ['tiny_qwen2_random','smollm2_135m_pretrained']:
    source=RUN/case
    target=source/'explicit_disabled_views';target.mkdir(exist_ok=False)
    stages=['gradients','updates'] if case=='tiny_qwen2_random' else ['gradients']
    for stage in stages:
        stem='gradient' if stage=='gradients' else 'update'
        contract=read(source/f'{stem}_contract.json')
        # The collector recorded explicit no-clipping and no-optimizer execution.
        # conditions.known treats nested None as unknown, so spell these states out.
        contract['common']['state']['clipping']='disabled'
        if contract['common']['state']['optimizer'] is None:
            contract['common']['state']['optimizer']='not executed: backward capture only'
        cpath=write(target/f'{stem}_contract.json',contract)
        manifests=[]
        for side in ['openrlhf-native','torch-reference']:
            dest=target/side;dest.mkdir(exist_ok=True)
            original=source/side
            manifest=read(original/f'{stage}.json')
            manifest['common']=contract['common']
            for tensor in manifest['tensors']:
                for shard in tensor['shards']:
                    for field in ['value','before','after']:
                        if field in shard:shard[field]['path']=str((original/shard[field]['path']).resolve())
            environment=read(original/'environment.json');environment['actual']=contract['common']
            write(dest/'environment.json',environment)
            write(dest/'status.json',read(original/'status.json'))
            mpath=write(dest/f'{stage}.json',manifest)
            write(dest/f'{stage}_validation.json',validate(cpath,mpath))
            manifests.append(mpath)
        report=compare(cpath,*manifests)
        path=write(target/f'{stage}_comparison.json',report)
        reports.append(dict(case=case,stage=stage,status=report['status'],report=str(path),metrics=report.get('global'),coverage=report.get('coverage'),reason=report.get('reason')))
write(RUN/'tensor_comparison_summary.json',reports)
print(json.dumps(reports,indent=2))
