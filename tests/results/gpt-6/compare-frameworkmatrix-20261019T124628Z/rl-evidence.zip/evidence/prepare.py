"""Bounded official-source checkout and isolated-environment prerequisite probes."""
import ast, concurrent.futures, datetime, json, os, pathlib, subprocess, sys, time

RUN = pathlib.Path(__file__).resolve().parent
ROOT = RUN.parent.parent
SOURCES = pathlib.Path('$FRAMEWORK_SOURCES')
ENV = pathlib.Path('$ISOLATED_ENV')
BASE = pathlib.Path('$BASE_ENV')
FRAMEWORKS = {
    'openrlhf': 'https://github.com/OpenRLHF/OpenRLHF.git',
    'slime': 'https://github.com/THUDM/slime.git',
    'nemo_rl': 'https://github.com/NVIDIA-NeMo/RL.git',
    'ms_swift': 'https://github.com/modelscope/ms-swift.git',
    'areal': 'https://github.com/areal-project/AReaL.git',
    'roll': 'https://github.com/alibaba/ROLL.git',
    'mindspeed_rl': 'https://github.com/Ascend/MindSpeed-RL.git',
}

def command(name, args, cwd=None, timeout=180, env=None):
    start = time.time()
    record = {'name': name, 'command': args, 'cwd': str(cwd or ROOT), 'timeout_seconds': timeout}
    try:
        p = subprocess.run(args, cwd=cwd or ROOT, env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=timeout, text=True)
        out, record['returncode'] = p.stdout, p.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b'').decode(errors='replace') if isinstance(e.stdout, bytes) else (e.stdout or '')
        record['returncode'] = 'timeout'
    record['elapsed_seconds'] = round(time.time() - start, 3)
    record['log'] = str(RUN / (name + '.log'))
    pathlib.Path(record['log']).write_text(out, encoding='utf-8')
    (RUN / (name + '.command.json')).write_text(json.dumps(record, indent=2), encoding='utf-8')
    return record, out

def clone(item):
    name, url = item
    target = SOURCES / name
    record, out = command('clone_' + name, ['git', 'clone', '--depth', '1', url, str(target)], timeout=240)
    result = {'name': name, 'official_repository': url, 'source': str(target), 'clone': record}
    if record['returncode'] == 0:
        p = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=target, text=True, capture_output=True)
        result['sha'] = p.stdout.strip()
        result['git_pack_bytes'] = sum(p.stat().st_size for p in (target / '.git' / 'objects').rglob('*') if p.is_file())
        result['manifest_files'] = [str(p.relative_to(target)) for p in target.iterdir()
                                    if p.is_file() and any(v in p.name.lower() for v in ['requirements', 'pyproject', 'setup', 'readme'])]
    return result

if __name__ == '__main__':
    # Read-only base environment references; this .pth is written only in the isolated environment.
    ownsite = next((ENV / 'lib').glob('python*/site-packages'))
    basesite = next((BASE / 'lib').glob('python*/site-packages'))
    (ownsite / 'base-readonly.pth').write_text(str(basesite) + '\n')
    docs = {}
    for name in ['runtime_probe.py', 'compare_target_scores.py', 'compare_tensors.py', 'artifact_io.py', 'conditions.py']:
        docs[name] = ast.get_docstring(ast.parse((ROOT / 'skills/precision-skill/scripts' / name).read_text()))
    (RUN / 'selected_tool_docstrings.json').write_text(json.dumps(docs, indent=2))
    SOURCES.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(clone, FRAMEWORKS.items()))
    (RUN / 'source_pins.json').write_text(json.dumps(results, indent=2))
    print(json.dumps(results, indent=2), flush=True)
