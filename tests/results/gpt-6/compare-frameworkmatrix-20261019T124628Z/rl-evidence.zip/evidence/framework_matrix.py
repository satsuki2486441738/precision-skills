"""Final fresh-interpreter native entrypoint/backend and source prerequisite matrix."""
import importlib.metadata, json, os, pathlib, platform, subprocess, sys, tomllib
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from prepare import RUN, ROOT, ENV, SOURCES, command
from prerequisites import SELECTED

PY=str(ENV/'bin/python')
PROBE=str(ROOT/'skills/precision-skill/scripts/runtime_probe.py')

def probe(name,source,imports,symbols=()):
    spec=dict(imports=imports,symbols=list(symbols),python_paths=[str(source)],distributions=['torch','transformers','ray'])
    sp=RUN/(name+'.spec.json');sp.write_text(json.dumps(spec,indent=2))
    out=RUN/(name+'.json')
    rec,log=command(name,[PY,PROBE,'--spec',str(sp),'--output',str(out),'--python',PY,'--timeout','45'],timeout=60)
    return dict(command=rec,report=str(out),data=json.loads(out.read_text()) if out.exists() else None)

if __name__=='__main__':
    label=sys.argv[1] if len(sys.argv)>1 else 'final'
    os.environ['DS_ACCELERATOR']='cpu'
    os.environ['TOKENIZERS_PARALLELISM']='false'
    backends={
        'slime':['megatron.core','sglang'],
        'nemo_rl':['nemo_automodel','megatron.core','transformer_engine'],
        'ms_swift':['swift.rlhf_trainers.grpo_trainer'],
        'areal':['sglang','torch_memory_saver'],
        'roll':['mcore_adapter','megatron.core','quack'],
        'mindspeed_rl':['torch_npu','mindspeed','megatron.core'],
    }
    matrix=[]
    for name,(directory,imports,symbols,entry) in SELECTED.items():
        source=SOURCES/directory
        row=dict(framework=name,source=str(source),sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip())
        row['runtime']=probe(label+'_'+name+'_runtime',source,imports,symbols)
        env=dict(os.environ,PYTHONPATH=str(source),CUDA_VISIBLE_DEVICES='')
        args=[PY,'-m',entry,'--help'] if not entry.endswith('.py') else [PY,str(source/entry),'--help']
        row['native_entrypoint'],_=command(label+'_'+name+'_entrypoint',args,cwd=source,timeout=45,env=env)
        row['backends']={}
        if label=='final':
            for i,module in enumerate(backends.get(name,[])):
                row['backends'][module]=probe('backend_'+name+'_'+str(i),source,[module])
        evidence=[]
        files=[source/'requirements.txt',source/'requirements/framework.txt',source/'requirements_torch280_vllm.txt',source/'requirements_common.txt',source/'pyproject.toml',source/'README.md']
        for path in files:
            if not path.exists():continue
            lines=path.read_text(errors='replace').splitlines()
            wanted=[]
            terms=('requires-python','torch>=','torch==','transformers','sglang','megatron','mindsp','torch_npu','Ascend','A2','A3','H100','H800','8 GPUs')
            for i,line in enumerate(lines):
                if any(term.lower() in line.lower() for term in terms):wanted.append(dict(line=i+1,text=line[:700]))
            evidence.append(dict(path=str(path),lines=wanted[:45]))
        row['source_prerequisite_evidence']=evidence
        path=source/'pyproject.toml'
        requirements=[]
        if path.exists():
            project=tomllib.loads(path.read_text()).get('project',{})
            python_requires=project.get('requires-python')
            row['python_requirement']=dict(required=python_requires,actual=platform.python_version(),satisfied=SpecifierSet(python_requires).contains(platform.python_version())) if python_requires else None
            for text in project.get('dependencies',[]):
                try:
                    requirement=Requirement(text)
                    if requirement.name.lower() not in ['torch','transformers','ray','peft','datasets']:continue
                    actual=importlib.metadata.version(requirement.name)
                    requirements.append(dict(requirement=text,actual=actual,satisfied=requirement.specifier.contains(actual)))
                except Exception as exc:requirements.append(dict(requirement=text,error=str(exc)))
        row['version_prerequisite_checks']=requirements
        matrix.append(row)
        print(json.dumps(dict(framework=name,status=row['runtime']['data'].get('status') if row['runtime']['data'] else 'failed',error=row['runtime']['data'].get('error',{}).get('message') if row['runtime']['data'] else None,entrypoint_returncode=row['native_entrypoint']['returncode'])),flush=True)
    matrix_path=RUN/('framework_matrix.json' if label=='final' else 'framework_matrix_'+label+'.json')
    matrix_path.write_text(json.dumps(matrix,indent=2))
