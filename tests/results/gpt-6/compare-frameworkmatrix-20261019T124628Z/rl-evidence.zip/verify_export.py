"""Verify exported evidence hashes. Does not replay omitted model/gradient arrays."""
import hashlib,json,pathlib,sys,zipfile
p=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'rl-evidence.zip')
with zipfile.ZipFile(p) as z:
 m=json.loads(z.read('EXPORT.json'))
 for f in m['files']:
  raw=z.read(f['archive_path'])
  assert hashlib.sha256(raw).hexdigest()==f['exported_sha256'],f['archive_path']
  assert len(raw)==f['exported_bytes']
 print(json.dumps({'status':'validated','exported_files':len(m['files']),'full_gradient_replay':False},indent=2))
