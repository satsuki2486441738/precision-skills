import argparse,pathlib,json,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--skill',required=True);p.add_argument('--output',required=True);a=p.parse_args();root=pathlib.Path(__file__).parent;out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=False);results=[]
for f in sorted((root/'core').iterdir()):
 if not f.is_dir() or not (f/'contract.json').exists():continue
 tool='compare_target_scores.py' if f.name=='action-scores' else 'compare_tensors.py'
 if f.name!='action-scores':
  for side in ['native','reference']:
   q=subprocess.run([sys.executable,'-B',str(pathlib.Path(a.skill)/'scripts/validate_artifacts.py'),'--contract',str(f/'contract.json'),'--manifest',str(f/(side+'.json')),'--output',str(out/(f.name+'-'+side+'-validation.json'))],capture_output=True,text=True);assert q.returncode==0,(q.stdout,q.stderr)
 target=out/(f.name+'-report.json');q=subprocess.run([sys.executable,'-B',str(pathlib.Path(a.skill)/'scripts'/tool),'--contract',str(f/'contract.json'),'--side-a',str(f/'native.json'),'--side-b',str(f/'reference.json'),'--output',str(target)],capture_output=True,text=True);assert q.returncode==0,(q.stdout,q.stderr)
 actual=json.loads(target.read_text());expected=json.loads((f/'report.json').read_text());key='metrics' if f.name=='action-scores' else 'global';assert actual[key]==expected[key],f.name;results.append({'name':f.name,'status':actual['status'],'metrics_reproduced':True})
print(json.dumps({'comparisons':results,'thresholds':None},indent=2))
