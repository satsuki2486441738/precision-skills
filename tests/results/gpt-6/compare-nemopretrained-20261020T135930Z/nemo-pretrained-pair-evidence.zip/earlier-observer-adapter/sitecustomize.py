"""Disclosed NeMo CLI adapter: official device migration, Ray NPU isolation, local data, observational step capture."""
import os,sys,pathlib,json,time
if os.environ.get('PRECISION_NEMO_CLI_ADAPTER')=='1':
 import torch,torch_npu
 from torch_npu.contrib import transfer_to_npu
 if os.environ.get('PRECISION_NEMO_SEED'):
  torch.manual_seed(int(os.environ['PRECISION_NEMO_SEED']));torch.npu.manual_seed_all(int(os.environ['PRECISION_NEMO_SEED']))
 import ray
 _ray_init=ray.init
 def npu_init(*args,**kwargs):
  if kwargs.get('address')=='auto':raise ConnectionError('Private NeMo test requires an isolated owned Ray cluster')
  kwargs.update(num_gpus=0,num_cpus=8,resources={'NPU':1},include_dashboard=False,object_store_memory=256*1024*1024,_node_ip_address='127.0.0.1')
  kwargs['_temp_dir']=os.environ['PRECISION_NEMO_RAY_TMP']
  result=_ray_init(*args,**kwargs)
  print('ACTUAL_RAY_RESOURCES '+json.dumps(ray.cluster_resources()),flush=True)
  return result
 ray.init=npu_init
 import datasets
 _load_dataset=datasets.load_dataset
 def fixed_dataset(name,*args,**kwargs):
  if name=='nvidia/OpenMathInstruct-2':
   print('LOCAL_FIXED_DATASET '+os.environ['PRECISION_NEMO_DATASET'],flush=True)
   return _load_dataset('json',data_files=os.environ['PRECISION_NEMO_DATASET'],split='train')
  return _load_dataset(name,*args,**kwargs)
 datasets.load_dataset=fixed_dataset

 from nemo_reinforcer.algorithms.loss_functions import ClippedPGLossFn
 _loss_call=ClippedPGLossFn.__call__
 def observed_loss(self,logits,data):
  result=_loss_call(self,logits,data)
  if logits.device.type=='npu':
   import numpy as np
   folder=pathlib.Path(os.environ['PRECISION_NEMO_CAPTURE']);folder.mkdir(parents=True,exist_ok=True);stem='loss-'+str(os.getpid())+'-'+str(time.time_ns())
   arrays={k:v.detach().cpu().numpy() for k,v in data.items() if torch.is_tensor(v)};np.savez(folder/(stem+'.npz'),**arrays)
   advantages=data['advantages'];mask=data['token_mask']*data['sample_mask'][:,None];effective=advantages[mask.bool()]
   record={'event':'native ClippedPGLossFn completed','loss':float(result[0].detach().cpu()),'metrics':result[1],'masked_action_count':int(mask.sum()),'nonzero_advantage_actions':int((effective!=0).sum()),'advantage_min':float(effective.min()),'advantage_max':float(effective.max()),'data_arrays':stem+'.npz','capture_observational_only':True}
   (folder/(stem+'.json')).write_text(json.dumps(record,indent=2));print('NATIVE_LOSS_OBSERVATION '+json.dumps(record),flush=True)
  return result
 ClippedPGLossFn.__call__=observed_loss
 _adam_step=torch.optim.AdamW.step
 def observed_adam_step(self,*args,**kwargs):
  params=[p for group in self.param_groups for p in group['params']]
  observe=bool(params and params[0].device.type=='npu')
  if observe:
   before=[p.detach().reshape(-1)[:64].cpu().clone() for p in params]
   grads=[p.grad.detach().reshape(-1)[:64].cpu().clone() if p.grad is not None else torch.zeros_like(v) for p,v in zip(params,before)]
   squared_norm=sum(float(p.grad.detach().float().square().sum().item()) for p in params if p.grad is not None)
  result=_adam_step(self,*args,**kwargs)
  if observe:
   from safetensors.torch import save_file
   folder=pathlib.Path(os.environ['PRECISION_NEMO_CAPTURE']);folder.mkdir(parents=True,exist_ok=True);stem='adamw-'+str(os.getpid())+'-'+str(time.time_ns());after=[p.detach().reshape(-1)[:64].cpu().clone() for p in params]
   tensors={f'parameter-{i}-{stage}':v.contiguous() for stage,values in [('before',before),('after',after),('postclip-gradient',grads)] for i,v in enumerate(values)}
   save_file(tensors,str(folder/(stem+'.safetensors')))
   record={'pid':os.getpid(),'event':'native AdamW.step completed','parameter_elements':sum(p.numel() for p in params),'sampled_elements':sum(v.numel() for v in before),'sample_selection':'first min(64,numel) flat elements per optimizer parameter','parameter_indices_shapes':[(i,list(p.shape)) for i,p in enumerate(params)],'device':str(params[0].device),'steps':[float(self.state[p]['step']) for p in params if 'step' in self.state[p]],'sampled_max_stored_update':max(float((x-y).abs().max()) for x,y in zip(after,before)),'postclip_full_gradient_l2':squared_norm**0.5,'sampled_max_abs_gradient':max(float(g.abs().max()) for g in grads),'capture_observational_only':True}
   (folder/(stem+'.json')).write_text(json.dumps(record,indent=2));print('NATIVE_ORCHESTRATOR_ADAMW_COMPLETE '+json.dumps({k:v for k,v in record.items() if k not in ['steps','parameter_indices_shapes']}),flush=True)
  return result
 torch.optim.AdamW.step=observed_adam_step
