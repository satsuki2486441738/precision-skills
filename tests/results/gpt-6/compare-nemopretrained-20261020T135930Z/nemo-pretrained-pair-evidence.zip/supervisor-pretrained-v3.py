import pathlib,os,sys,time,json,subprocess,signal,psutil
root=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);cmd=[sys.executable,'-B',str(root/'source/examples/run_grpo_math.py'),'--config',str(root/'config-pretrained.yaml')]
started=time.time();known={}
with (out/'official-cli.log').open('w') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,cwd=root/'source',start_new_session=True)
 (out/'child-launch.json').write_text(json.dumps({'pid':p.pid,'command':cmd},indent=2))
 while p.poll() is None and time.time()-started<600:
  try:
   for child in psutil.Process(p.pid).children(recursive=True):known[child.pid]=child.create_time()
  except psutil.Error:pass
  time.sleep(2)
 timed_out=p.poll() is None
 if timed_out:
  p.terminate()
  try:p.wait(15)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 rc=p.returncode
 cleaned=[]
 for pid,ctime in reversed(list(known.items())):
  try:
   child=psutil.Process(pid)
   if child.create_time()==ctime and child.is_running():child.terminate();cleaned.append(pid)
  except psutil.Error:pass
 result={'returncode':rc,'timed_out':timed_out,'seconds':time.time()-started,'owned_children_terminated':cleaned,'optimizer_captures':list(map(str,(out/'captures').glob('*.json'))),'official_entrypoint':'examples/run_grpo_math.py','status':'completed' if rc==0 else 'incomplete'}
 (out/'RESULT.json').write_text(json.dumps(result,indent=2))
