"""Independent CPU fixed-trajectory GRPO reference for one NeMo CLI step.

Reads only checkpoint/config and clean *inputs*: train-input.npz plus the four
loss-<pid>-<timestamp>.npz microbatches.  Never reads native losses, current
scores, gradients, updates or optimizer observations.  Does not import NeMo or
the Ascend migration adapter.  Ordinary transformers/accelerate availability
checks may import the installed torch_npu package; those imports are recorded
and permitted only without the vendor migration module.  All model, inputs,
outputs and optimization remain on CPU.  Outputs use safe formats only.
"""

import argparse
import hashlib
import json
import os
import pathlib
import platform
import re
import sys
import time

# Must be set before the first torch/transformers import.  The launcher must
# also omit the native adapter directory from PYTHONPATH and disable its flag.
os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def dump_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def assert_clean_imports():
    forbidden = sorted(
        name for name in sys.modules
        if name == "nemo_reinforcer" or name.startswith("nemo_reinforcer.")
        or name == "torch_npu.contrib.transfer_to_npu"
        or name.startswith("torch_npu.contrib.transfer_to_npu.")
    )
    if forbidden:
        raise RuntimeError("CPU reference imported forbidden native modules: " + repr(forbidden))
    if os.environ.get("PRECISION_NEMO_CLI_ADAPTER") == "1":
        raise RuntimeError("Native CLI adapter flag must be disabled")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", required=True, type=pathlib.Path)
    parser.add_argument("--config", required=True, type=pathlib.Path,
                        help="JSON-format config-pretrained.yaml; contains no native outputs")
    parser.add_argument("--model", default="/host-model/Qwen3-0.6B", type=pathlib.Path)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--seed", type=int, default=20261020)
    args = parser.parse_args()
    assert_clean_imports()
    import numpy as np
    import torch
    import transformers
    from safetensors.torch import save_file
    from transformers import AutoModelForCausalLM
    assert_clean_imports()

    started = time.time()
    if args.threads < 1:
        raise ValueError("--threads must be positive")
    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    config = json.loads(args.config.read_text())
    policy = config["policy"]
    loss_cfg = config["loss_fn"]
    expected_loss = {
        "reference_policy_kl_penalty": 0.01,
        "ratio_eps_min": 0.2,
        "ratio_eps_max": 0.2,
        "use_on_policy_kl_approximation": False,
        "use_importance_sampling_correction": False,
    }
    if any(loss_cfg.get(key) != value for key, value in expected_loss.items()):
        raise ValueError("Unexpected loss config; this bounded reference must be reviewed")
    if loss_cfg.get("disable_ppo_ratio", False):
        raise ValueError("This case requires the PPO probability ratio")
    if policy["precision"] != "float32" or policy["activation_checkpointing_enabled"]:
        raise ValueError("Expected float32 model without activation checkpointing")
    if policy["train_global_batch_size"] != 8 or policy["train_micro_batch_size"] != 2:
        raise ValueError("Expected one global batch of eight in four microbatches of two")
    if policy["max_grad_norm"] != 0.5 or "scheduler" in policy:
        raise ValueError("Expected clip 0.5 and native default constant scheduler")
    optimizer_cfg = policy["optimizer"]
    expected_optimizer = {
        "lr": 0.0001, "weight_decay": 0.01, "betas": [0.9, 0.999],
        "eps": 1e-8, "foreach": False, "fused": False,
    }
    if optimizer_cfg["name"] != "torch.optim.AdamW" or optimizer_cfg["kwargs"] != expected_optimizer:
        raise ValueError("Unexpected optimizer configuration")

    # Read an explicit allow-list only.  No native result JSON/current-score
    # files or native optimizer/gradient artifacts are opened by this program.
    field_names = (
        "input_ids", "input_lengths", "advantages", "generation_logprobs",
        "token_mask", "sample_mask", "prev_logprobs", "reference_policy_logprobs",
    )
    input_dir = args.input_dir.resolve()
    input_paths_read = []

    def load_inputs(path):
        with np.load(path, allow_pickle=False) as archive:
            if set(archive.files) != set(field_names):
                raise ValueError("Unexpected clean input fields in " + str(path))
            arrays = {key: np.array(archive[key], copy=True) for key in field_names}
        input_paths_read.append({"file": path.name, "bytes": path.stat().st_size,
                                 "sha256": sha256_file(path)})
        return arrays

    full = load_inputs(input_dir / "train-input.npz")
    mb_paths = sorted(
        (p for p in input_dir.iterdir() if re.fullmatch(r"loss-\d+-\d+\.npz", p.name)),
        key=lambda p: int(p.stem.rsplit("-", 1)[1]),
    )
    if len(mb_paths) != 4:
        raise ValueError("Require exactly four clean loss-input NPZs")
    microbatches = [load_inputs(path) for path in mb_paths]
    if full["input_ids"].shape[0] != 8:
        raise ValueError("Require eight full-batch trajectories")
    for key in field_names:
        reconstructed = np.concatenate([batch[key] for batch in microbatches], axis=0)
        if reconstructed.dtype != full[key].dtype or not np.array_equal(reconstructed, full[key]):
            raise ValueError("Microbatch order/input mismatch for " + key)
    if full["input_ids"].dtype != np.int64:
        raise ValueError("Expected native int64 token IDs")
    if full["advantages"].dtype != np.float32:
        raise ValueError("Expected native float32 normalized advantages")
    dump_json(out / "clean-input-identities.json", {
        "inputs_read": input_paths_read,
        "config_file": args.config.name, "config_sha256": sha256_file(args.config),
        "microbatch_order": [path.name for path in mb_paths],
        "trajectory_rows_by_microbatch": [[0, 1], [2, 3], [4, 5], [6, 7]],
        "native_outputs_read": [],
    })
    model_files = {
        path.name: {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
        for path in sorted(args.model.iterdir()) if path.is_file()
    }
    dump_json(out / "initial-model-identities.json", {
        "model_store": str(args.model), "public_model_id": "Qwen/Qwen3-0.6B",
        "files": model_files,
    })
    print("CPU_REFERENCE_LOAD_START", flush=True)
    model = AutoModelForCausalLM.from_pretrained(
        str(args.model), device_map="cpu", torch_dtype=torch.float32,
        local_files_only=True,
    )
    assert_clean_imports()
    model.train()
    named_parameters = list(model.named_parameters())
    params = [parameter for _, parameter in named_parameters]
    if len(params) != 310 or len({id(parameter) for parameter in params}) != 310:
        raise ValueError("Unexpected deduplicated optimizer parameter count")
    if sum(parameter.numel() for parameter in params) != 596049920:
        raise ValueError("Unexpected initial model size")
    if any(parameter.device.type != "cpu" or parameter.dtype != torch.float32 for parameter in params):
        raise ValueError("All reference parameters must be CPU float32")
    aliases = {}
    for name, parameter in model.named_parameters(remove_duplicate=False):
        aliases.setdefault(id(parameter), []).append(name)
    tied_groups = [names for names in aliases.values() if len(names) > 1]
    if model.get_input_embeddings().weight is not model.get_output_embeddings().weight:
        raise ValueError("Pretrained tied embeddings must remain tied")
    parameter_records = [
        {"index": index, "name": name, "shape": list(parameter.shape),
         "numel": parameter.numel(), "sample_count": min(64, parameter.numel()),
         "sample_flat_indices": list(range(min(64, parameter.numel())))}
        for index, (name, parameter) in enumerate(named_parameters)
    ]

    def samples_of_parameters():
        return [parameter.detach().reshape(-1)[:64].clone().contiguous() for parameter in params]

    def samples_of_gradients():
        if any(parameter.grad is None for parameter in params):
            raise ValueError("Every bounded-case parameter should have a gradient")
        return [parameter.grad.detach().reshape(-1)[:64].clone().contiguous() for parameter in params]

    before = samples_of_parameters()
    optimizer = torch.optim.AdamW(model.parameters(), **optimizer_cfg["kwargs"])
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda epoch: 1)
    if optimizer.state:
        raise ValueError("The independent optimizer must begin with empty state")
    optimizer.zero_grad()
    losses_scaled = []
    loss_records = []
    score_arrays = []
    coordinates = []
    for mb_index, arrays in enumerate(microbatches):
        data = {key: torch.from_numpy(value) for key, value in arrays.items()}
        if any(value.device.type != "cpu" for value in data.values()):
            raise ValueError("All fixed reference inputs must remain on CPU")
        ids = data["input_ids"]
        # This deliberately matches the source's actual all-ones training mask,
        # including right padding, rather than its separate rescoring mask.
        attention_mask = torch.ones(ids.shape, dtype=torch.long, device="cpu")
        outputs = model(input_ids=ids, attention_mask=attention_mask, use_cache=False)
        logits = outputs.logits.to(torch.float32)
        if logits.device.type != "cpu":
            raise ValueError("Reference forward output must remain on CPU")
        current = torch.nn.functional.log_softmax(logits[:, :-1], dim=-1).gather(
            -1, ids[:, 1:].unsqueeze(-1)
        ).squeeze(-1)
        mask = data["token_mask"][:, 1:] * data["sample_mask"].unsqueeze(-1)
        advantages = data["advantages"][:, 1:]
        old = data["prev_logprobs"][:, 1:]
        reference = data["reference_policy_logprobs"][:, 1:]

        def mean_masked(value):
            return (value * mask).sum() / (mask.sum() + 1e-8)

        ratio = (current - old).exp()
        clipped = ratio.clamp(1.0 - loss_cfg["ratio_eps_min"], 1.0 + loss_cfg["ratio_eps_max"])
        actor_weight = torch.ones_like(old)
        actor = mean_masked(actor_weight * torch.max(-advantages * ratio, -advantages * clipped))
        # Preserve native floating-point operation order: coefficient multiplies
        # each token's estimator before the masked reduction.
        difference = reference - current
        kl_weight = torch.ones_like(current)
        kl = mean_masked(
            kl_weight * loss_cfg["reference_policy_kl_penalty"]
            * (torch.exp(difference) - difference - 1)
        )
        objective = actor + kl
        scaled = objective / 4
        scaled.backward()
        losses_scaled.append(scaled.item())
        current_array = current.detach().numpy().copy()
        score_arrays.append(current_array)
        np.save(out / ("microbatch-" + str(mb_index) + "-current-logprobs.npy"), current_array,
                allow_pickle=False)
        valid = mask.detach().numpy().astype(bool)
        for row, position in zip(*np.nonzero(valid)):
            coordinates.append({"sample": mb_index * 2 + int(row), "position": int(position) + 1,
                                "token_id": int(ids[row, position + 1])})
        record = {
            "microbatch": mb_index, "trajectory_rows": [mb_index * 2, mb_index * 2 + 1],
            "input_file": mb_paths[mb_index].name, "loss": objective.item(),
            "actor_loss": actor.item(), "kl_loss": kl.item(), "scaled_loss": scaled.item(),
            "valid_actions": int(mask.sum().item()),
            "nonzero_advantage_actions": int(((advantages != 0) & mask.bool()).sum().item()),
            "probs_ratio": mean_masked(ratio.detach()).item(),
            "probs_ratio_clamped": mean_masked(clipped.detach()).item(),
            "actor_clipped_branch_actions": int(((clipped != ratio) & mask.bool()).sum().item()),
        }
        loss_records.append(record)
        print("CPU_REFERENCE_MICROBATCH " + json.dumps(record), flush=True)
        del outputs, logits, current, objective, scaled, actor, kl, ratio, clipped
    # This is the worker's report reduction (float32 scalars, sum, world_size=1),
    # independent of and computed before opening any native result artifact.
    global_loss = torch.tensor(losses_scaled).sum().item()
    preclip = samples_of_gradients()
    preclip_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=policy["max_grad_norm"])
    postclip = samples_of_gradients()
    # Same native diagnostic convention (per-parameter float32 reductions and
    # a Python outer sum).  This is not used to build the reference gradients.
    postclip_full_l2 = sum(float(parameter.grad.detach().float().square().sum().item())
                          for parameter in params) ** 0.5
    optimizer.step()
    scheduler.step()
    after = samples_of_parameters()
    tensors = {
        "parameter-" + str(index) + "-" + stage: value
        for stage, values in (("before", before), ("preclip-gradient", preclip),
                              ("postclip-gradient", postclip), ("after", after))
        for index, value in enumerate(values)
    }
    steps = []
    for index, parameter in enumerate(params):
        state = optimizer.state[parameter]
        steps.append(float(state["step"]))
        tensors["parameter-" + str(index) + "-adam-exp-avg"] = state["exp_avg"].detach().reshape(-1)[:64].clone().contiguous()
        tensors["parameter-" + str(index) + "-adam-exp-avg-sq"] = state["exp_avg_sq"].detach().reshape(-1)[:64].clone().contiguous()
    save_file(tensors, str(out / "samples.safetensors"))
    current_all = np.concatenate(score_arrays, axis=0)
    np.save(out / "current-logprobs.npy", current_all, allow_pickle=False)
    valid_all = full["token_mask"][:, 1:] * full["sample_mask"][:, None]
    np.savez(out / "cpu-objective-and-scores.npz", current_logprobs=current_all,
             valid_action_logprobs=current_all[valid_all.astype(bool)],
             mask=valid_all, global_loss=np.array([global_loss], dtype=np.float32),
             scaled_microbatch_losses=np.asarray(losses_scaled, dtype=np.float32),
             unscaled_microbatch_losses=np.asarray([row["loss"] for row in loss_records], dtype=np.float32))
    dump_json(out / "action-coordinates.json", coordinates)
    assert_clean_imports()
    dump_json(out / "RESULT.json", {
        "status": "completed", "seconds": time.time() - started,
        "device": "cpu", "reference_kind": "independent explicit fixed-trajectory objective and fresh AdamW",
        "seed": args.seed, "threads": torch.get_num_threads(),
        "interop_threads": torch.get_num_interop_threads(),
        "python": sys.version, "platform": platform.platform(), "processor": platform.processor(),
        "versions": {"torch": torch.__version__, "transformers": transformers.__version__, "numpy": np.__version__},
        "module_paths": {"torch": torch.__file__, "transformers": transformers.__file__, "numpy": np.__file__},
        "torch_device_backend_autoload": os.environ.get("TORCH_DEVICE_BACKEND_AUTOLOAD"),
        "nemo_modules_imported": False,
        "torch_npu_modules_imported": any(name == "torch_npu" or name.startswith("torch_npu.") for name in sys.modules),
        "torch_npu_import_kind": "ordinary installed package availability imports permitted; vendor migration forbidden",
        "vendor_migration_module_imported": False,
        "vendor_migration_absent": True,
        "native_migration_flag": os.environ.get("PRECISION_NEMO_CLI_ADAPTER"),
        "model_parameter_devices": sorted({str(parameter.device) for parameter in params}),
        "input_tensor_devices": ["cpu"],
        "torch_npu_module_identities": [
            {"module": name, "file": getattr(module, "__file__", None),
             "version": str(getattr(module, "__version__", "unavailable"))}
            for name, module in sorted(sys.modules.items())
            if name == "torch_npu" or name.startswith("torch_npu.")
        ],
        "native_outputs_read": [], "inputs_file": "clean-input-identities.json",
        "model_identities_file": "initial-model-identities.json",
        "dtype": "float32", "model_training": model.training,
        "attention_implementation": getattr(model.config, "_attn_implementation", None),
        "attention_mask": "all ones including right padding, matching native FSDP1PolicyWorker.train",
        "use_cache": False, "matmul_precision": torch.get_float32_matmul_precision(),
        "optimizer": optimizer_cfg, "initial_optimizer_state_entries": 0,
        "scheduler": "LambdaLR(lambda epoch: 1)", "optimizer_steps": steps,
        "lr_before_and_after": [expected_optimizer["lr"], optimizer.param_groups[0]["lr"]],
        "global_batch_size": 8, "micro_batch_size": 2, "gradient_accumulation_divisor": 4,
        "objective_reduction": "FP32 sum of four FP32 microbatch loss/4 values; world_size=1",
        "masked_reduction": "sum(values * token_mask[:,1:] * sample_mask[:,None]) / (sum(mask) + 1e-8)",
        "loss_config": loss_cfg, "native_normalized_advantages_used_as_fixed_inputs": True,
        "rewards_and_rollouts_regenerated": False, "microbatches": loss_records,
        "global_loss": global_loss, "preclip_full_gradient_l2": float(preclip_norm),
        "postclip_full_gradient_l2_float32_diagnostic": postclip_full_l2,
        "clip_max_norm": policy["max_grad_norm"], "clip_norm_type": 2.0,
        "sample_selection": "first min(64,numel) flat elements per deduplicated optimizer parameter",
        "parameter_elements": sum(parameter.numel() for parameter in params),
        "parameter_objects": len(params), "unique_parameter_objects": len({id(parameter) for parameter in params}),
        "sampled_elements": sum(value.numel() for value in before),
        "parameter_records": parameter_records,
        "parameters": [{"name": name, "shape": list(parameter.shape)} for name, parameter in named_parameters],
        "tied_parameter_groups": tied_groups,
        "valid_actions": len(coordinates),
        "sampled_max_stored_update": max(float((x - y).abs().max()) for x, y in zip(after, before)),
        "state_sample_file": "samples.safetensors",
        "objective_score_file": "cpu-objective-and-scores.npz",
    })
    (out / "metadata.json").write_bytes((out / "RESULT.json").read_bytes())
    generated = {path.name: {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
                 for path in sorted(out.iterdir()) if path.is_file()}
    dump_json(out / "FILES.json", generated)
    print("CPU_REFERENCE_COMPLETED " + json.dumps({"output": str(out), "seconds": time.time() - started,
                                                   "loss": global_loss, "valid_actions": len(coordinates),
                                                   "sampled_elements": sum(value.numel() for value in before)}), flush=True)


if __name__ == "__main__":
    main()
