"""Disclosed NeMo CLI adapter: official device migration, Ray NPU isolation, local data, observational step capture."""
import os,sys,pathlib,json,time
if os.environ.get('PRECISION_NEMO_CLI_ADAPTER')=='1':
 import torch,torch_npu
 from torch_npu.contrib import transfer_to_npu
 if os.environ.get('PRECISION_NEMO_SEED'):
  torch.manual_seed(int(os.environ['PRECISION_NEMO_SEED']));torch.npu.manual_seed_all(int(os.environ['PRECISION_NEMO_SEED']))
 import ray
 _ray_init=ray.init
 def npu_init(*args,**kwargs):
  if kwargs.get('address')=='auto':raise ConnectionError('Private NeMo test requires an isolated owned Ray cluster')
  kwargs.update(num_gpus=0,num_cpus=8,resources={'NPU':1},include_dashboard=False,object_store_memory=256*1024*1024,_node_ip_address='127.0.0.1')
  kwargs['_temp_dir']=os.environ['PRECISION_NEMO_RAY_TMP']
  result=_ray_init(*args,**kwargs)
  print('ACTUAL_RAY_RESOURCES '+json.dumps(ray.cluster_resources()),flush=True)
  return result
 ray.init=npu_init
 import datasets
 _load_dataset=datasets.load_dataset
 def fixed_dataset(name,*args,**kwargs):
  if name=='nvidia/OpenMathInstruct-2':
   print('LOCAL_FIXED_DATASET '+os.environ['PRECISION_NEMO_DATASET'],flush=True)
   return _load_dataset('json',data_files=os.environ['PRECISION_NEMO_DATASET'],split='train')
  return _load_dataset(name,*args,**kwargs)
 datasets.load_dataset=fixed_dataset

 from nemo_reinforcer.algorithms.loss_functions import ClippedPGLossFn
 _loss_call=ClippedPGLossFn.__call__
 _loss_context={}
 _log_softmax=torch.nn.functional.log_softmax
 def observed_log_softmax(input,*args,**kwargs):
  result=_log_softmax(input,*args,**kwargs)
  if _loss_context and input.device.type=='npu':
   data=_loss_context['data'];ids=data['input_ids'][:,1:].to(result.device)
   _loss_context['current_logprobs']=result.gather(-1,ids.unsqueeze(-1)).squeeze(-1).detach().cpu().numpy()
  return result
 torch.nn.functional.log_softmax=observed_log_softmax
 def observed_loss(self,logits,data):
  _loss_context['data']=data
  try:result=_loss_call(self,logits,data)
  finally:_loss_context.pop('data',None)
  if logits.device.type=='npu':
   import numpy as np
   folder=pathlib.Path(os.environ['PRECISION_NEMO_CAPTURE']);folder.mkdir(parents=True,exist_ok=True);stem='loss-'+str(os.getpid())+'-'+str(time.time_ns())
   arrays={k:v.detach().cpu().numpy() for k,v in data.items() if torch.is_tensor(v)};np.savez(folder/(stem+'.npz'),**arrays)
   np.save(folder/(stem+'-current-logprobs.npy'),_loss_context.pop('current_logprobs'))
   advantages=data['advantages'];mask=data['token_mask']*data['sample_mask'][:,None];effective=advantages[mask.bool()]
   record={'event':'native ClippedPGLossFn completed','loss':float(result[0].detach().cpu()),'metrics':result[1],'masked_action_count':int(mask.sum()),'nonzero_advantage_actions':int((effective!=0).sum()),'advantage_min':float(effective.min()),'advantage_max':float(effective.max()),'data_arrays':stem+'.npz','capture_observational_only':True}
   (folder/(stem+'.json')).write_text(json.dumps(record,indent=2));print('NATIVE_LOSS_OBSERVATION '+json.dumps(record),flush=True)
  return result
 ClippedPGLossFn.__call__=observed_loss
 _adam_step=torch.optim.AdamW.step
 def observed_adam_step(self,*args,**kwargs):
  params=[p for group in self.param_groups for p in group['params']]
  observe=bool(params and params[0].device.type=='npu')
  if observe:
   before=[p.detach().reshape(-1)[:64].cpu().clone() for p in params]
   grads=[p.grad.detach().reshape(-1)[:64].cpu().clone() if p.grad is not None else torch.zeros_like(v) for p,v in zip(params,before)]
   squared_norm=sum(float(p.grad.detach().float().square().sum().item()) for p in params if p.grad is not None)
  result=_adam_step(self,*args,**kwargs)
  if observe:
   from safetensors.torch import save_file
   folder=pathlib.Path(os.environ['PRECISION_NEMO_CAPTURE']);folder.mkdir(parents=True,exist_ok=True);stem='adamw-'+str(os.getpid())+'-'+str(time.time_ns());after=[p.detach().reshape(-1)[:64].cpu().clone() for p in params]
   tensors={f'parameter-{i}-{stage}':v.contiguous() for stage,values in [('before',before),('after',after),('postclip-gradient',grads)] for i,v in enumerate(values)}
   save_file(tensors,str(folder/(stem+'.safetensors')))
   record={'pid':os.getpid(),'event':'native AdamW.step completed','parameter_elements':sum(p.numel() for p in params),'sampled_elements':sum(v.numel() for v in before),'sample_selection':'first min(64,numel) flat elements per optimizer parameter','unique_optimizer_parameter_objects':len({id(p) for p in params}),'optimizer_parameter_objects':len(params),'native_tied_weight_guard_override':os.environ.get('NRL_SKIP_TIED_WEIGHT_CHECK'),'parameter_indices_shapes':[(i,list(p.shape)) for i,p in enumerate(params)],'device':str(params[0].device),'steps':[float(self.state[p]['step']) for p in params if 'step' in self.state[p]],'sampled_max_stored_update':max(float((x-y).abs().max()) for x,y in zip(after,before)),'postclip_full_gradient_l2':squared_norm**0.5,'sampled_max_abs_gradient':max(float(g.abs().max()) for g in grads),'capture_observational_only':True}
   (folder/(stem+'.json')).write_text(json.dumps(record,indent=2));print('NATIVE_ORCHESTRATOR_ADAMW_COMPLETE '+json.dumps({k:v for k,v in record.items() if k not in ['steps','parameter_indices_shapes']}),flush=True)
  return result
 torch.optim.AdamW.step=observed_adam_step

 if True:
  from nemo_reinforcer.models.policy.hf_policy import HfPolicy
  _policy_train=HfPolicy.train
  def observed_policy_train(self,data,loss_fn,eval_mode=False,gbs=None,mbs=None):
   import numpy as np
   folder=pathlib.Path(os.environ['PRECISION_NEMO_CAPTURE']);folder.mkdir(parents=True,exist_ok=True)
   np.savez(folder/'train-input.npz',**{k:v.detach().cpu().numpy() for k,v in data.items() if torch.is_tensor(v)})
   (folder/'train-input-settings.json').write_text(json.dumps({'global_batch_size':gbs or self.cfg['train_global_batch_size'],'micro_batch_size':mbs or self.cfg['train_micro_batch_size'],'eval_mode':eval_mode,'policy_config':self.cfg,'loss_config':vars(loss_fn),'capture_boundary':'before native HfPolicy.train, tensors copied only'},indent=2,default=str))
   result=_policy_train(self,data,loss_fn,eval_mode=eval_mode,gbs=gbs,mbs=mbs)
   def plain(x):
    if torch.is_tensor(x):return x.detach().cpu().tolist()
    if isinstance(x,dict):return {k:plain(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [plain(v) for v in x]
    return x
   (folder/'native-train-result.json').write_text(json.dumps(plain(result),indent=2))
   return result
  HfPolicy.train=observed_policy_train
  _clip_grad_norm=torch.nn.utils.clip_grad_norm_
  def observed_clip_grad_norm(parameters,*args,**kwargs):
   params=list(parameters);observe=bool(params and params[0].device.type=='npu')
   if observe:
    from safetensors.torch import save_file
    tensors={f'parameter-{i}-preclip-gradient':p.grad.detach().reshape(-1)[:64].cpu().clone().contiguous() for i,p in enumerate(params) if p.grad is not None}
   result=_clip_grad_norm(params,*args,**kwargs)
   if observe:
    folder=pathlib.Path(os.environ['PRECISION_NEMO_CAPTURE']);folder.mkdir(parents=True,exist_ok=True)
    save_file(tensors,str(folder/'preclip-gradients.safetensors'))
    (folder/'native-clip-result.json').write_text(json.dumps({'native_returned_norm':float(result.detach().cpu()),'args':list(args),'kwargs':kwargs,'parameter_shapes':[list(p.shape) for p in params],'capture_observational_only':True},indent=2))
   return result
  torch.nn.utils.clip_grad_norm_=observed_clip_grad_norm
