"""Actual pretrained NPU generation scout: choose a fixed math prompt only from genuine sampled rewards."""
import argparse,pathlib,os,json,time
p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=pathlib.Path(a.output);out.mkdir(exist_ok=False,parents=True)
import torch,torch_npu
from transformers import AutoModelForCausalLM,AutoTokenizer
from math_verify import parse,verify
os.environ['TOKENIZERS_PARALLELISM']='false';torch.set_num_threads(2);torch.npu.set_device(0)
modelpath='/host-model/Qwen3-0.6B';tokenizer=AutoTokenizer.from_pretrained(modelpath,local_files_only=True);tokenizer.chat_template='{% set enable_thinking = false %}'+tokenizer.chat_template
model=AutoModelForCausalLM.from_pretrained(modelpath,torch_dtype=torch.float32,device_map='cpu',local_files_only=True).to('npu');model.eval()
cases=[('What is 17 times 19? Answer with only the integer.','323'),('What is 37 times 23? Answer with only the integer.','851'),('Compute 13*17-8. Answer with only the integer.','213'),('What is 147 plus 286? Answer with only the integer.','433')]
rows=[]
for i,(question,answer) in enumerate(cases):
 seed=20261020+i;torch.manual_seed(seed);torch.npu.manual_seed_all(seed)
 text=tokenizer.apply_chat_template([{'role':'user','content':question}],tokenize=False,add_generation_prompt=True,add_special_tokens=False)
 tokens=tokenizer([text]*8,return_tensors='pt',padding=True).to('npu')
 with torch.no_grad():output=model.generate(**tokens,max_new_tokens=16,do_sample=True,temperature=1.3,top_p=1.0,top_k=0,pad_token_id=tokenizer.pad_token_id,eos_token_id=[tokenizer.eos_token_id],return_dict_in_generate=True,output_scores=True)
 responses=tokenizer.batch_decode(output.sequences[:,tokens['input_ids'].shape[1]:],skip_special_tokens=True);rewards=[]
 for response in responses:
  try:rewards.append(float(verify(parse(answer),parse(response[-100:]))))
  except Exception:rewards.append(0.)
 row={'question':question,'expected_answer':answer,'seed':seed,'responses':responses,'rewards':rewards,'prompt_ids':tokens['input_ids'][0].cpu().tolist(),'generated_ids':output.sequences[:,tokens['input_ids'].shape[1]:].cpu().tolist(),'temperature':1.3,'max_new_tokens':16,'model':modelpath,'tokenizer_chat_template':tokenizer.chat_template};rows.append(row);(out/'scout.json').write_text(json.dumps(rows,indent=2));print(json.dumps({k:v for k,v in row.items() if k!='tokenizer_chat_template'}),flush=True)
 if min(rewards)==0 and max(rewards)==1:
  (out/'chosen.json').write_text(json.dumps(row,indent=2));print('ACTUAL_REWARD_VARIATION_FOUND',flush=True);break
print('SCOUT_COMPLETE',flush=True)
