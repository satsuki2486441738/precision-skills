"""Finish independent CPU references and unchanged skill exports for real DDP.

Only TorchVersion, the native PyTorch version string subclass, is allowlisted
for weights_only reads. No tensor arithmetic, original capture, or native
training implementation is changed. CPU execution runs in separate processes
and consumes only each dedicated starting-input file.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import torch
from torch.torch_version import TorchVersion


def dump(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False,default=str)+'\n')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--tools',type=Path,required=True)
    p.add_argument('--workers',type=int,default=2)
    a=p.parse_args()
    assert not torch.cuda.is_initialized()
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PRECISION_SFT_ROOT=str(a.source_root),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
    sys.path.insert(0,str(a.source_root))
    torch.serialization.add_safe_globals([TorchVersion])
    from export_compare_sft import export
    completions=sorted(a.run.glob('*/rank-*/native-completion.json'))
    assert len(completions)==16,'Four real native cases with four completed ranks are required'
    def finish(completion):
        case=completion.parent
        metadata=json.loads(completion.read_text())
        assert metadata['world_size']==4 and metadata['entrypoint_returned']
        assert metadata['device'].startswith('cuda')
        if not (case/'reference-execution.json').exists():
            with (case/'recovery-reference.log').open('xb')as out:
                subprocess.run([sys.executable,'-B',str(a.source_root/'native_gpu_sft.py'),'--reference','--model',metadata['model'],'--output',str(case)],env=env,check=True,stdout=out,stderr=subprocess.STDOUT)
        reference=json.loads((case/'reference-execution.json').read_text())
        assert reference['device']=='cpu' and reference['reference_topology'].startswith('independent single-process CPU')
        assert reference['native_world_size']==4 and reference['world_size']==1
        output=case/'metrics-recovery-v8'
        result=export(case,output,a.tools)
        assert not (case/'metrics').exists()
        (case/'metrics').symlink_to(output,target_is_directory=True)
        dump(case/'recovery-export-receipt.json',{'status':'completed','native_arithmetic_changed':False,'original_PT_changed':False,
            'weights_only_safe_metadata_class':'torch.torch_version.TorchVersion','reference_execution':'separate CPU process completed before export reads native outcomes','export':result})
        print(json.dumps({'completed_rank':str(case),'native_world_size':4,'reference_world_size':1,'comparisons':5}),flush=True)
        return str(case)
    with ThreadPoolExecutor(max_workers=a.workers)as pool:completed=list(pool.map(finish,completions))
    groups=sorted({path.parent.parent for path in completions})
    original_argv=list(sys.argv)
    for group in groups:
        try:
            sys.argv=[str(a.source_root/'audit_ddp.py'),'--case',str(group),'--world-size','4']
            runpy.run_path(str(a.source_root/'audit_ddp.py'),run_name='__main__')
        finally:sys.argv=original_argv
    dump(a.run/'CPU-RECOVERY-v8.json',{'status':'all_native_ranks_and_independent_CPU_references_compared','native_case_count':len(groups),
         'native_rank_completion_count':len(completed),'native_world_size':4,'reference_world_size':1,'reference_topology':'independent single-process CPU, one local batch per matched native rank; actual DDP equivalence verified separately',
         'rank_comparison_count':len(completed)*5,'DDP_audits':len(groups),'safe_metadata_class':'torch.torch_version.TorchVersion',
         'native_collector_SHA256':hashlib.sha256((a.source_root/'native_gpu_sft.py').read_bytes()).hexdigest(),'native_numeric_implementation_changed':False,'original_capture_files_changed':False,'thresholds':None})


if __name__=='__main__':main()
