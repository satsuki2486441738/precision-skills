#!/usr/bin/env bash
# Real native SFT work only. Run under AFS --training-command "bash suite.sh".
set -uo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export PRECISION_SFT_ROOT="${PRECISION_SFT_ROOT:-$HERE}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}" OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-4}"
export TOKENIZERS_PARALLELISM=false WANDB_MODE=disabled AXOLOTL_DO_NOT_TRACK=1
export PIP_DISABLE_PIP_VERSION_CHECK=1 PIP_NO_COMPILE=1 MAX_JOBS=4
export PYTHONPATH="$HERE${PYTHONPATH:+:$PYTHONPATH}"
BASE_PYTHON="${BASE_PYTHON:-python3}"
export PRECISION_MODEL_REVISION="${PRECISION_MODEL_REVISION:-c1899de289a04d12100db370d81485cdf75e47ca}"
TOOLS="${PRECISION_TOOLS:-$HERE/toolchain}"
RUN="${PRECISION_RUN:-$HERE/runs/compare-gpusft-$(date -u +%Y%m%dT%H%M%SZ)}"
mkdir -p "$RUN" "$HERE/environments" "$HERE/models" "$HERE/cache"
export PIP_CACHE_DIR="$HERE/cache/pip" HF_HOME="$HERE/cache/huggingface"
exec > >(tee -a "$RUN/suite.log") 2>&1
printf '%s\n' "SFT native suite start UTC=$(date -u +%FT%TZ) run=$RUN"
nvidia-smi --query-gpu=index,name,uuid,memory.total,driver_version --format=csv > "$RUN/hardware.csv"
if ! "$BASE_PYTHON" -c 'import sys; assert sys.version_info >= (3,11)'; then
  "$BASE_PYTHON" -m venv "$HERE/environments/python-bootstrap" || exit 1
  "$HERE/environments/python-bootstrap/bin/python" -m pip install uv==0.9.4 > "$RUN/python-bootstrap.log" 2>&1 || exit 1
  "$HERE/environments/python-bootstrap/bin/uv" python install 3.11 >> "$RUN/python-bootstrap.log" 2>&1 || exit 1
  BASE_PYTHON="$("$HERE/environments/python-bootstrap/bin/uv" python find 3.11)"
fi
status=0
install_lane() {
  local lane="$1" torchver="$2"; shift 2
  local envdir="$HERE/environments/$lane" py
  if [[ ! -x "$envdir/bin/python" ]]; then "$BASE_PYTHON" -m venv "$envdir" || return; fi
  py="$envdir/bin/python"
  "$py" -m pip install --upgrade pip setuptools wheel > "$RUN/install-$lane-bootstrap.log" 2>&1 || return
  "$py" -m pip install --dry-run --report "$RUN/resolver-$lane.json" "torch==$torchver" "$@" > "$RUN/resolver-$lane.log" 2>&1 || return
  "$py" -m pip install "torch==$torchver" --index-url https://download.pytorch.org/whl/cu128 > "$RUN/install-$lane-torch.log" 2>&1 || return
  "$py" -m pip install "torch==$torchver" "$@" > "$RUN/install-$lane-packages.log" 2>&1 || return
  "$py" -m pip freeze --all > "$RUN/freeze-$lane.txt"
  "$py" -m pip check > "$RUN/check-$lane.txt" 2>&1 || return
}
prepare_models() {
  py="$1"
  "$py" -B "$HERE/native_gpu_sft.py" --prepare || return
  if [[ -z "${PRECISION_PRETRAINED_MODEL:-}" ]]; then
    for candidate in /host-model/Qwen3-0.6B /data/models/Qwen3-0.6B /workspace/models/Qwen3-0.6B; do
      if [[ -f "$candidate/config.json" ]]; then export PRECISION_PRETRAINED_MODEL="$candidate"; break; fi
    done
  fi
  export PRECISION_PRETRAINED_MODEL="${PRECISION_PRETRAINED_MODEL:-$HERE/models/Qwen3-0.6B}"
  if [[ ! -f "$PRECISION_PRETRAINED_MODEL/config.json" ]]; then
    HF_HUB_OFFLINE=0 "$py" -c 'import os; from huggingface_hub import snapshot_download; snapshot_download("Qwen/Qwen3-0.6B",revision=os.environ["PRECISION_MODEL_REVISION"],local_dir=os.environ["PRECISION_PRETRAINED_MODEL"],ignore_patterns=["*.gguf","*.bin","*.msgpack","*.h5"] )' || return
  fi
}
run_case() {
  py="$1"; framework="$2"; model="$3"; precision="$4"; world="$5"
  case_dir="$RUN/$framework-$model-$precision-w$world"
  printf '%s\n' "START $framework $model $precision world=$world UTC=$(date -u +%FT%TZ)"
  if [[ "$world" -gt 1 ]]; then
    "$py" -m torch.distributed.run --standalone --nnodes=1 --nproc-per-node="$world" "$HERE/native_gpu_sft.py" --framework "$framework" --model "$model" --precision "$precision" --output "$case_dir" > "$case_dir.native.log" 2>&1
  else
    "$py" -B "$HERE/native_gpu_sft.py" --framework "$framework" --model "$model" --precision "$precision" --output "$case_dir" > "$case_dir.native.log" 2>&1
  fi
  code=$?
  printf '%s\n' "$code" > "$case_dir.native.exit"
  if [[ "$code" -ne 0 ]]; then tail -n 35 "$case_dir.native.log"; return "$code"; fi
  for ((rank=0;rank<world;rank++)); do
    CUDA_VISIBLE_DEVICES='' "$py" -B "$HERE/native_gpu_sft.py" --reference --model "$model" --output "$case_dir/rank-$rank" > "$case_dir/rank-$rank/reference.log" 2>&1 || return
    "$py" -B -c 'import sys; from pathlib import Path; from export_compare_sft import export; print(export(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3])))' "$case_dir/rank-$rank" "$case_dir/rank-$rank/metrics" "$TOOLS" > "$case_dir/rank-$rank/export.log" 2>&1 || return
  done
  if [[ "$world" -gt 1 ]]; then
    CUDA_VISIBLE_DEVICES='' "$py" -B "$HERE/audit_ddp.py" --case "$case_dir" --world-size "$world" > "$case_dir/ddp-audit.log" 2>&1 || return
  fi
  printf '%s\n' "COMPLETE $framework $model $precision world=$world UTC=$(date -u +%FT%TZ)"
}
LANES="${PRECISION_LANES:-trl factory swift axolotl bridge}"
for lane in $LANES; do
  case "$lane" in
    trl|swift)
      if [[ ! -f "$RUN/swift-trl.ready" ]]; then
        install_lane swift-trl 2.9.0 transformers==5.3.0 accelerate==1.14.0 datasets==4.8.4 peft==0.20.0 trl==0.29.1 ms-swift==4.6.0 numpy==1.26.4 pyarrow==21.0.0 safetensors || { status=1; continue; }
        touch "$RUN/swift-trl.ready"
      fi
      py="$HERE/environments/swift-trl/bin/python" ;;
    factory)
      install_lane factory 2.9.0 torchvision==0.24.0 torchaudio==2.9.0 transformers==5.3.0 accelerate==1.11.0 datasets==4.0.0 peft==0.18.1 trl==0.24.0 llamafactory==0.9.5 numpy==1.26.4 pyarrow==21.0.0 safetensors || { status=1; continue; }
      py="$HERE/environments/factory/bin/python" ;;
    axolotl)
      install_lane axolotl 2.10.0 axolotl==0.17.0 xformers==0.0.34 numpy==2.2.6 safetensors || { status=1; continue; }
      py="$HERE/environments/axolotl/bin/python" ;;
    bridge)
      if [[ -f "$HERE/bridge_suite.sh" ]]; then bash "$HERE/bridge_suite.sh" "$RUN" || status=1; else printf '%s\n' 'Bridge CUDA adapter missing; lane incomplete' > "$RUN/bridge-unavailable.txt"; status=1; fi
      continue ;;
    *) printf '%s\n' "Unknown lane $lane"; status=1; continue ;;
  esac
  prepare_models "$py" || { status=1; continue; }
  world=1
  if [[ "$lane" == trl ]]; then world="${PRECISION_DDP_WORLD:-4}"; fi
  for model in tiny pretrained; do
    for precision in ${PRECISION_PRECISIONS:-fp32 bf16}; do
      run_case "$py" "$lane" "$model" "$precision" "$world" || status=1
    done
  done
done
printf '%s\n' "SFT suite end UTC=$(date -u +%FT%TZ) status=$status" 
printf '%s\n' "$status" > "$RUN/suite.exit"
exit "$status"
