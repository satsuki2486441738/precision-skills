"""Audit actual DDP completion and identical-sample single-CPU equivalence.

The CPU side remains a single-process reference. Identical ordered samples on
every native rank make native averaged DDP gradients comparable to that local
objective. Report the observed best scalar relative to the independent CPU
gradient rather than assuming a world-size factor or numerical acceptance.
"""
import argparse
import json
from pathlib import Path
import torch


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--case',required=True);p.add_argument('--world-size',required=True,type=int)
 a=p.parse_args();root=Path(a.case)
 ranks=[];baseline=None
 for rank in range(a.world_size):
  case=root/('rank-'+str(rank))
  done=json.loads((case/'native-completion.json').read_text())
  assert done['rank']==rank and done['world_size']==a.world_size and done['entrypoint_returned']
  native=torch.load(case/'native-captures.pt',map_location='cpu',weights_only=True)
  reference=torch.load(case/'reference-captures.pt',map_location='cpu',weights_only=True)
  if baseline is None:baseline=native
  for key in ['input_ids','labels','attention_mask']:
   assert torch.equal(native['batch'][key],baseline['batch'][key]),'Native ranks used different ordered batches'
  assert set(native['before'])==set(baseline['before'])
  for name,value in native['before'].items():
   assert torch.equal(value,baseline['before'][name]),'Native initial rank values differ'
   left,right=native['gradients'][name],baseline['gradients'][name]
   assert (left is None)==(right is None)
   if left is not None:assert torch.equal(left,right),'Synchronized native gradient replicas differ'
  dot=0.;native_sq=0.;reference_sq=0.
  for name,g in native['gradients'].items():
   h=reference['gradients'][name]
   assert (g is None)==(h is None)
   if g is None:continue
   g=g.double();h=h.double()
   dot+=float((g*h).sum());native_sq+=float(g.square().sum());reference_sq+=float(h.square().sum())
  assert reference_sq>0
  ranks.append({'native_rank':rank,'native_device':done['device'],'native_world_size':a.world_size,'reference_world_size':1,'initial_parameters_identical_across_native_ranks':True,'ordered_inputs_labels_masks_identical_across_native_ranks':True,'synchronized_native_gradient_replicas_bitwise_equal':True,'best_native_scalar_relative_to_single_cpu_gradient':dot/reference_sq,'native_to_cpu_gradient_norm_ratio':(native_sq/reference_sq)**.5,'native_gradient_l2':native_sq**.5,'reference_gradient_l2':reference_sq**.5})
 result={'native_topology':'actual CUDA DDP','native_world_size':a.world_size,'reference_topology':'independent single-process CPU local-batch recomputation','reference_world_size':1,'equivalence_condition':'every native rank used identical initial values and the same ordered input, labels and mask; native DDP averages identical local-objective gradients','rank_completion_count':len(ranks),'ranks':ranks,'thresholds':None,'numerical_acceptance_not_claimed':True}
 (root/'ddp-audit.json').write_text(json.dumps(result,indent=2,allow_nan=False))
 print(json.dumps(result,indent=2))


if __name__=='__main__':main()
