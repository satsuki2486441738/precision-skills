#!/usr/bin/env bash
set -euo pipefail
ADAPTER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
WORK_ROOT=${SLIME_WORK_ROOT:-$ADAPTER/work}
GPU_IDS=${SLIME_GPU_IDS:-0,1}
CASES=${SLIME_CASES:-tiny,pretrained}
SKILL_ROOT=${SLIME_SKILL_ROOT:-}
INSTALL=1
SPLIT_DEBUG=0
TRAIN_DEBUG_DATA=''
while (($#)); do
  case "$1" in
    --work-root) WORK_ROOT=$2; shift 2;;
    --gpu-ids) GPU_IDS=$2; shift 2;;
    --cases) CASES=$2; shift 2;;
    --skill-root) SKILL_ROOT=$2; shift 2;;
    --no-install) INSTALL=0; shift;;
    --split-debug) SPLIT_DEBUG=1; shift;;
    --train-debug-data) TRAIN_DEBUG_DATA=$2; shift 2;;
    *) printf 'Unknown argument: %s\n' "$1" >&2; exit 2;;
  esac
done
mkdir -p "$WORK_ROOT"
WORK_ROOT=$(cd "$WORK_ROOT" && pwd)
if [[ "$INSTALL" == 1 ]]; then
  UV=${UV:-$(command -v uv || true)}
  if [[ -z "$UV" ]]; then
    python3 -m pip install --user uv
    UV="$HOME/.local/bin/uv"
  fi
  "$UV" venv --python 3.11 "$WORK_ROOT/.venv"
  "$UV" pip install --python "$WORK_ROOT/.venv/bin/python" 'sglang==0.5.9' 'torchvision==0.24.1' 'ray[default]==2.54.0' \
    'accelerate==1.12.0' 'sglang-router==0.2.3' wandb tensorboard omegaconf mcp blobfile numba pillow pylatexenc pyyaml qwen_vl_utils memray 'ring-flash-attn==0.1.8' \
    >"$WORK_ROOT/install.log" 2>&1
  "$UV" pip install --python "$WORK_ROOT/.venv/bin/python" --no-deps -e "$ADAPTER/source" >>"$WORK_ROOT/install.log" 2>&1
fi
PYTHON="$WORK_ROOT/.venv/bin/python"
export PATH="$WORK_ROOT/.venv/bin:$PATH"
if [[ -n "${SLIME_CUDA_HOME:-}" ]]; then
  export CUDA_HOME="$SLIME_CUDA_HOME"
elif [[ -z "${CUDA_HOME:-}" ]] && ! command -v nvcc >/dev/null; then
  if [[ ! -f "$WORK_ROOT/cuda-toolkit/NVIDIA-REDISTRIBUTABLES.json" ]] || [[ ! -e "$WORK_ROOT/cuda-toolkit/lib64/libcudart.so" ]]; then
    "$PYTHON" "$ADAPTER/prepare_cuda_toolkit.py" --root "$WORK_ROOT/cuda-toolkit" >"$WORK_ROOT/cuda-toolkit.log" 2>&1
  fi
  export CUDA_HOME="$WORK_ROOT/cuda-toolkit"
fi
if [[ -n "${CUDA_HOME:-}" ]]; then export PATH="$CUDA_HOME/bin:$PATH"; fi
LOCAL_IPS=$(hostname -I | tr ' ' ',')
export NO_PROXY="${NO_PROXY:-},localhost,127.0.0.1,$LOCAL_IPS"
export no_proxy="$NO_PROXY"
export LD_LIBRARY_PATH="$WORK_ROOT/syslibs/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
if ! "$PYTHON" -c "import ctypes; ctypes.CDLL('libnuma.so.1')" 2>/dev/null; then
  mkdir -p "$WORK_ROOT/syslibs"
  (cd "$WORK_ROOT/syslibs" && apt download libnuma1 >install.log 2>&1 && dpkg-deb -x libnuma1_*.deb .)
fi
export PYTHONUNBUFFERED=1 TOKENIZERS_PARALLELISM=false WANDB_MODE=disabled
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-2} MKL_NUM_THREADS=${MKL_NUM_THREADS:-2} MAX_JOBS=${MAX_JOBS:-2}
export PYTHONPATH="$ADAPTER:$ADAPTER/source${PYTHONPATH:+:$PYTHONPATH}"
export HF_HOME="$WORK_ROOT/hf-cache"
export SLIME_SKILL_ROOT="$SKILL_ROOT"
MODEL_ARGS=()
if [[ -n "${SLIME_PRETRAINED_LOCAL:-}" ]]; then MODEL_ARGS+=(--pretrained-local "$SLIME_PRETRAINED_LOCAL"); fi
"$PYTHON" "$ADAPTER/prepare_models.py" --root "$WORK_ROOT/models" "${MODEL_ARGS[@]}" >"$WORK_ROOT/models.log" 2>&1
IFS=',' read -r -a CASE_ARRAY <<< "$CASES"
IFS=',' read -r -a GPU_ARRAY <<< "$GPU_IDS"
for CASE in "${CASE_ARRAY[@]}"; do
  RUN="$WORK_ROOT/$(date -u +compare-slime-${CASE}-%Y%m%dT%H%M%SZ)"
  mkdir "$RUN"
  mkdir "$RUN/native"
  mkdir "$RUN/adapter-source"
  cp "$ADAPTER/"{native_capture.py,sitecustomize.py,driver.py,cpu_reference.py,prepare_models.py,prepare_cuda_toolkit.py,launch_slime.sh} "$RUN/adapter-source/"
  sha256sum "$RUN/adapter-source/"* >"$RUN/adapter-source.SHA256"
  export PYTHONPATH="$RUN/adapter-source:$ADAPTER/source"
  export SLIME_NATIVE_SOURCE="$ADAPTER/source"
  export SLIME_PRECISION_CAPTURE=1 SLIME_PRECISION_OUTPUT="$RUN/native"
  export CUDA_VISIBLE_DEVICES="$GPU_IDS"
  export CUBLAS_WORKSPACE_CONFIG=:4096:8 NCCL_CUMEM_ENABLE=0
  MODE=official-train-loop
  if [[ "$SPLIT_DEBUG" == 1 ]]; then MODE=official-split-debug-partial; fi
  if [[ -n "$TRAIN_DEBUG_DATA" ]]; then MODE=official-debug-train-retained-partial; fi
  printf '{"mode":"%s"}\n' "$MODE" >"$RUN/workflow-scope.json"
  NATIVE_ARGS=(--train-backend fsdp --actor-num-nodes 1 --actor-num-gpus-per-node 1
    --num-gpus-per-node "${#GPU_ARRAY[@]}" --rollout-num-gpus 1 --rollout-num-gpus-per-engine 1
    --hf-checkpoint "$WORK_ROOT/models/$CASE" --attn-implementation eager
    --prompt-data "$WORK_ROOT/models/prompts.jsonl" --input-key input
    --num-rollout 1 --rollout-batch-size 2 --n-samples-per-prompt 2 --global-batch-size 4 --micro-batch-size 1
    --rollout-max-response-len 6 --rollout-max-context-len 128 --rollout-temperature 1 --rollout-top-p 1 --rollout-top-k -1
    --seed 20261022 --rollout-seed 20261022 --custom-rm-path native_capture.synthetic_reward
    --advantage-estimator grpo --entropy-coef 0 --kl-coef 0 --kl-loss-coef 0
    --eps-clip 0.2 --eps-clip-high 0.2 --clip-grad 0.1
    --optimizer adam --lr 0.00001 --lr-warmup-iters 0 --lr-decay-style constant
    --adam-beta1 0.9 --adam-beta2 0.95 --adam-eps 0.00000001 --weight-decay 0.01
    --sglang-dtype bfloat16 --sglang-attention-backend triton --sglang-sampling-backend pytorch
    --sglang-disable-cuda-graph --sglang-mem-fraction-static 0.25 --sglang-max-running-requests 4
    --sglang-max-total-tokens 256 --sglang-chunked-prefill-size 128 --sglang-max-prefill-tokens 128
    --sglang-context-length 128 --sglang-log-level info --update-weight-buffer-size 67108864)
  if [[ "${#GPU_ARRAY[@]}" == 1 ]]; then
    NATIVE_ARGS+=(--colocate --no-offload-train --no-offload-rollout)
  fi
  if [[ "$SPLIT_DEBUG" == 1 ]]; then
    mkdir "$RUN/native-rollout"
    export SLIME_PRECISION_OUTPUT="$RUN/native-rollout"
    set +e
    "$PYTHON" "$RUN/adapter-source/driver.py" "${NATIVE_ARGS[@]}" --debug-rollout-only \
      --save-debug-rollout-data "$RUN/native-rollout/rollout_{rollout_id}.pt" >"$RUN/rollout.log" 2>&1
    CODE=$?
    set -e
    printf '{"rollout_only_exit_code":%s}\n' "$CODE" >"$RUN/rollout-exit.json"
    if [[ "$CODE" != 0 ]]; then tail -n 40 "$RUN/rollout.log"; exit "$CODE"; fi
    export SLIME_PRECISION_OUTPUT="$RUN/native"
    "$PYTHON" - "$RUN/debug-config.json" "$RUN/native-rollout/rollout_{rollout_id}.pt" <<'PY'
import json,sys
from pathlib import Path
Path(sys.argv[1]).write_text(json.dumps({'load_debug_rollout_data': sys.argv[2]}))
PY
    NATIVE_ARGS+=(--debug-train-only --custom-config-path "$RUN/debug-config.json")
  fi
  if [[ -n "$TRAIN_DEBUG_DATA" ]]; then
    mkdir "$RUN/native-rollout"
    cp "$TRAIN_DEBUG_DATA" "$RUN/native-rollout/rollout_0.pt"
    sha256sum "$TRAIN_DEBUG_DATA" "$RUN/native-rollout/rollout_0.pt" >"$RUN/retained-rollout.SHA256"
    "$PYTHON" - "$RUN/debug-config.json" "$RUN/native-rollout/rollout_{rollout_id}.pt" <<'PY'
import json,sys
from pathlib import Path
Path(sys.argv[1]).write_text(json.dumps({'load_debug_rollout_data': sys.argv[2]}))
PY
    NATIVE_ARGS+=(--debug-train-only --custom-config-path "$RUN/debug-config.json")
  fi
  printf '%q ' "$PYTHON" "$RUN/adapter-source/driver.py" "${NATIVE_ARGS[@]}" >"$RUN/command.txt"
  printf '\n' >>"$RUN/command.txt"
  set +e
  "$PYTHON" "$RUN/adapter-source/driver.py" "${NATIVE_ARGS[@]}" >"$RUN/native.log" 2>&1
  CODE=$?
  set -e
  unset SLIME_PRECISION_CAPTURE SLIME_PRECISION_OUTPUT
  printf '{"native_exit_code":%s}\n' "$CODE" >"$RUN/native-exit.json"
  if [[ "$CODE" != 0 ]]; then tail -n 70 "$RUN/native.log"; exit "$CODE"; fi
  export CUDA_VISIBLE_DEVICES=''
  if [[ -n "$SKILL_ROOT" ]]; then
    "$PYTHON" "$RUN/adapter-source/cpu_reference.py" --run "$RUN" --model "$WORK_ROOT/models/$CASE" --skill-root "$SKILL_ROOT" >"$RUN/reference.log" 2>&1
  fi
  printf 'SLIME_COMPLETED %s\n' "$RUN"
done
