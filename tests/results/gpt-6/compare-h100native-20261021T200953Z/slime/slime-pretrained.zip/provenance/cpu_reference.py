"""Independent CPU FP32 recomputation, portable comparison and indexed replay.

Before completing its own backward, clipping and AdamW update, the reference
reads only rollout trajectories, initial configuration and parameter inventory.
It reloads the original immutable checkpoint; no native gradient, current score,
objective result or updated parameter is an input to the independent execution.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import socket
import subprocess
import sys
import time
import numpy as np
import torch
from transformers import AutoModelForCausalLM

p = argparse.ArgumentParser()
p.add_argument('--run', required=True)
p.add_argument('--model', required=True)
p.add_argument('--skill-root', required=True)
p.add_argument('--native-source', help='Retain an existing native capture in a fresh reference/comparison run; never mutate source evidence.')
a = p.parse_args()
run = Path(a.run).resolve()
if a.native_source:
    source_run = Path(a.native_source).resolve()
    assert source_run.is_dir() and not run.exists()
    run.mkdir(parents=True)
    shutil.copytree(source_run / 'native', run / 'native')
    for name in ['native-rollout', 'adapter-source']:
        if (source_run / name).exists():
            shutil.copytree(source_run / name, run / name)
    for name in ['command.txt', 'native-exit.json', 'native.log', 'runtime-probe.json', 'runtime-probe-rollout.json',
            'workflow-scope.json', 'adapter-source.SHA256', 'rollout.log', 'rollout-exit.json', 'driver-runtime.json']:
        if (source_run / name).exists():
            shutil.copy2(source_run / name, run / name)
    (run / 'reference-source.json').write_text(json.dumps({'native_source_run': str(source_run),
        'reference_adapter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'mode': 'new independent CPU computation from retained native rollout and original immutable checkpoint'}, indent=2))
native = run / 'native'
model_path = Path(a.model).resolve()
skill = Path(a.skill_root).resolve()
torch.set_num_threads(int(os.environ.get('OMP_NUM_THREADS', '2')))

def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    return path

def event_metadata(event):
    return [json.loads(path.read_text()) for path in sorted(native.glob(event + '-pid*.json'))]

def event_data(meta):
    return torch.load(native / meta['data'], map_location='cpu', weights_only=False)

initial_meta = event_metadata('initial')
assert len(initial_meta) == 1
initial_meta = initial_meta[0]
# Configuration is allowed; initial numeric values are deliberately not used.
initial_payload = event_data(initial_meta)
settings = initial_payload['args']
del initial_payload
converted_meta = event_metadata('rollout-conversion')
assert len(converted_meta) == 1
converted = event_data(converted_meta[0])
samples = converted['samples']
assert len(samples) == 4
assert all(s['response_length'] > 0 for s in samples)
selected_names = [row['name'] for row in initial_meta['inventory'] if row['selected']]
groups = {}
for i, sample in enumerate(samples):
    groups.setdefault(sample['group_index'], []).append(i)
assert len(groups) == 2 and all(len(g) == 2 for g in groups.values())
rewards = torch.tensor([float(s['index'] % 2) + sum(s['tokens'][-s['response_length']:]) % 17 / 100.0 for s in samples], dtype=torch.float32)
advantages = torch.empty_like(rewards)
group_means, group_stds = [], []
for indices in groups.values():
    r = rewards[indices]
    mean = r.mean()
    centered = r - mean
    std = centered.std(unbiased=True)
    advantages[indices] = centered / (std + 1e-6)
    group_means.append(float(mean))
    group_stds.append(float(std))
assert all(v > 0 for v in group_stds)

model = AutoModelForCausalLM.from_pretrained(model_path, dtype=torch.float32,
    attn_implementation='eager', local_files_only=True).cpu().train()
assert all(p.dtype == torch.float32 and p.device.type == 'cpu' for p in model.parameters())
parameters = dict(model.named_parameters())
assert set(selected_names).issubset(parameters)
before = {name: parameters[name].detach().clone() for name in selected_names}
temperature = float(settings['rollout_temperature'])

def score(sample):
    ids = torch.tensor(sample['tokens'], dtype=torch.long).unsqueeze(0)
    logits = model(input_ids=ids, position_ids=torch.arange(ids.shape[1]).unsqueeze(0), attention_mask=None).logits[0].float()
    r = sample['response_length']
    targets = ids[0, -r:]
    action_logits = logits[-r - 1:-1]
    logps = torch.log_softmax(action_logits / temperature, dim=-1).gather(-1, targets.unsqueeze(-1)).squeeze(-1)
    full_logps = torch.log_softmax(action_logits, dim=-1)
    entropy = -(torch.softmax(action_logits, dim=-1) * full_logps).sum(-1)
    return logps, entropy

with torch.no_grad():
    old_logps = [score(s)[0] for s in samples]
current_logps, entropies, objective_values, ratios, branches = [], [], [], [], []
model.zero_grad(set_to_none=True)
for i, sample in enumerate(samples):
    current, entropy = score(sample)
    ratio = torch.exp(current - old_logps[i])
    unclipped = -ratio * advantages[i]
    clipped = -ratio.clamp(1 - settings['eps_clip'], 1 + settings['eps_clip_high']) * advantages[i]
    mask = torch.tensor(sample.get('loss_mask') or [1] * sample['response_length'], dtype=torch.float32)
    loss = (torch.maximum(unclipped, clipped) * mask).sum() / mask.sum().clamp_min(1)
    loss = loss - settings['entropy_coef'] * (entropy * mask).sum() / mask.sum().clamp_min(1)
    assert not settings['use_kl_loss'] and not settings['use_opsm']
    scaled = loss / settings['global_batch_size']
    scaled.backward()
    current_logps.append(current.detach())
    entropies.append(entropy.detach())
    objective_values.append(float(scaled.detach()))
    ratios.append(ratio.detach())
    branches.append((clipped > unclipped).float().detach())
pre = {name: None if parameters[name].grad is None else parameters[name].grad.detach().clone() for name in selected_names}
full_preclip = sum(p.grad.detach().double().square().sum().item() for p in model.parameters() if p.grad is not None) ** 0.5
returned_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), settings['clip_grad'])
post = {name: None if parameters[name].grad is None else parameters[name].grad.detach().clone() for name in selected_names}
optimizer = torch.optim.AdamW(model.parameters(), lr=settings['lr'], betas=(settings['adam_beta1'], settings['adam_beta2']),
    eps=settings['adam_eps'], weight_decay=settings['weight_decay'])
optimizer.step()
after = {name: parameters[name].detach().clone() for name in selected_names}
reference_finished = time.time()
reference = dict(before=before, after=after, preclip_gradients=pre, postclip_gradients=post,
    rewards=rewards, advantages=advantages, old_logps=old_logps, current_logps=current_logps,
    entropies=entropies, objective_values=objective_values, ratios=ratios, branches=branches,
    group_means=group_means, group_stds=group_stds, full_preclip_norm=full_preclip,
    returned_clip_norm=float(returned_norm), reference_complete_time=reference_finished)
torch.save(reference, run / 'independent-reference.pt')

# Only now consume native numeric objective, gradient and updated-state output.
initial = event_data(initial_meta)
clip_meta = event_metadata('clip')
pre_meta = event_metadata('optimizer-pre')
post_meta = event_metadata('optimizer-post')
assert len(clip_meta) == len(pre_meta) == len(post_meta) == 1
if 'optimizer_state_entries' in pre_meta[0]:
    assert pre_meta[0]['optimizer_state_entries'] == 0
for group in pre_meta[0]['groups']:
    assert group['lr'] == settings['lr'] and group['weight_decay'] == settings['weight_decay']
    assert group['betas'] == [settings['adam_beta1'], settings['adam_beta2']] and group['eps'] == settings['adam_eps']
clip = event_data(clip_meta[0])
native_pre = event_data(pre_meta[0])
native_post = event_data(post_meta[0])
objective_metas = sorted(event_metadata('objective'), key=lambda x: x['mbs_id'])
assert len(objective_metas) == 4
objectives = [event_data(meta) for meta in objective_metas]
normalization_metas = event_metadata('native-group-normalization')
assert len(normalization_metas) == 1
normalization = event_data(normalization_metas[0])
native_scores, native_old, native_adv, native_masks = {}, {}, {}, {}
available = set(range(len(samples)))
for obj in objectives:
    tokens = obj['packed_batch']['tokens'].tolist()
    matches = [i for i in available if samples[i]['tokens'] == tokens]
    assert matches, 'Native pack must contain exactly one original trajectory'
    i = matches[0]
    available.remove(i)
    native_scores[i] = obj['log_probs']
    native_old[i] = obj['old_log_probs']
    native_adv[i] = obj['advantages']
    native_masks[i] = obj['loss_masks'][0]
assert not available
assert all(torch.equal(before[n], initial['parameters'][n].float()) for n in selected_names), 'Initial checkpoint values differ'
assert torch.equal(rewards, torch.tensor(converted['train_data']['raw_reward'], dtype=torch.float32))
assert torch.equal(advantages, torch.tensor(converted['train_data']['rewards'], dtype=torch.float32))
assert post_meta[0]['nonzero_update']

out = run / 'portable'
out.mkdir()
provenance = out / 'provenance'
provenance.mkdir()
private_originals = []
for folder in [native, run / 'native-rollout']:
    if folder.exists():
        for path in sorted(folder.rglob('*.pt')):
            private_originals.append({'path': path.relative_to(run).as_posix(),
                'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
write(provenance / 'private-original-artifacts.json', {'retention': 'Original PT files remain private and unchanged; this public receipt records their original bytes.',
    'public_numeric_arrays': 'NPY and safetensors preserve captured numeric storage independently of private text metadata.',
    'files': private_originals})
for path in native.glob('*.json'):
    shutil.copy2(path, provenance / path.name)
for path in (run / 'command.txt', run / 'native-exit.json', run / 'native.log', run / 'runtime-probe.json',
        run / 'workflow-scope.json', run / 'adapter-source.SHA256', run / 'rollout.log', run / 'rollout-exit.json', run / 'driver-runtime.json'):
    if path.exists():
        shutil.copy2(path, provenance / path.name)
if (run / 'runtime-probe-rollout.json').exists():
    shutil.copy2(run / 'runtime-probe-rollout.json', provenance / 'runtime-probe-rollout.json')
if (run / 'reference-source.json').exists():
    shutil.copy2(run / 'reference-source.json', provenance / 'reference-source.json')
if (run / 'adapter-source').exists():
    shutil.copytree(run / 'adapter-source', provenance / 'native-adapter-source')
for name in ('native_capture.py', 'driver.py', 'cpu_reference.py', 'prepare_models.py', 'prepare_cuda_toolkit.py', 'sitecustomize.py', 'launch_slime.sh'):
    shutil.copy2(Path(__file__).parent / name, provenance / name)
write(out / 'trajectories.json', samples)
write(out / 'parameter-inventory.json', initial_meta['inventory'])
write(out / 'reference-identity.json', dict(device='cpu', dtype='float32', torch=torch.__version__,
    original_checkpoint=str(model_path), independent_completion_time=reference_finished,
    native_output_arrays_read_after_independent_completion=True))
input_hash = hashlib.sha256(json.dumps(samples, sort_keys=True).encode()).hexdigest()
model_manifest = Path(a.model).absolute().parent / (Path(a.model).name + '-manifest.json')
assert model_manifest.exists()
model_identity = hashlib.sha256(model_manifest.read_bytes()).hexdigest()
common = dict(model=model_identity, inputs=input_hash,
    scope='one native slime GRPO optimizer step; complete trajectories; selected complete named parameter tensors',
    state='same original checkpoint; exact equality of selected initial FP32 storage checked')
conditions = {'native': {'numerics': 'CUDA official slime: SGLang BF16 rollout, FSDP2 BF16 actor compute, FP32 gradient reduction; measured storage dtypes in inventory'},
    'reference': {'numerics': 'independent CPU FP32 eager forward/backward and AdamW'}}
for side in ('native', 'reference'):
    folder = out / side
    folder.mkdir()
    versions = initial_meta['runtime']['modules'] if side == 'native' else {'torch': torch.__version__, 'numpy': np.__version__}
    write(folder / 'environment.json', dict(rank=0, versions=versions, actual={**common, **conditions[side]}))
    write(folder / 'status.json', dict(rank=0, status='completed'))

def save_array(folder, filename, value):
    if value.dtype == torch.bfloat16:
        from safetensors.torch import save_file
        filename += '.safetensors'
        save_file({'value': value.contiguous()}, str(folder / filename))
        return {'path': filename, 'key': 'value'}
    filename += '.npy'
    np.save(folder / filename, value.detach().cpu().contiguous().numpy(), allow_pickle=False)
    return {'path': filename}

reports, replay = {}, []
def compare_stage(stage, tensors, values):
    contract = write(out / (stage + '.contract.json'), dict(schema_version=2, kind='tensors', common=common,
        side_conditions=conditions, thresholds=None, expected_ranks={'native': [0], 'reference': [0]}, stage=stage, tensors=tensors))
    for side in ('native', 'reference'):
        folder = out / side
        entries = []
        for index, tensor in enumerate(tensors):
            entry = {**tensor, 'shards': []}
            if tensor['present']:
                shard = {'offset': 0}
                for kind, value in values[side][tensor['name']].items():
                    shard[kind] = save_array(folder, f'{stage}-{index:03}-{kind}', value)
                entry['shards'] = [shard]
            entries.append(entry)
        manifest = dict(schema_version=2, kind='tensors', common=common, side=side, expected_ranks=[0],
            ranks=[dict(rank=0, environment='environment.json', status='status.json')], stage=stage, tensors=entries)
        if stage == 'updates':
            manifest['events'] = {'policy': 'applied'}
        write(folder / (stage + '.manifest.json'), manifest)
    report_path = out / (stage + '.report.json')
    subprocess.run([sys.executable, str(skill / 'scripts/compare_tensors.py'), '--contract', str(contract),
        '--side-a', str(out / 'native' / (stage + '.manifest.json')), '--side-b', str(out / 'reference' / (stage + '.manifest.json')),
        '--output', str(report_path)], check=True)
    reports[stage] = json.loads(report_path.read_text())
    replay.append(dict(name=stage, operation='compare_tensors', inputs={'contract': contract.name,
        'side_a': 'native/' + stage + '.manifest.json', 'side_b': 'reference/' + stage + '.manifest.json'},
        expected={'status': 'no_thresholds', 'global': reports[stage]['global']}))

for stage, native_key, ref_values in [('gradients', 'gradients', pre), ('postclip-gradients', 'postclip_gradients', post)]:
    tensors = [dict(name=n, shape=list(before[n].shape), present=pre[n] is not None) for n in selected_names]
    values = {'native': {n: {'value': clip[native_key][n]} for n in selected_names},
              'reference': {n: {'value': ref_values[n]} for n in selected_names}}
    compare_stage(stage, tensors, values)
tensors = [dict(name=n, shape=list(before[n].shape), present=True) for n in selected_names]
compare_stage('updates', tensors, {'native': {n: {'before': native_pre['parameters'][n], 'after': native_post['parameters'][n]} for n in selected_names},
    'reference': {n: {'before': before[n], 'after': after[n]} for n in selected_names}})

observations = {'native': {}, 'reference': {}}
for side in observations:
    observations[side]['reward'] = rewards if side == 'reference' else torch.tensor(converted['train_data']['raw_reward'], dtype=torch.float32)
    observations[side]['normalized-reward'] = advantages if side == 'reference' else torch.tensor(converted['train_data']['rewards'], dtype=torch.float32)
    observations[side]['group-mean'] = torch.tensor(group_means, dtype=torch.float32) if side == 'reference' else normalization['mean'].reshape(-1)
    observations[side]['group-unbiased-std'] = torch.tensor(group_stds, dtype=torch.float32) if side == 'reference' else normalization['std'].reshape(-1)
    observations[side]['advantage-per-action'] = torch.cat([advantages[i].repeat(s['response_length']) if side == 'reference' else native_adv[i] for i, s in enumerate(samples)])
    observations[side]['old-logprob'] = torch.cat(old_logps if side == 'reference' else [native_old[i] for i in range(4)])
    observations[side]['current-logprob'] = torch.cat(current_logps if side == 'reference' else [native_scores[i] for i in range(4)])
    observations[side]['importance-ratio'] = torch.exp(observations[side]['current-logprob'] - observations[side]['old-logprob'])
    observations[side]['clip-upper-branch'] = torch.cat(branches) if side == 'reference' else torch.cat([
        (-torch.exp(native_scores[i] - native_old[i]).clamp(1 - settings['eps_clip'], 1 + settings['eps_clip_high']) * native_adv[i] >
         -torch.exp(native_scores[i] - native_old[i]) * native_adv[i]).float() for i in range(4)])
    observations[side]['loss'] = torch.tensor([sum(objective_values) if side == 'reference' else sum(float(o['loss']) for o in objectives)], dtype=torch.float32)
coordinates = {'boundary': 'native first optimizer step and independently recomputed fixed trajectories',
    'samples': [{'sample': str(s['index']), 'group': str(s['group_index']), 'response_length': s['response_length'],
        'action_positions': list(range(len(s['tokens']) - s['response_length'], len(s['tokens'])))} for s in samples],
    'derived_native_observations': ['importance-ratio', 'clip-upper-branch'], 'native_loss': 'sum of captured scaled microbatch losses'}
tensors = [dict(name=n, shape=list(value.shape), present=True, coordinates=coordinates) for n, value in observations['native'].items()]
compare_stage('observations', tensors, {side: {n: {'value': value} for n, value in values.items()} for side, values in observations.items()})

targets, rows = [], {'native': [], 'reference': []}
for i, sample in enumerate(samples):
    mask = sample.get('loss_mask') or [1] * sample['response_length']
    for j, include in enumerate(mask):
        if not include:
            continue
        position = len(sample['tokens']) - sample['response_length'] + j
        coordinate = dict(sample=str(sample['index']), position=position, token=sample['tokens'][position])
        targets.append(coordinate)
        rows['native'].append({**coordinate, 'logprob': float(native_scores[i][j])})
        rows['reference'].append({**coordinate, 'logprob': float(current_logps[i][j])})
contract = write(out / 'target-scores.contract.json', dict(schema_version=1, kind='target-scores', common=common,
    side_conditions=conditions, thresholds=None, expected_ranks={'native': [0], 'reference': [0]}, targets=targets))
for side in rows:
    write(out / side / 'target-scores.manifest.json', dict(schema_version=1, kind='target-scores', common=common,
        side=side, expected_ranks=[0], ranks=[dict(rank=0, environment='environment.json', status='status.json')], scores=rows[side]))
score_report = out / 'target-scores.report.json'
subprocess.run([sys.executable, str(skill / 'scripts/compare_target_scores.py'), '--contract', str(contract),
    '--side-a', str(out / 'native/target-scores.manifest.json'), '--side-b', str(out / 'reference/target-scores.manifest.json'),
    '--output', str(score_report)], check=True)
reports['target-scores'] = json.loads(score_report.read_text())
replay.append(dict(name='target-scores', operation='compare_target_scores', inputs={'contract': contract.name,
    'side_a': 'native/target-scores.manifest.json', 'side_b': 'reference/target-scores.manifest.json'},
    expected={'status': 'no_thresholds', 'metrics': reports['target-scores']['metrics']}))
for score_stage, native_values, reference_values in [
    ('old-target-scores', [native_old[i] for i in range(4)], old_logps),
    ('rollout-target-scores', [torch.tensor(s['rollout_log_probs'], dtype=torch.float32) for s in samples], current_logps)]:
    score_rows = {'native': [], 'reference': []}
    for i, sample in enumerate(samples):
        mask = sample.get('loss_mask') or [1] * sample['response_length']
        for j, include in enumerate(mask):
            if include:
                position = len(sample['tokens']) - sample['response_length'] + j
                coordinate = dict(sample=str(sample['index']), position=position, token=sample['tokens'][position])
                score_rows['native'].append({**coordinate, 'logprob': float(native_values[i][j])})
                score_rows['reference'].append({**coordinate, 'logprob': float(reference_values[i][j])})
    for side in score_rows:
        write(out / side / (score_stage + '.manifest.json'), dict(schema_version=1, kind='target-scores', common=common,
            side=side, expected_ranks=[0], ranks=[dict(rank=0, environment='environment.json', status='status.json')], scores=score_rows[side]))
    path = out / (score_stage + '.report.json')
    subprocess.run([sys.executable, str(skill / 'scripts/compare_target_scores.py'), '--contract', str(contract),
        '--side-a', str(out / 'native' / (score_stage + '.manifest.json')), '--side-b', str(out / 'reference' / (score_stage + '.manifest.json')),
        '--output', str(path)], check=True)
    reports[score_stage] = json.loads(path.read_text())
    replay.append(dict(name=score_stage, operation='compare_target_scores', inputs={'contract': contract.name,
        'side_a': 'native/' + score_stage + '.manifest.json', 'side_b': 'reference/' + score_stage + '.manifest.json'},
        expected={'status': 'no_thresholds', 'metrics': reports[score_stage]['metrics']}))
write(out / 'REPLAY.json', {'cases': replay})
workflow_scope = json.loads((run / 'workflow-scope.json').read_text())
split_debug = workflow_scope['mode'] != 'official-train-loop'
weight_sync_versions = [meta['version'] for meta in event_metadata('weight-sync')]
if not split_debug:
    assert weight_sync_versions == [1, 2], weight_sync_versions
summary = dict(status='partial_official_debug_stages_and_independent_reference_complete' if split_debug else 'native_full_workflow_and_independent_reference_complete', thresholds=None,
    workflow_scope=workflow_scope['mode'], full_production_workflow_completed=not split_debug,
    native_weight_sync_versions=weight_sync_versions,
    framework='slime', source_revision=initial_meta['source_revision'], native_entrypoint='official train.py',
    rollout_engine='SGLang 0.5.9', training_backend='FSDP2', reference_device='cpu', reference_dtype='float32',
    native_parameter_storage_dtypes=sorted({row['dtype'] for row in initial_meta['inventory']}),
    initial_optimizer_state_entries=pre_meta[0].get('optimizer_state_entries', 'not separately captured; original constructor and load=None recorded'),
    final_optimizer_state_entries=post_meta[0].get('optimizer_state_entries', 'not separately captured'),
    native_forward_observed_dtypes=sorted({meta['logits_dtype'] for meta in event_metadata('forward-dtype')}),
    actual_runtime=initial_meta['runtime'], initial_selected_storage_exact_equal=True,
    reward_fixture='execution only: index within group + response token checksum modulo17 /100; not a reward-quality evaluation',
    full_preclip_norm={'native_fp64': clip['full_preclip_norm_fp64'], 'reference_fp64': full_preclip,
        'native_returned': float(clip['native_norm']), 'reference_returned': float(returned_norm)},
    loss={'native': float(observations['native']['loss'][0]), 'reference': sum(objective_values)},
    coverage={'trajectories': len(samples), 'groups': len(groups), 'valid_actions': len(targets),
        'optimizer_events': 1, 'native_microbatches': 4, 'selected_parameter_tensors': len(selected_names),
        'selected_parameter_elements': sum(before[n].numel() for n in selected_names),
        'total_parameter_tensors': len(initial_meta['inventory']), 'total_parameter_elements': initial_meta['total_parameter_elements'],
        'selection': initial_meta['coverage']}, reference_finished_before_native_outputs_read=True,
    score_metrics={k: reports[k]['metrics'] for k in ['target-scores', 'old-target-scores', 'rollout-target-scores']},
    rollout_score_semantics='SGLang rollout BF16 logprobs are retained separately; policy ratio uses native FSDP recomputed old anchors',
    tensor_metrics={k: reports[k]['global'] for k in ['gradients', 'postclip-gradients', 'updates']})
write(out / 'summary.json', summary)
rollout_file = run / 'native-rollout' / 'rollout_0.pt'
if rollout_file.exists():
    original_samples = torch.load(rollout_file, map_location='cpu', weights_only=False)['samples']
    for original, converted_sample in zip(original_samples, samples, strict=True):
        for key in ['tokens', 'response_length', 'reward', 'index', 'group_index', 'status', 'rollout_log_probs']:
            assert original[key] == converted_sample[key], key
    write(provenance / 'original-native-rollout.json', dict(path='native-rollout/rollout_0.pt',
        sha256=hashlib.sha256(rollout_file.read_bytes()).hexdigest(), bytes=rollout_file.stat().st_size,
        samples=original_samples, native_conversion_adds_default_loss_mask=True,
        scope='official split debug diagnostic; production synchronization loop remains pending'))
for path in Path(a.model).absolute().parent.glob('*-manifest.json'):
    shutil.copy2(path, provenance / path.name)
model_lock = Path(a.model).absolute().parent / 'model-lock.json'
if model_lock.exists():
    shutil.copy2(model_lock, provenance / model_lock.name)
toolkit_receipt = run.parent / 'cuda-toolkit' / 'NVIDIA-REDISTRIBUTABLES.json'
if toolkit_receipt.exists():
    shutil.copy2(toolkit_receipt, provenance / toolkit_receipt.name)
replacements = [[str(run), '<RUN>'], [str(model_path), '<MODEL>'], [str(Path(a.model).absolute()), '<MODEL>'],
    [str(run.parent), '<WORK>'], [str(Path(__file__).parent.resolve()), '<ADAPTER>'],
    [str(skill), '<SKILL>'], [str(Path.home()), '<HOME>'], [platform.node(), '<HOST>'], ['<HOST>', '<HOST>']]
if os.environ.get('SLIME_NATIVE_SOURCE'):
    replacements.insert(0, [str(Path(os.environ['SLIME_NATIVE_SOURCE']).parent), '<ADAPTER>'])
ownership = run / 'driver-runtime.json'
if ownership.exists():
    replacements.insert(0, [json.loads(ownership.read_text())['private_ray_temp'], '<RAY_TMP>'])
try:
    for address in subprocess.check_output(['hostname', '-I'], text=True).split():
        if address not in ('127.0.0.1', '::1'):
            replacements.append([address, '<HOST_IP>'])
except (OSError, subprocess.SubprocessError):
    pass
try:
    address = socket.gethostbyname(socket.gethostname())
    if address not in ('127.0.0.1', '0.0.0.0'):
        replacements.append([address, '<HOST_IP>'])
except OSError:
    pass
if os.environ.get('SLIME_PUBLIC_REPLACEMENTS'):
    replacements.extend(json.loads(Path(os.environ['SLIME_PUBLIC_REPLACEMENTS']).read_text()))
replacements = [item for pair in replacements for item in
    ([pair, [json.dumps(pair[0])[1:-1], pair[1]]] if json.dumps(pair[0])[1:-1] != pair[0] else [pair])]
replacement_path = write(run / 'private-text-replacements.json', replacements)
bundle = run / 'slime-evidence.zip'
subprocess.run([sys.executable, str(skill / 'scripts/evidence_bundle.py'), 'pack', str(out), str(bundle), '--replacements', str(replacement_path)], check=True)
assert bundle.stat().st_size < 90 * 1024 * 1024
subprocess.run([sys.executable, str(skill / 'scripts/evidence_bundle.py'), 'verify', str(bundle)], check=True)
subprocess.run([sys.executable, str(skill / 'scripts/replay_bundle.py'), '--bundle', str(bundle), '--output-root', str(run / 'replay')], check=True)
write(run / 'bundle-receipt.json', dict(path=bundle.name, bytes=bundle.stat().st_size, sha256=hashlib.sha256(bundle.read_bytes()).hexdigest()))
print(json.dumps(summary, indent=2))
