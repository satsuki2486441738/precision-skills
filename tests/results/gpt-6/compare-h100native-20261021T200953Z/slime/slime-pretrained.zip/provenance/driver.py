"""Run the unmodified official train entrypoint in a bounded private Ray cluster."""
import os
import json
from pathlib import Path
import runpy
import shutil
import sys
import tempfile
import ray

root = Path(__file__).resolve().parent
source = Path(os.environ.get('SLIME_NATIVE_SOURCE', str(root / 'source')))
output = Path(os.environ['SLIME_PRECISION_OUTPUT']).parent
if os.environ.get('SLIME_SKILL_ROOT'):
    sys.path.insert(0, str(Path(os.environ['SLIME_SKILL_ROOT']) / 'scripts'))
    from runtime_probe import probe_runtime
    import json
    report = probe_runtime({'imports': ['torch', 'transformers', 'sglang', 'sgl_kernel', 'sglang.srt.configs.model_config', 'ray', 'slime.backends.fsdp_utils.actor'],
        'symbols': ['slime.backends.fsdp_utils.actor:FSDPTrainRayActor._train_core', 'torch.optim:AdamW'],
        'checks': ['torch.cuda:is_available'], 'distributions': ['torch', 'transformers', 'sglang', 'slime', 'ray']}, timeout=60)
    probe_name = 'runtime-probe-rollout.json' if '--debug-rollout-only' in sys.argv else 'runtime-probe.json'
    (output / probe_name).write_text(json.dumps(report, indent=2))
    if report.get('status') != 'completed':
        raise RuntimeError(report)
ray_temp = Path(tempfile.mkdtemp(prefix='sray-'))
namespace = 'slime-precision-' + output.name
ray.init(address='local', namespace=namespace, num_gpus=len(os.environ['CUDA_VISIBLE_DEVICES'].split(',')), num_cpus=16,
    include_dashboard=False, _temp_dir=str(ray_temp), object_store_memory=536870912,
    runtime_env={'env_vars': {key: os.environ[key] for key in
        ['SLIME_PRECISION_CAPTURE', 'SLIME_PRECISION_OUTPUT', 'SLIME_SKILL_ROOT', 'SLIME_NATIVE_SOURCE', 'PYTHONPATH', 'TOKENIZERS_PARALLELISM', 'WANDB_MODE']}})
(output / 'driver-runtime.json').write_text(json.dumps({'driver_pid': os.getpid(),
    'visible_gpu_ids': os.environ['CUDA_VISIBLE_DEVICES'], 'ray_namespace': namespace,
    'private_ray_temp': str(ray_temp), 'ray_address_mode': 'local private Ray instance',
    'omp_threads': os.environ.get('OMP_NUM_THREADS'), 'max_jobs': os.environ.get('MAX_JOBS')}, indent=2))
try:
    runpy.run_path(str(source / 'train.py'), run_name='__main__')
finally:
    ray.shutdown()
    logs = ray_temp / 'session_latest' / 'logs'
    if logs.exists():
        log_destination = output / ('ray-logs-rollout' if '--debug-rollout-only' in sys.argv else 'ray-logs')
        shutil.copytree(logs, log_destination)
    shutil.rmtree(ray_temp)
