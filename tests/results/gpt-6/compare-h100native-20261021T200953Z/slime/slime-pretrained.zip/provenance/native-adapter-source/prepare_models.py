"""Prepare deterministic tiny Qwen3 and immutable official Qwen3 snapshot."""
import argparse
import hashlib
import json
from pathlib import Path
import torch
from huggingface_hub import snapshot_download
from tokenizers import Tokenizer, models, pre_tokenizers, decoders
from transformers import PreTrainedTokenizerFast, Qwen3Config, Qwen3ForCausalLM

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--pretrained-local')
a = p.parse_args()
root = Path(a.root)
root.mkdir(parents=True, exist_ok=True)
revision = 'c1899de289a04d12100db370d81485cdf75e47ca'
tiny = root / 'tiny'
if not (tiny / 'config.json').exists():
    vocabulary = {'<pad>': 0, '<unk>': 1, '<eos>': 2, '<bos>': 3}
    words = ['Complete', 'the', 'sequence', 'one', 'two', 'three', 'four', 'State', 'a', 'short', 'fact', 'about', 'numbers', '.']
    vocabulary.update({word: i + 4 for i, word in enumerate(words)})
    vocabulary.update({f'word{i}': i for i in range(len(vocabulary), 256)})
    backend = Tokenizer(models.WordLevel(vocabulary, unk_token='<unk>'))
    backend.pre_tokenizer = pre_tokenizers.Whitespace()
    backend.decoder = decoders.WordPiece(prefix='##')
    tokenizer = PreTrainedTokenizerFast(tokenizer_object=backend, bos_token='<bos>', eos_token='<eos>', unk_token='<unk>', pad_token='<pad>', model_max_length=128)
    config = Qwen3Config(vocab_size=256, hidden_size=128, intermediate_size=256, num_hidden_layers=2,
        num_attention_heads=2, num_key_value_heads=1, head_dim=64, max_position_embeddings=128,
        tie_word_embeddings=False, attention_dropout=0.0, bos_token_id=3, eos_token_id=2, pad_token_id=0)
    torch.manual_seed(20261022)
    Qwen3ForCausalLM(config).float().save_pretrained(tiny, safe_serialization=True)
    tokenizer.save_pretrained(tiny)
pretrained = root / 'pretrained'
if a.pretrained_local:
    candidate = Path(a.pretrained_local).resolve()
    assert (candidate / 'config.json').is_file() and (candidate / 'model.safetensors').is_file()
    if pretrained.exists() and pretrained.resolve() != candidate:
        assert pretrained.is_dir() and not any(pretrained.iterdir()), 'Refuse to replace an existing checkpoint'
        pretrained.rmdir()
    if not pretrained.exists():
        pretrained.symlink_to(candidate, target_is_directory=True)
else:
    snapshot_download('Qwen/Qwen3-0.6B', revision=revision, local_dir=pretrained,
        ignore_patterns=['*.gguf', '*.h5', '*.msgpack', '*.onnx'])
identity = {'repository': 'Qwen/Qwen3-0.6B', 'revision': revision, 'tiny_seed': 20261022,
    'tiny_origin': 'random 2-layer Qwen3, hidden128/head64, vocabulary256 WordLevel tokenizer'}
(root / 'model-lock.json').write_text(json.dumps(identity, indent=2))
for case in ('tiny', 'pretrained'):
    inventory = []
    for path in sorted((root / case).rglob('*')):
        if path.is_file() and '.cache' not in path.parts:
            h = hashlib.sha256()
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                    h.update(chunk)
            inventory.append({'path': path.relative_to(root / case).as_posix(), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()})
    (root / f'{case}-manifest.json').write_text(json.dumps({'identity': identity, 'files': inventory}, indent=2))
(root / 'prompts.jsonl').write_text('\n'.join(json.dumps({'input': prompt}) for prompt in
    ['Complete the sequence one two three', 'State a short fact about numbers']) + '\n')
print(json.dumps(identity))
