"""Install genuine NVIDIA CUDA12.8.1 compiler/runtime/headers in a private root.

Archives and SHA256 values come from NVIDIA's immutable redistributable index.
This is needed by SGLang's bundled DeepGEMM import even in dense BF16 workflows.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
import urllib.request

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
a = p.parse_args()
root = Path(a.root)
root.mkdir(parents=True, exist_ok=True)
base = 'https://developer.download.nvidia.com/compute/cuda/redist/'
index = json.load(urllib.request.urlopen(base + 'redistrib_12.8.1.json'))
receipt = []
for key in ['cuda_nvcc', 'cuda_cudart', 'cuda_cccl']:
    item = index[key]['linux-x86_64']
    archive = root / Path(item['relative_path']).name
    if not archive.exists():
        urllib.request.urlretrieve(base + item['relative_path'], archive)
    actual = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert actual == item['sha256'], (key, actual)
    destination = root / (key + '-source')
    if not destination.exists():
        destination.mkdir()
        with tarfile.open(archive) as tf:
            tf.extractall(destination, filter='data')
        folder, = destination.iterdir()
        shutil.copytree(folder, root, dirs_exist_ok=True)
    receipt.append({'component': key, 'url': base + item['relative_path'], 'sha256': actual, 'bytes': archive.stat().st_size})
assert (root / 'bin/nvcc').exists()
if not (root / 'lib64').exists() and (root / 'lib').is_dir():
    (root / 'lib64').symlink_to('lib', target_is_directory=True)
(root / 'NVIDIA-REDISTRIBUTABLES.json').write_text(json.dumps(receipt, indent=2))
print(root)
