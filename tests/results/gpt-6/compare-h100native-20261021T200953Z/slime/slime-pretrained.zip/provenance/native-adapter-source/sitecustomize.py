"""Install passive Python profiling only in explicitly enabled native runs."""
import os
if os.environ.get('SLIME_PRECISION_CAPTURE'):
    import native_capture
    native_capture.install()
