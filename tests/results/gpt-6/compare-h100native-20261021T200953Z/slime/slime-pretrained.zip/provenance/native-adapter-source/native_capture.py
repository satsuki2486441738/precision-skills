"""Observe official slime methods using profiling and optimizer observer hooks.

No native function is replaced. The synthetic reward is an explicitly selected
execution fixture, not a benchmark reward: sample parity plus token checksum.
"""
import importlib.metadata
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import time

ROOT = Path(os.environ.get('SLIME_PRECISION_OUTPUT', '.'))
ACTOR = None
COUNT = {}
SELECTED = []
BEFORE = None
CLIP = None
CAPTURE_NAMES = frozenset(['init', '_train_core', '_train_step', 'get_logprob_and_entropy', 'update_weights',
    '_convert_samples_to_train_data', '_post_process_rewards', 'clip_grad_norm_', 'forward'])

def torch_module():
    import torch
    return torch

def cpu(value):
    torch = torch_module()
    if torch.is_tensor(value):
        if hasattr(value, 'to_local'):
            value = value.to_local()
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {str(k): cpu(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [cpu(v) for v in value]
    if hasattr(value, 'to_dict'):
        return cpu(value.to_dict())
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    return str(value)

def save(event, data=None, **metadata):
    torch = torch_module()
    ROOT.mkdir(parents=True, exist_ok=True)
    n = COUNT.get(event, 0)
    COUNT[event] = n + 1
    stem = f'{event}-pid{os.getpid()}-{n:03}'
    if data is not None:
        torch.save(cpu(data), ROOT / (stem + '.pt'))
    record = dict(event=event, pid=os.getpid(), index=n, time=time.time(), data=stem + '.pt' if data is not None else None, **metadata)
    (ROOT / (stem + '.json')).write_text(json.dumps(record, indent=2, default=str))
    print('SLIME_PRECISION ' + json.dumps(record, default=str), flush=True)

def snapshot(grad=False):
    return {n: cpu(p.grad if grad else p) if not grad or p.grad is not None else None for n, p in SELECTED}

def full_norm():
    def scalar(gradient):
        if hasattr(gradient, 'to_local'):
            gradient = gradient.to_local()
        return gradient.detach().double().square().sum().item()
    return sum(scalar(p.grad) for p in ACTOR.model.parameters() if p.grad is not None) ** 0.5

def pre_step(optimizer, args, kwargs):
    global BEFORE
    assert all(p.device.type == 'cuda' for _, p in SELECTED), 'Native optimizer must update CUDA parameters'
    BEFORE = snapshot()
    save('optimizer-pre', {'parameters': BEFORE, 'gradients': snapshot(True)},
        optimizer=type(optimizer).__module__ + '.' + type(optimizer).__name__,
        optimizer_state_entries=len(optimizer.state),
        groups=[{k: cpu(v) for k, v in g.items() if k != 'params'} for g in optimizer.param_groups],
        full_norm=full_norm(),
        full_gradient_inventory=[{'name': n, 'present': p.grad is not None,
            'dtype': str(p.grad.dtype) if p.grad is not None else None,
            'device': str(p.grad.device) if p.grad is not None else None,
            'shape': list(p.shape)} for n, p in ACTOR.model.named_parameters()])

def post_step(optimizer, args, kwargs):
    after = snapshot()
    updates = {n: after[n].float() - BEFORE[n].float() for n in after}
    save('optimizer-post', {'parameters': after, 'updates': updates},
        optimizer_state_entries=len(optimizer.state),
        optimizer_state_dtypes=sorted({str(v.dtype) for state in optimizer.state.values() for v in state.values() if torch_module().is_tensor(v)}),
        nonzero_update=any(bool(v.ne(0).any()) for v in updates.values()))

def on_init(actor):
    global ACTOR, SELECTED
    ACTOR = actor
    torch = torch_module()
    pairs = list(actor.model.named_parameters())
    total = sum(p.numel() for _, p in pairs)
    if total <= 1_000_000:
        SELECTED = pairs
    else:
        selected_names = {'model.layers.0.self_attn.k_proj.weight', 'model.layers.0.self_attn.q_norm.weight',
            'model.layers.0.self_attn.k_norm.weight', 'model.layers.0.input_layernorm.weight',
            'model.layers.0.post_attention_layernorm.weight', 'model.norm.weight'}
        SELECTED = [(n, p) for n, p in pairs if n in selected_names]
    assert SELECTED
    actor.optimizer.register_step_pre_hook(pre_step)
    actor.optimizer.register_step_post_hook(post_step)
    inventory = [{'name': n, 'shape': list(p.shape), 'elements': p.numel(), 'dtype': str(p.dtype),
        'device': str(p.device), 'requires_grad': p.requires_grad, 'selected': any(n == s for s, _ in SELECTED),
        'placements': str(getattr(p, 'placements', None))} for n, p in pairs]
    modules = {}
    for name in ('torch', 'transformers', 'slime', 'sglang', 'ray'):
        module = sys.modules.get(name)
        try:
            version = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            version = None
        modules[name] = {'path': getattr(module, '__file__', None), 'imported_version': getattr(module, '__version__', None), 'distribution_version': version}
    save('initial', {'parameters': snapshot(), 'args': vars(actor.args)}, inventory=inventory,
        total_parameter_elements=total, selected_parameter_elements=sum(p.numel() for _, p in SELECTED),
        coverage='all parameters' if len(SELECTED) == len(pairs) else 'selected complete tensors; other parameter numerical arrays unavailable',
        runtime={'modules': modules, 'cuda': torch.version.cuda, 'device': torch.cuda.get_device_name(),
            'rank': torch.distributed.get_rank(), 'world_size': torch.distributed.get_world_size(),
            'tf32': torch.backends.cuda.matmul.allow_tf32},
        source_revision='0104a9e922ecd3cea768f7c2520e7d1a122afdc9',
        policy_param_dtype='torch.bfloat16', policy_reduce_dtype='torch.float32')
    source_root = Path(sys.modules['slime'].__file__).resolve().parent.parent
    save('source-identity', files=[{'path': path, 'sha256': hashlib.sha256((source_root / path).read_bytes()).hexdigest()}
        for path in ['train.py', 'slime/backends/fsdp_utils/actor.py', 'slime/ray/rollout.py',
            'slime/rollout/sglang_rollout.py', 'slime/utils/ppo_utils.py']])
    if os.environ.get('SLIME_SKILL_ROOT'):
        sys.path.insert(0, str(Path(os.environ['SLIME_SKILL_ROOT']) / 'scripts'))
        from runtime_probe import inspect_runtime
        save('native-worker-runtime', report=inspect_runtime({'imports': ['torch', 'transformers', 'slime', 'sglang', 'ray'],
            'symbols': ['slime.backends.fsdp_utils.actor:FSDPTrainRayActor._train_core', 'torch.optim:AdamW'],
            'checks': ['torch.cuda:is_available'], 'distributions': ['torch', 'transformers', 'sglang', 'slime', 'ray']}))

def profile(frame, event, result):
    global CLIP
    if event not in ('call', 'return'):
        return profile
    name = frame.f_code.co_name
    if name not in CAPTURE_NAMES:
        return profile
    filename = frame.f_code.co_filename.replace('\\', '/')
    if not filename.endswith(('/slime/backends/fsdp_utils/actor.py', '/slime/ray/rollout.py',
            '/torch/nn/utils/clip_grad.py', '/models/qwen3/modeling_qwen3.py')):
        return profile
    loc = frame.f_locals
    if filename.endswith('/slime/backends/fsdp_utils/actor.py'):
        if name == 'init' and event == 'return' and hasattr(loc.get('self'), 'optimizer'):
            on_init(loc['self'])
        elif name == '_train_core' and event == 'call':
            save('train-input', loc['rollout_data'], rollout_id=loc['rollout_id'])
        elif name == '_train_step' and event == 'return' and 'loss' in loc:
            keys = ['old_log_probs', 'log_probs', 'advantages', 'response_lengths', 'loss_masks', 'reported', 'loss', 'ppo_kl', 'packed_batch']
            save('objective', {k: loc[k] for k in keys if k in loc}, mbs_id=loc['mbs_id'], grad_accum=loc['grad_accum'])
        elif name == 'get_logprob_and_entropy' and event == 'return' and isinstance(result, tuple):
            save('model-score', {'log_probs': result[0], 'entropy': result[1], 'tokens': loc['target_tokens']},
                native_logits_dtype=str(loc['logits'].dtype), temperature=loc.get('temperature'))
        elif name == 'update_weights' and event == 'return':
            actor = loc.get('self')
            if hasattr(actor, 'weight_updater'):
                save('weight-sync', version=actor.weight_updater.weight_version)
    elif filename.endswith('/slime/ray/rollout.py') and name == '_convert_samples_to_train_data' and event == 'return':
        save('rollout-conversion', {'samples': loc['samples'], 'train_data': result})
    elif filename.endswith('/slime/ray/rollout.py') and name == '_post_process_rewards' and event == 'return':
        save('native-group-normalization', {key: loc[key] for key in ['raw_rewards', 'rewards', 'mean', 'std'] if key in loc})
    elif ACTOR is not None and filename.endswith('/models/qwen3/modeling_qwen3.py') and name == 'forward' and event == 'return' and hasattr(result, 'logits'):
        save('forward-dtype', logits_dtype=str(result.logits.dtype), device=str(result.logits.device))
    elif ACTOR is not None and filename.endswith('/torch/nn/utils/clip_grad.py') and name == 'clip_grad_norm_':
        if event == 'call':
            CLIP = {'gradients': snapshot(True), 'full_preclip_norm_fp64': full_norm()}
        elif event == 'return' and CLIP is not None:
            save('clip', {**CLIP, 'postclip_gradients': snapshot(True), 'native_norm': result},
                max_norm=float(loc['max_norm']), full_postclip_norm_fp64=full_norm())
            CLIP = None
    return profile

async def synthetic_reward(args, sample, **kwargs):
    checksum = sum(sample.tokens[-sample.response_length:]) % 17
    return float(sample.index % args.n_samples_per_prompt) + checksum / 100.0

def install():
    sys.setprofile(profile)
    threading.setprofile(profile)
