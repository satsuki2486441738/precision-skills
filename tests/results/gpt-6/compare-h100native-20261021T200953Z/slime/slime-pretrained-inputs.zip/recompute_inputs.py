"""Verify typed fixed inputs; optionally execute an independent CPU FP32 step.

python recompute_inputs.py CASE_DIRECTORY --model ORIGINAL_CHECKPOINT
No captured native current score, old anchor, loss, gradient or update is read.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np
import torch


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_tree(directory, node):
    kind = node['type']
    if kind == 'tensor':
        path = Path(directory) / node['path']
        assert sha(path) == node['file_sha256']
        array = np.load(path, allow_pickle=False)
        assert list(array.shape) == node['shape'] and array.dtype.str == node['numpy_dtype']
        assert hashlib.sha256(array.tobytes(order='C')).hexdigest() == node['storage_sha256']
        value = torch.from_numpy(array.copy())
        if node['encoding'] == 'uint16-bfloat16-bits':
            value = value.view(torch.bfloat16)
        assert str(value.dtype) == node['torch_dtype']
        return value
    if kind == 'dict':
        return {load_tree(directory, k): load_tree(directory, v) for k, v in node['items']}
    if kind in ('tuple', 'list'):
        result = [load_tree(directory, item) for item in node['items']]
        return tuple(result) if kind == 'tuple' else result
    assert kind == 'scalar'
    value = node['value']
    assert type(value).__name__ == node['python_type']
    return value


def compute(directory, model_path=None):
    directory = Path(directory)
    document = json.loads((directory / 'INPUTS.json').read_text())
    data = load_tree(directory, document['tree'])
    samples, settings = data['samples'], document['configuration']
    rewards = torch.tensor([float(s['index'] % 2) + sum(s['tokens'][-s['response_length']:]) % 17 / 100.0 for s in samples], dtype=torch.float32)
    groups = {}
    for i, sample in enumerate(samples):
        groups.setdefault(sample['group_index'], []).append(i)
    assert len(groups) == 2 and all(len(indices) == 2 for indices in groups.values())
    advantages = torch.empty_like(rewards)
    for indices in groups.values():
        values = rewards[indices]
        centered = values - values.mean()
        std = centered.std(unbiased=True)
        assert std > 0
        advantages[indices] = centered / (std + 1e-6)
    raw = data['train_input']
    assert torch.equal(rewards, torch.tensor(raw['raw_reward'], dtype=torch.float32))
    assert torch.equal(advantages, torch.tensor(raw['rewards'], dtype=torch.float32))
    seen = set()
    for pack in data['native_packed_inputs']:
        i = pack['sample_index']
        assert i not in seen
        seen.add(i)
        values = pack['inputs']
        sample = samples[i]
        assert values['tokens'].dtype == torch.int64 and values['tokens'].tolist() == sample['tokens']
        assert values['loss_masks'].dtype == torch.int32 and values['loss_masks'].tolist() == sample['loss_mask']
        assert values['position_ids'].tolist() == list(range(len(sample['tokens'])))
        assert values['cu_seqlens'].tolist() == [0, len(sample['tokens'])]
        assert values['response_lengths'] == [sample['response_length']]
        assert torch.equal(values['rewards'], advantages[i:i + 1])
    assert len(seen) == len(samples)
    report = {'typed_input_storage_bits_verified': True, 'trajectories': len(samples), 'groups': len(groups),
        'valid_actions': sum(sum(s['loss_mask']) for s in samples),
        'old_policy_semantics': document['old_policy_semantics'], 'reward_recomputed_from_token_checksum': True,
        'no_native_current_score_loss_gradient_or_update_loaded': True, 'thresholds': None}
    if model_path is None:
        return report
    model_path = Path(model_path)
    for row in document['checkpoint_manifest']['files']:
        if row['path'] == 'SOURCE_IDENTITY_VERIFIED.json':
            continue
        target = model_path / row['path']
        assert target.is_file() and target.stat().st_size == row['bytes'] and sha(target) == row['sha256'], row['path']
    from transformers import AutoModelForCausalLM
    torch.set_num_threads(2)
    model = AutoModelForCausalLM.from_pretrained(model_path, dtype=torch.float32,
        attn_implementation='eager', local_files_only=True).cpu().train()
    assert all(p.device.type == 'cpu' and p.dtype == torch.float32 for p in model.parameters())
    parameters = dict(model.named_parameters())
    selected = document['selected_parameter_names']
    before = {n: parameters[n].detach().clone() for n in selected}

    def score(sample):
        ids = torch.tensor(sample['tokens'], dtype=torch.long).unsqueeze(0)
        logits = model(input_ids=ids, position_ids=torch.arange(ids.shape[1]).unsqueeze(0), attention_mask=None).logits[0].float()
        length = sample['response_length']
        target = ids[0, -length:]
        action = logits[-length - 1:-1]
        current = torch.log_softmax(action / settings['rollout_temperature'], -1).gather(-1, target.unsqueeze(-1)).squeeze(-1)
        entropy = -(torch.softmax(action, -1) * torch.log_softmax(action, -1)).sum(-1)
        return current, entropy

    with torch.no_grad():
        old = [score(sample)[0] for sample in samples]
    model.zero_grad(set_to_none=True)
    losses = []
    for i, sample in enumerate(samples):
        current, entropy = score(sample)
        ratio = (current - old[i]).exp()
        a = -ratio * advantages[i]
        b = -ratio.clamp(1 - settings['eps_clip'], 1 + settings['eps_clip_high']) * advantages[i]
        mask = torch.tensor(sample['loss_mask'], dtype=torch.float32)
        loss = (torch.maximum(a, b) * mask).sum() / mask.sum().clamp_min(1)
        loss -= settings['entropy_coef'] * (entropy * mask).sum() / mask.sum().clamp_min(1)
        assert not settings['use_kl_loss'] and not settings['use_opsm']
        loss = loss / settings['global_batch_size']
        loss.backward()
        losses.append(float(loss.detach()))
    norm_before = sum(p.grad.detach().double().square().sum().item() for p in model.parameters() if p.grad is not None) ** 0.5
    norm_returned = torch.nn.utils.clip_grad_norm_(model.parameters(), settings['clip_grad'])
    norm_after = sum(p.grad.detach().double().square().sum().item() for p in model.parameters() if p.grad is not None) ** 0.5
    optimizer = torch.optim.AdamW(model.parameters(), lr=settings['lr'], betas=(settings['adam_beta1'], settings['adam_beta2']),
        eps=settings['adam_eps'], weight_decay=settings['weight_decay'])
    optimizer.step()
    updates = {n: parameters[n].detach() - before[n] for n in selected}
    assert any(bool(value.ne(0).any()) for value in updates.values())
    report.update({'independent_cpu_step_completed': True, 'model_dtype': 'torch.float32', 'device': 'cpu',
        'torch': torch.__version__, 'cpu_threads': torch.get_num_threads(), 'loss': sum(losses),
        'full_preclip_fp64_diagnostic_norm': norm_before, 'actual_torch_clip_returned_norm_used_for_factor': float(norm_returned),
        'full_postclip_fp64_diagnostic_norm': norm_after, 'optimizer_state_entries': len(optimizer.state),
        'selected_update_elements': sum(value.numel() for value in updates.values()),
        'selected_update_norm': sum(value.double().square().sum().item() for value in updates.values()) ** 0.5,
        'cuda_initialized': torch.cuda.is_initialized()})
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('case')
    p.add_argument('--model')
    p.add_argument('--output')
    a = p.parse_args()
    result = compute(a.case, a.model)
    text = json.dumps(result, indent=2) + '\n'
    if a.output:
        Path(a.output).write_text(text)
    print(text)
