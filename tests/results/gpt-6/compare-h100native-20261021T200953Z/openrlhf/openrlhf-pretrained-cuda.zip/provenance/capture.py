"""Passive CUDA training capture. Wrappers return the unmodified native result."""
import dataclasses
import json
import os
import importlib
import importlib.metadata
from pathlib import Path
import time
import traceback
import subprocess

import torch

OUT = Path(os.environ['GPU_RL_OUTPUT'])
OUT.mkdir(parents=True, exist_ok=True)
NAMES = {}
COUNTS = {}
SELECTED_PARAMETERS = []


def runtime(modules):
    identities = {}
    for name in modules:
        module = importlib.import_module(name)
        identities[name] = {'path': getattr(module, '__file__', None), 'version': getattr(module, '__version__', None)}
    return {'modules': identities, 'torch_cuda': torch.version.cuda, 'cuda_available': torch.cuda.is_available(),
            'visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'),
            'cuda_devices': [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())],
            'cuda_capabilities': [list(torch.cuda.get_device_capability(i)) for i in range(torch.cuda.device_count())],
            'rank': os.environ.get('RANK'), 'local_rank': os.environ.get('LOCAL_RANK'),
            'torch_tf32_matmul': torch.backends.cuda.matmul.allow_tf32,
            'torch_tf32_cudnn': torch.backends.cudnn.allow_tf32,
            'communication_environment': {k: v for k, v in os.environ.items() if k.startswith('NCCL_')
                or k in ['VLLM_NCCL_SO_PATH', 'RAY_ADDRESS', 'RAY_TMPDIR']}}


def source_identity(module):
    path = Path(module.__file__).resolve()
    revision = None
    working_tree_status = None
    for parent in path.parents:
        if (parent / '.git').exists():
            result = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=parent, text=True,
                                    capture_output=True, check=True)
            revision = result.stdout.strip()
            working_tree_status = subprocess.run(['git', 'status', '--porcelain', '--untracked-files=no'],
                cwd=parent, text=True, capture_output=True, check=True).stdout.strip()
            break
    import hashlib
    return {'module_path': str(path), 'module_file_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'git_revision': revision, 'working_tree_status': working_tree_status,
            'identity_kind': 'git checkout' if revision else 'installed distribution with retained file hashes'}


def cpu(value):
    if torch.is_tensor(value):
        if hasattr(value, 'to_local'):
            value = value.to_local()
        return value.detach().cpu().clone()
    if dataclasses.is_dataclass(value):
        return {k: cpu(getattr(value, k)) for k in value.__dataclass_fields__}
    if isinstance(value, dict):
        return {str(k): cpu(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [cpu(v) for v in value]
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    if hasattr(value, '__dict__'):
        return cpu(vars(value))
    return repr(value)


def initial_state(model, master_value=None):
    """Hash every unmodified DP1 parameter and declare actual aliases."""
    import hashlib
    aliases = {}
    for name, parameter in model.named_parameters(remove_duplicate=False):
        aliases.setdefault(id(parameter), []).append(name)

    def record(name, value):
        value = cpu(value).contiguous()
        return {'name': name, 'shape': list(value.shape), 'dtype': str(value.dtype),
                'sha256': hashlib.sha256(value.view(torch.uint8).numpy().tobytes()).hexdigest()}

    state, masters = [], []
    for name, parameter in model.named_parameters():
        assert cpu(parameter).shape == parameter.shape, 'Full state hashing currently requires DP1 unsharded coordinates'
        state.append(record(name, parameter))
        if master_value is not None:
            masters.append(record(name, master_value(name, parameter)))
    return save('initial_state', None, parameters=state,
        aliases=[names for names in aliases.values() if len(names) > 1],
        configuration=model.config.to_dict(), master_parameters=masters,
        semantics='All parameter hashes before the first native optimizer event; reference initializes only from immutable checkpoint')


def save(event, data=None, **meta):
    index = COUNTS.get(event, 0)
    COUNTS[event] = index + 1
    stem = f'{event}-pid{os.getpid()}-{index:03d}'
    if data is not None:
        torch.save(cpu(data), OUT / (stem + '.pt'))
    record = {'event': event, 'index': index, 'pid': os.getpid(),
              'time': time.time(), 'data': stem + '.pt' if data is not None else None,
              'stack': traceback.format_stack(limit=14), **meta}
    (OUT / (stem + '.json')).write_text(json.dumps(record, indent=2, default=str))
    print('GPU_RL ' + json.dumps({k: v for k, v in record.items() if k != 'stack'}, default=str), flush=True)
    return record


def selected(parameters):
    parameters = list(parameters)
    if SELECTED_PARAMETERS:
        available = {id(p) for p in parameters}
        return [(NAMES.get(id(p), f'unnamed-{i}'), p) for i, p in enumerate(SELECTED_PARAMETERS)
                if id(p) in available]
    return [(NAMES.get(id(p), f'unnamed-{i}'), p) for i, p in enumerate(parameters)
            if p.numel() and p.requires_grad][:12]


def samples(pairs, gradient=False):
    def sample(value):
        if hasattr(value, 'to_local'):
            value = value.to_local()
        return value.detach().reshape(-1)[:8192].cpu().clone()
    return {name: None if gradient and p.grad is None else
            sample(p.grad if gradient else p)
            for name, p in pairs}


def norm(parameters):
    return sum((p.grad.to_local() if hasattr(p.grad, 'to_local') else p.grad).detach().double().square().sum().item()
               for p in parameters if p.grad is not None) ** .5


def attach_optimizer_capture(opt):
    """Attach passive hooks to an existing optimizer in a native Ray worker."""
    if getattr(opt, '_precision_capture_attached', False):
        return
    opt._precision_capture_attached = True
    if True:
        SELECTED_PARAMETERS[:] = [p for g in opt.param_groups for p in g['params']
                                   if p.numel() and p.requires_grad][:12]

        def pre(current, args, kwargs):
            parameters = [p for g in current.param_groups for p in g['params']]
            pairs = selected(parameters)
            current._gpu_capture = (pairs, samples(pairs), samples(pairs, True))
            assert all(p.device.type == 'cuda' for _, p in pairs), 'Native optimizer must update actual CUDA parameters'

        def post(current, args, kwargs):
            pairs, before, gradients = current._gpu_capture
            after = samples(pairs)
            updates = {name: after[name].float() - before[name].float() for name in before}
            save('optimizer', {'before': before, 'after': after, 'postclip_gradients': gradients,
                 'stored_updates': updates}, optimizer=type(current).__module__ + '.' + type(current).__name__,
                 groups=[{k: cpu(v) for k, v in g.items() if k != 'params'} for g in current.param_groups],
                 coordinates=[{'name': name, 'shape': list(p.shape), 'native_parameter_dtype': str(p.dtype),
                   'native_gradient_dtype': str(p.grad.dtype) if p.grad is not None else None,
                   'device': str(p.device), 'slice': [0, min(8192, p.numel())]} for name, p in pairs],
                 full_parameter_elements=sum(p.numel() for g in current.param_groups for p in g['params']),
                 selected_elements=sum(x.numel() for x in before.values()),
                 nonzero_update=any(bool(x.ne(0).any()) for x in updates.values()))

        opt.register_step_pre_hook(pre)
        opt.register_step_post_hook(post)


def install_optimizer_capture():
    """Capture native optimizer creation and torch clipping; safe in workers."""
    if getattr(torch.optim.Optimizer.__init__, '_precision_capture_installed', False):
        return
    original_init = torch.optim.Optimizer.__init__

    def observed_init(opt, *args, **kwargs):
        original_init(opt, *args, **kwargs)
        attach_optimizer_capture(opt)

    observed_init._precision_capture_installed = True
    torch.optim.Optimizer.__init__ = observed_init
    original_clip = torch.nn.utils.clip_grad_norm_

    def observed_clip(parameters, max_norm, *args, **kwargs):
        parameters = list(parameters)
        pairs = selected(parameters)
        pre = samples(pairs, True)
        full_pre = norm(parameters)
        result = original_clip(parameters, max_norm, *args, **kwargs)
        save('clip', {'preclip_gradients': pre, 'postclip_gradients': samples(pairs, True),
             'native_returned_norm': result}, max_norm=float(max_norm), full_fp64_preclip_norm=full_pre,
             full_fp64_postclip_norm=norm(parameters),
             native_coefficient=float((torch.as_tensor(max_norm, device=result.device) / (result + 1e-6)).clamp(max=1).item()))
        return result

    torch.nn.utils.clip_grad_norm_ = observed_clip
