This is a source-pinned dependency/import boundary package, not a completed training or precision comparison.

Read BOUNDARY.json, the final clean pip-check/freeze, native entrypoint log and cpu-import-probe. Three real runtime traces and the additional Core resolver conflicts are retained. Earlier failed configurations remain separately labelled. No GPU workflow was executed for this candidate.

Public text replaces private paths/endpoints. ORIGINAL-EXPORT-HASHES.json retains original/export byte counts and SHA256. Pinned source files retain their original bytes. There are no captured numerical arrays, no numerical REPLAY, and no numerical acceptance claim.
