"""Record genuine module imports without replacing any hardware or operator API."""
import argparse
import importlib
import importlib.metadata
import json
from pathlib import Path
import sys
import traceback

p = argparse.ArgumentParser()
p.add_argument('--output', required=True)
a = p.parse_args()
modules = ['torch', 'transformers', 'triton', 'triton.backends.ascend', 'transformer_engine.pytorch',
    'fsdp_turbo', 'mindspeed', 'mindspeed_llm.fsdp2.models.model_factory', 'mindspeed_llm.fsdp2.train.trainer']
results = []
for name in modules:
    try:
        module = importlib.import_module(name)
        results.append({'module': name, 'status': 'imported', 'path': getattr(module, '__file__', None),
            'imported_version': getattr(module, '__version__', None)})
    except Exception as exc:
        results.append({'module': name, 'status': 'failed', 'exception': type(exc).__name__, 'message': str(exc),
            'traceback': traceback.format_exc()})
distributions = {}
for name in ['torch', 'torchvision', 'transformers', 'triton', 'triton-ascend', 'transformer-engine',
        'transformer-engine-torch', 'fsdp-turbo', 'mindspeed', 'mindspeed-llm']:
    try:
        distributions[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        distributions[name] = None
torch = sys.modules.get('torch')
report = {'status': 'module_probe_only_not_native_workflow', 'modules': results, 'distributions': distributions,
    'cuda_initialized': torch.cuda.is_initialized() if torch is not None else None,
    'native_model_training_started': False, 'source_changes_or_hardware_shims': False}
Path(a.output).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
