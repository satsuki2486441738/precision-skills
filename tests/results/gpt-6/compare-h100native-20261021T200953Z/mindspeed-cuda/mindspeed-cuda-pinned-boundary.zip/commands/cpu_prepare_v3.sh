#!/usr/bin/env bash
set -euo pipefail
SOURCE=$1
BASE=/workspace/gpu-validation/mindspeed-cuda
RUNTIME=/workspace/mindspeed-cuda-source-py311-t290-ta322post2
UV=/workspace/gpu-validation/runtime-sft-v3/bootstrap/bin/uv
SLIME=/workspace/gpu-validation/slime-native/runtime-beab0a5
RUN="$BASE/$(date -u +compare-mindspeed-deps322post2-UTC%Y%m%dT%H%M%SZ)"
mkdir -p "$RUN"
export CUDA_VISIBLE_DEVICES=''
unset PIP_INDEX_URL PIP_EXTRA_INDEX_URL UV_INDEX_URL UV_EXTRA_INDEX_URL
export PIP_CONFIG_FILE=/dev/null UV_CACHE_DIR="$SLIME/uv-cache"
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 MAX_JOBS=2 CMAKE_BUILD_PARALLEL_LEVEL=2
export UV_CONCURRENT_DOWNLOADS=2 UV_CONCURRENT_INSTALLS=2 UV_CONCURRENT_BUILDS=1
export CUDA_HOME="$SLIME/cuda-toolkit" PATH="$SLIME/cuda-toolkit/bin:$PATH"
"$UV" --no-config venv --python "$SLIME/.venv/bin/python" "$RUNTIME/.venv" >"$RUN/venv.log" 2>&1
"$UV" --no-config pip install --python "$RUNTIME/.venv/bin/python" --index-url https://pypi.org/simple --link-mode copy \
  'torch==2.9.0' 'torchvision==0.24.0' 'transformers==5.2.0' setuptools wheel ninja cmake \
  "$BASE/wheels/transformer_engine-2.9.0-py3-none-any.whl" \
  "$BASE/wheels/transformer_engine_cu12-2.9.0-py3-none-manylinux_2_28_x86_64.whl" \
  "$BASE/wheels/transformer_engine_torch-2.9.0-cp311-cp311-linux_x86_64.whl" \
  'triton-ascend @ https://mirrors.huaweicloud.com/ascend/repos/pypi/triton-ascend/triton_ascend-3.2.2.post2-cp311-cp311-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl' \
  -e "$SOURCE/sources/mindspeed-core" -e "$SOURCE/sources/fsdp-turbo[gpu]" -e "$SOURCE/sources/mindspeed-llm" \
  >"$RUN/install.log" 2>&1
"$UV" --no-config pip check --python "$RUNTIME/.venv/bin/python" >"$RUN/pip-check.log" 2>&1
"$UV" --no-config pip freeze --python "$RUNTIME/.venv/bin/python" >"$RUN/requirements-resolved.txt"
export PYTHONPATH="$SOURCE/sources/mindspeed-llm:$SOURCE/sources/fsdp-turbo:$SOURCE/sources/mindspeed-core"
"$RUNTIME/.venv/bin/python" "$SOURCE/probe_imports.py" --output "$RUN/cpu-import-probe.json" >"$RUN/probe.log" 2>&1
printf 'MINDSPEED_CPU_PREPARATION_FINISHED %s\n' "$RUN"
