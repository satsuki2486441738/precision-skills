"""Validate typed CUDA RL inputs and optionally execute independent CPU FP32 loss.

python rl_inputs_loader.py INPUTS --model IMMUTABLE_CHECKPOINT
Only immutable source weights, histories, masks, rewards and fixed old anchors
initialize the reference. Captured current scores/gradients/updates are absent.
"""
import argparse
import hashlib
import json
from pathlib import Path
import torch
from fixed_inputs_loader import load_case


def independent_rewards(data, descriptor):
    lane = descriptor['lane']
    fixed = data['fixed_inputs']
    if lane == 'openrlhf':
        call = data['reward']
        ordered = torch.tensor([float(i % 2) + float(sum(ord(c) for c in str(text)) % 997) / 9970
                                for i, text in enumerate(call['queries'])], dtype=torch.float32)
        effective = torch.empty_like(ordered)
        for item in data['reward_inputs']:
            for row, index in enumerate(item['indices']):
                effective[index] = item['rewards'][row].float()
        assert torch.equal(ordered, effective)
        values = ordered
    elif lane == 'areal':
        values = torch.tensor([float(int(ids.sum()) % 997) / 997. for ids in fixed['response_ids']], dtype=torch.float32)
        assert torch.equal(values, data['reward_inputs']['rewards'].reshape(-1).float())
    else:
        assert lane == 'roll'
        call = data['reward']
        histories = [ids[m.bool()] for ids, m in zip(call['response_ids'], call['response_mask'])]
        expected = torch.stack([ids.float().mean() / 100. for ids in histories])
        assert torch.equal(expected, call['values'].float())
        values = torch.stack([ids.float().mean() / 100. for ids in fixed['response_ids']])
    config = descriptor['objective']
    groups = values.view(-1, config['group_size'])
    if lane == 'areal':
        mean = groups.double().mean(-1, keepdim=True).float()
        std = ((groups.double() - mean.double()).square().mean(-1, keepdim=True).sqrt()).float()
    else:
        mean = groups.mean(-1, keepdim=True)
        std = groups.std(-1, keepdim=True, unbiased=config['group_std_unbiased'])
    assert (std > 0).all()
    advantages = ((groups - mean) / (std + config['group_std_epsilon'])).reshape(-1)
    if lane == 'openrlhf':
        advantages = advantages[torch.as_tensor(fixed['sample_ids']).reshape(-1).long()]
    return values, advantages


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case')
    parser.add_argument('--model')
    args = parser.parse_args()
    data, descriptor = load_case(args.case)
    fixed = data['fixed_inputs']
    assert fixed['old_per_token_logps'] is not None
    values, advantages = independent_rewards(data, descriptor)
    report = {'input_bits_verified': True, 'rewards_independently_checked': True,
              'samples': len(values), 'actions': int(fixed['completion_mask'].sum()),
              'old_policy': 'frozen native effective anchors; independently recomputed current CPU policy'}
    if args.model:
        from transformers import AutoModelForCausalLM
        torch.set_num_threads(2)
        model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=torch.float32,
            attn_implementation='eager', local_files_only=True, device_map={'': 'cpu'})
        if descriptor['native_parameter_dtype'] == 'bfloat16':
            model.to(torch.bfloat16).to(torch.float32)
        initial = descriptor.get('full_initial_state')
        if initial:
            if initial['aliases']:
                assert model.config.tie_word_embeddings
                model.tie_weights()
            dtypes = {entry['name']: getattr(torch, entry['dtype'].removeprefix('torch.')) for entry in initial['parameters']}
            hashes = [{'name': name, 'shape': list(p.shape), 'dtype': str(dtypes[name]),
                       'sha256': hashlib.sha256(p.detach().to(dtypes[name]).contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
                      for name, p in model.named_parameters()]
            assert hashes == initial['parameters']
            report['full_initial_parameter_hashes_match'] = True
            if initial.get('master_parameters'):
                master_hashes = [{'name': name, 'shape': list(p.shape), 'dtype': str(p.dtype),
                    'sha256': hashlib.sha256(p.detach().contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
                    for name, p in model.named_parameters()]
                assert master_hashes == initial['master_parameters']
                report['full_initial_master_hashes_match'] = True
        model.train()
        inputs = dict(fixed['model_inputs'])
        inputs.pop('logits_to_keep', None)
        inputs.pop('labels', None)
        inputs['use_cache'] = False
        k = int(fixed['logits_to_keep'])
        config = descriptor['objective']
        logits = model(**inputs).logits[:, -(k + 1):-1, :] / config['temperature']
        labels = inputs['input_ids'][:, -k:]
        current = logits.log_softmax(-1).gather(-1, labels.unsqueeze(-1)).squeeze(-1)
        ratio = (current - fixed['old_per_token_logps'].float()).exp()
        clipped = ratio.clamp(1 - config['epsilon_low'], 1 + config['epsilon_high'])
        terms = -torch.minimum(ratio * advantages[:, None], clipped * advantages[:, None])
        mask = fixed['completion_mask'].bool()
        loss = ((terms * mask).sum() / mask.sum()) if config['loss_reduction'] == 'token-mean' else ((terms * mask).sum(-1) / mask.sum(-1).clamp(min=1)).mean()
        loss.backward()
        norm = sum(p.grad.double().square().sum().item() for p in model.parameters() if p.grad is not None) ** .5
        report.update(independent_cpu_loss=float(loss.detach()), full_preclip_gradient_norm=norm)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
