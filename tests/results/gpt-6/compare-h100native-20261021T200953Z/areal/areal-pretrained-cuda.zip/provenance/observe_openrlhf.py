"""Passive observers of official OpenRLHF + DeepSpeed BF16 CUDA path."""
import os
import torch
import capture


def attach_runtime_bf16(optimizer):
    """Observe the actual wrapper instance and its real clipping function."""
    if getattr(optimizer, '_precision_instance_observed', False):
        return
    import importlib
    module = importlib.import_module(type(optimizer).__module__)
    assert all(hasattr(optimizer, key) for key in ['bf16_groups', 'fp32_groups_gradients', 'optimizer'])
    original_step = optimizer.step
    original_clip = module.clip_tensors_by_global_norm

    def entries():
        result = [(gi, pi, capture.NAMES.get(id(p)), p) for gi, group in enumerate(optimizer.bf16_groups)
                  for pi, p in enumerate(group)][:12]
        assert all(name and p.device.type == 'cuda' for _, _, name, p in result)
        return result

    def values(selected, gradients=False):
        return {name: (optimizer.fp32_groups_gradients[gi][pi] if gradients else p)
            .detach().reshape(-1)[:8192].cpu().clone() for gi, pi, name, p in selected}

    def norm():
        return sum(g.detach().double().square().sum().item()
                   for group in optimizer.fp32_groups_gradients for g in group) ** .5

    def clip(*args, **kwargs):
        selected = entries()
        pre, full_pre = values(selected, True), norm()
        result = original_clip(*args, **kwargs)
        capture.save('clip', {'preclip_gradients': pre, 'postclip_gradients': values(selected, True),
            'native_returned_norm': None, 'native_clip_function_return': capture.cpu(result),
            'native_global_grad_norm': torch.tensor(float(optimizer._global_grad_norm))},
            max_norm=float(optimizer.clip_grad), full_fp64_preclip_norm=full_pre,
            full_fp64_postclip_norm=norm(),
            norm_semantics='native BF16 optimizer _global_grad_norm field; clip_tensors_by_global_norm returns None',
            real_clip_function='deepspeed.runtime.bf16_optimizer.clip_tensors_by_global_norm')
        return result

    def step(*args, **kwargs):
        selected = entries()
        before = values(selected)
        holder = {}

        def inner_pre(opt, call_args, call_kwargs):
            holder['post'] = values(selected, True)
        handle = optimizer.optimizer.register_step_pre_hook(inner_pre)
        optimizer._precision_instance_active = True
        try:
            result = original_step(*args, **kwargs)
        finally:
            optimizer._precision_instance_active = False
            handle.remove()
        after = values(selected)
        updates = {name: after[name].float() - before[name].float() for name in before}
        capture.save('optimizer', {'before': before, 'after': after,
            'postclip_gradients': holder['post'], 'stored_updates': updates},
            optimizer=type(optimizer.optimizer).__module__ + '.' + type(optimizer.optimizer).__name__,
            wrapper=type(optimizer).__module__ + '.' + type(optimizer).__name__,
            groups=[{key: capture.cpu(value) for key, value in group.items() if key != 'params'}
                    for group in optimizer.optimizer.param_groups],
            coordinates=[{'name': name, 'shape': list(p.shape), 'native_parameter_dtype': str(p.dtype),
                'native_gradient_dtype': str(optimizer.fp32_groups_gradients[gi][pi].dtype),
                'device': str(p.device), 'slice': [0, min(8192, p.numel())]}
                for gi, pi, name, p in selected],
            full_parameter_elements=sum(p.numel() for group in optimizer.bf16_groups for p in group),
            selected_elements=sum(value.numel() for value in before.values()),
            nonzero_update=any(bool(value.ne(0).any()) for value in updates.values()), master_storage='float32')
        return result

    module.clip_tensors_by_global_norm = clip
    optimizer.step = step
    optimizer._precision_instance_observed = True


def patch(name, module):
    if name == 'vllm.distributed.device_communicators.pynccl':
        original_init = module.PyNcclCommunicator.__init__

        def observed_init(self, *args, **kwargs):
            def record(phase, error=None):
                library = getattr(self, 'nccl', None)
                try:
                    with open('/proc/self/maps') as stream:
                        paths = sorted({line.split()[-1] for line in stream if 'libnccl.so' in line})
                except OSError:
                    paths = []
                capture.save('nccl_runtime', None, phase=phase, error=error,
                    library_paths=paths, library_version=library.ncclGetVersion() if library else None,
                    requested_device=str(kwargs.get('device', args[1] if len(args) > 1 else None)),
                    logical_current_device=torch.cuda.current_device(),
                    visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
                    logical_devices=[{'index': i, 'name': torch.cuda.get_device_name(i),
                        'capability': list(torch.cuda.get_device_capability(i))} for i in range(torch.cuda.device_count())],
                    world_size=getattr(self, 'world_size', None),
                    nccl_environment={k: v for k, v in os.environ.items() if k.startswith('NCCL_')},
                    native_communicator_result_unmodified=True)
            try:
                result = original_init(self, *args, **kwargs)
            except Exception as error:
                record('failed', type(error).__name__ + ': ' + str(error))
                raise
            record('initialized')
            return result

        module.PyNcclCommunicator.__init__ = observed_init
    elif name == 'openrlhf.models.actor':
        original = module.Actor.forward

        def observed(self, sequences, *args, **kwargs):
            result = original(self, sequences, *args, **kwargs)
            if torch.is_grad_enabled() and kwargs.get('return_output') and isinstance(result, tuple):
                assert result[0].device.type == 'cuda'
                capture.save('scores', {'result': result[0]}, native_dtype=str(result[0].dtype),
                             device=str(result[0].device), temperature=float(self.temperature))
            return result
        module.Actor.forward = observed
    elif name == 'openrlhf.models.loss':
        original = module.PolicyLoss.forward

        def observed(self, *args, **kwargs):
            result = original(self, *args, **kwargs)
            capture.save('objective', {'result': result, 'args': args, 'kwargs': kwargs},
                clip_eps_low=self.clip_eps_low, clip_eps_high=self.clip_eps_high,
                token_level_loss=self.token_level_loss, policy_loss_type=self.policy_loss_type,
                enable_vllm_is_correction=self.enable_vllm_is_correction)
            return result
        module.PolicyLoss.forward = observed
    elif name == 'openrlhf.trainer.ppo_utils.experience_maker':
        original = module.SamplesGenerator.generate_samples

        def observed(self, *args, _original=original, **kwargs):
            result = _original(self, *args, **kwargs)
            capture.save('rollout', result)
            return result
        module.SamplesGenerator.generate_samples = observed
        original = module.RemoteExperienceMaker.compute_advantages_and_returns

        def observed(self, *args, _original=original, **kwargs):
            capture.save('reward_inputs', [{'sequences': e.sequences, 'attention_mask': e.attention_mask,
                'action_mask': e.action_mask, 'rewards': e.rewards, 'indices': e.index} for e in args[0]],
                semantics='native-generated ordered histories and effective external reward dependency before native group normalization')
            for experience in args[0]:
                experience.info['_precision_sample_id'] = torch.tensor(experience.index,
                    dtype=torch.long, device=experience.sequences.device)
            result = _original(self, *args, **kwargs)
            capture.save('advantages', result, estimator=self.advantage_estimator)
            return result
        module.RemoteExperienceMaker.compute_advantages_and_returns = observed
    elif name == 'openrlhf.trainer.ray.ppo_actor':
        original = module.ActorPPOTrainer.training_step

        def observed(self, experience, *args, **kwargs):
            engine = self.actor.model
            optimizer = engine.optimizer
            capture.save('optimizer_runtime', None,
                optimizer_type=type(optimizer).__module__ + '.' + type(optimizer).__name__,
                inner_optimizer_type=type(getattr(optimizer, 'optimizer', None)).__module__ + '.' + type(getattr(optimizer, 'optimizer', None)).__name__,
                data_types=[str(value) for value in engine.get_data_types()],
                instance_step_override='step' in vars(optimizer),
                native_gradient_clip=float(engine.gradient_clipping()),
                zero_stage=int(engine.zero_optimization_stage()))
            # DeepSpeed may already be imported during package initialization;
            # attach the same passive observer to its actual runtime class too.
            if type(optimizer).__name__ == 'BF16_Optimizer':
                import importlib
                patch('deepspeed.runtime.bf16_optimizer', importlib.import_module(type(optimizer).__module__))
                attach_runtime_bf16(optimizer)
            capture.NAMES.update({id(p): n for n, p in engine.module.named_parameters()})
            position_ids = experience.attention_mask.long().cumsum(-1) - 1
            position_ids.masked_fill_(experience.attention_mask == 0, 1)
            capture.save('fixed_inputs', {'model_inputs': {'input_ids': experience.sequences,
                'attention_mask': experience.attention_mask, 'position_ids': position_ids},
                'completion_mask': experience.action_mask, 'logits_to_keep': experience.action_mask.shape[1],
                'old_per_token_logps': experience.action_log_probs,
                'sample_ids': experience.info['_precision_sample_id']}, temperature=float(self.actor.temperature),
                group_size=int(self.args.n_samples_per_prompt), loss_type='grpo',
                epsilon_low=float(self.actor_loss_fn.clip_eps_low), epsilon_high=float(self.actor_loss_fn.clip_eps_high), scale_rewards='group',
                group_epsilon=1e-9, loss_reduction='token-mean' if self.actor_loss_fn.token_level_loss else 'seq-mean-token-mean',
                token_level_loss=bool(self.actor_loss_fn.token_level_loss), init_kl_coef=float(self.args.init_kl_coef),
                reward_clip_range=list(self.args.reward_clip_range), initial_storage='bfloat16', rank=os.environ.get('RANK'),
                old_policy_semantics='native detached actor-rescored old policy, fixed for CPU recomputation')
            capture.save('inventory', None, parameters=[{'name': n, 'shape': list(p.shape),
                'numel': p.numel(), 'dtype': str(p.dtype), 'device': str(p.device), 'trainable': p.requires_grad}
                for n, p in engine.module.named_parameters()])
            return original(self, experience, *args, **kwargs)
        module.ActorPPOTrainer.training_step = observed
    elif name == 'deepspeed.runtime.bf16_optimizer':
        original = module.BF16_Optimizer.step
        if getattr(original, '_precision_observed', False):
            return

        def observed(self, *args, **kwargs):
            if getattr(self, '_precision_instance_active', False):
                return original(self, *args, **kwargs)
            assert all(count == 1 for count in self.partition_count), 'Observer currently defines DP=1 coordinates'
            entries = [(gi, pi, capture.NAMES.get(id(p)), p) for gi, group in enumerate(self.bf16_groups)
                       for pi, p in enumerate(group)][:12]
            assert all(name and p.device.type == 'cuda' for _, _, name, p in entries), entries

            def values(gradient=False):
                return {name: (self.fp32_groups_gradients[gi][pi] if gradient else p)
                    .detach().reshape(-1)[:8192].cpu().clone() for gi, pi, name, p in entries}

            before = values()
            pre = values(True)
            full_pre = sum(g.detach().double().square().sum().item() for group in self.fp32_groups_gradients for g in group) ** .5
            holder = {}

            def inner_pre(opt, call_args, call_kwargs):
                holder['post'] = values(True)
                holder['full_post'] = sum(g.detach().double().square().sum().item()
                    for group in self.fp32_groups_gradients for g in group) ** .5
            handle = self.optimizer.register_step_pre_hook(inner_pre)
            try:
                result = original(self, *args, **kwargs)
            finally:
                handle.remove()
            after = values()
            updates = {n: after[n].float() - before[n].float() for n in before}
            returned_norm = self._global_grad_norm
            native_norm = float(returned_norm.item() if torch.is_tensor(returned_norm) else returned_norm)
            capture.save('clip', {'preclip_gradients': pre, 'postclip_gradients': holder['post'],
                'native_returned_norm': torch.tensor(native_norm)}, max_norm=float(self.clip_grad),
                full_fp64_preclip_norm=full_pre, full_fp64_postclip_norm=holder['full_post'],
                native_coefficient=min(1., self.clip_grad / (native_norm + 1e-6)))
            capture.save('optimizer', {'before': before, 'after': after,
                'postclip_gradients': holder['post'], 'stored_updates': updates},
                optimizer=type(self.optimizer).__module__ + '.' + type(self.optimizer).__name__,
                groups=[{k: capture.cpu(v) for k, v in g.items() if k != 'params'} for g in self.optimizer.param_groups],
                coordinates=[{'name': n, 'shape': list(p.shape), 'native_parameter_dtype': str(p.dtype),
                    'native_gradient_dtype': str(self.fp32_groups_gradients[gi][pi].dtype),
                    'device': str(p.device), 'slice': [0, min(8192, p.numel())]} for gi, pi, n, p in entries],
                full_parameter_elements=sum(p.numel() for group in self.bf16_groups for p in group),
                selected_elements=sum(x.numel() for x in before.values()),
                nonzero_update=any(bool(x.ne(0).any()) for x in updates.values()), master_storage='float32')
            return result
        observed._precision_observed = True
        module.BF16_Optimizer.step = observed
