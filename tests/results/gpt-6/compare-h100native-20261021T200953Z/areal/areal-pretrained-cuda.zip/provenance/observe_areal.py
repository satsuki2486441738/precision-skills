"""Passive observers for AReaL's actual FSDP PPO workflow; native results unchanged."""
import torch
import capture
import hashlib

FIXED = None
CURRENT_SCORES = []
SCALED_LOSSES = []


def patch_actor(module):
    original_adv = module.PPOActor._compute_advantages

    def advantages(self, data, *args, **kwargs):
        capture.save('rollout', {k: data[k] for k in ['input_ids', 'attention_mask', 'loss_mask', 'logprobs', 'rewards']})
        capture.save('reward_inputs', {k: data[k] for k in ['input_ids', 'attention_mask', 'loss_mask', 'rewards']})
        result = original_adv(self, data, *args, **kwargs)
        capture.save('advantages', {'advantages': result['advantages']})
        return result

    module.PPOActor._compute_advantages = advantages
    original_update = module.PPOActor._ppo_update

    def update(self, data, *args, **kwargs):
        global FIXED
        assert data['input_ids'].shape[0] == 4, 'Exactly one complete group is required'
        attn = data['attention_mask'].bool()
        positions = torch.arange(attn.shape[1], device=attn.device).expand_as(attn).clone()
        positions.masked_fill_(~attn, 0)
        token_mask = data['input_token_loss_mask'].bool()
        fixed = {'model_inputs': {'input_ids': data['input_ids'].long(), 'attention_mask': attn,
                                  'position_ids': positions},
                 'completion_mask': data['loss_mask'][:, :-1], 'logits_to_keep': attn.shape[1] - 1,
                 'old_per_token_logps': data['logprobs'][:, :-1],
                 'response_ids': [ids[m] for ids, m in zip(data['input_ids'], token_mask)],
                 'sample_ids': torch.arange(4)}
        FIXED = capture.cpu(fixed)
        capture.save('fixed_inputs', fixed, temperature=float(self.config.temperature), group_size=4,
            loss_type='grpo', scale_rewards='group', epsilon_low=float(self.config.eps_clip),
            epsilon_high=float(self.config.eps_clip), loss_reduction='token-mean',
            std_unbiased=False, normalization_epsilon=1e-4,
            native_compute_dtype='bfloat16', native_storage_dtype='float32',
            microbatch_semantics='four native single-sequence SDPA causal forwards, one optimizer event',
            ordered_sample_identity='native padded group order; packed microbatches matched by complete token history')
        return original_update(self, data, *args, **kwargs)

    module.PPOActor._ppo_update = update
    original_loss = module.grpo_loss_fn

    def loss(logprobs, entropy, input_data, *args, **kwargs):
        assert logprobs.device.type == 'cuda'
        cu = input_data['cu_seqlens'].tolist()
        assert len(cu) == 2, 'Native n_mbs=4 must produce single-sequence microbatches'
        CURRENT_SCORES.append(capture.cpu({'input_ids': input_data['input_ids'], 'logprobs': logprobs}))
        return original_loss(logprobs, entropy, input_data, *args, **kwargs)

    module.grpo_loss_fn = loss


def patch_fsdp(module):
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    capture.install_optimizer_capture()
    original_create = module.FSDPEngine._create_optimizer

    def create(self, *args, **kwargs):
        result = original_create(self, *args, **kwargs)
        capture.install_optimizer_capture()
        if isinstance(getattr(self, 'optimizer', None), torch.optim.Optimizer):
            capture.attach_optimizer_capture(self.optimizer)
        capture.NAMES.update({id(p): n for n, p in self.model.named_parameters()})
        aliases = {}
        for name, parameter in self.model.named_parameters(remove_duplicate=False):
            aliases.setdefault(id(parameter), []).append(name)
        state = []
        for name, parameter in self.model.named_parameters():
            value = capture.cpu(parameter).contiguous()
            state.append({'name': name, 'shape': list(value.shape), 'dtype': str(value.dtype),
                'sha256': hashlib.sha256(value.view(torch.uint8).numpy().tobytes()).hexdigest()})
        capture.save('initial_state', None, parameters=state,
            aliases=[names for names in aliases.values() if len(names) > 1],
            configuration=self.model.config.to_dict(),
            semantics='Full initial parameter hashes and aliases before the first optimizer event; no values used to initialize reference')
        capture.save('inventory', None, parameters=[{'name': n, 'shape': list(p.shape), 'numel': p.numel(),
            'dtype': str(p.dtype), 'device': str(p.device), 'trainable': p.requires_grad}
            for n, p in self.model.named_parameters()], runtime=capture.runtime(['torch', 'areal', 'transformers']),
            configuration=self.model.config.to_dict())
        return result

    module.FSDPEngine._create_optimizer = create
    original_prepare = module.FSDPEngine._prepare_mb_list

    def prepare(self, *args, **kwargs):
        result = original_prepare(self, *args, **kwargs)
        keys = ['input_ids', 'position_ids', 'attention_mask', 'cu_seqlens', 'max_seqlen',
                'max_length_q', 'max_length_k', 'cu_seq_lens_q', 'cu_seq_lens_k', 'use_cache']
        capture.save('model_inputs', [{key: mb[key] for key in keys if key in mb}
            for mb in result.padded_mbs], attn_implementation=self.config.attn_impl,
            semantics='Actual padded native model forward inputs; one sequence per microbatch')
        return result

    module.FSDPEngine._prepare_mb_list = prepare
    original_clip = module.fsdp2_clip_grad_norm

    def clip(parameters, max_norm, *args, **kwargs):
        parameters = list(parameters)
        pairs = capture.selected(parameters)
        before = capture.samples(pairs, True)
        full = capture.norm(parameters)
        result = original_clip(parameters, max_norm, *args, **kwargs)
        capture.save('clip', {'preclip_gradients': before,
            'postclip_gradients': capture.samples(pairs, True), 'native_returned_norm': torch.tensor(result)},
            max_norm=float(max_norm), full_fp64_preclip_norm=full,
            full_fp64_postclip_norm=capture.norm(parameters),
            native_coefficient=min(1., float(max_norm) / (float(result) + 1e-6)))
        return result

    module.fsdp2_clip_grad_norm = clip
    original_scaled_loss = module.FSDPEngine._compute_logprobs_and_loss

    def scaled_loss(self, *args, **kwargs):
        result = original_scaled_loss(self, *args, **kwargs)
        SCALED_LOSSES.append(result.detach().cpu().clone())
        return result

    module.FSDPEngine._compute_logprobs_and_loss = scaled_loss
    original_step = module.FSDPEngine.optimizer_step

    def step(self, *args, **kwargs):
        result = original_step(self, *args, **kwargs)
        assert FIXED is not None and len(CURRENT_SCORES) == len(SCALED_LOSSES) == 4
        inputs = FIXED['model_inputs']
        scores = torch.zeros_like(FIXED['completion_mask'], dtype=torch.float32)
        unused = set(range(4))
        for item in CURRENT_SCORES:
            ids = item['input_ids'].reshape(-1).long()
            matches = [i for i in sorted(unused) if torch.equal(
                inputs['input_ids'][i, inputs['attention_mask'][i]], ids)]
            assert matches, 'Every native microbatch needs an ordered history identity'
            index = matches[0]
            unused.remove(index)
            scores[index, :len(ids) - 1] = item['logprobs'].reshape(-1)[:len(ids) - 1]
        assert not unused
        capture.save('scores', {'result': [scores]}, current_policy_with_grad=True, native_microbatches=4)
        capture.save('objective', {'result': [torch.stack(SCALED_LOSSES).sum()]},
                     semantics='sum of actual native scaled backward scalars', native_microbatches=4)
        return result

    module.FSDPEngine.optimizer_step = step
