import json,subprocess
from pathlib import Path
py='<ENV_ROOT>/bin/python'
run=Path('<WORK_ROOT>/source-b64759b/sft/runs/compare-bridge-mcore-pin-v7-20261021T210603Z')
commands=[('resolver',['-m','pip','install','--dry-run','--no-deps','--no-build-isolation','--report',str(run/'resolver.json'),'megatron-core @ https://github.com/NVIDIA/Megatron-LM/archive/0d8e0714cd29c01e164fe6de9f532182bdffa942.tar.gz']),('install',['-m','pip','install','--no-deps','--no-build-isolation','--force-reinstall','megatron-core @ https://github.com/NVIDIA/Megatron-LM/archive/0d8e0714cd29c01e164fe6de9f532182bdffa942.tar.gz']),('freeze',['-m','pip','freeze','--all']),('check',['-m','pip','check'])]
receipt=[]
for name,args in commands:
 with (run/(name+'.log')).open('w')as out:result=subprocess.run([py,*args],stdout=out,stderr=subprocess.STDOUT)
 receipt.append({'stage':name,'returncode':result.returncode})
 if name in ['resolver','install']and result.returncode:break
(run/'exit.json').write_text(json.dumps(receipt,indent=2))
