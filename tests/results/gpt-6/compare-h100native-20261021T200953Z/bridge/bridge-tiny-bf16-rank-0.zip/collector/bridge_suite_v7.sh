#!/usr/bin/env bash
# Finite real CUDA Bridge; preserve the official cu12 wheel's tag check failure.
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
RUN="${1:?Pass a fresh native run directory}"
PREP="${PRECISION_BRIDGE_PREPARE_RECEIPT:?Pass the completed CPU preparation run}"
CORE="${PRECISION_BRIDGE_MCORE_RECEIPT:?Pass the official MCore gitlink installation receipt}"
[[ -f "$PREP/TE-ORIGINAL-WHEEL-AUDIT.json" && -f "$PREP/freeze.txt" ]]
[[ "${PRECISION_BRIDGE_DEVICE:?An explicit physical GPU assignment is required}" == 3 ]]
PY="$HERE/environments/bridge-cuda-v020/bin/python"
mkdir "$RUN"
mkdir "$RUN/bridge-environment"
cp "$PREP/"{resolver.json,resolver.log,build-paths.json,nvcc.txt,reused-wheel-identities.json} "$RUN/bridge-environment/"
cp "$PREP/freeze.txt" "$RUN/bridge-environment/pre-gitlink-freeze.txt"
cp -r "$CORE" "$RUN/bridge-environment/official-mcore-source"
CUDA_VISIBLE_DEVICES='' "$PY" -m pip freeze --all > "$RUN/bridge-environment/freeze.txt"
CUDA_VISIBLE_DEVICES='' "$PY" - "$PREP" "$CORE" "$RUN/bridge-environment" <<'PY'
import json,subprocess,sys
from pathlib import Path
prep,core_run,out=map(Path,sys.argv[1:])
audit=json.loads((prep/'TE-ORIGINAL-WHEEL-AUDIT.json').read_text())
core=next(w for w in audit['original_official_wheels']if w['original_filename'].startswith('transformer_engine_cu12-'))
assert core['sha256']=='ad14981cbbd964f8e4446c35199d1bc5349ea30244e76bc57c1cceb5d469dd24'
assert 'Tag: cp310-cp310-manylinux_2_28_x86_64'in core['original_WHEEL_metadata']
assert all(not x['undefined_CPython_symbols'] and not any('python'in s.lower()for s in x['needed'])for x in core['ELF_libraries'])
gitlink=json.loads((core_run/'OFFICIAL-GITLINK.json').read_text())
assert gitlink['sha']=='0d8e0714cd29c01e164fe6de9f532182bdffa942'
result=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True)
expected={'megatron-bridge 0.2.0 has requirement megatron-core[dev,mlm]<0.16.0,>=0.15.0a0, but you have megatron-core 0.16.0rc0.','transformer_engine_cu12 2.9.0 is not supported on this platform'}
assert result.returncode==1 and set(result.stdout.strip().splitlines())==expected and not result.stderr.strip(),result
(out/'native-launch-check.txt').write_text(result.stdout)
(out/'TE-ORIGINAL-WHEEL-AUDIT.json').write_text(json.dumps(audit,indent=2))
(out/'DEPENDENCY-METADATA-EXCEPTION.json').write_text(json.dumps({'status':'original_two_official_source_metadata_failures_retained','pip_check_returncode':1,'errors':sorted(expected),'official_MCore_gitlink':gitlink['sha'],'original_wheel_or_package_metadata_changed':False,'native_operators_replaced':False,'runtime_result':'pending full native workflow; no success inferred from package checks'},indent=2))
PY
CUDA_VISIBLE_DEVICES='' "$PY" -c 'from importlib.metadata import version; assert version("torch")=="2.9.0+cu128"; assert version("megatron-core")=="0.16.0rc0"; assert version("transformer-engine")=="2.9.0"; assert version("transformers")=="4.57.1"; print({p:version(p)for p in ["torch","transformers","megatron-core","megatron-bridge","transformer-engine","nvidia-modelopt"]})' > "$RUN/bridge-environment/runtime-pins.txt"
export PYTHONPATH="$HERE${PYTHONPATH:+:$PYTHONPATH}"
export CUDA_VISIBLE_DEVICES="$PRECISION_BRIDGE_DEVICE"
export PRECISION_PRETRAINED_MODEL="${PRECISION_PRETRAINED_MODEL:-$HERE/models/Qwen3-0.6B}"
export PRECISION_BRIDGE_MODEL_REVISION=c1899de289a04d12100db370d81485cdf75e47ca
for model in tiny pretrained; do
  converted="$RUN/bridge-$model-convert"
  trained="$RUN/bridge-$model-bf16/rank-0"
  "$PY" -m torch.distributed.run --standalone --nnodes=1 --nproc-per-node=1 "$HERE/bridge_gpu_sft_v7.py" --root "$HERE" --mode convert --model "$model" --output "$converted" > "$RUN/bridge-$model-convert.log" 2>&1
  "$PY" -m torch.distributed.run --standalone --nnodes=1 --nproc-per-node=1 "$HERE/bridge_gpu_sft_v7.py" --root "$HERE" --mode train --model "$model" --checkpoint "$converted/converted-native" --output "$trained" > "$RUN/bridge-$model-train.log" 2>&1
done
CUDA_VISIBLE_DEVICES='' "$PY" -c 'import json,sys; from pathlib import Path; root=Path(sys.argv[1]); rows=[json.loads(p.read_text())for p in root.glob("bridge-*-bf16/rank-0/native-completion.json")]; assert len(rows)==2 and all(r["entrypoint_returned"] and r["world_size"]==1 for r in rows); (root/"NATIVE-GPU-JOINED.json").write_text(json.dumps({"native_cases":2,"all_native_commands_joined":True,"no_further_GPU_commands_in_suite":True,"physical_device":3,"logical_device":"cuda:0"},indent=2))' "$RUN"
export CUDA_VISIBLE_DEVICES=''
for model in tiny pretrained; do
  trained="$RUN/bridge-$model-bf16/rank-0"
  "$PY" -B "$HERE/bridge_gpu_sft_v7.py" --root "$HERE" --mode reference --model "$model" --output "$trained" > "$RUN/bridge-$model-reference.log" 2>&1
  "$PY" -B -c 'import sys; from pathlib import Path; from export_compare_sft import export; print(export(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3])))' "$trained" "$trained/metrics" "${PRECISION_TOOLS:?Provide frozen skill scripts}" > "$RUN/bridge-$model-export.log" 2>&1
done
