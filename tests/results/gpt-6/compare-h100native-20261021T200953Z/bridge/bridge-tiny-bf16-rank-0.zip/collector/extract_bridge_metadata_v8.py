"""Extract selected original PT metadata after independent references completed.

Original PT files are read only and never rewritten. This is CPU-only work.
"""
import argparse
import hashlib
import json
from pathlib import Path
import torch


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def scalar(value):
    if torch.is_tensor(value):return {'original_dtype':str(value.dtype),'original_shape':list(value.shape),'values':value.tolist()}
    if isinstance(value,dict):return {k:scalar(v)for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [scalar(v)for v in value]
    return value


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True)
    a=p.parse_args()
    keys=['native_optimizer_class','native_optimizer_parameter_inventory','native_grad_scaler_class','native_gradient_inventory','compute_loss_controls','native_checkpoint_load_event','optimizer_event']
    for case in sorted(a.run.glob('bridge-*-bf16/rank-0')):
        assert (case/'reference-execution.json').is_file()
        path=case/'native-captures.pt';original_sha=sha(path)
        captured=torch.load(path,map_location='cpu',weights_only=True)
        metadata={'source':'selected original native PT metadata, extracted after independent CPU reference; original PT never rewritten','source_PT_sha256':original_sha,'observations':{k:scalar(captured[k])for k in keys if k in captured},'extraction_runtime':{'torch':str(torch.__version__),'device':'cpu','CUDA_execution_used':False}}
        (case/'native-extra-observations.json').write_text(json.dumps(metadata,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        assert original_sha==sha(path)
        print(json.dumps({'case':case.parent.name,'keys':list(metadata['observations']),'original_PT_unchanged':True}),flush=True)


if __name__=='__main__':main()
