"""Correct only Bridge scope descriptions in a fresh metrics copy, then replay.

Original exporter outputs and numeric safetensors remain unchanged. This creates
zero new native measurements or comparison groups.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--tools',type=Path,required=True)
    p.add_argument('--metrics-subdir',default='metrics-public-v10')
    a=p.parse_args()
    sys.path.insert(0,str(a.tools))
    from replay_bundle import check_subset,TOLERANCE
    replacements={
        'rank-local replicated after native gradient synchronization':'single-process CUDA Megatron Bridge; world1 TP1 PP1, physical GPU3 exposed as logical cuda0',
        'independent single-process local-batch CPU reference; identical-sample DDP equivalence audited separately':'independent single-process CPU FP32 reference for the matched world1 Bridge batch',
        'accepted native initial coordinates copied exactly to independent CPU':'original HF initial parameters independently reloaded on CPU; every full logical initial tensor verified by canonical FP32 SHA256',
    }
    def adapt(value,counts):
        if isinstance(value,str)and value in replacements:
            counts[value]=counts.get(value,0)+1
            return replacements[value]
        if isinstance(value,dict):return {k:adapt(v,counts)for k,v in value.items()}
        if isinstance(value,list):return [adapt(v,counts)for v in value]
        return value
    for case in sorted(a.run.glob('bridge-*-bf16/rank-0')):
        old=case/'metrics';new=case/a.metrics_subdir
        shutil.copytree(old,new)
        counts={}
        original_numeric={f.name:sha(f)for f in old.glob('*.safetensors')}
        for path in sorted(new.glob('*.json')):
            if path.name.endswith('-comparison.json'):continue
            value=adapt(json.loads(path.read_text(encoding='utf-8')),counts)
            path.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
        commands=[]
        for kind in ['gradients','updates','observations','distributions','target-scores']:
            script='compare_distributions.py' if kind=='distributions'else 'compare_target_scores.py'if kind=='target-scores'else 'compare_tensors.py'
            recomputed=new/('scope-recomputed-'+kind+'.json')
            command=[sys.executable,'-B',str(a.tools/script),'--contract',str(new/(kind+'-contract.json')),'--side-a',str(new/(kind+'-native.json')),'--side-b',str(new/(kind+'-reference.json')),'--output',str(recomputed)]
            with (new/('scope-recomputed-'+kind+'.log')).open('w',encoding='utf-8')as stream:
                code=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT).returncode
            assert code==0,(case,kind)
            before=json.loads((old/(kind+'-comparison.json')).read_text())
            after=json.loads(recomputed.read_text())
            assert after['status']==before['status']=='no_thresholds'
            numerical_key='aggregate'if kind=='distributions'else 'metrics'if kind=='target-scores'else 'global'
            check_subset(after[numerical_key],before[numerical_key],kind)
            if kind in ['gradients','updates','observations']:check_subset(after['per_tensor'],before['per_tensor'],kind+'.per_tensor')
            assert sha(old/(kind+'-comparison.json'))==sha(new/(kind+'-comparison.json'))
            commands.append({'kind':kind,'returncode':code,'original_report_bytes_preserved':True,'recomputed_metrics_match_core_replay_tolerance':True,'core_replay_float_assertion_tolerance':TOLERANCE,'this_is_not_a_model_precision_threshold':True,'script_sha256':sha(a.tools/script)})
        assert original_numeric=={f.name:sha(f)for f in new.glob('*.safetensors')}
        receipt={'metadata_only_recovery':True,'original_metrics_directory_preserved':True,'new_measurement_groups':0,'source_script_sha256':sha(__file__),'replaced_exact_text_counts':counts,'numeric_safetensors_sha256':original_numeric,'numeric_bytes_equal':True,'comparisons':commands,'thresholds':None}
        (new/'scope-metadata-recovery.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'case':case.parent.name,'replacement_count':sum(counts.values()),'comparisons':len(commands),'numeric_bytes_equal':True}),flush=True)


if __name__=='__main__':main()
