"""Official ms-swift rlhf_main -> native rollout/reward/group/loss/train/AdamW on CUDA."""
import argparse
import importlib.metadata as md
import json
import os
from pathlib import Path
import sys

import torch
import capture

parser = argparse.ArgumentParser()
parser.add_argument('--model', required=True)
parser.add_argument('--dtype', default='float32', choices=['float32', 'bfloat16'])
parser.add_argument('--batch-size', type=int, default=4)
parser.add_argument('--max-completion', type=int, default=8)
args = parser.parse_args()
assert torch.cuda.is_available(), 'Actual CUDA runtime required'
assert 'torch_npu' not in sys.modules
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
capture.install_optimizer_capture()
OUT = capture.OUT

from swift.rewards import ORM, orms


class PipelineVariationReward(ORM):
    def __call__(self, completions, **kwargs):
        values = [float(i % 2) + float(sum(ord(c) for c in str(text)) % 997) / 9970
                  for i, text in enumerate(completions)]
        capture.save('reward', {'completions': completions, 'values': values},
                     semantics='synthetic group variation and response checksum; execution validation only; no answer quality claim')
        return values


orms['precision_pipeline_variation'] = PipelineVariationReward
from swift.rlhf_trainers.grpo_trainer import GRPOTrainer
import swift.rlhf_trainers.grpo_trainer as native_grpo_module

for method, event in [('_rollout_samples', 'rollout'), ('_compute_rewards_per_func', 'rewards_tensor'),
                      ('_compute_advantages', 'advantages'), ('_compute_loss_and_metrics', 'objective'),
                      ('_get_per_token_logps_and_entropies', 'scores')]:
    original = getattr(GRPOTrainer, method)

    def wrap(original=original, method=method, event=event):
        def observed(self, *call_args, **kwargs):
            if method == '_compute_loss_and_metrics':
                batch = call_args[2]
                capture.save('fixed_inputs', {'model_inputs': call_args[1],
                    'completion_mask': batch.completion_mask, 'logits_to_keep': batch.logits_to_keep,
                    'old_per_token_logps': batch.old_per_token_logps},
                    temperature=float(self.temperature), group_size=int(self.num_generations),
                    loss_type=str(self.loss_type), epsilon_low=float(self.epsilon_low),
                    epsilon_high=float(self.epsilon_high), scale_rewards=str(self.scale_rewards),
                    old_policy_semantics='native effective old scores; null means independently recomputed current.detach')
            result = original(self, *call_args, **kwargs)
            data = {'args': call_args, 'kwargs': kwargs, 'result': result}
            if method in ('_compute_loss_and_metrics', '_get_per_token_logps_and_entropies'):
                data = {'model_inputs': call_args[1], 'grpo_batch': call_args[2], 'result': result}
            meta = {'method': method}
            if method == '_get_per_token_logps_and_entropies':
                meta['current_policy_with_grad'] = bool(result[0].requires_grad)
            capture.save(event, data, **meta)
            return result
        return observed
    setattr(GRPOTrainer, method, wrap())

original_create = GRPOTrainer.create_optimizer


def create_optimizer(self, *call_args, **kwargs):
    result = original_create(self, *call_args, **kwargs)
    capture.NAMES.update({id(p): name for name, p in self.model.named_parameters()})
    capture.save('inventory', None, parameters=[{'name': n, 'shape': list(p.shape), 'numel': p.numel(),
        'dtype': str(p.dtype), 'device': str(p.device), 'trainable': p.requires_grad}
        for n, p in self.model.named_parameters()], tied_weights=getattr(self.model, '_tied_weights_keys', None))
    return result


GRPOTrainer.create_optimizer = create_optimizer
from swift.pipelines.train.rlhf import rlhf_main
rows = [{'messages': [{'role': 'user', 'content': text}]} for text in
        ['Choose a random digit from 0 to 9. Output only the digit.',
         'Choose a random capital letter. Output only the letter.',
         'Name one random color.', 'Pick one random integer between 1 and 100.']]
data = OUT / 'train.jsonl'
data.write_text('\n'.join(json.dumps(row) for row in rows) + '\n')
argv = ['--rlhf_type', 'grpo', '--model', args.model, '--model_type', 'qwen3', '--template', 'qwen3',
    '--tuner_type', 'full', '--dataset', str(data), '--reward_funcs', 'precision_pipeline_variation',
    '--use_vllm', 'false', '--num_generations', '2', '--max_completion_length', str(args.max_completion), '--max_length', '128',
    '--per_device_train_batch_size', str(args.batch_size), '--gradient_accumulation_steps', '1', '--max_steps', '1',
    '--num_train_epochs', '1', '--learning_rate', '0.001', '--weight_decay', '0', '--max_grad_norm', '1',
    '--optim', 'adamw_torch', '--lr_scheduler_type', 'constant', '--warmup_steps', '0', '--beta', '0',
    '--torch_dtype', args.dtype, '--bf16', str(args.dtype == 'bfloat16').lower(), '--fp16', 'false',
    '--attn_impl', 'eager', '--gradient_checkpointing', 'false', '--padding_free', 'false',
    '--use_liger_kernel', 'false', '--save_strategy', 'no', '--eval_strategy', 'no', '--report_to', 'none',
    '--logging_steps', '1', '--dataset_num_proc', '1', '--dataloader_num_workers', '0',
    '--dataloader_pin_memory', 'false', '--add_version', 'false', '--use_hf', 'true',
    '--use_logits_to_keep', 'false', '--temperature', '1.5', '--seed', '20261022',
    '--output_dir', str(OUT / 'trained'), '--enable_thinking', 'false', '--top_k', '0', '--top_p', '1',
    '--loss_type', 'grpo', '--overlong_filter', 'false']
(OUT / 'arguments.json').write_text(json.dumps(argv, indent=2))
(OUT / 'identity.json').write_text(json.dumps({'model': str(Path(args.model).resolve()), 'dtype': args.dtype,
    'framework': 'official modelscope/ms-swift', 'source_identity': capture.source_identity(native_grpo_module),
    'entrypoint': 'swift.pipelines.train.rlhf.rlhf_main', 'torch': torch.__version__, 'cuda': torch.version.cuda,
    'device': torch.cuda.get_device_name(), 'tf32': False, 'native_operators_replaced': False,
    'runtime': capture.runtime(['torch', 'swift', 'transformers', 'trl', 'accelerate']),
    'versions': {name: md.version(name) for name in ['torch', 'ms-swift', 'transformers', 'trl', 'accelerate']}}, indent=2))
result = rlhf_main(argv)
capture.save('train_returned', {'result': result})
required = ['rollout', 'reward', 'rewards_tensor', 'advantages', 'objective', 'scores', 'clip', 'optimizer']
assert all(capture.COUNTS.get(name, 0) for name in required), capture.COUNTS
events = [json.loads(p.read_text()) for p in OUT.glob('optimizer-*.json')]
assert len(events) == 1 and events[0]['nonzero_update'], events
(OUT / 'completion.json').write_text(json.dumps({'status': 'native_cuda_workflow_complete',
    'events': capture.COUNTS, 'optimizer_steps': len(events), 'reward_quality_claimed': False}, indent=2))
