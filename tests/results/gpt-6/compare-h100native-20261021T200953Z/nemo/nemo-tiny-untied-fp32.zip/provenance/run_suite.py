"""Real GPU RL suite entrypoint: isolated dependency installation and native training.

Launch on the CUDA allocation:
  python run_suite.py --work-root /workspace/gpu-rl --skill-root /workspace/precision-skills/skills/precision-skill
All stages are bounded subprocesses. Failures are retained and later lanes continue.
"""
import argparse
from datetime import datetime, timezone
import json
import hashlib
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PINS = {'swift': ('https://github.com/modelscope/ms-swift.git', 'ad818a2cdfafaf4305ac40c4acd892a211978bc2'),
        'openrlhf': ('https://github.com/OpenRLHF/OpenRLHF.git', '06ab51e75c0e8c5b4d6b66912996b2a611e3dc2f'),
        'nemo': ('https://github.com/NVIDIA-NeMo/RL.git', '26f651ea490ef2a343e7f298b9aa54bc7c5da67c'),
        'roll': ('https://github.com/alibaba/ROLL.git', 'd3506ea9e280ae720fb74df9f82db6efac1c72d5'),
        'areal': ('https://github.com/inclusionAI/AReaL.git', '3b93679888e9f4929f6f155f13c6a286a62dfd72')}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--work-root', required=True)
    ap.add_argument('--skill-root', required=True)
    ap.add_argument('--lanes', default='swift,openrlhf')
    ap.add_argument('--model', default='Qwen/Qwen3-0.6B')
    ap.add_argument('--model-root', help='Owned model variant directory; preserve earlier model paths')
    ap.add_argument('--python', default=sys.executable)
    ap.add_argument('--environment-root', help='Optional fast local filesystem for isolated, recreatable virtualenvs')
    ap.add_argument('--installer-uv', help='Optional existing uv executable; install the same locked requirements with uv pip')
    ap.add_argument('--cache-root', help='Optional fast local filesystem for package caches')
    ap.add_argument('--areal-python', help='Existing Python 3.12 interpreter; otherwise isolated uv manages 3.12.15')
    ap.add_argument('--skip-install', action='store_true')
    ap.add_argument('--prepare-only', action='store_true', help='Install/check dependencies and pin models, without native CUDA execution')
    ap.add_argument('--dependencies-only', action='store_true', help='Install/check source and dependencies without downloading models or invoking CUDA')
    ap.add_argument('--local-model', help='Read-only verified Qwen snapshot; retain an owned symlink instead of downloading it again')
    a = ap.parse_args()
    root = Path(a.work_root).resolve()
    models = Path(a.model_root).resolve() if a.model_root else root / 'models'
    run = root / 'runs' / ('compare-gpurl-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    run.mkdir(parents=True)
    environments = Path(a.environment_root).resolve() if a.environment_root else root / 'environments'
    cache = Path(a.cache_root).resolve() if a.cache_root else root / 'cache'
    git_config = root / 'git-safe-directories.conf'
    git_config.write_text('[safe]\n' + ''.join('    directory = ' + str(root / 'sources' / lane) + '\n' for lane in PINS))
    env = dict(os.environ, PYTHONUNBUFFERED='1', TOKENIZERS_PARALLELISM='false', OMP_NUM_THREADS='2',
               HF_HOME=str(root / 'cache' / 'huggingface'), PIP_CACHE_DIR=str(cache / 'pip'),
               UV_CACHE_DIR=str(cache / 'uv'), UV_PYTHON_INSTALL_DIR=str(root / 'managed-python'),
               DS_BUILD_OPS='0', MAX_JOBS='2', PIP_CONFIG_FILE=os.devnull, PIP_EXTRA_INDEX_URL='',
               UV_EXTRA_INDEX_URL='', PIP_INDEX_URL='https://pypi.org/simple',
               UV_INDEX_URL='https://pypi.org/simple', GIT_CONFIG_GLOBAL=str(git_config))
    local_addresses = {'localhost', '127.0.0.1', '::1', '0.0.0.0', socket.gethostname()}
    try:
        local_addresses.update(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError:
        pass
    bypass = env.get('NO_PROXY', env.get('no_proxy', ''))
    env['NO_PROXY'] = env['no_proxy'] = ','.join(filter(None, [bypass, *sorted(local_addresses)]))
    results = []

    def execute(name, command, timeout=3600, extra=None, cwd=None):
        start = time.time()
        command = [str(x) for x in command]
        if a.installer_uv and command[1:4] == ['-m', 'pip', 'install']:
            command = [a.installer_uv, '--no-config', 'pip', 'install', '--python', command[0], *command[4:]]
        stage_env = {**env, **(extra or {})}
        executable = Path(str(command[0]))
        if executable.is_absolute():
            stage_env['PATH'] = str(executable.parent) + os.pathsep + stage_env.get('PATH', '')
        with (run / (name + '.log')).open('w') as log:
            print('GPU_RL_SUITE', name, flush=True)
            try:
                process = subprocess.Popen([str(x) for x in command], cwd=cwd, env=stage_env,
                    stdout=log, stderr=subprocess.STDOUT, start_new_session=os.name != 'nt')
                code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                if os.name != 'nt':
                    os.killpg(process.pid, signal.SIGTERM)
                else:
                    process.terminate()
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    if os.name != 'nt':
                        os.killpg(process.pid, signal.SIGKILL)
                    else:
                        process.kill()
                    process.wait()
                code = 124
        receipt = {'stage': name, 'command': [str(x) for x in command], 'exit_code': code,
                   'elapsed_seconds': time.time() - start}
        (run / (name + '.json')).write_text(json.dumps(receipt, indent=2))
        print(json.dumps(receipt), flush=True)
        return code == 0

    for lane in a.lanes.split(','):
        if lane not in PINS:
            results.append({'lane': lane, 'status': 'unimplemented_native_adapter'})
            continue
        source = root / 'sources' / lane
        venv = environments / lane
        py = venv / 'bin' / 'python'
        url, pin = PINS[lane]
        source.parent.mkdir(parents=True, exist_ok=True)
        venv.parent.mkdir(parents=True, exist_ok=True)
        ok = True
        if not a.skip_install:
            if not source.exists():
                ok = execute(lane + '-clone', ['git', 'clone', '--filter=blob:none', '--no-checkout', url, source], 240)
            if ok:
                ok = execute(lane + '-checkout', ['git', 'checkout', '--detach', pin], 240, cwd=source)
            if ok and lane == 'areal':
                # This is the official documented vLLM project variant, not a
                # dependency override. Framework operator sources stay pinned.
                variant = source / 'pyproject.vllm.toml'
                shutil.copy2(variant, source / 'pyproject.toml')
                (run / 'areal-project-variant.json').write_text(json.dumps({'git_revision': pin,
                    'official_variant': variant.name, 'sha256': hashlib.sha256(variant.read_bytes()).hexdigest()}, indent=2))
            if not py.exists():
                if lane == 'areal' and not a.areal_python:
                    bootstrap = root / 'bootstrap-uv'
                    bootstrap_py = bootstrap / 'bin/python'
                    if not bootstrap_py.exists():
                        ok = ok and execute('uv-bootstrap-venv', [a.python, '-m', 'venv', bootstrap], 120)
                        ok = ok and execute('uv-bootstrap-install', [bootstrap_py, '-m', 'pip', 'install', 'uv==0.13.1'], 300)
                    ok = ok and execute(lane + '-venv', [bootstrap_py, '-m', 'uv', 'venv', '--python', '3.12.15', '--seed', venv], 600)
                else:
                    ok = ok and execute(lane + '-venv', [a.areal_python if lane == 'areal' else a.python, '-m', 'venv', venv], 120)
            if ok:
                ok = execute(lane + '-build-tools', [py, '-m', 'pip', 'install', '-U', 'pip', 'setuptools', 'wheel', 'packaging', 'ninja'], 600)
            lock = HERE / (lane + '.requirements.lock')
            if ok and lock.exists():
                # The resolver lock retains the whole dependency combination. The
                # exact Git checkout then supplies the framework's actual source.
                torch_version, cuda_index = {'swift': ('2.9.0', 'cu128'), 'openrlhf': ('2.8.0', 'cu128'),
                    'nemo': ('2.6.0', 'cu124'), 'roll': ('2.8.0', 'cu128'),
                    'areal': ('2.10.0', 'cu129')}[lane]
                torch_packages = ['torch==' + torch_version]
                if lane == 'areal':
                    torch_packages += ['torchaudio==2.10.0', 'torchvision==0.25.0']
                ok = execute(lane + '-torch', [py, '-m', 'pip', 'install', *torch_packages,
                    '--index-url', 'https://download.pytorch.org/whl/' + cuda_index], 1800)
                ok = ok and execute(lane + '-locked-dependencies', [py, '-m', 'pip', 'install', '-r', lock,
                    '--no-build-isolation'], 2400, cwd=source)
                if ok:
                    ok = execute(lane + '-editable-source', [py, '-m', 'pip', 'install', '--no-deps', '-e', source], 600)
                if not ok:
                    results.append({'lane': lane, 'status': 'locked_environment_failed'})
                    continue
            if ok and not lock.exists() and lane == 'swift':
                ok = execute(lane + '-torch', [py, '-m', 'pip', 'install', 'torch==2.9.0', '--index-url', 'https://download.pytorch.org/whl/cu128'], 1800)
                ok = ok and execute(lane + '-install', [py, '-m', 'pip', 'install', '-e', source, 'transformers==5.3.0', 'trl==0.29.1', 'accelerate==1.14.0', 'msgspec==0.19.0'], 1800)
            elif ok and not lock.exists() and lane == 'nemo':
                ok = execute(lane + '-torch', [py, '-m', 'pip', 'install', 'torch==2.6.0', '--index-url', 'https://download.pytorch.org/whl/cu124'], 1800)
                ok = ok and execute(lane + '-install', [py, '-m', 'pip', 'install', '-e', source,
                    'transformers==4.51.3', 'accelerate==1.6.0', 'datasets==3.5.0', 'torchdata==0.11.0'], 1800)
            elif ok and not lock.exists():
                ok = execute(lane + '-torch', [py, '-m', 'pip', 'install', 'torch==2.8.0', '--index-url', 'https://download.pytorch.org/whl/cu128'], 1800)
                ok = ok and execute(lane + '-flash-attn', [py, '-m', 'pip', 'install', 'flash-attn==2.8.3', '--no-build-isolation'], 1800)
                if lane == 'roll':
                    ok = ok and execute(lane + '-install', [py, '-m', 'pip', 'install', '-r', 'requirements_torch280_vllm.txt',
                        '-e', '.', 'flash-attn==2.8.3', '--no-build-isolation'], 2400, cwd=source)
                else:
                    ok = ok and execute(lane + '-install', [py, '-m', 'pip', 'install', '-e', str(source) + '[vllm]'], 2400)
        if not ok:
            results.append({'lane': lane, 'status': 'environment_failed'})
            continue
        actual_pin = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, env=env, text=True).strip()
        (run / (lane + '-source-pin.json')).write_text(json.dumps({'expected': pin, 'actual': actual_pin,
            'matched': actual_pin == pin}, indent=2))
        if actual_pin != pin:
            results.append({'lane': lane, 'status': 'source_pin_mismatch'})
            continue
        ok = execute(lane + '-pipcheck', [py, '-m', 'pip', 'check'], 120)
        ok = ok and execute(lane + '-freeze', [py, '-m', 'pip', 'freeze'], 120)
        if not ok:
            results.append({'lane': lane, 'status': 'dependency_check_failed'})
            continue
        if a.dependencies_only:
            results.append({'lane': lane, 'status': 'dependencies_ready', 'native_cuda_executed': False})
            (run / 'suite-status.json').write_text(json.dumps(results, indent=2))
            continue
        model_command = [py, HERE / 'prepare_models.py', '--model', a.model, '--root', models]
        if a.local_model:
            model_command += ['--local-model', a.local_model]
        ok = execute(lane + '-models', model_command, 1200)
        if a.prepare_only:
            results.append({'lane': lane, 'status': 'prepared' if ok else 'model_preparation_failed',
                            'native_cuda_executed': False})
            (run / 'suite-status.json').write_text(json.dumps(results, indent=2))
            continue
        for case in ['tiny', 'pretrained'] if ok else []:
            output = run / lane / case
            output.mkdir(parents=True)
            for filename in ['pipcheck', 'freeze']:
                shutil.copy2(run / (lane + '-' + filename + '.log'), output / (filename + '.txt'))
            for path in [models / 'model-lock.json', models / (case + '-manifest.json')]:
                shutil.copy2(path, output / path.name)
            if (models / 'derivation.json').exists():
                shutil.copy2(models / 'derivation.json', output / 'derivation.json')
            native = HERE / {'swift': 'native_swift.py', 'openrlhf': 'native_openrlhf.py', 'nemo': 'native_nemo.py', 'roll': 'native_roll.py', 'areal': 'native_areal.py'}[lane]
            native_command = [py, native, '--model', models / case]
            if lane in ['nemo', 'areal']:
                native_command += ['--source', source]
            ok = execute(lane + '-' + case + '-native', native_command, 1200,
                         {'GPU_RL_OUTPUT': str(output), 'GPU_RL_CAPTURE_OPEN': '1' if lane == 'openrlhf' else '0',
                          'GPU_RL_CAPTURE_NEMO': '1' if lane == 'nemo' else '0',
                          'GPU_RL_CAPTURE_AREAL': '1' if lane == 'areal' else '0',
                          'PYTHONPATH': str(HERE) + os.pathsep + str(source),
                          'PATH': str(venv / 'bin') + os.pathsep + env.get('PATH', '')})
            if ok:
                ok = execute(lane + '-' + case + '-reference', [py, HERE / 'cpu_reference.py', '--native-output', output,
                    '--skill-root', a.skill_root], 1800, {'CUDA_VISIBLE_DEVICES': '',
                    'GPU_RL_CAPTURE_OPEN': '0', 'GPU_RL_CAPTURE_NEMO': '0', 'GPU_RL_CAPTURE_AREAL': '0'})
            results.append({'lane': lane, 'case': case, 'status': 'complete' if ok else 'failed', 'output': str(output)})
        (run / 'suite-status.json').write_text(json.dumps(results, indent=2))
    (run / 'suite-status.json').write_text(json.dumps(results, indent=2))
    return 0 if results and all(x['status'] in ['complete', 'prepared', 'dependencies_ready'] for x in results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
