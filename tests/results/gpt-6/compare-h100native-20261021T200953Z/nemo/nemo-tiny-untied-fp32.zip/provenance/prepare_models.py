"""Retain a fixed official pretrained snapshot and a reproducible tiny Qwen3."""
import argparse
import hashlib
import json
from pathlib import Path

import torch
from huggingface_hub import HfApi, snapshot_download
from transformers import AutoTokenizer, Qwen3Config, Qwen3ForCausalLM

ap = argparse.ArgumentParser()
ap.add_argument('--model', default='Qwen/Qwen3-0.6B')
ap.add_argument('--root', required=True)
ap.add_argument('--local-model')
ap.add_argument('--revision', default='c1899de289a04d12100db370d81485cdf75e47ca')
a = ap.parse_args()
root = Path(a.root)
root.mkdir(parents=True, exist_ok=True)
lock = root / 'model-lock.json'
if lock.exists():
    identity = json.loads(lock.read_text())
    assert identity['repository'] == a.model
    assert a.revision is None or identity['revision'] == a.revision, 'Retained model revision differs from requested pin'
    revision = identity['revision']
else:
    revision = a.revision or HfApi().model_info(a.model, revision='main').sha
    identity = {'repository': a.model, 'revision': revision,
        'tiny_seed': 20261022, 'tiny_origin': 'random Qwen3 config with the same official tokenizer'}
    lock.write_text(json.dumps(identity, indent=2))
pretrained = root / 'pretrained'
if a.local_model:
    assert Path(a.local_model).is_dir()
    if not pretrained.exists():
        pretrained.symlink_to(Path(a.local_model).resolve(), target_is_directory=True)
    assert pretrained.resolve() == Path(a.local_model).resolve()
else:
    snapshot_download(a.model, revision=revision, local_dir=pretrained,
                      ignore_patterns=['*.gguf', '*.h5', '*.msgpack', '*.onnx'])
tiny = root / 'tiny'
if not (tiny / 'config.json').exists():
    tokenizer = AutoTokenizer.from_pretrained(pretrained, local_files_only=True)
    config = Qwen3Config(vocab_size=len(tokenizer), hidden_size=128, intermediate_size=256,
        num_hidden_layers=2, num_attention_heads=4, num_key_value_heads=2, head_dim=32,
        max_position_embeddings=512, attention_dropout=0.0, tie_word_embeddings=True,
        bos_token_id=tokenizer.bos_token_id, eos_token_id=tokenizer.eos_token_id,
        pad_token_id=tokenizer.pad_token_id)
    torch.manual_seed(identity['tiny_seed'])
    model = Qwen3ForCausalLM(config).float()
    model.save_pretrained(tiny, safe_serialization=True)
    tokenizer.save_pretrained(tiny)
for case in ['pretrained', 'tiny']:
    files = []
    for path in sorted((root / case).rglob('*')):
        if path.is_file() and '.cache' not in path.parts:
            h = hashlib.sha256()
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                    h.update(chunk)
            files.append({'path': path.relative_to(root / case).as_posix(), 'bytes': path.stat().st_size,
                          'sha256': h.hexdigest()})
    (root / (case + '-manifest.json')).write_text(json.dumps({'identity': identity, 'files': files}, indent=2))
print(json.dumps(identity, indent=2))
