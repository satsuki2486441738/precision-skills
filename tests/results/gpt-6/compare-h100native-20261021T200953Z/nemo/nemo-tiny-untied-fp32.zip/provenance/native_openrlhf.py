"""Official OpenRLHF Ray CLI, vLLM rollout and DeepSpeed BF16 native update."""
import argparse
import importlib.metadata as md
import json
import os
from pathlib import Path
import runpy
import sys


def reward_func(queries, prompts, labels):
    import torch
    import capture
    values = [float(i % 2) + float(sum(ord(c) for c in str(text)) % 997) / 9970
              for i, text in enumerate(queries)]
    capture.save('reward', {'queries': queries, 'prompts': prompts, 'labels': labels, 'values': values},
        semantics='synthetic within-group variation/checksum; execution validation only; no answer quality claim')
    return torch.tensor(values, dtype=torch.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    a = ap.parse_args()
    import torch
    import ray
    import capture
    assert torch.cuda.is_available() and torch.cuda.device_count() >= 2
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    out = capture.OUT
    rows = [{'prompt': 'Choose one random digit.', 'label': ''}, {'prompt': 'Name a random color.', 'label': ''}]
    data = out / 'data.jsonl'
    data.write_text('\n'.join(json.dumps(x) for x in rows) + '\n')
    argv = ['--actor_num_nodes', '1', '--actor_num_gpus_per_node', '1', '--vllm_num_engines', '1',
        '--vllm_tensor_parallel_size', '1', '--vllm_gpu_memory_utilization', '0.2', '--enforce_eager',
        '--pretrain', a.model, '--save_path', str(out / 'checkpoint'),
        '--prompt_data', str(data), '--input_key', 'prompt', '--label_key', 'label',
        '--apply_chat_template', '--remote_rm_url', str(Path(__file__).resolve()),
        '--micro_train_batch_size', '4', '--train_batch_size', '4', '--micro_rollout_batch_size', '4',
        '--rollout_batch_size', '2', '--n_samples_per_prompt', '2', '--max_samples', '2',
        '--max_epochs', '1', '--num_episodes', '1', '--generate_max_len', '8',
        '--prompt_max_len', '96', '--max_len', '128', '--zero_stage', '0', '--bf16',
        '--grad_accum_dtype', 'fp32', '--attn_implementation', 'eager',
        '--actor_learning_rate', '0.001', '--l2', '0', '--lr_warmup_ratio', '0',
        '--lr_scheduler', 'constant', '--max_norm', '1', '--init_kl_coef', '0',
        '--advantage_estimator', 'group_norm', '--seed', '20261022', '--temperature', '1.5',
        '--save_steps', '-1', '--eval_steps', '-1']
    (out / 'arguments.json').write_text(json.dumps(argv, indent=2))
    (out / 'identity.json').write_text(json.dumps({'model': str(Path(a.model).resolve()), 'dtype': 'bfloat16',
        'framework': 'official OpenRLHF/OpenRLHF', 'source_pin': '06ab51e75c0e8c5b4d6b66912996b2a611e3dc2f',
        'entrypoint': 'openrlhf.cli.train_ppo_ray', 'torch': torch.__version__, 'cuda': torch.version.cuda,
        'device': torch.cuda.get_device_name(), 'tf32': False, 'native_operators_replaced': False,
        'versions': {n: md.version(n) for n in ['torch', 'openrlhf', 'transformers', 'deepspeed', 'vllm', 'ray']}}, indent=2))
    env_vars = {k: v for k, v in os.environ.items() if k.startswith('GPU_RL_') or k in
                ['PYTHONPATH', 'PATH', 'LD_LIBRARY_PATH', 'HF_HOME', 'TOKENIZERS_PARALLELISM', 'OMP_NUM_THREADS', 'NO_PROXY', 'no_proxy']}
    ray.init(address='local', num_cpus=8, num_gpus=2, include_dashboard=False,
             object_store_memory=2 * 1024 ** 3, runtime_env={'env_vars': env_vars})
    sys.argv = ['openrlhf.cli.train_ppo_ray'] + argv
    try:
        runpy.run_module('openrlhf.cli.train_ppo_ray', run_name='__main__')
        capture.save('train_returned', None)
    finally:
        ray.shutdown()
    required = ['rollout', 'reward', 'advantages', 'fixed_inputs', 'objective', 'scores', 'clip', 'optimizer']
    assert all(list(out.glob(name + '-pid*-*.json')) for name in required)
    optimizer_events = [json.loads(p.read_text()) for p in out.glob('optimizer-pid*-*.json')]
    assert len(optimizer_events) == 1 and optimizer_events[0]['nonzero_update']
    (out / 'completion.json').write_text(json.dumps({'status': 'native_cuda_workflow_complete',
        'optimizer_steps': len(optimizer_events), 'reward_quality_claimed': False}, indent=2))


if __name__ == '__main__':
    main()
