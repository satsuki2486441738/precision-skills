"""NeMo data/reward adapters and passive captures; original CUDA operators execute."""
import os
import sys
import torch
import capture

OPTIMIZER_INSTALLED = False


def patch(name, module):
    global OPTIMIZER_INSTALLED
    if name == 'nemo_reinforcer.distributed.virtual_cluster':
        # Select the already pinned, isolated native CUDA interpreter for Ray.
        module.PY_EXECUTABLES.BASE = sys.executable
        original_init = module.init_ray

        def isolated_init(*args, **kwargs):
            assert os.environ['RAY_ADDRESS'] == 'local'
            assert torch.cuda.device_count() == 1, 'Only the explicitly assigned physical GPU may be visible'
            native_ray_init = module.ray.init

            def configured_ray_init(*ray_args, **ray_kwargs):
                # Runtime configuration only. Preserve NeMo's native runtime_env
                # and execution; isolate this job from other local Ray clusters.
                ray_kwargs.update(num_cpus=6, num_gpus=1, namespace=os.environ['GPU_RL_RAY_NAMESPACE'],
                                  _temp_dir=os.environ['GPU_RL_RAY_TMPDIR'], object_store_memory=2 * 1024 ** 3)
                return native_ray_init(*ray_args, **ray_kwargs)

            module.ray.init = configured_ray_init
            try:
                result = original_init(*args, **kwargs)
            finally:
                module.ray.init = native_ray_init
            resources = module.ray.cluster_resources()
            assert resources.get('GPU') == 1 and resources.get('CPU') == 6, resources
            capture.save('ray_resources', None, resources=resources,
                         namespace=module.ray.get_runtime_context().namespace,
                         visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
                         ray_tmpdir=os.environ['GPU_RL_RAY_TMPDIR'],
                         launch_configuration_only=True, arithmetic_operators_replaced=False)
            return result

        module.init_ray = isolated_init
    elif name == 'nemo_reinforcer.data.hf_datasets.openmathinstruct2':
        original = module.load_dataset

        def local_dataset(path, *args, **kwargs):
            if path == 'nvidia/OpenMathInstruct-2':
                return original('json', data_files=os.environ['GPU_RL_NEMO_DATASET'], split='train')
            return original(path, *args, **kwargs)
        module.load_dataset = local_dataset
    elif name == 'nemo_reinforcer.environments.math_environment':
        cls = module.HFVerifyWorker.__ray_metadata__.modified_class

        def synthetic_reward(self, pred_responses, ground_truths):
            values = [float(i % 2) + float(sum(ord(c) for c in str(text)) % 997) / 9970
                      for i, text in enumerate(pred_responses)]
            capture.save('reward', {'completions': pred_responses, 'values': values},
                semantics='declared synthetic environment reward; group variation/checksum only; no answer-quality conclusion')
            return values
        cls.verify = synthetic_reward
    elif name == 'nemo_reinforcer.algorithms.loss_functions':
        original = module.ClippedPGLossFn.__call__

        def observed(self, logits, data):
            result = original(self, logits, data)
            assert logits.device.type == 'cuda'
            labels = data['input_ids'][:, 1:].to(logits.device)
            logps = logits[:, :-1].float().log_softmax(-1).gather(-1, labels.unsqueeze(-1)).squeeze(-1)
            capture.save('scores', {'result': [logps]}, device=str(logits.device), dtype=str(logits.dtype),
                semantics='derived FP32 normalized scores from exact native logits; native loss result retained separately')
            capture.save('objective', {'result': result}, dtype=str(result[0].dtype), device=str(result[0].device))
            return result
        module.ClippedPGLossFn.__call__ = observed
    elif name in ['nemo_reinforcer.models.policy.dtensor_policy_worker', 'nemo_reinforcer.models.policy.fsdp1_policy_worker']:
        if not OPTIMIZER_INSTALLED:
            capture.install_optimizer_capture()
            OPTIMIZER_INSTALLED = True
        is_fsdp1 = name.endswith('.fsdp1_policy_worker')
        if is_fsdp1:
            native_fsdp = module.FullyShardedDataParallel

            def configured_fsdp(*args, **kwargs):
                kwargs['use_orig_params'] = True
                return native_fsdp(*args, **kwargs)

            module.FullyShardedDataParallel = configured_fsdp
        cls = (module.FSDP1PolicyWorker if is_fsdp1 else module.DTensorPolicyWorker).__ray_metadata__.modified_class
        original_train = cls.train

        def train(self, data, loss_fn, *args, **kwargs):
            # Ray may deserialize the observed class without importing the
            # driver's module initialization in the worker process.
            capture.install_optimizer_capture()
            capture.attach_optimizer_capture(self.optimizer)
            clean_name = lambda name: name.replace('_fsdp_wrapped_module.', '')
            capture.NAMES.update({id(p): clean_name(n) for n, p in self.model.named_parameters()})
            inputs = data['input_ids']
            capture.save('fixed_inputs', {'model_inputs': {'input_ids': inputs, 'attention_mask': torch.ones_like(inputs)},
                'completion_mask': data['token_mask'][:, 1:] * data['sample_mask'][:, None],
                'logits_to_keep': inputs.shape[1] - 1, 'old_per_token_logps': data['prev_logprobs'][:, 1:]},
                temperature=1., group_size=4, loss_type='grpo', epsilon_low=.2, epsilon_high=.2,
                scale_rewards='group', group_std='population', group_epsilon=0., loss_reduction='token-mean')
            capture.save('rollout', {'input_ids': inputs, 'input_lengths': data['input_lengths'],
                'token_mask': data['token_mask'], 'generation_logprobs': data['generation_logprobs']},
                semantics='real native HF generated histories after native rollout/reward/group preparation')
            capture.save('runtime', None, **capture.runtime(['torch', 'nemo_reinforcer', 'transformers']))
            aliases = {}
            for n, p in self.model.named_parameters(remove_duplicate=False):
                aliases.setdefault(id(p), []).append(clean_name(n))
            capture.save('inventory', None, parameter_alias_groups=list(aliases.values()),
                parameters=[{'name': clean_name(n), 'shape': list(p.shape), 'numel': p.numel(),
                'dtype': str(p.dtype), 'device': str(p.device), 'trainable': p.requires_grad}
                for n, p in self.model.named_parameters()])
            return original_train(self, data, loss_fn, *args, **kwargs)
        cls.train = train
        if is_fsdp1:
            return
        original_clip = module.clip_grad_by_total_norm_

        def clip(parameters, max_grad_norm, total_norm, *args, **kwargs):
            parameters = list(parameters)
            pairs = capture.selected(parameters)
            pre = capture.samples(pairs, True)
            norm_before = capture.norm(parameters)
            result = original_clip(parameters, max_grad_norm, total_norm, *args, **kwargs)
            capture.save('clip', {'preclip_gradients': pre, 'postclip_gradients': capture.samples(pairs, True),
                'native_returned_norm': total_norm}, max_norm=float(max_grad_norm),
                full_fp64_preclip_norm=norm_before, full_fp64_postclip_norm=capture.norm(parameters),
                native_coefficient=min(1., float(max_grad_norm) / (float(total_norm) + 1e-6)))
            return result
        module.clip_grad_by_total_norm_ = clip
