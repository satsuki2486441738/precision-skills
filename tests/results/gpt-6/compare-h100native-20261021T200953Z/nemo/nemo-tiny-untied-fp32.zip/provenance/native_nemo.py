"""Official NeMo 0.2 run_grpo_math.py, CUDA/NCCL FSDP1 + HF generation."""
import argparse
import importlib.metadata as md
import json
import os
from pathlib import Path
import runpy
import sys
import hashlib

import torch
from omegaconf import OmegaConf
import capture

ap = argparse.ArgumentParser()
ap.add_argument('--model', required=True)
ap.add_argument('--source', required=True)
a = ap.parse_args()
assert torch.cuda.is_available()
source = Path(a.source).resolve()
out = capture.OUT
assert torch.cuda.device_count() == 1
os.environ['RAY_ADDRESS'] = 'local'
os.environ['GPU_RL_RAY_NAMESPACE'] = 'precision-nemo-' + str(os.getpid())
os.environ['GPU_RL_RAY_TMPDIR'] = '/tmp/nr' + hashlib.sha256(str(out).encode()).hexdigest()[:8]
os.environ['RAY_TMPDIR'] = os.environ['GPU_RL_RAY_TMPDIR']
rows = [{'problem': 'Choose one random digit from 0 to 9.', 'expected_answer': '0'} for _ in range(24)]
data = out / 'data.jsonl'
data.write_text('\n'.join(json.dumps(row) for row in rows) + '\n')
os.environ['GPU_RL_NEMO_DATASET'] = str(data)
prompt = out / 'prompt.txt'
prompt.write_text('{}')
cfg = OmegaConf.to_container(OmegaConf.load(source / 'examples/configs/grpo_math_1B.yaml'), resolve=False)
cfg['grpo'].update(num_prompts_per_step=1, num_generations_per_prompt=4, max_num_steps=1,
    use_leave_one_out_baseline=False, normalize_rewards=True, val_period=0, val_at_start=False)
cfg['loss_fn'].update(reference_policy_kl_penalty=0., use_on_policy_kl_approximation=False,
                      use_importance_sampling_correction=False)
cfg['checkpointing']['enabled'] = False
policy = cfg['policy']
policy.update(model_name=a.model, train_global_batch_size=4, train_micro_batch_size=4,
    generation_batch_size=4, logprob_batch_size=4, max_total_sequence_length=128,
    precision='float32', max_grad_norm=1., make_sequence_length_divisible_by=1)
policy['tokenizer'] = {'name': a.model}
policy['dtensor_cfg'].update(enabled=False, tensor_parallel_size=1, sequence_parallel=False,
                            cpu_offload=False, activation_checkpointing=False)
policy['optimizer'] = {'name': 'torch.optim.AdamW', 'kwargs': {'lr': .001, 'weight_decay': 0.,
    'betas': [.9, .999], 'eps': 1e-8, 'foreach': False, 'fused': False}}
policy['scheduler'] = {'name': 'torch.optim.lr_scheduler.ConstantLR', 'kwargs': {'factor': 1., 'total_iters': 2}}
policy['generation'].update(backend='hf', max_new_tokens=8, temperature=1.5, top_p=1., top_k=0)
cfg['data'].update(max_input_seq_length=96, prompt_file=str(prompt), system_prompt_file=None)
cfg['env']['math']['num_workers'] = 1
cfg['logger'].update(log_dir=str(out / 'training-logs'), wandb_enabled=False,
    tensorboard_enabled=False, monitor_gpus=False, num_val_samples_to_print=0)
cfg['cluster'].update(gpus_per_node=1, num_nodes=1)
config = out / 'config.yaml'
OmegaConf.save(config=OmegaConf.create(cfg), f=str(config))
(out / 'identity.json').write_text(json.dumps({'model': str(Path(a.model).resolve()), 'dtype': 'float32',
    'framework': 'official NVIDIA-NeMo/RL', 'source_pin': '26f651ea490ef2a343e7f298b9aa54bc7c5da67c',
    'entrypoint': 'examples/run_grpo_math.py', 'torch': torch.__version__, 'cuda': torch.version.cuda,
    'device': torch.cuda.get_device_name(), 'native_operators_replaced': False,
    'runtime_selection': 'same isolated interpreter for policy and environment workers',
    'model_variant': json.loads((Path(a.model).parent / 'derivation.json').read_text()),
    'training_backend': 'official FSDP1PolicyWorker DP=1; native single-GPU branch skips FSDP wrapping',
    'versions': {n: md.version(n) for n in ['torch', 'nemo-reinforcer', 'transformers', 'ray']}}, indent=2))
sys.argv = [str(source / 'examples/run_grpo_math.py'), '--config', str(config)]
os.chdir(source)
try:
    runpy.run_path(str(source / 'examples/run_grpo_math.py'), run_name='__main__')
finally:
    import ray
    ray.shutdown()
capture.save('train_returned', None)
required = ['rollout', 'reward', 'fixed_inputs', 'objective', 'scores', 'clip', 'optimizer']
assert all(list(out.glob(name + '-pid*-*.json')) for name in required)
events = [json.loads(p.read_text()) for p in out.glob('optimizer-pid*-*.json')]
assert len(events) == 1 and events[0]['nonzero_update']
(out / 'completion.json').write_text(json.dumps({'status': 'native_cuda_workflow_complete',
    'optimizer_events': len(events), 'reward_quality_claimed': False}, indent=2))
