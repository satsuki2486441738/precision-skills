"""Own untied-config variant; original pretrained config and weight bytes stay intact."""
import argparse
import hashlib
import json
from pathlib import Path
import torch
from safetensors import safe_open
from transformers import AutoTokenizer, Qwen3Config, Qwen3ForCausalLM

ap = argparse.ArgumentParser()
ap.add_argument('--source-models', required=True)
ap.add_argument('--output', required=True)
a = ap.parse_args()
source, output = Path(a.source_models), Path(a.output)
output.mkdir(parents=True, exist_ok=False)
pretrained = output / 'pretrained'
pretrained.mkdir()
original = source / 'pretrained'
config_path = original / 'config.json'
before = json.loads(config_path.read_text())
after = {**before, 'tie_word_embeddings': False}
assert before['tie_word_embeddings'] is True
for path in original.iterdir():
    if path.is_file() and path.name != 'config.json':
        (pretrained / path.name).symlink_to(path.resolve())
(pretrained / 'config.json').write_text(json.dumps(after, indent=2) + '\n')
with safe_open(pretrained / 'model.safetensors', framework='pt', device='cpu') as stream:
    assert 'model.embed_tokens.weight' in stream.keys() and 'lm_head.weight' in stream.keys()
tiny_config = Qwen3Config.from_dict(json.loads((source / 'tiny/config.json').read_text()))
tiny_config.tie_word_embeddings = False
torch.manual_seed(20261022)
tiny = Qwen3ForCausalLM(tiny_config).float()
assert tiny.model.embed_tokens.weight is not tiny.lm_head.weight
tiny.save_pretrained(output / 'tiny', safe_serialization=True)
AutoTokenizer.from_pretrained(original, local_files_only=True).save_pretrained(output / 'tiny')
lock = json.loads((source / 'model-lock.json').read_text())
lock.update(model_configuration='untied configuration variant', tiny_tie_word_embeddings=False)
(output / 'model-lock.json').write_text(json.dumps(lock, indent=2) + '\n')
manifest = json.loads((source / 'pretrained-manifest.json').read_text())
receipt = {'model_configuration': 'Qwen3-0.6B pretrained weights, untied configuration variant',
    'source_repository': lock['repository'], 'source_revision': lock['revision'],
    'source_config_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest(),
    'derived_config_sha256': hashlib.sha256((pretrained / 'config.json').read_bytes()).hexdigest(),
    'exact_config_diff': [{'key': 'tie_word_embeddings', 'before': True, 'after': False}],
    'original_pretrained_files': manifest['files'], 'original_weights_modified': False,
    'original_config_modified': False, 'both_native_and_cpu_load_derived_config': True,
    'pretrained_weight_storage': 'read-only symlinks to original verified files',
    'tiny': {'seed': 20261022, 'untied': True, 'parameters': sum(p.numel() for p in tiny.parameters()),
             'config_sha256': hashlib.sha256((output / 'tiny/config.json').read_bytes()).hexdigest()}}
assert [k for k in set(before) | set(after) if before.get(k) != after.get(k)] == ['tie_word_embeddings']
(output / 'derivation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
