"""Independent CPU FP32 fixed-trajectory Qwen3 GRPO reference.

Inputs are only model weights, immutable trajectory/anchor inputs and a sampling
layout. Native current losses, gradients and after parameters are never read.
CPU uses ordinary Transformers eager operators and Torch AdamW with a cold state.
"""
import argparse, hashlib, inspect, json, os, pathlib, time
os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD']='0'
import numpy as np
import torch
import transformers

def write(path,value):
 path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')

def mapped(model,name,gradient=False):
 name=name.split('decoder.layers.',1)[1]; layer,tail=name.split('.',1)
 module=model.model.layers[int(layer)]
 def get(path):
  p=module.get_parameter(path)
  return p.grad if gradient else p.detach()
 direct={
  'self_attention.linear_proj.weight':'self_attn.o_proj.weight',
  'self_attention.linear_qkv.layer_norm_weight':'input_layernorm.weight',
  'self_attention.q_layernorm.weight':'self_attn.q_norm.weight',
  'self_attention.k_layernorm.weight':'self_attn.k_norm.weight',
  'mlp.linear_fc1.layer_norm_weight':'post_attention_layernorm.weight',
  'mlp.linear_fc2.weight':'mlp.down_proj.weight'}
 if tail in direct:return get(direct[tail])
 assert tail=='self_attention.linear_qkv.weight',tail
 # Megatron Qwen3 groups: [Q_head0,Q_head1,K_head,V_head] for each of 8 groups.
 q=get('self_attn.q_proj.weight').reshape(8,2,128,1024)
 k=get('self_attn.k_proj.weight').reshape(8,1,128,1024)
 v=get('self_attn.v_proj.weight').reshape(8,1,128,1024)
 return torch.cat([q,k,v],dim=1).reshape(4096,1024)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--inputs',required=True);parser.add_argument('--layout',required=True)
 parser.add_argument('--model',required=True);parser.add_argument('--output',required=True)
 args=parser.parse_args();out=pathlib.Path(args.output);out.mkdir(parents=True,exist_ok=False)
 torch.set_num_threads(8);torch.manual_seed(20261020)
 data=json.loads(pathlib.Path(args.inputs).read_text());layout=json.loads(pathlib.Path(args.layout).read_text())
 start=time.monotonic()
 model=transformers.AutoModelForCausalLM.from_pretrained(args.model,torch_dtype=torch.float32,attn_implementation='eager',local_files_only=True)
 model.config.use_cache=False;model.train()
 assert all(p.dtype==torch.float32 and p.device.type=='cpu' for p in model.parameters())
 assert model.config.tie_word_embeddings and model.lm_head.weight is model.model.embed_tokens.weight
 inventory={name:{'shape':list(p.shape),'dtype':str(p.dtype),'requires_grad':p.requires_grad} for name,p in model.named_parameters()}
 write(out/'inventory.json',inventory)
 def save(stage,gradient=False):
  for i,(name,entry) in enumerate(layout.items()):
   value=mapped(model,name,gradient).flatten()[::entry['sampling_stride']].detach().numpy().copy()
   np.save(out/f'{stage}-{i:02d}.npy',value,allow_pickle=False)
 save('before')
 raw=torch.tensor(data['raw_rewards'],dtype=torch.float32).reshape(-1,4)
 centered=raw-raw.mean(-1,keepdim=True);std=centered.std(-1,keepdim=True)
 advantages=(centered/(std+1e-6)).flatten()
 optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,betas=(.9,.999),eps=1e-8,weight_decay=0,foreach=False)
 assert len(optimizer.state)==0
 scores=[];objectives=[];ratios=[];branches=[]
 for index,item in enumerate(data['trajectories']):
  tokens=torch.tensor(item['tokens'],dtype=torch.int64).unsqueeze(0)
  r=item['response_length'];p=tokens.shape[1]-r
  logits=model(input_ids=tokens,use_cache=False).logits[0,p-1:-1].float()
  logdist=torch.log_softmax(logits,dim=-1)
  current=logdist.gather(-1,tokens[0,-r:].unsqueeze(-1)).squeeze(-1)
  old=torch.tensor(item['old_log_probs'],dtype=torch.float32)
  mask=torch.tensor(item['loss_mask'],dtype=torch.float32)
  ratio=(current-old).exp();plain=-ratio*advantages[index]
  clipped=-ratio.clamp(.8,1.2)*advantages[index]
  pg=(torch.maximum(plain,clipped)*mask).sum()/mask.sum()
  entropy=(-(logdist.exp()*logdist).sum(-1)*mask).sum()/mask.sum()
  clipfrac=((clipped>plain).float()*mask).sum()/mask.sum()
  kl=((old-current)*mask).sum()/mask.sum()
  mismatch=((old-torch.tensor(item['rollout_log_probs'])) .abs()*mask).sum()/mask.sum()
  (pg/len(data['trajectories'])).backward()
  scores.append(current.detach().tolist());ratios.append(ratio.detach().tolist());branches.append((clipped>plain).tolist())
  objectives.append([float(pg.detach()),float(pg.detach()),float(entropy.detach()),float(clipfrac.detach()),float(kl.detach()),float(mismatch.detach())])
  print(json.dumps({'sample':index,'elapsed_seconds':time.monotonic()-start,'loss':float(pg.detach())}),flush=True)
  del logits,logdist,current,ratio,plain,clipped,pg,entropy,clipfrac,kl,mismatch
 save('gradient',True)
 norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.0,foreach=False)
 save('postclip',True)
 optimizer.step()
 save('after')
 np.save(out/'objectives.npy',np.asarray(objectives,dtype=np.float64),allow_pickle=False)
 write(out/'scores.json',scores)
 write(out/'result.json',{'status':'completed','model_class':type(model).__name__,'model_parameters':sum(p.numel() for p in model.parameters()),
  'torch':torch.__version__,'transformers':transformers.__version__,'numpy':np.__version__,'device':'cpu','compute_dtype':'float32','parameter_storage_dtype':'float32',
  'torch_source_sha256':hashlib.sha256(pathlib.Path(inspect.getfile(torch)).read_bytes()).hexdigest(),
  'modeling_source_sha256':hashlib.sha256(pathlib.Path(inspect.getfile(type(model))).read_bytes()).hexdigest(),
  'normalized_rewards':advantages.tolist(),'reward_group_mean':raw.mean(-1).tolist(),'reward_group_std_unbiased':std.flatten().tolist(),
  'ratio':ratios,'clipped_branch':branches,'global_preclip_gradient_l2':float(norm),'clip_coefficient':min(1.0,1.0/(float(norm)+1e-6)),
  'optimizer':'torch.optim.AdamW','optimizer_initial_state':'empty','optimizer_steps':sorted(set(int(s['step']) for s in optimizer.state.values())),
  'optimizer_hyperparameters':{'lr':1e-4,'betas':[.9,.999],'eps':1e-8,'weight_decay':0.0},
  'sample_order':list(range(8)),'microbatches':8,'accumulation_denominator':8,'elapsed_seconds':time.monotonic()-start,
  'excluded_native_inputs':['current_native_loss','native_gradients','native_after_parameters','native_optimizer_outcomes']})
 print('CPU_REFERENCE_COMPLETED',flush=True)

if __name__=='__main__':main()
