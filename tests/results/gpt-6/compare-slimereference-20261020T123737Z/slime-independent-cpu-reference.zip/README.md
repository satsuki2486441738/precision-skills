# Slime native GRPO versus independent CPU reference

This case completes the independent precision comparison for the preserved real
Slime NPU rollout and optimizer step. It reuses that step's fixed trajectories;
no additional NPU job, synthetic gradient, or native-outcome reconstruction was
used to produce the CPU reference.

The native actor used pretrained Qwen3-0.6B, 596,049,920 parameters, Slime commit
2418a7844abe4d490a1676dcf88fc3401adab362 with the recorded official Ascend/MindSpeed
deployment patches and private compatibility repairs. The training backend was
Megatron/MindSpeed; SGLang generated eight trajectories in two complete groups of
four. All64 response actions remain valid, including truncated responses. The
synthetic response-hash rewards validate numerical plumbing, not model quality.
Full native source/version/repair histories remain in the preceding frozen
`slime-and-upstream-boundaries.zip`; this case includes exact objective sources
and complete hashes of original native artifacts and external model files.

The independent process loaded those original pretrained BF16 weights into a
fresh CPU FP32 Transformers4.57.1 Qwen3 model. It used eager attention, ordinary
Torch2.8 autograd, unbiased group reward standard deviation with epsilon1e-6,
clipped GRPO ratio bounds0.8..1.2, eight microbatches accumulated with denominator8,
full-model norm clipping1, and cold Torch AdamW (lr1e-4, beta0.9/0.999, eps1e-8,
weight decay0). Its input files contain fixed token IDs, masks, raw rewards and
detached old-policy anchors. It does not read native current losses, gradients,
after parameters, or optimizer outcomes. `reference_cpu.py` is the executable
implementation; `captures/cpu/result.json` records actual execution.

All16 sampled initial tensors match exactly, including the explicit grouped-QKV
mapping. This verifies135,680 paired coordinates. CPU reward normalization also
matches exactly. The source native observer selected the first16 trainable
tensors with32..5,000,000 elements and sampled their flattened storage at
stride=max(1,numel//16384). `captures/layout.json` preserves shapes and strides.

Core CLI results use thresholds=null and status=no_thresholds:

- 64 action scores: MAE0.03028716880362481 nats, P990.1130942642688751, maximum
  0.1175692081451416 at sample5, target position10, token11652. Native/CPU NLL is
  3.038545394781977/3.0373060439014807 nats per action.
- 135,680 preclip gradient coordinates: L2 error0.054481531738253534,
  RMSE0.00014790790706445333, cosine0.998239895131943.
- 135,680 stored-update coordinates: L2 error0.021139787311546643,
  RMSE0.00005739085516281744, cosine0.8338031014664161.
- 48 per-microbatch objective component values: L2 error0.06776869021764122,
  RMSE0.009781567884945877. Each side's components and absolute differences are
  recorded separately in `summary.json`.

Native stored parameters are BF16 and copied losslessly into FP32 arrays; the
CPU model computes and stores parameters in FP32. The update comparison therefore
includes native BF16 storage rounding, which is an explicit side condition.
Gradient arrays are the original observer's FP32 copies; the native gradient
storage dtype was not captured and remains unavailable. Native action scores are
the captured preupdate actor-rescoring anchors at the same initial weight state;
per-action scores inside the backward invocation were not separately retained.
Native raw per-action ratios/branch decisions, postclip gradients, complete model
gradients/updates, and a common-restored optimizer step remain unavailable.
Full-model CPU clipping is independent of sampled-gradient coverage. These are
numerical diagnostics without a model-quality or pass/fail threshold claim.

Replay the real comparator CLIs after unpacking:

```sh
python -B replay.py --output NEW_REPLAY_DIRECTORY
```

NumPy is required. `tools/` freezes the exact core scripts. To recompute the CPU
model execution as well, supply the original model directory matching
`captures/model-resource-hashes.json` and a fresh output directory:

```sh
python -B reference_cpu.py --inputs captures/fixed-inputs.json --layout captures/layout.json --model MODEL_DIRECTORY --output NEW_CPU_DIRECTORY
```

That second command additionally requires Torch2.8.0, Transformers4.57.1 and the
external model files. No large model checkpoint is embedded. Hashes establish
byte identities and consistency, not independent authenticity. All public tensor
files are no-pickle NumPy arrays; no PT pickle metadata is included.
