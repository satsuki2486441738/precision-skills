"""Replay all core CLI comparisons in a freshly unpacked Slime reference case.

Usage: python replay.py --output NEW_DIRECTORY
NumPy is the only nonstandard dependency for comparator replay. The independent
model reference can separately be recomputed with reference_cpu.py and the pinned
original model files; the 1.2 GB external model is not embedded in this case.
"""
import argparse,json,pathlib,subprocess,sys

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args()
 root=pathlib.Path(__file__).resolve().parent;out=pathlib.Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
 rows=[]
 for stage,tool in [('scores','compare_target_scores.py'),('objectives','compare_tensors.py'),('gradients','compare_tensors.py'),('updates','compare_tensors.py')]:
  command=[sys.executable,'-B',str(root/'tools'/tool),'--contract',str(root/'case'/f'{stage}-contract.json'),
   '--side-a',str(root/'case'/f'{stage}-native.json'),'--side-b',str(root/'case'/f'{stage}-cpu.json'),'--output',str(out/f'{stage}.json')]
  completed=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  report=json.loads((out/f'{stage}.json').read_text())
  assert completed.returncode==0 and report['status']=='no_thresholds',(stage,completed.stderr.decode(),report)
  rows.append({'stage':stage,'exit_code':completed.returncode,'status':report['status'],'metrics':report.get('metrics',report.get('global'))})
 (out/'replay-summary.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
 print(json.dumps(rows,indent=2,allow_nan=False))

if __name__=='__main__':main()
