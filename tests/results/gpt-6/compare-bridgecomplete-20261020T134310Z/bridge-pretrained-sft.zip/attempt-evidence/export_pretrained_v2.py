"""Full source-side tensor comparison; compact portable logits/scores plus raw-file hash index."""
import argparse,datetime,hashlib,json,os,pathlib,shutil,subprocess,sys,zipfile
ROOT=pathlib.Path('<REMOTE_ROOT>')
CASE=ROOT/'bridge-pretrained-20261020T130342Z';TINY=ROOT/'bridge-native-20261020T123300Z'
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False,default=str)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def scrub(s,out):return s.replace(str(out),'<EXPORT_ROOT>').replace(str(ROOT),'<REMOTE_ROOT>').replace('<MODEL_STORE>/','<MODEL_STORE>/').replace('<USER_ID>','<USER_ID>')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--mode');ap.add_argument('--output',required=True);a=ap.parse_args();out=pathlib.Path(a.output);out.mkdir(exist_ok=False);public=out/'public';public.mkdir()
 import torch,numpy as np
 from safetensors.torch import save_file
 torch.set_num_threads(4)
 native=next(p for p in sorted(CASE.glob('sft-*'),reverse=True) if p.is_dir() and (p/'completion.json').exists() and json.loads((p/'batch.json').read_text()).get('eos_token_id') is not None)
 cpu=next(p for p in sorted(CASE.glob('cpu-*'),reverse=True) if p.is_dir() and (p/'completion.json').exists())
 batch=json.loads((native/'batch.json').read_text());assert batch['active_eos']==2 and batch['eos_token_id']!=2
 paths={'bridge-npu':native/'capture.pt','cpu':cpu/'capture.pt'}
 cap={s:torch.load(str(p),map_location='cpu',weights_only=False,mmap=True) for s,p in paths.items()}
 tools=public/'tools';tools.mkdir()
 with zipfile.ZipFile(TINY/'skill-scripts.zip') as z:
  for n in z.namelist():
   if n.endswith('.py'):(tools/pathlib.PurePosixPath(n).name).write_bytes(z.read(n))
 sys.path.insert(0,str(tools));from compare_tensors import Stats,compare as compare_tensor;from compare_target_scores import compare as compare_target;from compare_distributions import compare as compare_distribution;from validate_artifacts import validate
 def chunks(t):
  v=t.detach().reshape(-1)
  for start in range(0,v.numel(),1048576):yield start,v[start:start+1048576]
 tied=[]
 for side,c in cap.items():
  if 'lm_head.weight' in c['before']:
   for stage in ('before','after','gradients'):
    for start,v in chunks(c[stage]['lm_head.weight']):assert torch.equal(v,c[stage]['model.embed_tokens.weight'].reshape(-1)[start:start+v.numel()])
   tied.append({'side':side,'alias':'lm_head.weight','canonical':'model.embed_tokens.weight','exact_before_after_gradient':True})
   for stage in ('before','after','gradients'):c[stage].pop('lm_head.weight')
 names=sorted(cap['bridge-npu']['before']);assert set(names)==set(cap['cpu']['before'])
 count=0
 for n in names:
  a0=cap['bridge-npu']['before'][n];b0=cap['cpu']['before'][n];assert a0.shape==b0.shape
  for start,v in chunks(a0):assert torch.equal(v.float(),b0.reshape(-1)[start:start+v.numel()].float()),'Initial-state mismatch '+n
  for s,c in cap.items():assert c['gradients'][n] is not None and c['gradients'][n].shape==a0.shape and c['after'][n].shape==a0.shape
  count+=a0.numel()
 assert count==596049920
 print('PRETRAINED_INITIAL_STATE_EXACT '+str(count),flush=True)
 tensor_reports={}
 for stage in ('gradients','updates'):
  global_stats=Stats();per={};maximum=-1;coordinate=None;changed={s:0 for s in cap}
  for n in names:
   stat=Stats();size=cap['cpu']['before'][n].numel()
   for start in range(0,size,1048576):
    values=[]
    for side,c in cap.items():
     if stage=='gradients':v=c['gradients'][n].reshape(-1)[start:start+1048576].double().numpy()
     else:
      before=c['before'][n].reshape(-1)[start:start+1048576].double().numpy();after=c['after'][n].reshape(-1)[start:start+1048576].double().numpy();v=after-before;changed[side]+=int(np.count_nonzero(v))
     values.append(v)
    stat.add(*values)
   report=stat.report();per[n]={'shape':list(cap['cpu']['before'][n].shape),**report};global_stats.merge(stat)
   if stat.maximum>maximum:maximum=stat.maximum;coordinate={'parameter':n,'index':stat.max_index}
  total=global_stats.report();total['max_coordinate']=coordinate
  tensor_reports[stage]={'schema_version':1,'kind':'source-full-tensor-comparison','status':'no_thresholds','thresholds':None,'stage':stage,'method':'precision-skill compare_tensors.Stats with FP64 chunk reductions over every captured logical coordinate; updates subtract stored values in FP64','global':total,'tensors':per,'source_capture_sha256':{s:sha(p) for s,p in paths.items()},'portable_replay':'full tensor arrays retained privately at source; this compact archive contains metrics/index, not full tensor arrays'}
  if stage=='updates':tensor_reports[stage]['changed_coordinates']=changed
  dump(public/(stage+'-source-report.json'),tensor_reports[stage]);print('PRETRAINED_TENSORS_DONE '+stage,flush=True)
 hf=pathlib.Path((CASE/'initial-path.txt').read_text());model_files=[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(hf.glob('*.safetensors'))];assert model_files
 dump(public/'model-config.json',json.loads((hf/'config.json').read_text()))
 identity=hashlib.sha256(json.dumps(model_files,sort_keys=True).encode()).hexdigest()
 common={'model':{'architecture':'Qwen3-0.6B, 28layers hidden1024 head128 vocab151936','weight_file_inventory_sha256':identity},'inputs':batch,'scope':'one full-parameter SFT cold SGD step; TP1 PP1 CP1 DP1; tied aliases deduplicated','state':'exact local pretrained BF16 initial values represented in each side storage'}
 side_conditions={'bridge-npu':{'numerics':'BF16 stored params/logits; FP32 native main gradients and masters; MindSpeed real NPU flash attention'},'cpu':{'numerics':'FP32 stored params/gradients/logits; clean CPU Transformers eager attention'}}
 expected={s:[0] for s in cap};ranks=[{'rank':0,'environment':'environment.json','status':'status.json'}];vocab=cap['cpu']['logits'].shape[-1];assert vocab==151936
 for side,c in cap.items():
  folder=public/side;folder.mkdir();dump(folder/'environment.json',{'rank':0,'versions':{'torch':torch.__version__,'numpy':np.__version__},'actual':{**common,**side_conditions[side]},'execution':{'independent_process':True,'native_adapter':'MindSpeed transfer_to_npu' if side=='bridge-npu' else 'none','actual_cann':'9.1.0' if side=='bridge-npu' else 'not used','published_recipe_cann':'8.5.0' if side=='bridge-npu' else 'not used','official_complete_combination_support_claim':False}});dump(folder/'status.json',{'rank':0,'status':'completed'})
  save_file({'logits':c['logits'].detach().contiguous().clone()},str(folder/'logits.safetensors'))
  lp=torch.log_softmax(c['logits'].float(),dim=-1)[0].numpy();np.save(folder/'logprobs.npy',lp,allow_pickle=False)
  dump(folder/'dtypes-and-presence.json',{'logits':str(c['logits'].dtype),'before':{n:str(t.dtype) for n,t in c['before'].items()},'gradients':{n:{'present':True,'dtype':str(t.dtype),'shape':list(t.shape)} for n,t in c['gradients'].items()},'after':{n:str(t.dtype) for n,t in c['after'].items()},'logprobs':'derived FP32 full-vocabulary log_softmax'})
 coords={'sample':'fixed-0','prediction_positions':list(range(16)),'boundary':'full-vocabulary output projection before CE','invocation':0,'execution_stage':'SFT forward'}
 tensor={'name':'logits','shape':list(cap['cpu']['logits'].shape),'present':True,'coordinates':coords}
 tc={'schema_version':2,'kind':'tensors','thresholds':None,'common':common,'side_conditions':side_conditions,'expected_ranks':expected,'stage':'observations','tensors':[tensor]};dump(public/'observations-contract.json',tc)
 targets=[{'sample':'fixed-0','position':i,'token':t} for i,(t,m) in enumerate(zip(batch['labels'],batch['loss_mask'])) if m]
 sc={'schema_version':1,'kind':'target-scores','thresholds':None,'common':common,'side_conditions':side_conditions,'expected_ranks':expected,'targets':targets};dump(public/'targets-contract.json',sc)
 positions=[{'sample':'fixed-0','position':i,'history':batch['input_ids'][:i+1]} for i in range(16)]
 dc={'schema_version':2,'kind':'distributions','thresholds':None,'common':common,'side_conditions':side_conditions,'expected_ranks':expected,'vocab_size':vocab,'normalization_tolerance':1e-5,'renormalization':'none','positions':positions};dump(public/'distributions-contract.json',dc)
 validations={}
 for side in cap:
  base={'common':common,'side':side,'expected_ranks':[0],'ranks':ranks};lp=np.load(public/side/'logprobs.npy')
  dump(public/side/'observations.json',{'schema_version':2,'kind':'tensors',**base,'stage':'observations','tensors':[{**tensor,'shards':[{'offset':0,'value':{'path':'logits.safetensors','key':'logits'}}]}]})
  validations[side]=validate(public/'observations-contract.json',public/side/'observations.json')
  dump(public/side/'targets.json',{'schema_version':1,'kind':'target-scores',**base,'scores':[{**r,'logprob':float(lp[r['position'],r['token']])} for r in targets]})
  dump(public/side/'distributions.json',{'schema_version':2,'kind':'distributions',**base,'positions':[{**r,'scores':{'path':'logprobs.npy','row':r['position']}} for r in positions]})
 results={'observations':compare_tensor(public/'observations-contract.json',public/'bridge-npu/observations.json',public/'cpu/observations.json'),'targets':compare_target(public/'targets-contract.json',public/'bridge-npu/targets.json',public/'cpu/targets.json'),'distributions':compare_distribution(public/'distributions-contract.json',public/'bridge-npu/distributions.json',public/'cpu/distributions.json')}
 for k,r in results.items():dump(public/(k+'-report.json'),json.loads(scrub(json.dumps(r),out)))
 dump(public/'validations.json',json.loads(scrub(json.dumps(validations),out)))
 assert all(r['status']=='no_thresholds' for r in results.values()) and all(v['status']=='validated' for v in validations.values())
 nloss=cap['bridge-npu']['native_per_token_loss'].float().reshape(-1);mask=torch.tensor(batch['loss_mask']);native_loss=float((nloss*mask).sum()/mask.sum());cpu_loss=cap['cpu']['native_loss']
 summary={'native_finetune_returned':True,'native_optimizer_event':cap['bridge-npu']['event'],'initial_values_exact':True,'logical_tensor_count':len(names),'logical_elements':count,'active_target_count':len(targets),'eos_token_id':batch['eos_token_id'],'active_eos_count':batch['active_eos'],'native_losses':{'bridge-npu':native_loss,'cpu':cpu_loss,'absolute_difference':abs(native_loss-cpu_loss)},'gradient_metrics':tensor_reports['gradients']['global'],'update_metrics':tensor_reports['updates']['global'],'target_metrics':results['targets']['metrics'],'thresholds':None,'tied_aliases':tied,'canonical':{'native':native.name,'cpu':cpu.name},'classification':'Slime-prescribed Bridge fork + official MindSpeed/transfer_to_npu; not untouched NVIDIA upstream','coverage':{'complete_on_source':['objective','all trainable gradients','all stored updates','full-vocabulary logits and logprobs'],'portable_offline_replay':['observations','targets','distributions'],'tensor_arrays':'full captures remain private at persistent source; public metrics/index only'},'scope_limits':['one rank only; no sharding or replica precision conclusion','momentum-free SGD, weight decay0, clipping disabled; no stateful optimizer common-restored baseline','published Slime CANN8.5 vs actual CANN9.1; native execution evidence does not establish general support']}
 dump(public/'results.json',summary);dump(public/'model-files.json',model_files)
 dump(public/'CORRECTIONS.json',{'earlier_auxiliary_batch':{'native':'sft-20261020T130235Z','cpu':'cpu-20261020T130039Z','issue':'Tiny-template token2 was carried into this earlier pretrained batch. Its original active_eos:2 metadata was incorrect for the pretrained tokenizer; actual active EOS count was0. Bytes remain frozen in raw evidence.','canonical_status':'excluded from the published canonical numerical comparison'},'canonical':summary['canonical'],'canonical_eos_token_id':batch['eos_token_id'],'canonical_active_eos_count':2})
 # Freeze all original raw files by digest in the persistent private store.
 index=[]
 for p in sorted(CASE.rglob('*')):
  if not p.is_file() or p.is_symlink() or out in p.parents:continue
  rel=p.relative_to(CASE)
  if rel.parts[0]=='cache' or rel.parts[0].startswith('export-'):continue
  index.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p)})
 dump(out/'raw-index-private.json',index);dump(public/'raw-source-index.json',{'storage':'persistent private source; relative paths are resolved using the private locator','files':index,'capture_files':{s:str(p.relative_to(CASE)) for s,p in paths.items()},'full_tensor_portable_replay':False})
 for entry in index:
  p=CASE/entry['path']
  if p.suffix not in ('.log','.json','.py','.txt') or 'converted-native' in p.parts or 'finetuned-native' in p.parts or p.stat().st_size>2_000_000:continue
  dest=public/'attempt-evidence'/entry['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(scrub(p.read_text(errors='replace'),out))
 for name in ('logical-mapping.json','native-device-proof.json','runtime-identity.json'):
  (public/name).write_text(scrub((native/name).read_text(),out))
 for p in public.rglob('*'):
  if p.is_file():
   assert p.stat().st_size<45*1024*1024
   if p.suffix in ('.json','.log','.py','.txt'):assert '<USER_ID>' not in p.read_text(errors='replace') and str(ROOT) not in p.read_text(errors='replace')
 archive=out/'bridge-pretrained-sft.zip'
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(public.rglob('*')):
   if p.is_file():z.write(p,str(p.relative_to(public)))
 assert archive.stat().st_size<45*1024*1024
 dump(out/'summary.json',{**summary,'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'raw_index_sha256':sha(out/'raw-index-private.json')})
 dump(out/'completion.json',{'completed':True});print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
