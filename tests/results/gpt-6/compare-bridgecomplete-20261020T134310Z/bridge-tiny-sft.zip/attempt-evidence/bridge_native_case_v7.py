"""Bounded Bridge provider/conversion/SFT case; real vendor NPU adaptation is explicit."""
import argparse,datetime,hashlib,json,os,pathlib,sys,traceback

ROOT=pathlib.Path('<REMOTE_ROOT>')
CASE=ROOT/'bridge-native-20261020T123300Z'
SRC=ROOT/'rlmg/sources-offline-v1'

def dump(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,default=str))

def init_env():
 for k in ['RANK','WORLD_SIZE','LOCAL_RANK','LOCAL_WORLD_SIZE','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','LOCAL_SIZE','SLURM_PROCID','SLURM_NTASKS','SLURM_LOCALID','OMPI_COMM_WORLD_RANK','OMPI_COMM_WORLD_SIZE','OMPI_COMM_WORLD_LOCAL_RANK','PMI_RANK','PMI_SIZE']:os.environ.pop(k,None)
 for name in ['tmp','ascend','triton','torch_extensions','xdg','hf']:(CASE/'cache'/name).mkdir(parents=True,exist_ok=True)
 os.environ.update(ASCEND_RT_VISIBLE_DEVICES='4,5,6,7',TORCH_DEVICE_BACKEND_AUTOLOAD='1',TMPDIR=str(CASE/'cache/tmp'),ASCEND_CACHE_PATH=str(CASE/'cache/ascend'),TRITON_CACHE_DIR=str(CASE/'cache/triton'),TORCH_EXTENSIONS_DIR=str(CASE/'cache/torch_extensions'),XDG_CACHE_HOME=str(CASE/'cache/xdg'),HF_HOME=str(CASE/'cache/hf'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='4',MAX_JOBS='4',TOKENIZERS_PARALLELISM='false',WANDB_MODE='disabled')
 import tempfile
 short=pathlib.Path('/tmp/brn-'+str(os.getuid())+'-123300')
 if short.is_symlink():assert short.resolve()==(CASE/'cache/tmp').resolve()
 elif short.exists():raise RuntimeError('Private short temporary path occupied')
 else:short.symlink_to(CASE/'cache/tmp',target_is_directory=True)
 os.environ['TMPDIR']=str(short);tempfile.tempdir=str(short)

def native_imports():
 paths=[str(CASE/'overlay'),str(SRC/'megatron'),str(SRC/'mindspeed'),str(SRC/'bridge-npu/src')]
 sys.path[:0]=paths;os.environ['PYTHONPATH']=os.pathsep.join(paths+[os.environ.get('PYTHONPATH','')])
 # This is the official MindSpeed adapter. It imports torch_npu.contrib.transfer_to_npu.
 # CUDA-shaped API calls made by Megatron then execute on the registered real NPU backend.
 sys.argv=[sys.argv[0],'--use-mcore-models','--no-gradient-accumulation-fusion','--attention-backend','flash']
 import torch,torch_npu
 # Resolve the genuine ModelOpt package before MindSpeed registers its TE compatibility
 # module; otherwise ModelOpt's import-time plugin discovery recurses into Bridge.
 import modelopt.torch
 import mindspeed.megatron_adaptor
 return torch,torch_npu

def probe(out):
 torch,torch_npu=native_imports()
 from megatron.bridge import AutoBridge
 from megatron.bridge.models.gpt_provider import GPTModelProvider
 from megatron.bridge.training.finetune import finetune
 import megatron.bridge,megatron.core,mindspeed,inspect
 x=torch.arange(16,dtype=torch.float32,device='npu:0').reshape(4,4);y=x@x.T;torch.npu.synchronize()
 dump(out/'probe.json',{'modules':{m.__name__:{'file':m.__file__,'version':getattr(m,'__version__',None)} for m in [torch,torch_npu,megatron.bridge,megatron.core,mindspeed]},'device':str(y.device),'device_name':torch.npu.get_device_name(0),'tensor':y.cpu().tolist(),'provider_signature':str(inspect.signature(GPTModelProvider)),'autobridge_signature':str(inspect.signature(AutoBridge.from_hf_pretrained)),'finetune_source':inspect.getfile(finetune),'classification':'Slime-prescribed Bridge fork + official MindSpeed/transfer_to_npu; not untouched NVIDIA upstream'})

def prepare(out):
 import torch,transformers,tokenizers
 from transformers import Qwen3Config,Qwen3ForCausalLM,PreTrainedTokenizerFast
 from tokenizers.models import WordLevel
 torch.set_num_threads(4);torch.manual_seed(20261020)
 cfg=Qwen3Config(vocab_size=128,hidden_size=64,intermediate_size=128,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,head_dim=16,max_position_embeddings=64,tie_word_embeddings=True,attention_dropout=0.0,bos_token_id=1,eos_token_id=2,pad_token_id=0,rope_theta=1000000.0)
 m=Qwen3ForCausalLM(cfg).to(torch.bfloat16);m.save_pretrained(out/'hf')
 vocab={'[PAD]':0,'[BOS]':1,'[EOS]':2,'[UNK]':3};vocab.update({'w'+str(i):i for i in range(4,128)})
 tok=tokenizers.Tokenizer(WordLevel(vocab,unk_token='[UNK]'));pt=PreTrainedTokenizerFast(tokenizer_object=tok,pad_token='[PAD]',bos_token='[BOS]',eos_token='[EOS]',unk_token='[UNK]');pt.save_pretrained(out/'hf')
 dump(out/'model.json',{'config':cfg.to_dict(),'torch':torch.__version__,'transformers':transformers.__version__,'parameter_count':sum(p.numel() for p in m.parameters()),'storage_dtype':'bfloat16','seed':20261020,'clean_cpu':True})
 (CASE/'initial-path.txt').write_text(str(out/'hf'))

def cpu(out):
 import torch,transformers
 from transformers import AutoModelForCausalLM
 assert 'torch_npu.contrib.transfer_to_npu' not in sys.modules
 torch.set_num_threads(4);torch.manual_seed(20261020)
 hf=pathlib.Path((CASE/'initial-path.txt').read_text())
 model=AutoModelForCausalLM.from_pretrained(str(hf),torch_dtype=torch.float32,attn_implementation='eager').train()
 ids=torch.tensor([[1,7,11,5,9,17,23,2,31,8,19,6,10,13,29,2,0]],dtype=torch.long)
 mask=torch.ones(16,dtype=torch.float32);mask[0]=0;mask[-1]=0
 labels=ids.clone();labels[:,0]=-100;labels[:,1:][:,mask==0]=-100
 before={n:p.detach().clone() for n,p in model.named_parameters(remove_duplicate=False)}
 opt=torch.optim.SGD(model.parameters(),lr=0.001,momentum=0,weight_decay=0)
 result=model(input_ids=ids,labels=labels,use_cache=False);result.loss.backward()
 gradients={n:None if p.grad is None else p.grad.detach().clone() for n,p in model.named_parameters(remove_duplicate=False)}
 opt.step();after={n:p.detach().clone() for n,p in model.named_parameters(remove_duplicate=False)}
 capture={'before':before,'after':after,'gradients':gradients,'logits':result.logits.detach()[:,:-1].clone(),'native_loss':float(result.loss.detach()),'gradient_presence':{n:None if t is None else {'dtype':str(t.dtype),'shape':list(t.shape)} for n,t in gradients.items()}}
 torch.save(capture,out/'capture.pt');dump(out/'summary.json',{'clean_cpu_reference':True,'transfer_adapter_imported':False,'torch':torch.__version__,'transformers':transformers.__version__,'model_file':str(hf),'stored_dtype':'float32','initial_values_source':'exact BF16 saved tiny model represented in FP32','loss':capture['native_loss'],'valid_tokens':int(mask.sum()),'optimizer':'torch.optim.SGD lr=0.001 momentum=0 weight_decay=0','complete_gradients':all(t is not None for t in gradients.values())})

def sft(out):
 torch,torch_npu=native_imports()
 import functools,dataclasses,importlib
 from megatron.bridge import AutoBridge
 from megatron.bridge.training.config import ConfigContainer,TrainingConfig,OptimizerConfig,SchedulerConfig,LoggerConfig,CheckpointConfig,DistributedInitConfig,RNGConfig,DatasetProvider,DistributedDataParallelConfig
 from megatron.bridge.training.tokenizers.config import TokenizerConfig
 from megatron.bridge.training.gpt_step import forward_step as native_forward
 from megatron.bridge.training.finetune import finetune
 from megatron.core.utils import unwrap_model
 from megatron.core.transformer.enums import AttnBackend
 hf=pathlib.Path((CASE/'initial-path.txt').read_text());bridge=AutoBridge.from_hf_pretrained(str(hf))
 provider=bridge.to_megatron_provider(load_weights=True)
 # This fork's Qwen provider fixes kv_channels=128; explicitly retain the saved
 # tiny model's head dimension so conversion covers the same architecture.
 provider.kv_channels=16
 from mindspeed.args_utils import get_full_args
 vendor_defaults=get_full_args()
 for name,value in vars(vendor_defaults).items():
  if not hasattr(provider,name):setattr(provider,name,value)
 provider.seq_length=16;provider.gradient_accumulation_fusion=False;provider.cross_entropy_loss_fusion=False;provider.masked_softmax_fusion=False;provider.bias_activation_fusion=False;provider.bias_dropout_fusion=False;provider.attention_backend=AttnBackend.flash;provider.bf16=True;provider.params_dtype=torch.bfloat16;provider.pipeline_dtype=torch.bfloat16
 provider.finalize()
 os.environ.update(RANK='0',WORLD_SIZE='1',LOCAL_RANK='0',MASTER_ADDR='127.0.0.1',MASTER_PORT='29847')
 converted=provider.provide_distributed_model(wrap_with_ddp=False)
 bridge.save_megatron_model(converted,out/'converted-native')
 def export(models):
  return {name:t.detach().cpu().clone() for name,t in bridge.export_hf_weights(models,cpu=True,show_progress=False)}
 before_conversion=export(converted);torch.save(before_conversion,out/'converted-hf.pt')
 dump(out/'conversion.json',{'native_parameter_count':sum(p.numel() for m in unwrap_model(converted) for p in m.parameters()),'logical_names':{n:{'shape':list(t.shape),'dtype':str(t.dtype)} for n,t in before_conversion.items()},'checkpoint_saved':True,'checkpoint':str(out/'converted-native')})
 del converted;torch.npu.empty_cache()
 ids=torch.tensor([1,7,11,5,9,17,23,2,31,8,19,6,10,13,29,2,0],dtype=torch.long)
 mask=torch.ones(16,dtype=torch.float32);mask[0]=0;mask[-1]=0
 class DS(torch.utils.data.Dataset):
  def __len__(self):return 4
  def __getitem__(self,idx):return {'tokens':ids[:-1].clone(),'labels':ids[1:].clone(),'loss_mask':mask.clone(),'position_ids':torch.arange(16,dtype=torch.long)}
 @dataclasses.dataclass
 class FixedData(DatasetProvider):
  seq_length:int=16
  def build_datasets(self,context):return DS(),None,None
 cfg=ConfigContainer(model=provider,train=TrainingConfig(train_iters=1,micro_batch_size=1,global_batch_size=1,eval_iters=0,eval_interval=1000),optimizer=OptimizerConfig(optimizer='sgd',lr=0.001,min_lr=0.001,weight_decay=0.0,sgd_momentum=0.0,clip_grad=0.0,bf16=True,params_dtype=torch.bfloat16,use_distributed_optimizer=False),scheduler=SchedulerConfig(lr_decay_style='constant',lr_decay_iters=1),logger=LoggerConfig(log_interval=1,log_throughput=False),checkpoint=CheckpointConfig(pretrained_checkpoint=str(out/'converted-native'),finetune=True,save=str(out/'finetuned-native'),save_interval=1,save_optim=False,save_rng=False,load_optim=False,load_rng=False,save_tokenizer_assets=False),dataset=FixedData(dataloader_type='single',num_workers=0,pin_memory=False),tokenizer=TokenizerConfig(tokenizer_type='HuggingFaceTokenizer',tokenizer_model=str(hf)),dist=DistributedInitConfig(distributed_backend='nccl',use_gloo_process_groups=True),rng=RNGConfig(seed=20261020),ddp=DistributedDataParallelConfig(grad_reduce_in_fp32=True,overlap_grad_reduce=False))
 pretrain_mod=importlib.import_module('megatron.bridge.training.pretrain');original_setup=pretrain_mod.setup;captures={}
 def observed_setup(*args,**kwargs):
  result=original_setup(*args,**kwargs);models=result.model;native=unwrap_model(models)
  captures['before']=export(models);captures['parameters']=[{'name':n,'shape':list(p.shape),'dtype':str(p.dtype),'trainable':p.requires_grad} for m in native for n,p in m.named_parameters()]
  # The output layer emits full-vocabulary logits in [sequence,batch,vocabulary].
  def observe_logits(module,args,output):
   t=output[0] if isinstance(output,tuple) else output
   if t is not None:captures['logits']=t.detach().float().cpu().transpose(0,1).clone()
  native[0].output_layer.register_forward_hook(observe_logits)
  original_step=result.optimizer.step
  def observed_step(*a,**k):
   raw={n:p.main_grad.detach().cpu().clone() if hasattr(p,'main_grad') and p.main_grad is not None else p.grad.detach().cpu().clone() if p.grad is not None else None for m in native for n,p in m.named_parameters()}
   captures['gradient_presence']={n:None if t is None else {'dtype':str(t.dtype),'shape':list(t.shape)} for n,t in raw.items()}
   torch.save(raw,out/'native-main-grad.pt')
   step_result=original_step(*a,**k);captures['event']=step_result;captures['after']=export(models)
   # Run the exact Bridge mapping on captured FP32 gradients after the update.
   saved=[(p,p.data) for m in native for p in m.parameters()]
   try:
    for m in native:
     for n,p in m.named_parameters():
      if raw[n] is None:raise RuntimeError('Absent gradient '+n)
      p.data=raw[n].to(device=p.device)
    captures['gradients']=export(models)
   finally:
    for p,value in saved:p.data=value
   return step_result
  result.optimizer.step=observed_step;return result
 pretrain_mod.setup=observed_setup
 def observed_forward(state,data_iterator,model,return_schedule_plan=False):
  result=native_forward(state,data_iterator,model,return_schedule_plan)
  captures['native_per_token_loss']=result[0].detach().float().cpu().clone()
  return result
 try:finetune(cfg,observed_forward)
 finally:pretrain_mod.setup=original_setup
 assert captures.get('event') and bool(captures['event'][0])
 torch.save(captures,out/'capture.pt')
 dump(out/'batch.json',{'input_ids':ids[:-1].tolist(),'labels':ids[1:].tolist(),'loss_mask':mask.tolist(),'positions':list(range(16)),'active_eos':sum(1 for l,m in zip(ids[1:].tolist(),mask.tolist()) if l==2 and m),'token_count':int(mask.sum()),'optimizer':{'name':'native Megatron SGD','lr':0.001,'momentum':0.0,'weight_decay':0.0,'clip_grad':0.0}})
 dump(out/'summary.json',{'native_finetune_returned':True,'native_optimizer_event':captures['event'],'trainable_parameters':len(captures['parameters']),'logical_weights':len(captures['before']),'logical_gradient_count':len(captures['gradients']),'finite_gradients':all(bool(torch.isfinite(t).all()) for t in captures['gradients'].values()),'storage_dtype':'bfloat16','main_gradient_dtype':'float32','classification':'Slime-prescribed Bridge fork + official MindSpeed NPU adaptation; not untouched NVIDIA upstream'})

def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 out=pathlib.Path(a.output).resolve();assert out.is_relative_to(CASE);out.mkdir(parents=True,exist_ok=False)
 init_env();dump(out/'entry.json',{'mode':a.mode,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.executable,'pid':os.getpid(),'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'visible_devices':os.environ['ASCEND_RT_VISIBLE_DEVICES']})
 try:
  globals()[a.mode](out);dump(out/'completion.json',{'completed':True,'mode':a.mode})
 except BaseException as e:
  dump(out/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise

if __name__=='__main__':main()
