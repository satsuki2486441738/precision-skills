"""Bounded Bridge provider/conversion/SFT case; real vendor NPU adaptation is explicit."""
import argparse,datetime,hashlib,json,os,pathlib,sys,traceback

ROOT=pathlib.Path('<REMOTE_ROOT>')
CASE=ROOT/'bridge-native-20261020T123300Z'
SRC=ROOT/'rlmg/sources-offline-v1'

def dump(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,default=str))

def init_env():
 for k in ['RANK','WORLD_SIZE','LOCAL_RANK','LOCAL_WORLD_SIZE','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','LOCAL_SIZE','SLURM_PROCID','SLURM_NTASKS','SLURM_LOCALID','OMPI_COMM_WORLD_RANK','OMPI_COMM_WORLD_SIZE','OMPI_COMM_WORLD_LOCAL_RANK','PMI_RANK','PMI_SIZE']:os.environ.pop(k,None)
 for name in ['tmp','ascend','triton','torch_extensions','xdg','hf']:(CASE/'cache'/name).mkdir(parents=True,exist_ok=True)
 os.environ.update(ASCEND_RT_VISIBLE_DEVICES='4,5,6,7',TORCH_DEVICE_BACKEND_AUTOLOAD='1',TMPDIR=str(CASE/'cache/tmp'),ASCEND_CACHE_PATH=str(CASE/'cache/ascend'),TRITON_CACHE_DIR=str(CASE/'cache/triton'),TORCH_EXTENSIONS_DIR=str(CASE/'cache/torch_extensions'),XDG_CACHE_HOME=str(CASE/'cache/xdg'),HF_HOME=str(CASE/'cache/hf'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='4',MAX_JOBS='4',TOKENIZERS_PARALLELISM='false',WANDB_MODE='disabled')

def native_imports():
 paths=[str(SRC/'megatron'),str(SRC/'mindspeed'),str(SRC/'bridge-npu/src')]
 sys.path[:0]=paths;os.environ['PYTHONPATH']=os.pathsep.join(paths+[os.environ.get('PYTHONPATH','')])
 # This is the official MindSpeed adapter. It imports torch_npu.contrib.transfer_to_npu.
 # CUDA-shaped API calls made by Megatron then execute on the registered real NPU backend.
 sys.argv=[sys.argv[0],'--use-mcore-models','--no-gradient-accumulation-fusion','--attention-backend','flash']
 import torch,torch_npu
 import mindspeed.megatron_adaptor
 return torch,torch_npu

def probe(out):
 torch,torch_npu=native_imports()
 from megatron.bridge import AutoBridge
 from megatron.bridge.models.gpt_provider import GPTModelProvider
 from megatron.bridge.training.finetune import finetune
 import megatron.bridge,megatron.core,mindspeed,inspect
 x=torch.arange(16,dtype=torch.float32,device='npu:0').reshape(4,4);y=x@x.T;torch.npu.synchronize()
 dump(out/'probe.json',{'modules':{m.__name__:{'file':m.__file__,'version':getattr(m,'__version__',None)} for m in [torch,torch_npu,megatron.bridge,megatron.core,mindspeed]},'device':str(y.device),'device_name':torch.npu.get_device_name(0),'tensor':y.cpu().tolist(),'provider_signature':str(inspect.signature(GPTModelProvider)),'autobridge_signature':str(inspect.signature(AutoBridge.from_hf_pretrained)),'finetune_source':inspect.getfile(finetune),'classification':'Slime-prescribed Bridge fork + official MindSpeed/transfer_to_npu; not untouched NVIDIA upstream'})

def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 out=pathlib.Path(a.output).resolve();assert out.is_relative_to(CASE);out.mkdir(parents=True,exist_ok=False)
 init_env();dump(out/'entry.json',{'mode':a.mode,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.executable,'pid':os.getpid(),'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'visible_devices':os.environ['ASCEND_RT_VISIBLE_DEVICES']})
 try:
  globals()[a.mode](out);dump(out/'completion.json',{'completed':True,'mode':a.mode})
 except BaseException as e:
  dump(out/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise

if __name__=='__main__':main()
