"""Freeze raw private evidence and export portable, dtype-preserving tiny SFT comparisons."""
import argparse,datetime,hashlib,importlib.metadata,json,os,pathlib,re,shutil,subprocess,sys,zipfile

ROOT=pathlib.Path('<REMOTE_ROOT>')
CASE=ROOT/'bridge-native-20261020T123300Z'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False,default=str)+'\n')
def scrub(s,export):
 return s.replace(str(export),'<EXPORT_ROOT>').replace(str(ROOT),'<REMOTE_ROOT>').replace('<MODEL_STORE>/','<MODEL_STORE>/').replace('<USER_ID>','<USER_ID>')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--mode');ap.add_argument('--output',required=True);a=ap.parse_args();out=pathlib.Path(a.output);out.mkdir(exist_ok=False)
 public=out/'public';public.mkdir();private=out/'private';private.mkdir()
 import torch,numpy as np
 from safetensors.torch import save_file
 torch.set_num_threads(4)
 completed=[p for p in sorted(CASE.glob('sft-*')) if p.is_dir() and (p/'completion.json').exists() and (p/'capture.pt').exists()]
 assert completed,'No completed native SFT capture'
 native=completed[-1];cpu=next(p for p in sorted(CASE.glob('cpu-*'),reverse=True) if p.is_dir() and (p/'completion.json').exists())
 cap={'bridge-npu':torch.load(native/'capture.pt',map_location='cpu',weights_only=False),'cpu':torch.load(cpu/'capture.pt',map_location='cpu',weights_only=False)}
 batch=json.loads((native/'batch.json').read_text());hf=pathlib.Path((CASE/'initial-path.txt').read_text());init_hash=sha(hf/'model.safetensors')
 tied=[]
 for side,c in cap.items():
  if 'lm_head.weight' in c['before']:
   for stage in ('before','after','gradients'):assert torch.equal(c[stage]['lm_head.weight'],c[stage]['model.embed_tokens.weight'])
   tied.append({'side':side,'alias':'lm_head.weight','canonical':'model.embed_tokens.weight','exact_before_after_gradient':True})
   for stage in ('before','after','gradients'):c[stage].pop('lm_head.weight')
 names=sorted(cap['bridge-npu']['before']);assert set(names)==set(cap['cpu']['before'])
 for name in names:
  assert torch.equal(cap['bridge-npu']['before'][name].float(),cap['cpu']['before'][name].float()),'Different initial value '+name
  for side,c in cap.items():assert c['gradients'][name] is not None and c['after'][name].shape==c['before'][name].shape
 common={'model':{'architecture':'tiny Qwen3 2x64 head_dim16 vocab128','initial_safetensors_sha256':init_hash},'inputs':batch,'scope':'one full-parameter SFT cold SGD step; TP1 PP1 CP1 DP1; tied aliases deduplicated','state':'exact saved BF16 initial values represented in each side storage'}
 sides={'bridge-npu':{'numerics':'BF16 stored model and logits; FP32 Megatron main gradients/master weights; real NPU MindSpeed flash attention'},'cpu':{'numerics':'FP32 stored model and gradients; clean CPU Transformers eager attention'}}
 versions={k:importlib.metadata.version(k) for k in ('torch','torch-npu','transformers','numpy','safetensors')}
 for side,c in cap.items():
  folder=public/side;folder.mkdir();dump(folder/'environment.json',{'rank':0,'versions':versions,'actual':{**common,**sides[side]},'execution':{'independent_process':True,'adapter':'official MindSpeed + torch_npu transfer_to_npu' if side=='bridge-npu' else 'none; clean CPU','classification':'Slime-prescribed Megatron Bridge fork at 35b4ebfc486fb15dcc0273ceea804c3606be948a' if side=='bridge-npu' else 'Transformers 4.57.1 on PyTorch CPU'}});dump(folder/'status.json',{'rank':0,'status':'completed'})
  for stage in ('before','after','gradients'):save_file({n:t.detach().contiguous().clone() for n,t in c[stage].items()},str(folder/(stage+'.safetensors')))
  save_file({'logits':c['logits'].detach().contiguous()},str(folder/'logits.safetensors'))
  lp=torch.log_softmax(c['logits'].float(),dim=-1)[0].numpy();np.save(folder/'logprobs.npy',lp,allow_pickle=False)
  dump(folder/'native-dtypes.json',{'logits':str(c['logits'].dtype),'before':{n:str(t.dtype) for n,t in c['before'].items()},'gradients':{n:str(t.dtype) for n,t in c['gradients'].items()},'after':{n:str(t.dtype) for n,t in c['after'].items()},'scores':'derived FP32 full-vocabulary log_softmax from captured logits'})
 expected={s:[0] for s in cap};ranks=[{'rank':0,'environment':'environment.json','status':'status.json'}]
 tools=public/'tools';tools.mkdir()
 with zipfile.ZipFile(CASE/'skill-scripts.zip') as z:
  for name in z.namelist():
   if name.endswith('.py'): (tools/pathlib.PurePosixPath(name).name).write_bytes(z.read(name))
 sys.path.insert(0,str(tools));from compare_tensors import compare as compare_tensor;from compare_target_scores import compare as compare_target;from compare_distributions import compare as compare_distribution;from validate_artifacts import validate
 results={};validations={}
 for stage in ('gradients','updates','observations'):
  tensors=[{'name':n,'shape':list(cap['cpu']['before'][n].shape),'present':True} for n in names] if stage!='observations' else [{'name':'logits','shape':list(cap['cpu']['logits'].shape),'present':True,'coordinates':{'sample':'fixed-0','prediction_positions':list(range(16)),'boundary':'full vocabulary output projection before CE','invocation':0,'execution_stage':'SFT forward'}}]
  contract={'schema_version':2,'kind':'tensors','thresholds':None,'common':common,'side_conditions':sides,'expected_ranks':expected,'stage':stage,'tensors':tensors};contract_path=public/(stage+'-contract.json');dump(contract_path,contract)
  manifests=[]
  for side in cap:
   entries=[]
   for t in tensors:
    n=t['name'];shard={'offset':0}
    if stage=='updates':shard.update(before={'path':'before.safetensors','key':n},after={'path':'after.safetensors','key':n})
    else:shard['value']={'path':stage+'.safetensors' if stage!='observations' else 'logits.safetensors','key':n}
    entries.append({**t,'shards':[shard]})
   manifest={'schema_version':2,'kind':'tensors','common':common,'side':side,'expected_ranks':[0],'ranks':ranks,'stage':stage,'tensors':entries}
   if stage=='updates':manifest['events']={'qwen3':'applied'}
   path=public/side/(stage+'.json');dump(path,manifest);manifests.append(path);validations[side+'-'+stage]=validate(contract_path,path)
  results[stage]=compare_tensor(contract_path,*manifests);dump(public/(stage+'-report.json'),json.loads(scrub(json.dumps(results[stage]),out)))
 targets=[{'sample':'fixed-0','position':i,'token':t} for i,(t,m) in enumerate(zip(batch['labels'],batch['loss_mask'])) if m]
 sc={'schema_version':1,'kind':'target-scores','thresholds':None,'common':common,'side_conditions':sides,'expected_ranks':expected,'targets':targets};dump(public/'targets-contract.json',sc)
 positions=[{'sample':'fixed-0','position':i,'history':batch['input_ids'][:i+1]} for i in range(16)]
 dc={'schema_version':2,'kind':'distributions','thresholds':None,'common':common,'side_conditions':sides,'expected_ranks':expected,'vocab_size':128,'normalization_tolerance':1e-5,'renormalization':'none','positions':positions};dump(public/'distributions-contract.json',dc)
 for side in cap:
  lp=np.load(public/side/'logprobs.npy');scores=[{**r,'logprob':float(lp[r['position'],r['token']])} for r in targets]
  base={'common':common,'side':side,'expected_ranks':[0],'ranks':ranks}
  dump(public/side/'targets.json',{'schema_version':1,'kind':'target-scores',**base,'scores':scores})
  dump(public/side/'distributions.json',{'schema_version':2,'kind':'distributions',**base,'positions':[{**r,'scores':{'path':'logprobs.npy','row':r['position']}} for r in positions]})
 results['targets']=compare_target(public/'targets-contract.json',public/'bridge-npu/targets.json',public/'cpu/targets.json');results['distributions']=compare_distribution(public/'distributions-contract.json',public/'bridge-npu/distributions.json',public/'cpu/distributions.json')
 for k in ('targets','distributions'):dump(public/(k+'-report.json'),json.loads(scrub(json.dumps(results[k]),out)))
 dump(public/'validations.json',json.loads(scrub(json.dumps(validations),out)))
 native_losses=cap['bridge-npu']['native_per_token_loss'].float().reshape(-1);mask=torch.tensor(batch['loss_mask']);native_loss=float((native_losses*mask).sum()/mask.sum());cpu_loss=cap['cpu']['native_loss']
 summary={'native_finetune_returned':True,'native_optimizer_event':cap['bridge-npu']['event'],'initial_values_exact':True,'logical_tensor_count':len(names),'logical_elements':sum(cap['cpu']['before'][n].numel() for n in names),'all_trainable_gradients_present':True,'active_target_count':len(targets),'active_eos_count':batch['active_eos'],'native_losses':{'bridge-npu':native_loss,'cpu':cpu_loss,'absolute_difference':abs(native_loss-cpu_loss)},'gradient_metrics':results['gradients'].get('global'),'update_metrics':results['updates'].get('global'),'target_metrics':results['targets'].get('metrics'),'reports':{k:v['status'] for k,v in results.items()},'thresholds':None,'tied_aliases':tied,'classification':'Native finetune/provider/conversion via Slime-prescribed Bridge fork + official MindSpeed; untouched NVIDIA Bridge remains unexecuted on NPU','scope_limits':['tiny seeded model only in this independent comparison','no clipping; stateless momentum-free SGD, so no common-restored stateful-optimizer baseline required','one rank only; no sharding or replica precision conclusion']}
 dump(public/'results.json',summary)
 # Full original raw files stay in a separate frozen private archive, including failed attempts.
 raw=[]
 for p in sorted(CASE.rglob('*')):
  if not p.is_file() or p.is_symlink() or out in p.parents:continue
  rel=p.relative_to(CASE)
  if rel.parts[0] in ('cache','overlay') or rel.parts[0].startswith('export-') or rel.name=='skill-scripts.zip':continue
  raw.append((p,rel));
 private_index=[{'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p)} for p,rel in raw];dump(private/'raw-index.json',private_index)
 with zipfile.ZipFile(private/'raw-evidence.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p,rel in raw:z.write(p,str(rel))
 dump(public/'raw-evidence-index.json',{'private_archive_sha256':sha(private/'raw-evidence.zip'),'private_archive_bytes':(private/'raw-evidence.zip').stat().st_size,'file_count':len(raw),'files':private_index})
 for p,rel in raw:
  if p.suffix not in ('.log','.json','.py','.txt') or 'converted-native' in rel.parts or 'finetuned-native' in rel.parts or p.stat().st_size>2_000_000:continue
  dest=public/'attempt-evidence'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(scrub(p.read_text(errors='replace'),out))
 dump(public/'native-logical-mapping.json',json.loads((native/'logical-mapping.json').read_text()))
 dump(public/'native-parameter-inventory.json',cap['bridge-npu']['parameters'])
 dump(public/'native-gradient-presence.json',cap['bridge-npu']['gradient_presence'])
 # Read-only git identities, actual patches, and licenses identify the executed vendor stack.
 identities={}
 for name in ('bridge-npu','megatron','mindspeed'):
  tree=ROOT/'rlmg/sources-offline-v1'/name;git=['git','-c','safe.directory='+str(tree)]
  head=subprocess.check_output(git+['rev-parse','HEAD'],cwd=tree,text=True).strip();diff=subprocess.check_output(git+['diff','--binary'],cwd=tree)
  identities[name]={'commit':head,'diff_sha256':hashlib.sha256(diff).hexdigest(),'diff_bytes':len(diff)}
  (public/(name+'-actual.patch')).write_text(scrub(diff.decode(errors='replace'),out))
  lic=tree/'LICENSE'
  if lic.exists():shutil.copyfile(lic,public/(name+'-LICENSE.txt'))
 dump(public/'source-identities.json',identities)
 assert all(r['status']=='no_thresholds' for r in results.values()),summary
 assert all(v['status']=='validated' for v in validations.values())
 # No pickle files enter the publishable artifact. Safetensors preserve BF16/F32 storage.
 assert not any(p.suffix in ('.pt','.pth','.bin') for p in public.rglob('*'))
 for p in public.rglob('*'):
  if p.is_file() and p.suffix in ('.json','.log','.py','.txt','.patch'):assert str(ROOT) not in p.read_text(errors='replace') and '<USER_ID>' not in p.read_text(errors='replace'),str(p)
 with zipfile.ZipFile(out/'bridge-tiny-sft.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(public.rglob('*')):
   if p.is_file():z.write(p,str(p.relative_to(public)))
 dump(out/'summary.json',{**summary,'public_archive':str(out/'bridge-tiny-sft.zip'),'public_archive_sha256':sha(out/'bridge-tiny-sft.zip'),'public_archive_bytes':(out/'bridge-tiny-sft.zip').stat().st_size,'private_archive_sha256':sha(private/'raw-evidence.zip')})
 dump(out/'completion.json',{'completed':True})
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
