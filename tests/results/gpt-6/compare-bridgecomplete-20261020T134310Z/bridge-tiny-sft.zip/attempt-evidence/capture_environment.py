import argparse,datetime,hashlib,importlib.metadata,json,os,pathlib,subprocess,sys
ap=argparse.ArgumentParser();ap.add_argument('--mode');ap.add_argument('--output',required=True);a=ap.parse_args();out=pathlib.Path(a.output);out.mkdir(exist_ok=False)
root=pathlib.Path('<REMOTE_ROOT>');case=root/'bridge-native-20261020T123300Z'
import torch,torch_npu,transformers,numpy
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.executable,'clean_process':True,'modules':{m.__name__:{'file':m.__file__,'version':getattr(m,'__version__',None)} for m in (torch,torch_npu,transformers,numpy)},'installed_metadata':{},'npu_smi':subprocess.check_output(['npu-smi','info'],text=True),'native_processes':[]}
for name in ('torch','torch-npu','transformers','numpy','safetensors','nvidia-modelopt'):
 d=importlib.metadata.distribution(name);record['installed_metadata'][name]={'version':d.version,'metadata_path':str(d._path),'requires':d.requires}
for p in sorted(case.glob('*.launch.json')):
 x=json.loads(p.read_text());pid=x['pid'];proc=pathlib.Path('/proc',str(pid));record['native_processes'].append({'launch':p.name,'pid':pid,'alive':proc.exists(),'command':(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace') if proc.exists() else None})
uv=root/'rlmg/environments/tooling/bin/uv';record['pip_freeze']=subprocess.check_output([str(uv),'pip','freeze','--python',sys.executable],text=True)
(out/'environment.json').write_text(json.dumps(record,indent=2)+'\n');(out/'completion.json').write_text('{"completed":true}\n');print(json.dumps({'modules':record['modules'],'processes':record['native_processes']},indent=2))
