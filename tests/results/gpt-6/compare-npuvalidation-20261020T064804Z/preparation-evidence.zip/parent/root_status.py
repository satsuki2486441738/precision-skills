import json
from pathlib import Path
root=Path('/REMOTE_WORKSPACE/root')
result=[]
for p in sorted((root/'runs').glob('compare-install-*')):
 item={'attempt':p.name}
 if (p/'journal.jsonl').exists():item['journal']=(p/'journal.jsonl').read_text().splitlines()[-4:]
 logs=sorted(p.glob('*.log'),key=lambda f:f.stat().st_mtime)
 if logs:item['latest_log']={'name':logs[-1].name,'tail':logs[-1].read_text(errors='replace')[-1800:]}
 if (p/'status.json').exists():item['status']=json.loads((p/'status.json').read_text())
 result.append(item)
print(json.dumps(result,indent=2))
