"""Prepare private storage and record versions; shared packages stay read-only."""
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root=Path('/REMOTE_WORKSPACE/root')
for name in ['cache','tmp','environments','scripts','sources','models','runs']:
    (root/name).mkdir(parents=True,exist_ok=True)
os.environ['TMPDIR']=str(root/'tmp')
report={'root':str(root),'disk_free':shutil.disk_usage(root).free,'python':sys.executable,'packages':{},'models':[],'tools':{}}
for name in ['torch','torch-npu','transformers','accelerate','trl','llamafactory','ms-swift','axolotl','datasets','peft','tokenizers','huggingface-hub','numpy','safetensors','pyyaml','sentencepiece','deepspeed','vllm','vllm-ascend','triton-ascend','dlinfer','lmdeploy']:
    try:report['packages'][name]=metadata.version(name)
    except metadata.PackageNotFoundError:pass
for path in ['/SHARED_MODELS/Qwen3-0.6B','/SHARED_MODELS/Qwen3-0.6B-Base','/SHARED_MODELS/Qwen']:
    p=Path(path)
    candidates=[p]
    if p.is_dir() and not (p/'config.json').is_file():
        candidates += [q for q in p.iterdir() if q.is_dir() and not q.name.startswith('.')][:64]
    for q in candidates:
        f=q/'config.json'
        try:
            if f.is_file() and f.stat().st_size<200000:
                cfg=json.loads(f.read_text())
                report['models'].append({'path':str(q),'model_type':cfg.get('model_type'),'architectures':cfg.get('architectures'),'vocab_size':cfg.get('vocab_size'),'hidden_size':cfg.get('hidden_size'),'layers':cfg.get('num_hidden_layers'),'dtype':cfg.get('torch_dtype',cfg.get('dtype')),'weights':sorted(x.name for x in q.glob('*.safetensors'))[:12]})
        except (OSError,ValueError):pass
for tool in ['git','gcc','g++','cmake','ninja','curl','wget','uv','docker','podman']:
    report['tools'][tool]=shutil.which(tool)
os.environ['ASCEND_RT_VISIBLE_DEVICES']='0,1,2,3'
import torch,torch_npu
report['runtime']={'torch':torch.__version__,'torch_path':torch.__file__,'torch_npu':torch_npu.__version__,'device_count':torch.npu.device_count(),'name':torch.npu.get_device_name(0)}
print(json.dumps(report,indent=2))
