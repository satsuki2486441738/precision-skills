"""Install complete pinned case environments without changing shared Python."""
import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import sys
import venv

root=Path('/REMOTE_WORKSPACE/root')
lane=sys.argv[1]
profiles={
 'swift-trl': {'torch':'2.9.0','npu':'2.9.0.post6','packages':['transformers==5.3.0','accelerate==1.14.0','datasets==4.8.4','peft==0.20.0','trl==0.29.1','ms-swift==4.6.0','numpy==1.26.4']},
 'factory': {'torch':'2.9.0','npu':'2.9.0.post6','packages':['torchvision==0.24.0','torchaudio==2.9.0','transformers==5.3.0','accelerate==1.11.0','datasets==4.0.0','peft==0.18.1','trl==0.24.0','llamafactory==0.9.5','numpy==1.26.4']},
 'axolotl': {'torch':'2.10.0','npu':'2.10.0.post4','packages':['axolotl==0.17.0','numpy==2.2.6']},
}
profile=profiles[lane]
attempt=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=root/'runs'/f'compare-install-{lane}-{attempt}'
out.mkdir(parents=True)
envdir=root/'environments'/lane
os.environ.update(PIP_CACHE_DIR=str(root/'cache'),TMPDIR=str(root/'tmp'),MAX_JOBS='4',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PIP_DISABLE_PIP_VERSION_CHECK='1')
(out/'profile.json').write_text(json.dumps(profile,indent=2))
if not (envdir/'bin/python').is_file():venv.EnvBuilder(with_pip=True).create(envdir)
python=str(envdir/'bin/python')
stages=[('pip',[python,'-m','pip','install','--upgrade','pip','setuptools','wheel','--index-url','https://pypi.tuna.tsinghua.edu.cn/simple']),
 ('torch',[python,'-m','pip','install',f"torch=={profile['torch']}",'--index-url','https://download.pytorch.org/whl/cpu','--extra-index-url','https://pypi.tuna.tsinghua.edu.cn/simple']),
 ('npu',[python,'-m','pip','install',f"torch-npu=={profile['npu']}",'--index-url','https://pypi.tuna.tsinghua.edu.cn/simple']),
 ('frameworks',[python,'-m','pip','install','--no-build-isolation',*profile['packages'],'--index-url','https://pypi.tuna.tsinghua.edu.cn/simple','--extra-index-url','https://download.pytorch.org/whl/cpu']),
 ('freeze',[python,'-m','pip','freeze']),('check',[python,'-m','pip','check'])]
failed=None
for stage,cmd in stages:
 if failed and stage not in ['freeze','check']:continue
 with (out/(stage+'.log')).open('wb') as log:
  try:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=2400).returncode
  except subprocess.TimeoutExpired:code=124
 event={'stage':stage,'returncode':code,'command':cmd,'utc':dt.datetime.now(dt.timezone.utc).isoformat()}
 with (out/'journal.jsonl').open('a') as f:f.write(json.dumps(event)+'\n')
 if code and failed is None:failed=stage
(out/'status.json').write_text(json.dumps({'lane':lane,'environment':str(envdir),'failed_stage':failed,'native_completed':False,'attempt':str(out)},indent=2))
raise SystemExit(1 if failed else 0)
