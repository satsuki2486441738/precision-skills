"""Native TRL, Swift and LLaMAFactory SFT with passive state/tensor capture.

Use --prepare once, then --framework trl|swift|factory --model tiny|pretrained
--precision fp32|bf16 --output FRESH. A successful import is never completion.
The reference independently reloads the checkpoint and initial trainable state;
it never reads native gradients or post-update state to perform its execution.
"""
import argparse
import datetime as dt
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import sys

ROOT=Path('/REMOTE_WORKSPACE/root')
os.environ.setdefault('ASCEND_RT_VISIBLE_DEVICES','0,1,2,3')
os.environ.setdefault('OMP_NUM_THREADS','4')
os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('HF_DATASETS_OFFLINE','1')
os.environ.setdefault('WANDB_MODE','disabled')
os.environ.setdefault('HF_HOME',str(ROOT/'cache/huggingface'))
os.environ.setdefault('TMPDIR',str(ROOT/'tmp'))

import torch
import torch_npu
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainerCallback, set_seed


def dump(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False,default=str))


def cpu(value):
    if torch.is_tensor(value):return value.detach().cpu().clone()
    if isinstance(value,dict):return {k:cpu(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return type(value)(cpu(v) for v in value)
    return value


def parameters(model):
    return {n:p for n,p in model.named_parameters() if p.requires_grad}


def prepare():
    from tokenizers import Tokenizer
    from tokenizers.models import WordLevel
    from tokenizers.pre_tokenizers import WhitespaceSplit
    from transformers import PreTrainedTokenizerFast, Qwen2Config, Qwen2ForCausalLM
    path=ROOT/'models/tiny-qwen2-seed20261020'
    if path.exists():
        assert (path/'fixture-identity.json').is_file(),'Incomplete fixture; preserve and select a new fixture path'
        print(json.dumps({'fixture_already_present':str(path)}));return
    path.mkdir(parents=True)
    set_seed(20261020)
    words=['<|endoftext|>','<unk>','<|im_start|>','<|im_end|>','user','assistant','system','red','blue','green','yellow','Name','a','color','Answer','with','one','word','What','is','two','plus','three','five','Hello','Say','yes','no']
    words += ['token'+str(i) for i in range(256-len(words))]
    raw=Tokenizer(WordLevel(vocab={w:i for i,w in enumerate(words)},unk_token='<unk>'))
    raw.pre_tokenizer=WhitespaceSplit()
    tok=PreTrainedTokenizerFast(tokenizer_object=raw,pad_token=words[0],unk_token=words[1],bos_token=words[2],eos_token=words[3],additional_special_tokens=words[2:4],model_max_length=256)
    tok.chat_template="{% for message in messages %}{{ '<|im_start|>' + message['role'] + '\\n' + message['content'] + '<|im_end|>\\n' }}{% endfor %}{% if add_generation_prompt %}{{ '<|im_start|>assistant\\n' }}{% endif %}"
    tok.save_pretrained(path)
    cfg=Qwen2Config(vocab_size=256,hidden_size=128,intermediate_size=256,num_hidden_layers=2,num_attention_heads=2,num_key_value_heads=2,max_position_embeddings=256,attention_dropout=0.0,tie_word_embeddings=False,bos_token_id=2,eos_token_id=3,pad_token_id=0)
    model=Qwen2ForCausalLM(cfg)
    model.save_pretrained(path,safe_serialization=True)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in path.iterdir() if p.is_file()}
    dump(path/'fixture-identity.json',{'initialization':'seeded_random_not_pretrained','seed':20261020,'files_sha256':hashes,'config':cfg.to_dict()})
    print(json.dumps({'prepared':str(path),'files_sha256':hashes}))


class Capture(TrainerCallback):
    def __init__(self,out):
        self.out=out;self.payload={};self.events=[];self.steps=0;self.handles=[]

    def on_train_begin(self,args,state,control,model=None,**kwargs):
        assert all(p.device.type=='npu' for p in parameters(model).values()),'Native model not on NPU'
        self.model=model
        self.payload['before']={n:cpu(p) for n,p in parameters(model).items()}
        self.settings=args.to_dict()
        def before(module,pos,kw):
            if 'batch' not in self.payload and module.training and kw.get('labels') is not None:
                self.payload['batch']={k:cpu(v) for k,v in kw.items() if torch.is_tensor(v)}
        def after(module,pos,kw,output):
            if 'logits' not in self.payload and module.training and 'batch' in self.payload and getattr(output,'logits',None) is not None:
                self.payload['logits']=cpu(output.logits)
                self.payload['loss']=cpu(output.loss)
        self.handles=[model.register_forward_pre_hook(before,with_kwargs=True),model.register_forward_hook(after,with_kwargs=True)]

    def on_pre_optimizer_step(self,args,state,control,model=None,optimizer=None,**kwargs):
        self.payload['gradients']={n:cpu(p.grad) for n,p in parameters(model).items()}
        self.payload['optimizer_before']=cpu(optimizer.state_dict())
        self.optimizer_class=type(optimizer).__module__+'.'+type(optimizer).__qualname__

    def on_optimizer_step(self,args,state,control,model=None,optimizer=None,**kwargs):
        self.steps+=1
        self.payload['after']={n:cpu(p) for n,p in parameters(model).items()}
        self.payload['optimizer_after']=cpu(optimizer.state_dict())

    def on_log(self,args,state,control,logs=None,**kwargs):
        self.events.append({'step':state.global_step,'logs':logs})

    def on_train_end(self,args,state,control,**kwargs):
        for handle in self.handles:handle.remove()
        assert state.global_step==1 and self.steps==1,(state.global_step,self.steps)
        assert {'before','batch','logits','loss','gradients','after'}.issubset(self.payload),self.payload.keys()
        labels=self.payload['batch']['labels'][:,1:]
        valid=labels.ne(-100)
        assert int(valid.sum())>0,'No active training targets'
        updates={n:self.payload['after'][n].float()-p.float() for n,p in self.payload['before'].items()}
        gradients=[g for g in self.payload['gradients'].values() if g is not None]
        changed=sum(int(torch.count_nonzero(x)) for x in updates.values())
        assert changed>0,'Optimizer did not change stored parameters'
        assert gradients and all(torch.isfinite(g).all() for g in gradients)
        assert torch.isfinite(self.payload['loss']) and torch.isfinite(self.payload['logits']).all()
        torch.save(self.payload,self.out/'native-captures.pt')
        dump(self.out/'observations.json',{'optimizer_steps':self.steps,'training_steps':state.global_step,'optimizer':self.optimizer_class,'native_loss':float(self.payload['loss']),'valid_targets':int(valid.sum()),'changed_elements':changed,'gradient_l2':sum(float(g.double().square().sum()) for g in gradients)**0.5,'stored_update_l2':sum(float(d.double().square().sum()) for d in updates.values())**0.5,'logits_dtype':str(self.payload['logits'].dtype),'parameter_dtypes':sorted(set(str(p.dtype) for p in self.payload['before'].values())),'events':self.events,'effective_training_arguments':self.settings,'gradient_boundary':'native Trainer on_pre_optimizer_step; max_grad_norm=0','update_boundary':'native Trainer on_optimizer_step before zero_grad','rank':0,'world_size':1,'status':'observed_native_step_pending_entrypoint_return'})


def reference(out,model_path,lora):
    from peft import LoraConfig,get_peft_model
    data=torch.load(out/'native-captures.pt',map_location='cpu',weights_only=True)
    set_seed(20261020)
    model=AutoModelForCausalLM.from_pretrained(model_path,torch_dtype=torch.float32,attn_implementation='eager',local_files_only=True)
    if lora:model=get_peft_model(model,LoraConfig(r=4,lora_alpha=8,lora_dropout=0.0,target_modules=['q_proj','v_proj'],task_type='CAUSAL_LM'))
    named=parameters(model)
    assert set(named)==set(data['before']), 'Reference trainable names differ'
    with torch.no_grad():
        for name,p in named.items():p.copy_(data['before'][name])
    assert all(torch.equal(p.detach(),data['before'][name].float()) for name,p in named.items())
    model.train();optimizer=torch.optim.SGD(named.values(),lr=0.001,weight_decay=0.0)
    batch={k:v for k,v in data['batch'].items() if k in ['input_ids','attention_mask','position_ids','labels']}
    output=model(**batch,use_cache=False)
    output.loss.backward()
    result={'logits':cpu(output.logits),'loss':cpu(output.loss),'gradients':{n:cpu(p.grad) for n,p in named.items()},'before':{n:cpu(p) for n,p in named.items()}}
    optimizer.step();result['after']={n:cpu(p) for n,p in named.items()}
    torch.save(result,out/'reference-captures.pt')
    dump(out/'reference-execution.json',{'device':'cpu','compute':'fp32','loss':float(output.loss),'same_initial_trainable_state':True,'uses_native_gradients_or_updates':False,'reference_optimizer':'torch.optim.SGD','thresholds':None})


def run(args):
    from peft import LoraConfig
    from datasets import Dataset
    out=Path(args.output)
    out.mkdir(parents=True,exist_ok=False)
    model_path=str(ROOT/'models/tiny-qwen2-seed20261020') if args.model=='tiny' else '/SHARED_MODELS/Qwen3-0.6B'
    lora=args.model=='pretrained';bf16=args.precision=='bf16'
    rows=[{'messages':[{'role':'user','content':'Name a color'},{'role':'assistant','content':c}]} for c in ['red','blue','green','yellow']]
    (out/'train.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    (out/'train.json').write_text(json.dumps(rows))
    cb=Capture(out)
    set_seed(20261020)
    common={'output_dir':str(out/'trained'),'max_steps':1,'learning_rate':0.001,'weight_decay':0.0,'max_grad_norm':0.0,'gradient_accumulation_steps':1,'per_device_train_batch_size':1,'optim':'sgd','lr_scheduler_type':'constant','warmup_steps':0,'bf16':bf16,'fp16':False,'gradient_checkpointing':False,'save_strategy':'no','eval_strategy':'no','report_to':'none','logging_steps':1,'seed':20261020,'dataloader_num_workers':0,'dataloader_pin_memory':False}
    if args.framework=='trl':
        from trl import SFTConfig,SFTTrainer
        model=AutoModelForCausalLM.from_pretrained(model_path,torch_dtype=torch.float32,attn_implementation='eager',local_files_only=True)
        tok=AutoTokenizer.from_pretrained(model_path,local_files_only=True)
        config=SFTConfig(**common,max_length=128,packing=False,padding_free=False)
        trainer=SFTTrainer(model=model,args=config,train_dataset=Dataset.from_list(rows),processing_class=tok,callbacks=[cb],peft_config=LoraConfig(r=4,lora_alpha=8,lora_dropout=0.0,target_modules=['q_proj','v_proj'],task_type='CAUSAL_LM') if lora else None)
        trainer.train()
        entrypoint='trl.SFTTrainer.train with native dataset preparation'
    elif args.framework=='factory':
        from llamafactory.train.tuner import run_exp
        dump(out/'dataset_info.json',{'native_fixture':{'file_name':'train.json','formatting':'sharegpt','columns':{'messages':'messages'},'tags':{'role_tag':'role','content_tag':'content','user_tag':'user','assistant_tag':'assistant'}}})
        config=dict(common,stage='sft',do_train=True,model_name_or_path=model_path,template='qwen3' if lora else 'qwen',dataset_dir=str(out),dataset='native_fixture',cutoff_len=128,preprocessing_num_workers=1,finetuning_type='lora' if lora else 'full',flash_attn='disabled',overwrite_cache=True)
        if lora:config.update(lora_rank=4,lora_alpha=8,lora_dropout=0.0,lora_target='q_proj,v_proj')
        dump(out/'native-config.json',config)
        run_exp(args=config,callbacks=[cb])
        entrypoint='llamafactory.train.tuner.run_exp complete native SFT workflow'
    else:
        from swift.callbacks import callbacks_map
        from swift.pipelines.train.sft import sft_main
        callbacks_map['precision_native']=lambda *unused:cb
        cli=['--model',model_path,'--model_type','qwen3' if lora else 'qwen2','--tuner_type','lora' if lora else 'full','--dataset',str(out/'train.jsonl'),'--max_length','128','--torch_dtype','float32','--attn_impl','eager','--callbacks','precision_native','--add_version','false','--use_hf','true']
        for key,value in common.items():cli+=['--'+key,str(value).lower() if isinstance(value,bool) else str(value)]
        if lora:cli+=['--lora_rank','4','--lora_alpha','8','--lora_dropout','0','--target_modules','q_proj','v_proj']
        dump(out/'native-arguments.json',cli)
        sft_main(cli)
        entrypoint='swift.pipelines.train.sft.sft_main complete native SFT workflow'
    assert (out/'observations.json').is_file(),'No actual native step was observed'
    versions={}
    for name in ['torch','torch-npu','transformers','accelerate','trl','ms-swift','llamafactory','peft','datasets']:
        try:versions[name]=metadata.version(name)
        except metadata.PackageNotFoundError:pass
    dump(out/'native-completion.json',{'status':'native_execution_complete','entrypoint_returned':True,'entrypoint':entrypoint,'framework':args.framework,'model':args.model,'precision':args.precision,'device':str(next(cb.model.parameters()).device),'torch_path':torch.__file__,'torch_npu_path':torch_npu.__file__,'versions':versions,'model_path':model_path,'initialization':'seeded_random' if args.model=='tiny' else 'pretrained','training':'full' if not lora else 'LoRA_q_v_r4','rank':0,'world_size':1,'thresholds':None,'captures':'native-captures.pt'})
    reference(out,model_path,lora)
    print(json.dumps({'native_complete':True,'reference_complete':True,'output':str(out)}))


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--prepare',action='store_true')
    ap.add_argument('--framework',choices=['trl','swift','factory'])
    ap.add_argument('--model',choices=['tiny','pretrained'],default='tiny')
    ap.add_argument('--precision',choices=['fp32','bf16'],default='bf16')
    ap.add_argument('--output')
    args=ap.parse_args()
    if args.prepare:prepare()
    else:
        assert args.framework and args.output
        run(args)
