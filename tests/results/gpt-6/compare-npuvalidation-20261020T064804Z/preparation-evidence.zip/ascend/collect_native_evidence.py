"""Create a task-scoped, sanitized evidence ZIP without loading tensor pickles.

python -B collect_native_evidence.py --root FRESH_CASE --out NEW_EVIDENCE.zip
Optional --probe-env /explicit/venv collects fresh pip freeze/check in memory.
No environments, caches, credentials, source checkouts or model weights enter the
ZIP. Known native capture tensors remain byte-identical, with explicit hashes.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

SECRET_NAMES={"token","api_key","apikey","access_token","auth_token","authorization","password","passwd","secret","client_secret","private_key","credential","credentials"}
EXCLUDED_DIRS={"cache","caches","environments","envs","venv","env","build","dist","tmp","source","sources","src","repos","repositories","node_modules","weights","models","checkpoints","engine","random-tiny-llama"}
TEXT_SUFFIXES={".json",".jsonl",".log",".txt",".yaml",".yml",".toml",".py",".sh",".md"}
BINARY_SUFFIXES={".pt",".npy",".npz"}


def sanitize_text(text):
    text=re.sub(r"-----BEGIN [^-]*PRIVATE KEY-----.*?-----END [^-]*PRIVATE KEY-----","<redacted-private-key>",text,flags=re.S)
    text=re.sub(r"(?i)(https?://)[^\s/@:]+:[^\s/@]+@",r"\1<redacted-userinfo>@",text)
    text=re.sub(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+","Bearer <redacted>",text)
    text=re.sub(r"\b(?:hf_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9_-]{20,})\b","<redacted-token>",text)
    text=re.sub(r"(?i)((?:api[_-]?key|access[_-]?token|auth[_-]?token|password|passwd|client[_-]?secret|private[_-]?key)\s*[=:]\s*)[^\s,;]+",r"\1<redacted>",text)
    text=re.sub(r"(?i)([A-Z]:[/\\]Users[/\\])[^/\\\s]+",r"\1<user>",text)
    text=re.sub(r"(/(?:home|Users)/)[^/\s]+",r"\1<user>",text)
    text=re.sub(r"(/data/)[0-9]{5,}(?=/)",r"\1<user>",text)
    text=re.sub(r"(?<![\w.])(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})(?![\w.])","<private-ip>",text)
    return text


def sanitize(value):
    if isinstance(value,dict):
        return {str(k):("<redacted>" if str(k).lower().replace("-","_") in SECRET_NAMES and isinstance(v,str) and v else sanitize(v)) for k,v in value.items()}
    if isinstance(value,list):
        out=[]
        hide_next=False
        for item in value:
            if hide_next:
                out.append("<redacted>")
                hide_next=False
                continue
            out.append(sanitize(item))
            hide_next=isinstance(item,str) and item.lower().lstrip("-").replace("-","_") in SECRET_NAMES
        return out
    if isinstance(value,str):return sanitize_text(value)
    return value


def sha256(data):return hashlib.sha256(data).hexdigest()


def case_files(root):
    for current,dirs,files in os.walk(root,topdown=True,followlinks=False):
        dirs[:]=sorted(d for d in dirs if not d.startswith(".") and d.lower() not in EXCLUDED_DIRS and not d.lower().startswith(("model-weights","hf-cache","pip-cache")) and not (Path(current)/d).is_symlink() and not (Path(current)/d/".git").exists())
        for name in sorted(files):yield Path(current)/name


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",required=True)
    ap.add_argument("--out",required=True)
    ap.add_argument("--probe-env",action="append",default=[])
    ap.add_argument("--max-file-mib",type=int,default=512)
    ap.add_argument("--max-total-mib",type=int,default=2048)
    a=ap.parse_args()
    root=Path(a.root).resolve()
    destination=Path(a.out).absolute()
    if not root.is_dir():ap.error("Case root is not a directory")
    if destination.exists():ap.error("Output must be new; historical ZIPs are never overwritten")
    destination.parent.mkdir(parents=True,exist_ok=True)
    inventory=[]
    skipped=[]
    native=[]
    stages=[]
    hardware=[]
    bytes_added=0
    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with zipfile.ZipFile(destination,"x",zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in case_files(root):
            if not path.is_file() or path.is_symlink():continue
            relative=path.relative_to(root)
            parts=relative.parts
            if any(p.startswith(".") or p.lower() in EXCLUDED_DIRS or p.lower().startswith(("model-weights","hf-cache","pip-cache")) for p in parts[:-1]):continue
            if re.search(r"(?i)(?:credential|private.?key|(?:^|[_-])key(?:[_\-.]|$)|id_rsa|id_ed25519|\.pem$|\.key$|\.env$|auth.*\.json$|session.*\.json$)",path.name):
                skipped.append({"path":str(relative),"reason":"credential/session filename excluded"})
                continue
            text=path.suffix.lower() in TEXT_SUFFIXES
            tensor=path.suffix.lower() in BINARY_SUFFIXES and ("capture" in path.name.lower() or "logit" in path.name.lower() or "distribution" in path.name.lower() or "score" in path.name.lower() or path.name.startswith("rank-"))
            if not (text or tensor):continue
            size=path.stat().st_size
            if size>a.max_file_mib*(1<<20) or bytes_added+size>a.max_total_mib*(1<<20):
                skipped.append({"path":str(relative),"reason":"size budget","bytes":size})
                continue
            raw=path.read_bytes()
            parsed=None
            if text:
                value=raw.decode("utf-8",errors="replace")
                if path.suffix.lower()==".json":
                    try:parsed=json.loads(value)
                    except ValueError:pass
                sanitized=(json.dumps(sanitize(parsed),indent=2) if parsed is not None else sanitize_text(value)).encode("utf-8")
            else:sanitized=raw
            archive_name="case/"+relative.as_posix()
            archive.writestr(archive_name,sanitized)
            inventory.append({"path":archive_name,"source_bytes":len(raw),"source_sha256":sha256(raw),"archived_bytes":len(sanitized),"archived_sha256":sha256(sanitized),"sanitized_text":text,"native_binary_unmodified":tensor})
            bytes_added+=len(raw)
            if parsed is not None:
                if path.name=="stages.json":stages.append({"path":archive_name,"stages":sanitize(parsed)})
                elif path.name in ["command.json","status.json"] and "jobs" in parts:
                    stages.append({"path":archive_name,"record_type":path.stem,"job":path.parent.name,"record":sanitize(parsed)})
                if path.name=="native-result.json" or re.fullmatch(r"rank-\d+-result\.json",path.name):native.append({"path":archive_name,"result":sanitize(parsed)})
                if "probe" in path.name.lower() or path.name in ["hardware-proof.json","ascend-feasibility.json"]:hardware.append(archive_name)
        probes=[]
        for index,venv in enumerate(a.probe_env):
            python=Path(venv)/"bin/python"
            if not python.is_file():python=Path(venv)/"Scripts/python.exe"
            for label,args in [("freeze",["freeze","--all"]),("check",["check"])]:
                record={"environment":sanitize_text(str(venv)),"action":"pip "+label}
                try:
                    p=subprocess.run([str(python),"-B","-m","pip"]+args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
                    record.update(returncode=p.returncode,output=sanitize_text(p.stdout))
                except (OSError,subprocess.TimeoutExpired) as exc:record["error"]=sanitize_text(str(exc))
                name="fresh-package-probes/env-"+str(index)+"-"+label+".json"
                archive.writestr(name,json.dumps(record,indent=2))
                probes.append({"path":name,**{k:v for k,v in record.items() if k!="output"}})
        report={"schema":"precision-native-evidence-v1","created_utc":timestamp,"case_root":sanitize_text(str(root)),"installed_stage_journals":stages,"fresh_package_probes":probes,"native_results":native,"hardware_evidence":hardware,"coverage":{"installation_journals":len(stages),"native_result_records":len(native),"hardware_proof_files":len(hardware),"tensor_files":sum(x["native_binary_unmodified"] for x in inventory)},"missing_evidence_is_not_success":True,"archive_policy":{"text":"Sanitized credentials, PEM private keys, URL credentials, private IPs and user-home identifiers","binary":"Only known native capture/score/logit filenames; bytes and original dtypes unchanged; no pickle is loaded","excluded":"Environment installations, caches, source checkouts, model/checkpoint weights, engines, credentials and session files"},"files":inventory,"skipped":sanitize(skipped)}
        archive.writestr("evidence-report.json",json.dumps(sanitize(report),indent=2))
    digest=hashlib.sha256()
    with destination.open("rb") as f:
        for block in iter(lambda:f.read(1<<20),b""):digest.update(block)
    checksum=digest.hexdigest()
    destination.with_name(destination.name+".sha256").write_text(checksum+"  "+destination.name+"\n")
    print(json.dumps({"archive":str(destination),"sha256":checksum,"bytes":destination.stat().st_size,"coverage":report["coverage"],"skipped_files":len(skipped)},indent=2))


if __name__=="__main__":main()
