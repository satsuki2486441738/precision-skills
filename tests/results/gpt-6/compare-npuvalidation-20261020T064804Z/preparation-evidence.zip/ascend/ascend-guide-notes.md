# Current native Ascend attempt: evidence and setup notes

The NPU probe executed a real tensor square successfully on an assigned device. The private environments use published TorchNPU packages aligned with CANN 9.1.0. Successful import or setup is not native framework completion. The two latest native jobs were detached before the SSH endpoint became unavailable; their outcomes must be retrieved before any claim or retry.

## Runtime selection

The immutable [Ascend compatibility matrix](https://raw.githubusercontent.com/Ascend/pytorch/cf04f800cdebb3bdb650085d746b5433e869f145/COMPATIBILITY.en.md) maps CANN 9.1.0 / product 26.1.0 to `torch-npu==2.9.0.post6` or `torch-npu==2.7.1.post8`. The host's original 2.9.0.post2 did execute the probe, but its published row corresponds to CANN 9.0.0. The private MindIE environment uses Torch 2.9.0 and post6; MindSpeed-LLM uses CPU-distribution Torch 2.7.1 plus actual Ascend transfer/operators and post8.

Source `/usr/local/Ascend/cann/set_env.sh` before importing Torch. The initial uninitialized CANN environment raised a UnicodeDecodeError; the initialized environment executed the NPU probe. Source the installed ATB environment for inference builds.

MindSpeed-LLM uses a task-private byte copy of existing official branch 26.1.0 commit `b80e42f0a578424a07c03c65424d431e563295a6`; the original workspace remains untouched. Transformers 5.2.0 matches its source requirements. A system-site virtual environment initially inherited torchvision 0.24.0, which is built for Torch 2.9.0; this broke Transformers' Bloom import. Installing the matching official CPU torchvision 0.22.1 in the private Torch 2.7.1 environment repaired the dependency mismatch. The first failed log is preserved; the second native job outcome is pending retrieval.

## MindIE build boundary

The [official MindIE-LLM 3.1.0 source](https://github.com/Ascend/MindIE-LLM/tree/3.1.0) archive SHA256 is `b58ff9d99618381dd0c48df093b6943cd5c2c4c30eaadb6d607b3fce3ed77771`. Build only `examples/atb_models` for the official PagedAttention runner. This is native ATB inference and does not require building the separate service/HTTP server.

The installed ATB includes only CPython 3.10/3.11 `torch_atb` wheels, while this host is CPython 3.12. The task therefore compiles the official native source; it does not rename or force-install an incompatible wheel. CMake 3.31.10 is installed privately because the base CMake 4.4.3 can reject old CMake policy baselines. The first attempted pin 3.31.8 was absent from the package index; this installation failure is preserved.

The official ATB-Models CMake file attempts `sudo sh -c "echo 2 > /proc/sys/kernel/randomize_va_space"`. Only this global ASLR mutation block is omitted in the task-private CMake copy. A `precision-build-safety.json` records the original/modified file SHA256 and removed block. Native operator/model/loss code is unchanged. The rest of the official build script is retained; resumptions reuse an existing Makefile and compiled objects rather than deleting the cache.

GitHub DNS is unavailable from the remote host. Official source archives are downloaded locally and transferred as exact bytes with SHA256 verification. Build header dependencies from the source's own Huawei OBS URLs are likewise transferred unchanged: nlohmann include v3.11.2 SHA256 `e5c7a9f49a16814be27e4ed0ee900ecd0092bfb7dbfca65b5a421b774dccaaed`, spdlog v1.12.0 SHA256 `6174bf8885287422a6c6a0312eb8a30e8d22bcfcee7c48a6d02d1835d7769232`.

The planned actual native generation uses read-only `/SHARED_MODELS/Qwen3-0.6B`, one request, explicit IDs `[1,4,5,6]`, four new tokens, TP1, and the native cache. The copy-only observer excludes warmup and captures `ModelRunner.forward` output before native sampling, retaining original dtype. Qwen3 architecture is present in the release; its README model-size whitelist should not be represented as explicitly listing 0.6B.

## MindSpeed-RL preparation

The pinned [official install guide](https://github.com/Ascend/MindSpeed-RL/blob/26c21e64f84ae8cd26de9483292349a1850099cf/docs/zh/install_guide.md) selects MindSpeed commit `ac9f0e74061f968fdb285aa6a0df68a980fb0412`, MindSpeed-LLM commit `a2c0733b9c8674e240a0a7607ed3f973115cc6b7`, Megatron `core_v0.12.1`, vLLM `b8b302c` with `VLLM_TARGET_DEVICE=empty`, and vLLM-Ascend `1b16c01` with actual custom kernel compilation enabled. Empty is the vLLM packaging target for an external native Ascend plugin; it is not an inference substitute. Its original guide row references CANN 8.5/Python 3.10; execution on the host's CANN 9.1/Python 3.12 needs actual validation and should be reported as such.

The six immutable source archives are already on the persistent remote material volume. A separate private setup script is ready but has not run. Never execute official example shell wrappers that issue global `pkill -9 python` or `ray stop --force`; use the native CLI with task-owned Ray/session paths and only assigned devices.
