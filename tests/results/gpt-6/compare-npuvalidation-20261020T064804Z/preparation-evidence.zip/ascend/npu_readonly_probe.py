"""Read-only, task-scoped NPU/software/model inventory; emits JSON to stdout.

Example: python3 -B npu_readonly_probe.py --task-root /data/yz/precision \
  --model-root /weights --model-root /data/models --env-root /opt/venvs
No credential files, shell startup files or environment values are read. Model
inspection reads only bounded config.json metadata in explicitly named roots.
"""
import argparse
import datetime
import glob
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

PACKAGES = ["torch", "torch-npu", "torch_npu", "transformers", "mindspeed", "mindspeed-llm", "mindspeed-rl", "mindie-llm", "mindie", "atb-llm", "vllm", "vllm-ascend", "ray", "megatron-core", "numpy", "apex"]


def command(args, timeout=45):
    result={"argv":args,"executable":shutil.which(args[0])}
    try:
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
        result.update(returncode=p.returncode,output=p.stdout[:24000])
    except (OSError,subprocess.TimeoutExpired) as exc:
        result["error"]=str(exc)[:1200]
    return result


def bounded_dirs(root, depth=2, limit=96):
    root=Path(root).absolute()
    if not root.is_dir():
        return []
    found=[root]
    frontier=[root]
    for _ in range(depth):
        following=[]
        for parent in frontier:
            try:
                children=sorted(parent.iterdir(),key=lambda p:p.name)
            except OSError:
                continue
            for p in children:
                if p.is_dir() and not p.is_symlink() and not p.name.startswith("."):
                    found.append(p)
                    following.append(p)
                    if len(found)>=limit:
                        return found
        frontier=following
    return found


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--task-root",action="append",default=[])
    ap.add_argument("--model-root",action="append",default=[])
    ap.add_argument("--env-root",action="append",default=[])
    ap.add_argument("--containers",action="store_true",help="Read only container/image ID, image and name columns; never inspect container environment.")
    a=ap.parse_args()
    report={"schema":"precision-npu-readonly-probe-v1","utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"python":{"executable":sys.executable,"version":sys.version},"os":{"system":platform.system(),"release":platform.release(),"machine":platform.machine(),"libc":platform.libc_ver()},"device_nodes":sorted(set(glob.glob("/dev/davinci*")+glob.glob("/dev/devmm_svm")+glob.glob("/dev/hisi_hdc"))),"commands":[],"versions":{},"version_files":{},"task_paths":[],"model_configs":[],"python_environments":[]}
    for package in PACKAGES:
        try:
            dist=metadata.distribution(package)
            report["versions"][package]={"version":dist.version,"location":str(dist.locate_file(""))}
        except metadata.PackageNotFoundError:
            pass
    for args in [["npu-smi","info"],["npu-smi","info","-l"],["uname","-m"],["getconf","GNU_LIBC_VERSION"]]:
        report["commands"].append(command(args))
    if a.containers:
        for engine in ["docker","podman"]:
            if shutil.which(engine):
                for args in [[engine,"ps","--all","--format","{{.ID}} {{.Image}} {{.Names}}"],[engine,"images","--format","{{.ID}} {{.Repository}}:{{.Tag}}"]]:
                    item=command(args,timeout=30)
                    if "output" in item:
                        item["output"]="\n".join(item["output"].splitlines()[:96])
                    report.setdefault("containers",[]).append(item)
    version_paths=["/usr/local/Ascend/driver/version.info","/usr/local/Ascend/ascend-toolkit/latest/version.cfg","/usr/local/Ascend/cann/version.cfg","/usr/local/Ascend/mindie/latest/version.info","/usr/local/Ascend/mindie/version.info"]
    version_paths+=glob.glob("/usr/local/Ascend/ascend-toolkit/latest/*/ascend_toolkit_install.info")[:8]
    version_paths+=glob.glob("/usr/local/Ascend/cann/*/ascend_toolkit_install.info")[:8]
    for p in version_paths:
        f=Path(p)
        if f.is_file() and f.stat().st_size <= 32768:
            try:
                text=f.read_text(errors="replace")
                report["version_files"][p]=[line for line in text.splitlines() if any(k in line.lower() for k in ["version","cann","arch","os=","package"])]
            except OSError as exc:
                report["version_files"][p]={"error":str(exc)}
    report["runtime_roots"]={p:Path(p).exists() for p in ["/usr/local/Ascend/driver","/usr/local/Ascend/ascend-toolkit","/usr/local/Ascend/cann","/usr/local/Ascend/nnal/atb","/usr/local/Ascend/mindie","/usr/local/Ascend/atb-models"]}
    for root in a.task_root:
        p=Path(root).absolute()
        item={"root":str(p),"exists":p.is_dir()}
        if p.is_dir():
            disk=shutil.disk_usage(p)
            item.update(disk_total_bytes=disk.total,disk_free_bytes=disk.free)
            item["framework_dirs"]=[str(q) for q in bounded_dirs(p,depth=1) if any(s in q.name.lower() for s in ["mindspeed","mindie","megatron","venv","environment","model","weight"])]
        report["task_paths"].append(item)
    configs=[]
    for root in a.model_root:
        for parent in bounded_dirs(root,depth=2):
            p=parent/"config.json"
            if not p.is_file() or p.is_symlink() or p.stat().st_size>262144:
                continue
            try:
                cfg=json.loads(p.read_text())
                if "model_type" not in cfg and "architectures" not in cfg:
                    continue
                names=["model_type","architectures","vocab_size","hidden_size","num_hidden_layers","num_attention_heads","num_key_value_heads","torch_dtype","dtype","max_position_embeddings","tie_word_embeddings"]
                configs.append({"directory":str(parent),"metadata":{k:cfg[k] for k in names if k in cfg},"weight_files_present":any((parent/n).is_file() for n in ["model.safetensors","model.safetensors.index.json","pytorch_model.bin","pytorch_model.bin.index.json"]),"tokenizer_files_present":any((parent/n).is_file() for n in ["tokenizer.json","tokenizer.model","vocab.json"])})
            except (OSError,ValueError):
                continue
    report["model_configs"]=configs[:96]
    interpreters={Path(sys.executable).absolute()}
    for path in ["/opt/conda/bin/python","/opt/venv/bin/python","/opt/venvs/bin/python"]:
        if Path(path).is_file():
            interpreters.add(Path(path))
    for root in a.env_root:
        for p in bounded_dirs(root,depth=2):
            for n in ["bin/python","bin/python3"]:
                if (p/n).is_file():
                    interpreters.add(p/n)
    probe="import json,sys,importlib.metadata as m; names="+repr(PACKAGES)+"; r={'python':sys.version,'executable':sys.executable,'packages':{}}\nfor n in names:\n try:r['packages'][n]=m.version(n)\n except m.PackageNotFoundError:pass\nprint(json.dumps(r))"
    for interpreter in sorted(interpreters,key=str)[:12]:
        report["python_environments"].append(command([str(interpreter),"-B","-c",probe],timeout=30))
    # Import the actual device runtime only in the selected interpreter; no
    # allocations, generated text, model weights, or training are executed.
    device_probe="import json,torch; r={'torch':torch.__version__,'torch_path':torch.__file__};\ntry:\n import torch_npu; r.update(torch_npu=getattr(torch_npu,'__version__',None),torch_npu_path=torch_npu.__file__,npu_available=torch.npu.is_available(),npu_count=torch.npu.device_count()); r['npu_names']=[torch.npu.get_device_name(i) for i in range(min(torch.npu.device_count(),32))]\nexcept Exception as e:r['npu_error']=repr(e)\nprint(json.dumps(r))"
    report["selected_runtime"]=command([sys.executable,"-B","-c",device_probe],timeout=60)
    for p in ["/sys/fs/cgroup/memory.max","/sys/fs/cgroup/memory.current","/sys/fs/cgroup/memory.events"]:
        f=Path(p)
        if f.is_file():
            try:report.setdefault("memory_cgroup",{})[p]=f.read_text()[:2048]
            except OSError:pass
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
