"""Run untouched NeMo v0.2.0 worker via official Ascend API migration, then independent CPU replay."""
import argparse,os,pathlib,json,subprocess,sys,hashlib,traceback,socket,time
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--output',required=True);p.add_argument('--stage',default='driver');a=p.parse_args();root=pathlib.Path(a.root);out=pathlib.Path(a.output);out.mkdir(exist_ok=True,parents=True)
def js(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def stage(name):
 cmd=[sys.executable,'-B',__file__,'--root',str(root),'--output',str(out),'--stage',name]
 with (out/(name+'.log')).open('w') as f:
  r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 js(out/(name+'-execution.json'),{'command':cmd,'returncode':r.returncode});return r.returncode
if a.stage=='driver':
 result={'status':'running','thresholds':None}
 try:
  for s in ['prepare','native','reference']:
   rc=stage(s);result[s]=rc
   if rc:result['status']='incomplete';break
  else:result['status']='native_and_independent_reference_completed'
 except BaseException:result.update(status='driver_error',traceback=traceback.format_exc())
 js(out/'RESULT.json',result);print(json.dumps(result),flush=True);sys.exit(0 if result['status']=='native_and_independent_reference_completed' else 1)
import numpy as np
import torch
import transformers
from transformers import Qwen2Config,Qwen2ForCausalLM,AutoModelForCausalLM,AutoTokenizer,PreTrainedTokenizerFast
from safetensors.torch import save_file
if a.stage=='prepare':
 torch.set_num_threads(2);torch.manual_seed(20261020)
 from tokenizers import Tokenizer
 from tokenizers.models import WordLevel
 from tokenizers.pre_tokenizers import Whitespace
 fixture=out/'initial';fixture.mkdir()
 cfg=Qwen2Config(vocab_size=64,hidden_size=64,intermediate_size=128,num_hidden_layers=1,num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=64,tie_word_embeddings=False,bos_token_id=1,eos_token_id=2,pad_token_id=0,attention_dropout=0.0)
 model=Qwen2ForCausalLM(cfg);model.save_pretrained(fixture,safe_serialization=True)
 raw=Tokenizer(WordLevel({'<pad>':0,'<s>':1,'</s>':2,'<unk>':3,**{f'tok{i}':i for i in range(4,64)}},unk_token='<unk>'));raw.pre_tokenizer=Whitespace()
 PreTrainedTokenizerFast(tokenizer_object=raw,pad_token='<pad>',bos_token='<s>',eos_token='</s>',unk_token='<unk>').save_pretrained(fixture)
 js(out/'initial-files.json',{x.name:sha(x) for x in fixture.iterdir() if x.is_file()});print('PREPARED',sum(p.numel() for p in model.parameters()),flush=True);sys.exit(0)
def snapshot(model):return {n:p.detach().cpu().clone().contiguous() for n,p in model.named_parameters()}
def flatten(values,names):return np.concatenate([values[n].float().numpy().reshape(-1) for n in names])
def export(side,model,before,grads,post,scores,logits,loss,metrics):
 dest=out/side;dest.mkdir();names=list(before)
 after=snapshot(model)
 arrays={'before':flatten(before,names),'gradients':flatten(grads,names),'postclip_gradients':flatten(post,names),'after':flatten(after,names),'updates':flatten({n:after[n]-before[n] for n in names},names),'action_logprobs':scores.detach().cpu().float().numpy(),'logits':logits.detach().cpu().float().numpy(),'loss':np.array([float(loss)],dtype=np.float32)}
 for name,value in arrays.items():np.save(dest/(name+'.npy'),value,allow_pickle=False)
 save_file(after,str(dest/'after.safetensors'))
 js(dest/'metadata.json',{'side':side,'torch':torch.__version__,'transformers':transformers.__version__,'parameter_names_shapes':[{ 'name':n,'shape':list(before[n].shape),'dtype':str(before[n].dtype),'elements':before[n].numel()} for n in names],'loss':float(loss),'metrics':metrics,'model_device':str(next(model.parameters()).device),'attention_implementation':model.config._attn_implementation,'arrays':{k:{'shape':list(v.shape),'dtype':str(v.dtype),'sha256':sha(dest/(k+'.npy'))} for k,v in arrays.items()}})
if a.stage=='native':
 import torch_npu
 from torch_npu.contrib import transfer_to_npu
 torch.npu.set_device(0);torch.set_num_threads(2);torch.manual_seed(20261020)
 os.environ.update(RANK='0',WORLD_SIZE='1',LOCAL_RANK='0',MASTER_ADDR='127.0.0.1')
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));os.environ['MASTER_PORT']=str(sock.getsockname()[1])
 from nemo_reinforcer.models.policy.fsdp1_policy_worker import FSDP1PolicyWorker
 from nemo_reinforcer.distributed.batched_data_dict import BatchedDataDict
 from nemo_reinforcer.algorithms.loss_functions import ClippedPGLossFn
 cfg={'model_name':str(out/'initial'),'precision':'float32','activation_checkpointing_enabled':False,'fsdp_offload_enabled':False,'optimizer':{'name':'torch.optim.AdamW','kwargs':{'lr':0.0001,'betas':(0.9,0.999),'eps':1e-8,'weight_decay':0.01}},'train_global_batch_size':2,'train_micro_batch_size':2,'max_grad_norm':0.5,'logprob_batch_size':2,'generation_batch_size':2,'generation':{'max_new_tokens':4,'temperature':1.0,'top_p':1.0,'top_k':0,'pad_token_id':0,'stop_token_ids':[2]}}
 worker=FSDP1PolicyWorker.__ray_metadata__.modified_class(cfg,AutoTokenizer.from_pretrained(out/'initial'),init_reference_model=False)
 print('NATIVE_WORKER_READY',next(worker.model.parameters()).device,flush=True)
 prompt=BatchedDataDict({'input_ids':torch.tensor([[1,10,11,12],[1,20,21,22]]),'input_lengths':torch.tensor([4,4])})
 generation=worker.generate(prompt,greedy=True);print('NATIVE_GENERATION_COMPLETE',generation['output_ids'].tolist(),flush=True)
 ids=generation['output_ids'];lengths=generation['unpadded_sequence_lengths'];mask=torch.zeros_like(ids,dtype=torch.float32)
 for i,l in enumerate(lengths):mask[i,4:int(l)]=1
 data=BatchedDataDict({'input_ids':ids,'input_lengths':lengths})
 rescored=worker.get_logprobs(data)['logprobs']
 advantages=torch.zeros_like(mask);advantages[0]=1.;advantages[1]=-1.
 data.update({'token_mask':mask,'sample_mask':torch.ones(2),'advantages':advantages,'prev_logprobs':rescored+0.05,'generation_logprobs':generation['logprobs'],'reference_policy_logprobs':rescored-0.03})
 trajectory={k:v.detach().cpu().numpy() for k,v in data.items() if torch.is_tensor(v)};np.savez(out/'trajectory.npz',**trajectory)
 js(out/'rollout.json',{'input_ids':ids.tolist(),'input_lengths':lengths.tolist(),'generation_lengths':generation['generation_lengths'].tolist(),'generation_logprobs':generation['logprobs'].tolist(),'rescored_logprobs':rescored.tolist(),'mask':mask.tolist(),'advantages':advantages.tolist(),'dependencies':{'generated_tokens':'native worker.generate greedy HF backend','old_logprobs':'native rescored + injected 0.05 offset','reference_logprobs':'native rescored - injected 0.03 offset','advantages':'injected +1/-1 complete group; synthetic reward test','weights':'seeded random tiny Qwen2; no answer quality claim'}})
 before=snapshot(worker.model);grads={};post={};capture={};handles=[]
 for n,param in worker.model.named_parameters():
  handles.append(param.register_hook(lambda grad,n=n:grads.__setitem__(n,grad.detach().cpu().clone())))
 def pre_step(opt,args,kwargs):post.update({n:p.grad.detach().cpu().clone() for n,p in worker.model.named_parameters() if p.grad is not None})
 handles.append(worker.optimizer.register_step_pre_hook(pre_step))
 loss_cfg={'ratio_eps_min':0.2,'ratio_eps_max':0.2,'reference_policy_kl_penalty':0.02,'use_on_policy_kl_approximation':False,'use_importance_sampling_correction':False}
 loss_fn=ClippedPGLossFn(loss_cfg)
 def capture_loss(logits,mb):
  loss,metrics=loss_fn(logits,mb);capture.update(logits=logits.detach().cpu(),loss=float(loss.detach().cpu()),metrics=metrics);return loss,metrics
 print('NATIVE_TRAIN_ENTER',flush=True);metrics=worker.train(data,capture_loss);torch.npu.synchronize();print('NATIVE_OPTIMIZER_COMPLETE',metrics,flush=True)
 scores=torch.log_softmax(capture['logits'].float(),-1)[:,:-1].gather(-1,ids[:,1:,None]).squeeze(-1)
 export('native',worker.model,before,grads,post,scores,capture['logits'],capture['loss'],capture['metrics'])
 adapter=pathlib.Path(transfer_to_npu.__file__)
 js(out/'native-config.json',{'worker_config':cfg,'loss_config':loss_cfg,'torch_npu':torch_npu.__version__,'torch_npu_module':torch_npu.__file__,'adapter_path':str(adapter),'adapter_sha256':sha(adapter),'adapter_official_source':'https://github.com/Ascend/pytorch/blob/v2.9.0/torch_npu/contrib/transfer_to_npu.py','backend':torch.distributed.get_backend(),'source_files_sha256':{str(x.relative_to(root/'source')):sha(x) for x in (root/'source/nemo_reinforcer').rglob('*.py')},'source_pin':'26f651ea490ef2a343e7f298b9aa54bc7c5da67c','source_modified':False,'world_size':1,'reserved_devices':[8,9,10,11],'actual_visible_device':str(next(worker.model.parameters()).device),'training_backend':'FSDP1PolicyWorker single-device branch (wrapper skipped by upstream)','generation_backend':'native HuggingFace FSDP1PolicyWorker.generate'})
 torch.distributed.destroy_process_group();sys.exit(0)
if a.stage=='reference':
 torch.set_num_threads(2)
 assert 'torch_npu.contrib.transfer_to_npu' not in sys.modules
 model=AutoModelForCausalLM.from_pretrained(out/'initial',torch_dtype=torch.float32,device_map='cpu');model.train()
 before=snapshot(model);fixture=np.load(out/'trajectory.npz',allow_pickle=False);d={k:torch.from_numpy(fixture[k].copy()) for k in fixture.files}
 cfg=json.loads((out/'native-config.json').read_text());op=cfg['worker_config']['optimizer']['kwargs'];opt=torch.optim.AdamW(model.parameters(),**op)
 opt.zero_grad();logits=model(input_ids=d['input_ids'],attention_mask=torch.ones_like(d['input_ids']),use_cache=False).logits
 lp=torch.log_softmax(logits.float(),dim=-1)[:,:-1].gather(-1,d['input_ids'][:,1:,None]).squeeze(-1)
 mask=d['token_mask'][:,1:]*d['sample_mask'][:,None];advantages=d['advantages'][:,1:];old=d['prev_logprobs'][:,1:];ref=d['reference_policy_logprobs'][:,1:]
 ratio=torch.exp(lp-old);clipped=torch.clamp(ratio,0.8,1.2);actor=(torch.maximum(-advantages*ratio,-advantages*clipped)*mask).sum()/(mask.sum()+1e-8)
 delta=ref-lp;kl=((torch.exp(delta)-delta-1)*mask).sum()/(mask.sum()+1e-8);loss=actor+0.02*kl
 loss.backward();grads={n:p.grad.detach().cpu().clone() for n,p in model.named_parameters() if p.grad is not None};norm=torch.nn.utils.clip_grad_norm_(model.parameters(),max_norm=0.5);post={n:p.grad.detach().cpu().clone() for n,p in model.named_parameters() if p.grad is not None};opt.step()
 export('reference',model,before,grads,post,lp,logits,loss.detach(),{'actor_loss':float(actor.detach()),'kl_penalty':float(kl.detach()),'preclip_norm':float(norm),'implementation':'fresh CPU model, independent explicit torch clipped policy loss + KL; no nemo imports'})
 print('CPU_INDEPENDENT_REFERENCE_COMPLETE',float(loss.detach()),flush=True)
