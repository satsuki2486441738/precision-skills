"""Private NeMo continuation: inspect/start bounded jobs without touching other runs."""
import os,pathlib,json,subprocess,datetime,shutil,sys,hashlib
base=pathlib.Path(os.environ['PRECISION_REMOTE_ROOT'])
root=base/'nemo-continuation-20261020T123200Z'
root.mkdir(exist_ok=True)
source=base/'rlmg/sources-offline-v1/nemo'
if not (root/'source').exists():shutil.copytree(source,root/'source',ignore=shutil.ignore_patterns('.git','__pycache__'))
py=root/'env/bin/python'
if not py.exists():subprocess.check_call([sys.executable,'-m','venv','--system-site-packages',root/'env'])
site=base/'rlmg/environments/upstream-startups/lib/python3.12/site-packages'
(root/'env/lib/python3.12/site-packages/nemo_continuation_dependencies.pth').write_text(str(site)+'\n')
print(json.dumps({'root':str(root),'python':str(py),'source':str(source),'head':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()}))
if '--launch' in sys.argv:
 out=root/('attempt-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
 env=os.environ.copy();discard={}
 for k in ['RANK','WORLD_SIZE','LOCAL_RANK','LOCAL_WORLD_SIZE','GROUP_RANK','ROLE_RANK','ROLE_WORLD_SIZE','MASTER_ADDR','MASTER_PORT','NODE_RANK','LOCAL_SIZE','SLURM_PROCID','SLURM_NTASKS','SLURM_LOCALID','OMPI_COMM_WORLD_RANK','OMPI_COMM_WORLD_SIZE','OMPI_COMM_WORLD_LOCAL_RANK','PMI_RANK','PMI_SIZE']:
  if k in env:discard[k]=env.pop(k)
 env.update(ASCEND_RT_VISIBLE_DEVICES='8,9,10,11',TMPDIR='/tmp',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='2',TORCH_DEVICE_BACKEND_AUTOLOAD='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',MAX_JOBS='2',WANDB_MODE='disabled',PYTHONPATH=str(root/'source')+os.pathsep+env.get('PYTHONPATH',''))
 (out/'discarded-rank-env.json').write_text(json.dumps(discard,indent=2))
 cmd=[str(py),'-B',str(root/'collector_v3.py'),'--root',str(root),'--output',str(out)]
 with (out/'driver.log').open('w') as f:p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 (out/'launch.json').write_text(json.dumps({'pid':p.pid,'command':cmd,'output':str(out)},indent=2));print(json.dumps({'pid':p.pid,'output':str(out)}))
else:
 for p in sorted(root.glob('attempt-*')):
  print(str(p));print((p/'driver.log').read_text()[-10000:]);print('result', (p/'RESULT.json').read_text() if (p/'RESULT.json').exists() else 'pending'); print('\n'.join(x.name+'\n'+x.read_text()[-12000:] for x in p.glob('*.log') if x.name!='driver.log'))


