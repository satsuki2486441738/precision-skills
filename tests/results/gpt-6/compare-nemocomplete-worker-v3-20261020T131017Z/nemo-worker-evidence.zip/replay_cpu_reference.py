"""Recompute independent CPU reference in a fresh folder; preserve frozen capture bytes."""
import argparse,pathlib,shutil,subprocess,sys,os,json
p=argparse.ArgumentParser();p.add_argument('--evidence',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
for name in ['trajectory.npz','native-config.json']:shutil.copy2(a.evidence/'case'/name,a.output/name)
shutil.copytree(a.evidence/'case/initial',a.output/'initial')
env=os.environ.copy();env.update(TORCH_DEVICE_BACKEND_AUTOLOAD='0',OMP_NUM_THREADS='2',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
cmd=[sys.executable,'-B',str(a.evidence/'collector_v3.py'),'--root',str(a.evidence),'--output',str(a.output),'--stage','reference']
with (a.output/'reference.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
(a.output/'execution.json').write_text(json.dumps({'command':cmd,'returncode':r.returncode},indent=2));raise SystemExit(r.returncode)
