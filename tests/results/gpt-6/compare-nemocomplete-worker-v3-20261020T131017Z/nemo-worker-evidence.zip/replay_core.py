"""Replay the six frozen precision contracts through the repository's actual CLIs."""
import argparse,json,pathlib,subprocess,sys,hashlib
p=argparse.ArgumentParser();p.add_argument('--skill',type=pathlib.Path,required=True);p.add_argument('--evidence',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);rows=[]
for folder in sorted((a.evidence/'core').iterdir()):
 if not folder.is_dir() or not (folder/'contract.json').exists():continue
 tool='compare_target_scores.py' if folder.name=='action-scores' else 'compare_tensors.py';out=a.output/(folder.name+'.json')
 cmd=[sys.executable,'-B',str(a.skill/'scripts'/tool),'--contract',str(folder/'contract.json'),'--side-a',str(folder/'native.json'),'--side-b',str(folder/'reference.json'),'--output',str(out)]
 r=subprocess.run(cmd,capture_output=True,text=True);row={'name':folder.name,'returncode':r.returncode,'command':cmd,'stderr':r.stderr,'stdout':r.stdout};assert r.returncode==0,row
 frozen=json.loads((folder/'report.json').read_text());actual=json.loads(out.read_text());keys=['status','global','per_tensor'] if tool=='compare_tensors.py' else ['status','metrics','coverage'];row['matches_frozen_metrics']=all(actual[k]==frozen[k] for k in keys);assert row['matches_frozen_metrics'],row;rows.append(row)
result={'status':'completed','comparisons':len(rows),'thresholds':None,'results':rows};(a.output/'REPLAY.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'comparisons':len(rows)}))
