"""Export frozen NeMo/CPU arrays to existing precision core schemas and execute real CLIs."""
import argparse,pathlib,json,hashlib,sys,subprocess,numpy as np
p=argparse.ArgumentParser();p.add_argument('--evidence',required=True);p.add_argument('--skill',required=True);p.add_argument('--output',required=True);a=p.parse_args();e=pathlib.Path(a.evidence).resolve();out=pathlib.Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);skill=pathlib.Path(a.skill).resolve()
def js(path,v):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
case=e/'case';cfg=json.loads((case/'native-config.json').read_text());native=json.loads((case/'native/metadata.json').read_text());ref=json.loads((case/'reference/metadata.json').read_text());trajectory=np.load(case/'trajectory.npz',allow_pickle=False);ids=trajectory['input_ids'];mask=trajectory['token_mask'];positions=[(i,j) for i in range(len(ids)) for j in range(1,ids.shape[1]) if mask[i,j]]
assert native['parameter_names_shapes']==ref['parameter_names_shapes'];assert np.array_equal(np.load(case/'native/before.npy'),np.load(case/'reference/before.npy'))
common={'model':{'architecture':'seeded untied Qwen2 1layer hidden64 vocab64','initial_safetensors_sha256':sha(case/'initial/model.safetensors'),'tokenizer_sha256':sha(case/'initial/tokenizer.json')},'inputs':{'trajectory_npz_sha256':sha(case/'trajectory.npz'),'actions':len(positions),'trajectories':len(ids),'old_reference_scores':'injected captured shared anchors (native rescore+0.05; native rescore-0.03)','advantages':'injected +1/-1 fixed per trajectory; no GRPO group normalization'},'numerics':{'parameter_gradient_dtype':'float32','attention_backend':'sdpa','optimizer':cfg['worker_config']['optimizer'],'global_microbatch_size':[2,2],'max_grad_norm':0.5,'loss':cfg['loss_config'],'mask_reduction':'masked mean with denominator epsilon1e-8'},'scope':'one fixed trajectory clipped policy objective, gradients, postclip gradients, AdamW update and logits','state':{'initial_safetensors_sha256':sha(case/'initial/model.safetensors'),'optimizer':'empty state before first AdamW step'}}
per={'native':{'execution_stack':'Ascend npu:0 physical8, HCCL, official torch_npu.transfer_to_npu, untouched NeMo v0.2.0 worker, torch2.9.0, torch_npu2.9.0.post6, CANN9.1.0'},'reference':{'execution_stack':'clean CPU process, fresh same checkpoint, independent explicit torch objective and AdamW, torch2.9.0'}}
for side,meta in [('native',native),('reference',ref)]:
 js(out/side/'environment.json',{'rank':0,'versions':{'torch':meta['torch'],'transformers':meta['transformers'],'numpy':np.__version__,'source':'26f651ea490ef2a343e7f298b9aa54bc7c5da67c' if side=='native' else 'independent explicit CPU replay'},'actual':{**common,**per[side]},'captured_module_paths':meta['module_paths'],'captured_runtime_metadata':str(pathlib.Path('../../case')/side/'metadata.json')})
 js(out/side/'status.json',{'rank':0,'status':'completed','native_entrypoint':'FSDP1PolicyWorker.generate/get_logprobs/train' if side=='native' else 'fresh AutoModelForCausalLM forward + explicit independent loss.backward/clip_grad_norm_/AdamW.step'})
comparisons=[]
def run(tool,args,log):
 r=subprocess.run([sys.executable,'-B',str(skill/'scripts'/tool),*map(str,args)],capture_output=True,text=True);js(log,{'command':[sys.executable,'-B',tool,*map(str,args)],'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,(tool,r.stdout,r.stderr)
for name,stage,raw in [('gradients','gradients','gradients'),('postclip-gradients','postclip-gradients','postclip_gradients'),('updates','updates','updates'),('loss','observations','loss'),('training-logits','observations','logits')]:
 folder=out/name;folder.mkdir();inventory=[]
 if stage in ['gradients','postclip-gradients','updates']:
  inventory=[{'name':item['name'],'shape':item['shape'],'present':True} for item in native['parameter_names_shapes']]
 elif name=='loss':inventory=[{'name':'actor.clipped_policy_plus_kl_loss','shape':[1],'present':True,'coordinates':{'boundary':'pre-backward full minibatch objective','optimizer_step':0,'group':'both trajectories','invocation':0,'execution_stage':'training'}}]
 else:inventory=[{'name':'actor.logits','shape':[len(positions),64],'present':True,'coordinates':{'boundary':'pre-loss model logits','action_prediction_positions':[[i,j-1] for i,j in positions],'optimizer_step':0,'invocation':0,'execution_stage':'training'}}]
 contract={'schema_version':2,'kind':'tensors','thresholds':None,'common':common,'side_conditions':per,'expected_ranks':{'native':[0],'reference':[0]},'stage':stage,'tensors':inventory};js(folder/'contract.json',contract)
 for side in ['native','reference']:
  entries=[];start=0
  for index,item in enumerate(inventory):
   files={};count=int(np.prod(item['shape']))
   kinds=['before','after'] if stage=='updates' else ['value']
   for key in kinds:
    value=np.load(case/side/((key if stage=='updates' else raw)+'.npy'),allow_pickle=False)
    if name=='training-logits':value=np.stack([value[i,j-1] for i,j in positions])
    elif stage!='observations':value=value[start:start+count].reshape(item['shape'])
    target=out/side/(name+'-'+str(index)+'-'+key+'.npy');np.save(target,np.ascontiguousarray(value),allow_pickle=False);files[key]={'path':str(pathlib.Path('..')/side/target.name)}
   entries.append({**item,'shards':[{'offset':0,**files}]});start+=count
  manifest={'schema_version':2,'kind':'tensors','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':str(pathlib.Path('..')/side/'environment.json'),'status':str(pathlib.Path('..')/side/'status.json')}],'stage':stage,'tensors':entries}
  if stage=='updates':manifest['events']={'actor':'applied'}
  js(folder/(side+'.json'),manifest)
  run('validate_artifacts.py',['--contract',folder/'contract.json','--manifest',folder/(side+'.json'),'--output',folder/(side+'-validation.json')],folder/(side+'-validation-execution.json'))
 run('compare_tensors.py',['--contract',folder/'contract.json','--side-a',folder/'native.json','--side-b',folder/'reference.json','--output',folder/'report.json'],folder/'comparison-execution.json');report=json.loads((folder/'report.json').read_text());comparisons.append({'name':name,'status':report['status'],'global':report['global']})
folder=out/'action-scores';folder.mkdir();targets=[{'sample':'trajectory-'+str(i),'position':j,'token':int(ids[i,j])} for i,j in positions];js(folder/'contract.json',{'schema_version':1,'kind':'target-scores','thresholds':None,'common':common,'side_conditions':per,'expected_ranks':{'native':[0],'reference':[0]},'targets':targets})
for side in ['native','reference']:
 values=np.load(case/side/'action_logprobs.npy',allow_pickle=False);scores=[{**t,'logprob':float(values[i,j-1])} for t,(i,j) in zip(targets,positions)]
 js(folder/(side+'.json'),{'schema_version':1,'kind':'target-scores','common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':str(pathlib.Path('..')/side/'environment.json'),'status':str(pathlib.Path('..')/side/'status.json')}],'scores':scores})
run('compare_target_scores.py',['--contract',folder/'contract.json','--side-a',folder/'native.json','--side-b',folder/'reference.json','--output',folder/'report.json'],folder/'comparison-execution.json');scores=json.loads((folder/'report.json').read_text());comparisons.append({'name':'action-scores','status':scores['status'],'metrics':scores['metrics'],'coverage':scores['coverage']})
sourcehash=cfg['source_files_sha256'];mismatches=[]
for name,digest in sourcehash.items():
 local=e/'source'/name
 if sha(local)!=digest:mismatches.append(name)
assert not mismatches,mismatches
js(out/'SUMMARY.json',{'native_and_independent_reference_completed':True,'canonical_cases':1,'core_comparisons':len(comparisons),'parameter_elements':sum(p['elements'] for p in native['parameter_names_shapes']),'parameter_tensors':len(native['parameter_names_shapes']),'trajectories':len(ids),'actions':len(positions),'optimizer_steps':1,'native_loss':native['loss'],'reference_loss':ref['loss'],'absolute_loss_error':abs(native['loss']-ref['loss']),'source_files_verified':len(sourcehash),'thresholds':None,'comparisons':comparisons});print(json.dumps({'out':str(out),'summary':comparisons},indent=2))
